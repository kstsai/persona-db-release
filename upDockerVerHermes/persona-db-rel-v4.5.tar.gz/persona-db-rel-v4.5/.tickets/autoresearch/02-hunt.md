# Ticket 02 — hunt.py：假設生成 + 掃描主流程

**What to build:** `scripts/contradiction_hunt/hunt.py` — 主流程：
1. 程式列舉維度對（19 取 2）
2. LLM 對每對生成 1-3 個假設（結構化 condition + rationale + severity）→ `hypotheses.json`
3. 對每個假設用 dsl.py 掃描 1069 筆 → `violations.json`

**Blocked by:** 01

**Acceptance criteria:**
- [ ] 維度對列舉完整（SCORED_DIMS 15 維取 2 = 105 對）
- [ ] LLM 假設生成含重試（LLM_ANALYSIS_MODEL 或同 model）
- [ ] 假設 JSON schema 驗證（id/dimensions/condition/rationale/severity）
- [ ] 掃描結果含 persona_ids + 命中維度值 + 總數
- [ ] 可重跑（hypotheses.json 已存在時可 skip LLM 步驟）
