# Ticket 03 — 分類層：LLM 三分類 + 抽驗

**What to build:** `scripts/contradiction_hunt/classify.py` — 對 violations.json 的每筆違反，LLM 判斷 `contradiction`（真矛盾）/ `explainable`（可解釋，附豁免情境）/ `insufficient`（資訊不足）→ `classified.json`。含 10-20% 抽驗輔助輸出。

**Blocked by:** 02

**Acceptance criteria:**
- [ ] 每筆違反有分類 + 理由
- [ ] 分類 prompt 含「可解釋情境」引導（例：fam>1 北漂靠家、0-11 兒童搭爸媽車）
- [ ] 輸出 `classified.json`（persona_id + hypothesis_id + label + reason）
- [ ] 抽驗：隨機 15% 樣本標記 `spot_check: true` 供人工核對
- [ ] 摘要統計（各 label 數量）
