# Ticket 01 — dsl.py：condition 受限 DSL 解析器

**What to build:** `scripts/contradiction_hunt/dsl.py` — 解析 LLM 生成的 condition 字串（白名單 ops：`==`, `!=`, `in`, `AND`, `OR`, 括號），轉成可對 persona dict 執行的 predicate function。

**Blocked by:** None

**Acceptance criteria:**
- [ ] 支援 `dim == '值'`、`dim != '值'`、`dim in ['a','b']`、AND/OR/括號
- [ ] 不支援任意 code execution（白名單 ops，拒絕 eval/import/函數呼叫）
- [ ] 語法錯誤 → 明確 exception + 跳過該假設（不 crash 整個 hunt）
- [ ] 單元測試：正確解析「occupation == '學生' AND income == '>8萬'」
