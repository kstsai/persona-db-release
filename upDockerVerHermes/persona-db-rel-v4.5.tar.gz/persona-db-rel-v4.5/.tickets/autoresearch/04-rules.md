# Ticket 04 — 落地：規則草案 JSON → patch diff 產生器

**What to build:** `scripts/contradiction_hunt/rules.py` — 從 classified.json 的「contradiction + severity=high」生成規則草案 `rules_draft.json`（id/name/condition/fix模板/evidence/status=pending_approval），並產生 `_generate_997.py` 的 patch diff 供人工 review。

**Blocked by:** 03

**Acceptance criteria:**
- [ ] rules_draft.json 含 evidence（違反樣本 persona_ids）
- [ ] fix 用程式模板（重抽低值分布），LLM 不生成 code
- [ ] patch diff 產生器：diff 格式（可 git apply），人 review 後套用
- [ ] 規則名稱命名慣例（如 student_noinc_highinc）
- [ ] 輸出 summary：N 條規則待審批
