# Ticket 05 — 驗證閉環 + 文件 + 首跑（v4.4.3 基準）

**What to build:**
1. 對 v4.4.3 跑完整 hunt → `reports/contradiction-hunt-v4.4.3.md`（基準清單）
2. RFC 加「自動化矛盾偵測」章節（流程 + 三指標）
3. skill Post-Generation Self-Check 加「regen 後跑 hunt 對比」
4. 驗證閉環測試：確認已知矛盾（若希類/R-A/R-B/R-C 的違反者）能被 hunt 抓到

**Blocked by:** 04

**Acceptance criteria:**
- [ ] v4.4.3 基準報告產出（reports/）
- [ ] 已知矛盾 recall：R-A/R-B/R-C 的違反模式在 hunt 結果中出現
- [ ] RFC 章節完成
- [ ] skill 檢查清單更新
- [ ] 三指標定義文件化（Recall/Precision/新發現）
