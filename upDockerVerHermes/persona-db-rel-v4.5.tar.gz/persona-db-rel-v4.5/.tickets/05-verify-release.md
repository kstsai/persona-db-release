# Ticket 05 — 驗證 + Release v4.4

**What to build:**
1. 跑 spec 的 Testing Decisions：確定性 ×5、可稽核性（手算=response）、稀有度（自營排前）、relaxation 打折、test-persona-db-api.sh 回歸
2. Bump VERSION → v4.4 → do-release.sh → tarball 含 `dim_weights.json`

**Blocked by:** 03, 04

**Acceptance criteria:**
- [ ] 確定性測試：同 query ×5，persona_ids 一致
- [ ] 可稽核性：任一 persona 手算 score = response score
- [ ] 稀有度：自營 > 製造 排序正確
- [ ] test-persona-db-api.sh 全 case ok
- [ ] tarball 含 dim_weights.json（tar tzf 驗證）
- [ ] v4.4 tag 兩個 repo 都推
