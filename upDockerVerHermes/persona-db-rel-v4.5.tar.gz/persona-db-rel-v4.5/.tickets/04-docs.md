# Ticket 04 — 文件：RFC Scoring 章節 + generation-verify 權重統計 + skill 檢查清單

**What to build:**
1. `tw-persona-db-rfc.md` 新增「Scoring 演算法」章節（公式 + 權重表範例 + DGBAS 來源 + 限制聲明）
2. Generation Verification Report 新增權重表統計（每維度權重範圍 + 來源對照）
3. `persona-db-release-workflow` skill 的 to-tickets 檢查清單加：新增維度時同步更新 SCORED_DIMS 與權重表

**Blocked by:** 01, 02

**Acceptance criteria:**
- [ ] RFC 有 Scoring 演算法章節（公式、範例、限制）
- [ ] Verification Report 有權重統計 + 來源對照
- [ ] skill 有「新維度 → 同步權重表」檢查項
