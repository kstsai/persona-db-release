# Ticket 02 — 實作 scoring 函數 + API 排序

**What to build:** `api/persona_matcher.py` 新增 `score_persona()` + `load_dim_weights()`；`api/server.py` 在 filter 後依 score 排序再取 top_k。

**Blocked by:** 01

**Acceptance criteria:**
- [ ] `score_persona(persona, filters, relaxed_dims)` 實作（只算被 filter 的維度；hobby list 命中任一即加分；relaxed 維度 ×0.5）
- [ ] `load_dim_weights()` 載入 `dim_weights.json`（與 load_persona_db 同層路徑）
- [ ] matched 依 score 降冪排序，同分保持 DB 順序（穩定排序）
- [ ] `dim_weights.json` 缺失時 graceful degradation（不 crash，回歸無 scoring 排序）
