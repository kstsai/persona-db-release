# Ticket 03 — Response 揭露 applied_filters + scoring_basis + score

**What to build:** `api/models.py` 的 `PersonaSummary` 加 `score` 欄位；`CandidatesResponse` 加 `applied_filters` + `scoring_basis`；`api/server.py` 組裝。

**Blocked by:** 02

**Acceptance criteria:**
- [ ] `PersonaSummary.score: float`（round 2 位）
- [ ] `CandidatesResponse.applied_filters: dict`（實際用於 filter 的 filters，含 relaxation 後）
- [ ] `CandidatesResponse.scoring_basis: dict`（method / weight_source / dims_counted / relaxed_dims_scored_at）
- [ ] relaxed_dims 為空時 scoring_basis 的 relaxed_dims_scored_at 顯示 1.0（未打折）
- [ ] **三層檢查**：models.py + persona_matcher.py + server.py 都改到
