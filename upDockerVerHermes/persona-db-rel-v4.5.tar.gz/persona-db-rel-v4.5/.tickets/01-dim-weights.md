# Ticket 01 — 產生權重表 dim_weights.json

**What to build:** 新 script `scripts/gen_dim_weights.py`（或併入 `_generate_997.py`），讀 `tw_persona_1069.json`，計算 15 個維度的 log 反頻率權重 + 跨維度正規化到 [0.5, 2.0]，輸出 `dim_weights.json`（含 `_meta`：版本/日期/方法/DGBAS 資料源對照）。

**Blocked by:** None — 可立即開始

**Acceptance criteria:**
- [ ] `dim_weights.json` 產出，15 個維度都在（age/sex/region/residence/education/occupation/income/family_income/family_size/marriage/commute_mode/housing_cost/housing_burden/clothing_spend/hobby）
- [ ] `_meta.data_sources` 有 DGBAS/交通部來源對照
- [ ] 權重值在 [0.5, 2.0] 範圍（正規化驗證）
- [ ] 可重現：跑兩次結果一致
