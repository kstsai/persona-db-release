"""
rules.py — Draft coherence rules from classified violations (issue #5, ticket 04).

Input: classified.json (from classify.py), hypotheses.json
Output: rules_draft.json (structured rules with evidence)
        → generates _generate_997.py patch diff for manual review

Usage:
    python3 scripts/contradiction_hunt/rules.py [classified.json] [hypotheses.json]
"""
import json, sys, os, difflib
from pathlib import Path
from collections import defaultdict

BASE = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE))

OUT_DIR = Path(__file__).resolve().parent
RULES_FILE = OUT_DIR / "rules_draft.json"
GENERATOR_FILE = BASE / "_generate_997.py"

FIX_TEMPLATES = {
    "lowfi": {
        "desc": "重抽 family_income 為低值（<1萬 40% / 1-3萬 60%）",
        "code": "fam_inc = wchoice({'<1萬': 0.4, '1-3萬': 0.6})",
        "counter": "fam_lowfi",
    },
    "nocar": {
        "desc": "重抽 commute_mode 為大眾運輸/步行（無車）",
        "code": "commute_mode = wchoice({'機車': 0.3, '捷運/公車': 0.4, '步行/腳踏車': 0.3})",
        "counter": "fam_nocar",
    },
    "lowcs": {
        "desc": "重抽 clothing_spend 為低值（<500 50% / 500~1500 30% / 1500~3000 20%）",
        "code": "clothing_spend = wchoice({'<500': 0.5, '500~1500': 0.3, '1500~3000': 0.2})",
        "counter": "fam_lowcs",
    },
    "reassign_inc": {
        "desc": "重抽 income 為低值（<3萬 70% / 3-8萬 30%）",
        "code": "inc = wchoice({'<3萬': 0.7, '3-8萬': 0.3})",
        "counter": "reassign_inc",
    },
    "edu_bump": {
        "desc": "學歷提升（國中以下→大學 70% / 高中 30%）",
        "code": "edu = wchoice({'大學': 0.7, '高中': 0.3})",
        "counter": "edu_bump",
    },
    "no_wfh_retired": {
        "desc": "退休/家管不應在家工作",
        "code": "commute_mode = wchoice({'捷運/公車': 0.3, '步行/腳踏車': 0.4, '機車': 0.3})",
        "counter": "no_wfh_retired",
    },
    "lowhb_lowcs": {
        "desc": "高負擔+高治裝 → 壓低 clothing_spend",
        "code": "clothing_spend = wchoice({'<500': 0.6, '500~1500': 0.3, '1500~3000': 0.1})",
        "counter": "lowhb_lowcs",
    },
}


def generate_rules(classified_file, hypotheses_file):
    with open(classified_file) as f:
        cdata = json.load(f)
    entries = cdata.get("entries", [])

    with open(hypotheses_file) as f:
        hypotheses = json.load(f)
    hyp_map = {h["id"]: h for h in hypotheses}

    # Group entries by hypothesis_id, only keep contradictions
    groups = defaultdict(list)
    for e in entries:
        if e["label"] == "contradiction":
            groups[e["hypothesis_id"]].append(e["persona_id"])

    rules = []
    for hid, pids in sorted(groups.items(), key=lambda x: -len(x[1])):
        h = hyp_map.get(hid)
        if not h or h.get("severity") != "high":
            continue
        # Suggest a fix template based on condition keywords
        cond = h.get("condition", "")
        dims = h.get("dimensions", [])
        fix_key = "reassign_inc"  # default
        if "housing_burden" in cond and "clothing_spend" in cond:
            fix_key = "lowhb_lowcs"
        elif "education" in cond and "occupation" in cond:
            fix_key = "edu_bump"
        elif "clothing_spend" in cond:
            fix_key = "lowcs"
        elif "commute_mode" in cond and "汽車" in cond:
            fix_key = "nocar"
        elif "family_income" in cond:
            fix_key = "lowfi"
        elif "income" in cond and ">" in cond:
            fix_key = "reassign_inc"
        if "退休" in cond and "在家工作" in cond:
            fix_key = "no_wfh_retired"
        tpl = FIX_TEMPLATES.get(fix_key, FIX_TEMPLATES["reassign_inc"])

        rule = {
            "id": f"R-{len(rules)+1:02d}",
            "hypothesis_id": hid,
            "name": hid.replace("H-", "rule_").replace("-", "_").lower(),
            "condition": cond,
            "dimensions": dims,
            "fix_template": tpl["desc"],
            "fix_counter": tpl["counter"],
            "evidence": pids[:10],  # first 10 as evidence samples
            "total_violations": len(pids),
            "severity": h.get("severity"),
            "rationale": h.get("rationale", ""),
            "status": "pending_approval",
        }
        rules.append(rule)

    with open(RULES_FILE, "w") as f:
        json.dump({"total_rules": len(rules), "rules": rules}, f, ensure_ascii=False, indent=2)
    print(f"✅ {len(rules)} rules → {RULES_FILE}")
    return rules


def generate_patch_diff(rules):
    """Generate a unified diff against _generate_997.py for manual review."""
    original = GENERATOR_FILE.read_text().splitlines(keepends=True)

    # Build new coherence rules to insert
    new_rules = [
        "\n        # ── Autoresearch hunt rules (pending approval) ──\n",
    ]
    for r in rules:
        tpl = FIX_TEMPLATES.get(r.get("fix_counter", "reassign_inc"), FIX_TEMPLATES["reassign_inc"])
        new_rules.append(
            f"        # {r['id']}: {r['rationale']} (severity={r['severity']}, {r['total_violations']} violations)\n"
        )
        new_rules.append(
            f"        if {r['condition']}:\n"
        )
        new_rules.append(
            f"            {tpl['code']}\n"
        )
        new_rules.append(
            f"            coherence_fixes[\"{tpl['counter']}\"] = coherence_fixes.get(\"{tpl['counter']}\", 0) + 1\n"
        )
        new_rules.append("\n")

    rules_text = "".join(new_rules)
    diff = difflib.unified_diff(
        original,
        original,  # unchanged — just show what would be inserted
        str(GENERATOR_FILE),
        str(GENERATOR_FILE),
        lineterm="",
    )

    diff_path = OUT_DIR / "rules_draft.diff"
    with open(diff_path, "w") as f:
        f.write("# RULES DRAFT — review before applying\n")
        f.write("# Generated by scripts/contradiction_hunt/rules.py\n\n")
        f.write("# ── New coherence rules to insert into _generate_997.py ──\n")
        f.write(rules_text)
    print(f"✅ Patch diff → {diff_path}")
    return diff_path


def main():
    cf = sys.argv[1] if len(sys.argv) > 1 else str(OUT_DIR / "classified.json")
    hf = sys.argv[2] if len(sys.argv) > 2 else str(OUT_DIR / "hypotheses.json")
    rules = generate_rules(cf, hf)
    if rules:
        generate_patch_diff(rules)


if __name__ == "__main__":
    main()
