"""
hunt.py — Autonomous contradiction hunt (issue #5, autoresearch pattern).

Flow:
    1. Enumerate dim pairs (SCORED_DIMS 15 choose 2 = 105 pairs)
    2. LLM generates 1-3 hypotheses per pair → hypotheses.json
    3. Scan 1069 personas with dsl.py → violations.json

LLM model: uses LLM_ANALYSIS_MODEL (from api/llm.py) — deepseek-v4-pro
by default, for its superior Chinese language understanding.

Usage:
    python3 scripts/contradiction_hunt/hunt.py [--skip-llm] [data.json]
"""
import json, os, sys, math, asyncio
from collections import Counter
from pathlib import Path

# Project root
BASE = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE))

from scripts.contradiction_hunt.dsl import evaluate
from api.llm import call_llm, LLM_CONFIG

OUT_DIR = Path(__file__).resolve().parent
HYPOTHESES_FILE = OUT_DIR / "hypotheses.json"
VIOLATIONS_FILE = OUT_DIR / "violations.json"

# 15 scored dimensions (from dim_weights.py — align with LLM filter capability)
SCORED_DIMS = [
    "age", "sex", "region", "residence", "education", "occupation",
    "income", "family_income", "family_size", "marriage",
    "commute_mode", "housing_cost", "housing_burden", "clothing_spend",
    "hobby",
]

# 不計分的維度（LLM 幾乎不用它們 filter；文字/政治維度）
EXCLUDED_DIMS = [
    "political_stance", "political_issues", "politics", "media_diet",
    "background_story", "prompt_prefix", "reference_pre_prompt", "hh_income_tier",
    "price_tier",
]

HYPOTHESIS_PROMPT = """你是一個資料品質審核助手，負責檢查台灣人口資料庫（1069 筆人設，19 個維度）中可能存在的**矛盾組合**。

## 任務

針對以下兩個維度的組合：**{dim_a}** 與 **{dim_b}**，請列出 1-3 個「在某些值組合下可能矛盾」的假設。

## 規則

1. `condition` 必須是可執行的條件式（只支援: dim == '值', dim != '值', dim in ['a','b'], AND, OR, 括號）
2. `rationale` 是給人審核用的理由，用繁體中文
3. `severity` 分 high（明顯矛盾）/ medium（可疑）/ low（邊緣案例）
4. 請考慮**合理地可解釋的情境**（例如：學生無收入但家庭有錢 → 不一定矛盾）
5. 若這兩個維度沒有明顯矛盾可能，可以回空陣列 []

## 有效維度值參考

{dim_options}

## 輸出格式（嚴格 JSON）

```json
[
  {{
    "id": "H-<dim_a>-<dim_b>-<N>",
    "dimensions": ["{dim_a}", "{dim_b}"],
    "condition": "...",
    "rationale": "...",
    "severity": "high|medium|low"
  }}
]
```"""


def enumerate_dim_pairs():
    """Enumerate all 2-dim combinations of SCORED_DIMS (105 pairs)."""
    pairs = []
    for i, a in enumerate(SCORED_DIMS):
        for b in SCORED_DIMS[i + 1:]:
            pairs.append((a, b))
    return pairs


def build_dim_options(db):
    """Build a human-readable summary of valid values per dimension."""
    lines = []
    for dim in SCORED_DIMS:
        c = Counter()
        for p in db:
            v = p.get("dimensions", {}).get(dim)
            if isinstance(v, list):
                for x in v:
                    c[x] += 1
            elif v:
                c[v] += 1
        top_vals = [v for v, _ in c.most_common(15)]
        lines.append(f"- {dim}: {', '.join(top_vals)}")
    return "\n".join(lines)


async def generate_hypotheses(db, skip_llm=False):
    """Generate hypotheses for all dim pairs, return list of hypothesis dicts."""
    pairs = enumerate_dim_pairs()
    print(f"📋 {len(pairs)} dimension pairs to check")
    dim_options = build_dim_options(db)

    if skip_llm and HYPOTHESES_FILE.exists():
        with open(HYPOTHESES_FILE) as f:
            hypotheses = json.load(f)
        print(f"📂 Loaded {len(hypotheses)} hypotheses from {HYPOTHESES_FILE} (--skip-llm)")
        return hypotheses

    all_hypotheses = []
    for i, (dim_a, dim_b) in enumerate(pairs):
        prompt = HYPOTHESIS_PROMPT.format(dim_a=dim_a, dim_b=dim_b, dim_options=dim_options)
        try:
            analysis_model = LLM_CONFIG.get("analysis_model") or LLM_CONFIG["model"]
            resp = await call_llm(prompt, temperature=0.3, max_tokens=600, model_override=analysis_model)
            if not resp:
                continue
            # Extract JSON
            resp = resp.strip()
            if "```json" in resp:
                resp = resp.split("```json")[1].split("```")[0].strip()
            elif "```" in resp:
                resp = resp.split("```")[1].split("```")[0].strip()
            batch = json.loads(resp)
            if isinstance(batch, list):
                all_hypotheses.extend(batch)
        except Exception as e:
            print(f"  ⚠️  {dim_a}-{dim_b}: {e}")
        if (i + 1) % 20 == 0:
            print(f"  ... {i+1}/{len(pairs)} pairs done, {len(all_hypotheses)} hypotheses so far")

    with open(HYPOTHESES_FILE, "w") as f:
        json.dump(all_hypotheses, f, ensure_ascii=False, indent=2)
    print(f"✅ {len(all_hypotheses)} hypotheses → {HYPOTHESES_FILE}")
    return all_hypotheses


def scan_violations(db, hypotheses):
    """Scan DB for each hypothesis. Return {hypothesis_id: [persona_ids]}."""
    violations = {}
    for h in hypotheses:
        try:
            matches = []
            for p in db:
                dims = p.get("dimensions", {})
                if evaluate(h["condition"], dims):
                    matches.append(p["id"])
            if matches:
                violations[h["id"]] = matches
        except Exception as e:
            print(f"  ⚠️  {h['id']}: {e}")
    print(f"🔍 {len(violations)} hypotheses have violations (out of {len(hypotheses)})")
    return violations


def main():
    db_path = sys.argv[1] if len(sys.argv) > 1 else str(BASE / "tw_persona_1069.json")
    skip_llm = "--skip-llm" in sys.argv

    with open(db_path) as f:
        db = json.load(f)
    print(f"📦 Loaded {len(db)} personas from {db_path}")

    # Step 1: Generate hypotheses
    hypotheses = asyncio.run(generate_hypotheses(db, skip_llm=skip_llm))

    # Step 2: Scan
    violations = scan_violations(db, hypotheses)

    # Output
    out = {
        "data_version": db_path,
        "total_hypotheses": len(hypotheses),
        "hypotheses_with_violations": len(violations),
        "violations": {hid: sorted(pids) for hid, pids in violations.items()},
    }
    with open(VIOLATIONS_FILE, "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"✅ Violations → {VIOLATIONS_FILE}")

    # Quick summary
    if violations:
        top = sorted(violations.items(), key=lambda x: len(x[1]), reverse=True)[:10]
        print("\n📊 Top 10 hypotheses by violation count:")
        for hid, pids in top:
            h = next(h for h in hypotheses if h["id"] == hid)
            print(f"  {h['severity']:6s} | {len(pids):3d} violations | {h['condition']}")


if __name__ == "__main__":
    main()
