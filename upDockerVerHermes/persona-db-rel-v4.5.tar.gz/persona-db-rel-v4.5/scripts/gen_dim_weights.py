#!/usr/bin/env python3
"""
gen_dim_weights.py — 產生維度權重表 dim_weights.json

依據 tw_persona_1069.json 計算 15 個維度的 log 反頻率權重，
並跨維度正規化到 [0.5, 2.0]。

公式:
    raw_weight(dim, value) = log(total / count(dim, value))
    normalized = 0.5 + 1.5 * (raw - raw_min) / (raw_max - raw_min)

產出:
    dim_weights.json — 含 _meta (版本/方法/DGBAS 資料源對照)

用法:
    python3 scripts/gen_dim_weights.py [data.json] [output.json]
"""
import json, math, sys, os
from collections import Counter

# 對齊 LLM filter 能力的 15 個維度（spec D1）
SCORED_DIMS = [
    "age", "sex", "region", "residence", "education", "occupation",
    "income", "family_income", "family_size", "marriage",
    "commute_mode", "housing_cost", "housing_burden", "clothing_spend",
    "hobby",
]

# DGBAS / 官方資料源對照（spec D1）
DATA_SOURCES = {
    "age/sex/region": "內政部戶政司 113年人口統計",
    "residence": "內政部戶政司 113年 各縣市人口分布",
    "education/occupation": "DGBAS 113年 人力資源調查",
    "income/family_income": "DGBAS 113年 家庭收支調查（可支配所得）",
    "housing_cost/housing_burden": "DGBAS 113年 家庭收支調查（居住支出）",
    "clothing_spend": "DGBAS 113年 家庭收支調查（衣著鞋襪消費支出）",
    "commute_mode": "交通部 2024 運具分配調查",
    "marriage/family_size": "內政部戶政司 113年 戶口統計",
    "hobby": "民間生活型態調查（合成）",
}

def main():
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(base, "tw_persona_1069.json")
    out_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(base, "dim_weights.json")

    with open(data_path) as f:
        db = json.load(f)
    total = len(db)

    # 1. 計算每個維度值的 raw log 權重
    weights = {}
    for dim in SCORED_DIMS:
        counts = Counter()
        for p in db:
            v = p.get("dimensions", {}).get(dim)
            if isinstance(v, list):
                for x in v:
                    counts[x] += 1
            elif v:
                counts[v] += 1
        if not counts:
            continue
        raws = {v: math.log(total / n) for v, n in counts.items()}
        # 2. 跨維度正規化
        #    - 值數 ≥4: 正規化到 [0.5, 2.0]（保留稀有度分辨力）
        #    - 值數 ≤3: 溫和壓縮到 [0.8, 1.4] — 值少的維度（如 sex 2 值）log 差異
        #      極小，強制拉到 [0.5,2.0] 會失真（男/女幾乎各半卻變 0.5/2.0 兩極）
        if len(raws) <= 3:
            lo, hi = 0.8, 1.4
        else:
            lo, hi = 0.5, 2.0
        wmax, wmin = max(raws.values()), min(raws.values())
        if wmax == wmin:
            norm = {v: (lo + hi) / 2 for v in raws}
        else:
            norm = {v: lo + (hi - lo) * (r - wmin) / (wmax - wmin) for v, r in raws.items()}
        weights[dim] = {v: round(w, 4) for v, w in sorted(norm.items(), key=lambda x: -x[1])}

    # 3. 讀 VERSION
    version = "unknown"
    ver_path = os.path.join(base, "VERSION")
    if os.path.exists(ver_path):
        version = open(ver_path).read().strip()

    out = {
        "_meta": {
            "version": version,
            "generated": "2026-08-05",
            "total": total,
            "method": "log(total/count) + cross-dim normalize to [0.5, 2.0]",
            "scored_dims": list(weights.keys()),
            "data_sources": DATA_SOURCES,
        },
        **weights,
    }

    with open(out_path, "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"✅ dim_weights.json generated: {out_path}")
    print(f"   version={version} | total={total} | dims={len(weights)}")
    for dim, ws in weights.items():
        vals = list(ws.items())
        print(f"   {dim:16s} {len(vals):2d} values | top: {vals[0][0]}={vals[0][1]} | bot: {vals[-1][0]}={vals[-1][1]}")

if __name__ == "__main__":
    main()
