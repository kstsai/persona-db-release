# Contradiction Hunt Report — v4.5 (Recall vs v4.4.3 Baseline)

> 日期: 2026-08-10 | 工具: scripts/contradiction_hunt/
> 對比基準: v4.4.3 (首跑, 70 hypotheses)

## Recall 驗證（4 條修過的矛盾）— ✅ ALL ZERO RESIDUAL

| 規則 | 舊版 violations | 新版 residual |
|:----|:-------------:|:-----------:|
| R-D hb高+cs>5000 | 3 fixes | **0** |
| R-E 國中以下+醫療 | 1 residual | **0** |
| R-F fi低+hc高 | 2 fixes | **0** |
| R-G 離島+>8萬 | 1 fix | **0** |

## 對比摘要

- 首跑: 34 hypotheses with violations → 再跑: 29
- 消失: 5 hypotheses（規則生效）
- **新浮現: 無**（本次 regen 僅加規則，無新增矛盾）

## Precision

- 首跑分類: 5 contradictions / 329 total (1.5%)
- 再跑分類: 對新版重跑 classify → (待跑 classify.py)

