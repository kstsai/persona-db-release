# Spec: Regen-time Weight Table + Query-time Relevance Scoring

> 日期: 2026-08-05 | 來源: grill-me 收斂（Q1-Q7）| 對應 issue: #4

## Problem Statement

`/personadb/candidates` 的 `persona_ids` 目前是 `matched[:top_k]` — 直接取 DB 檔案順序的前 N 筆，**沒有 relevance ranking**。使用者無法知道「為什麼是這幾筆」，且 top_k 可能漏掉「其實最符合但排在檔案後段」的 persona。`important_dimensions` 常被誤解為 filter 條件（其實是結果統計），response 也未揭露實際使用的 filters。

## Solution

兩階段：

1. **Regen 時產生權重表 `dim_weights.json`** — 每個維度每個值的稀有度權重（log 反頻率 + 跨維度正規化），含 DGBAS 資料源對照，隨 tarball 部署。
2. **Query 時 relevance scoring** — 對 matched personas 依「命中 filter 維度的權重總和」排序，取 top_k。Response 揭露 `score`、`applied_filters`、`scoring_basis`。

## User Stories

1. 作為市場研究員，我查「時尚服裝設計師的目標客戶」時，希望 top 3 是「最像目標客戶」的人，而不是檔案順序前 3 個。
2. 作為 kstsai，我希望知道每個回傳 persona 的 score 是怎麼算的，能自己驗算（可稽核性）。
3. 作為 kstsai，我希望權重表有 DGBAS 來源對照，跟 RFC 的其他維度一樣可信。
4. 作為 API 使用者，我希望 response 揭露實際使用的 filters（`applied_filters`），不再靠猜 `important_dimensions`。
5. 作為開發者，我希望 relaxation（#3）介入時，被丟掉的維度仍以打折方式計分，保留原始意圖。
6. 作為 QA，我希望同一個 query 連續呼叫結果一致（確定性），方便驗證。

## Implementation Decisions

### D1. 權重表格式（regen 產物）

`dim_weights.json` 放 persona-db root，進 tarball（與 `tw_persona_1069.json` 同層）：

```json
{
  "_meta": {
    "version": "v4.4",
    "generated": "2026-08-05",
    "total": 1069,
    "method": "log(1069/count) + cross-dim normalize to [0.5, 2.0]",
    "data_sources": {
      "age/sex/region": "內政部戶政司 113年人口統計",
      "occupation/income/family_income/housing/clothing": "DGBAS 113年 家庭收支調查 / 人力資源調查",
      "commute_mode": "交通部 2024 運具分配調查"
    }
  },
  "occupation": { "製造": 1.37, "自營": 4.78, ... },
  "clothing_spend": { "<500": 1.07, ">5000": 1.92, ... },
  ...
}
```

覆蓋 15 個維度（對齊 LLM filter 能力）：
`age, sex, region, residence, education, occupation, income, family_income, family_size, marriage, commute_mode, housing_cost, housing_burden, clothing_spend, hobby`

不計分：`political_stance, political_issues, politics, media_diet, background_story, prompt_prefix`（LLM 幾乎不用它們 filter；文字欄位無法計分）。

### D2. Scoring 函數（query 時）

```python
def score_persona(persona, filters, relaxed_dims):
    s = 0.0
    for dim, accepted in filters.items():
        v = persona.dimensions.get(dim)
        if dim == "hobby" and isinstance(v, list):
            hit = any(x in accepted for x in v)   # 命中任一即加分
        else:
            hit = v in accepted
        if hit and dim in dim_weights:
            w = dim_weights[dim].get(v, 0)
            if dim in relaxed_dims:               # #3 relaxation 丟掉的 → 打折
                w *= 0.5
            s += w
    return s
```

- 只算「LLM filter 有出現的維度」（Q2b-B）
- 被 relaxation 丟掉的維度**不計分**（Q3-A' 修正：relaxation 丟維度是因為 matched 無人命中該維度，計分恆為 0，故不計）— 但 `relaxed_dims` 照樣回傳揭露
- 同分 → DB 順序（Q7-A，確定性）

### D3. Response 變更

- `PersonaSummary` 新增 `score: float`（round 2 位）
- Response 新增 `applied_filters: dict`（實際用於 filter_personas 的 filters，含 relaxation 後）
- Response 新增 `scoring_basis: dict`：
  ```json
  {
    "method": "log-frequency × cross-dim normalized",
    "weight_source": "DGBAS 113年 家庭收支調查 / 人力資源調查 / 交通部 2024",
    "dims_counted": ["age", "clothing_spend", "commute_mode"],
    "relaxed_dims_scored_at": null
  }
  ```
  （relaxed dims 不計分 — Q3-A'；`relaxed_dims_scored_at: null` 標示無打折機制）
- 排序：`matched.sort(key=score, reverse=True)` 後取 top_k

### D4. 文件

- RFC 新增「Scoring 演算法」章節（公式 + 權重表範例 + 資料源對照 + 限制：靜態稀有度非語意）
- Generation Verification Report 新增權重表統計（每維度權重範圍 + 來源對照）
- `persona-db-release-workflow` skill 的 to-tickets 檢查清單加一條：**新增維度時同步更新 SCORED_DIMS 與權重表**

## Testing Decisions

1. **確定性測試**：同 query 連續 5 次（LLM 非確定性，但 scoring 是確定性的）— score 排序一致、`persona_ids` 一致
2. **可稽核性測試**：對任一 persona，用 `dim_weights.json` 手算 score 應等於 response 的 `score`
3. **稀有度測試**：`自營`（9人）命中的 persona 應排在使用 `製造`（273人）命中的 persona 前面
4. **Relaxation 測試**：人工構造 0 交集 filter → 確認 relaxed_dims 揭露、relaxed 維度不計分（score 只含有效維度）
5. **回歸測試**：`test-persona-db-api.sh` 全部 case 仍回 status ok

## Out of Scope

- LLM 語意打分（方案 B/C 的 Stage 3）— 靜態稀有度權重先上，語意排名留待後續評估
- Typicality score（Q7-C）— 同分決勝先用 DB 順序
- `background_story` / `prompt_prefix` 文字相似度計分
- 權重表的即時更新（每次 regen 才重建）

## Further Notes

- 權重表是**資料的衍生產物** — 與 `tw_persona_1069.json` 綁定，regen 時一起產出、一起進 tarball
- 限制（寫入 RFC）：權重反映「靜態稀有度」，不反映「語意相關性」— 花蓮高消費 vs 台北時尚圈分數可能相同；真正的語意理解需要 LLM 打分（未來工作）
