# Spec: 自動化矛盾人設偵測（Autoresearch Contradiction Hunt）

> 日期: 2026-08-05 | 來源: grill-me 收斂（Q1-Q4）+ issue #5
> 參考: github.com/karpathy/autoresearch — LLM 假設 + 程式驗證閉環

## Problem Statement

v4.4.3 的 Coherence Rules R-A/R-B/R-C 源自**人工發現**（若希 TW-P-0177 在 API 實測時肉眼看到）。現有 QA 23 rules 只能抓「已知要檢查什麼」的矛盾，**未知維度組合靠運氣**。需要一個自動化系統：LLM 提出矛盾假設 → 程式掃描 1069 筆 → 分類驗證 → 寫成 coherence rule → regen 後驗證規則生效。

## Solution

**Autonomous Contradiction Hunt** — autoresearch pattern 的閉環：

```
① 假設生成（Hybrid）
   程式列舉維度對（19取2 = 171 對）
   → LLM 對每對生成具體矛盾假設（結構化 condition + NL rationale + severity）
   ↓
② 程式掃描
   對每個假設掃描 1069 筆 → 違反清單（persona_ids + 命中維度值）
   ↓
③ LLM 逐筆三分類
   真矛盾 / 可解釋（有豁免情境）/ 資訊不足（每個都給理由）
   ↓
④ 人工精審（只碰高信心真矛盾）
   篩出 severity=high + 判「真矛盾」的小集合（通常幾十筆）
   → kstsai 確認 → 寫成 coherence rule
   ↓
⑤ 落地
   規則草案 JSON → 產生 _generate_997.py patch diff → 人 review → 套用
   → regen → QA → 驗證
   ↓
⑥ 再跑一次對比（驗證步驟）
   對新版 tw_persona_1069.json 再跑 hunt
   → 對比清單（Recall / Precision / 新發現）
```

## User Stories

1. 作為 kstsai，我希望系統能自動發現「我沒寫過規則」的矛盾組合，而不是靠 API 實測時肉眼看到（若希案例）。
2. 作為 kstsai，我希望每個假設都有結構化 condition（可執行）+ 自然語言 rationale（可審核）。
3. 作為 kstsai，我希望 LLM 逐筆分類違反（真矛盾/可解釋/資訊不足），我只審核「高信心真矛盾」的小集合。
4. 作為開發者，我希望規則以 JSON 草案產出（含證據），審批後產生 patch diff 給我 review，不直接改 code。
5. 作為 QA，我希望 regen 後再跑一次 hunt，用 Recall（舊矛盾消失）/ Precision（假陽性下降）/ 新發現三個指標驗證規則生效。
6. 作為開發者，我希望歷史 hunt 報告留存（reports/），讓「再跑一次」有對比基準。

## Implementation Decisions

### D1. 假設格式（Q2-B/C 收斂）

LLM 對每個維度對生成結構化假設：

```json
{
  "id": "H-001",
  "dimensions": ["occupation", "income"],
  "condition": "occupation == '學生' AND income == '>8萬'",
  "rationale": "學生（尤其19-24）不太可能有 >8萬 收入",
  "severity": "high"
}
```

- `condition` 用**受限 DSL**（`dim == '值'` + AND/OR + 括號），不用完整 eval — 安全、可稽核
- 每個維度對生成 1-3 個假設，LLM 自行判斷哪些組合可疑

### D2. 掃描與分類（Q3-C 收斂）

```
掃描: 對每個假設跑 condition → 違反 persona 清單
  → LLM 逐筆三分類:
      "contradiction"  真矛盾（附理由）
      "explainable"    可解釋（附豁免情境，例: fam>1 北漂靠家）
      "insufficient"   資訊不足（缺維度無法判斷）
  → 篩出 contradiction + severity=high → 人工精審
  → 人工抽驗 LLM 分類準確率（10-20% 樣本）
```

### D3. 規則落地（Q4-B 收斂）

```json
{
  "rules": [
    {
      "id": "R-D",
      "name": "student_noinc_highinc",
      "condition": "occ=='學生' AND inc=='無收入' AND age=='19-24'",
      "fix": "程式模板 — 重抽 income 為低值分布",
      "evidence": ["TW-P-0144 阿豪 ...", "TW-P-1016 添財 ..."],
      "status": "pending_approval"
    }
  ]
}
```

- `fix` 用**程式模板**（如「重抽 X 維度為低值分布」），不讓 LLM 生成 code — 安全
- 審批 → 產生 `_generate_997.py` patch diff → 人 review → 套用
- 規則同時記錄到 RFC Coherence Rules 表格

### D4. 驗證閉環（再跑一次對比）

regen 後對新版再跑 hunt，對比三指標：

| 指標 | 定義 | 目標 |
|:----|:-----|:-----|
| **Recall** | 上次的矛盾在新版是否消失 | 0 殘留 |
| **Precision** | 新清單「真矛盾」比例 | 上升（規則 filter 掉假陽性） |
| **新發現** | 新浮現的組合 | 存在（證明自動化 > 肉眼） |

- 歷史報告存 `reports/contradiction-hunt-<version>.md`
- 對比基準 = 上次報告的清單

### D5. 檔案結構

```
scripts/contradiction_hunt/
├── hunt.py              # 主流程（假設→掃描→分類→報告）
├── dsl.py               # condition 受限 DSL 解析器
├── hypotheses.json      # LLM 生成的假設（可重跑）
├── violations.json      # 掃描結果
├── classified.json      # LLM 三分類結果
└── rules_draft.json     # 待審批規則草案
reports/contradiction-hunt-v4.4.3.md   # 歷史報告
```

### D6. 文件

- RFC 加「自動化矛盾偵測」章節（流程 + 三指標定義）
- 每次 hunt 產報告（reports/）
- `persona-db-release-workflow` skill 的 Post-Generation Self-Check 加「regen 後跑 hunt 對比」

## Testing Decisions

1. **DSL 正確性**：假設的 condition 能正確掃描（對照已知 R-A/R-B/R-C 的違反者應被抓到）
2. **分類準確率**：抽驗 10-20% 樣本，LLM 三分類與人工判斷一致率 ≥ 90%
3. **Recall 驗證**：v4.4.3 的已知矛盾（若希類）在 v4.5 中消失
4. **Precision 驗證**：新清單中「真矛盾」比例 vs 基準清單
5. **安全**：condition DSL 不支援任意 code execution（白名單 ops）
6. **回歸**：現有 QA 23 rules 仍 ALL PASS

## Out of Scope

- 自動套用規則（不經人 review）— 永遠人工審批 patch diff
- 跨版本自動排程 hunt — 目前手動觸發
- 用 LLM 生成 fix code — fix 一律程式模板
- 對 background_story / prompt_prefix 文字矛盾偵測 — 僅維度值組合

## Further Notes

- 這是 issue #5 的完整設計 — 與現有 `coherence_fixes` dict + `_generate_997.py` 驗證區塊天然契合
- 現有半自動工具可作驗證層：persona_contradiction_check.py / persona_review_deep.py / qa_validate.py
- 甲方參考資料：karpathy/autoresearch（LLM 假設+程式驗證閉環）
