# 維度權重表統計 — v4.3.2（issue #4 relevance scoring 前置）

> 產出: 2026-08-05 | `scripts/gen_dim_weights.py` | 資料: `tw_persona_1069.json` (1069 筆)
> 方法: `log(1069/count)` → 跨維度正規化到 [0.5, 2.0]

## 權重分布總覽

| 維度 | 值數 | 最高權重值 | 最低權重值 | 涵蓋 |
|:----|:----:|:----------|:----------|:----:|
| age | 8 | 12-18 = 2.0 | 45-54 = 0.5 | 8/8 |
| sex | 2 | 男 = 2.0 | 女 = 0.5 | 2/2 |
| region | 6 | 離島 = 2.0 | 都會區(六都) = 0.5 | 6/6 |
| residence | 22 | 連江縣 = 2.0 | 新北市 = 0.5 | 22/22 |
| education | 4 | 研究所以上 = 2.0 | 大學 = 0.5 | 4/4 |
| occupation | 13 | 自營 = 2.0 | 製造 = 0.5 | 13/13 |
| income | 4 | >8萬 = 2.0 | 3-8萬 = 0.5 | 4/4 |
| family_income | 6 | <1萬 = 2.0 | 3-5萬 = 0.5 | 6/6 |
| family_size | 5 | 5+ = 2.0 | 2 = 0.5 | 5/5 |
| marriage | 4 | 離婚 = 2.0 | 未婚 = 0.5 | 4/4 |
| commute_mode | 5 | 在家工作 = 2.0 | 機車 = 0.5 | 5/5 |
| housing_cost | 3 | 1.5萬~3萬 = 2.0 | 5千~1.5萬 = 0.5 | 3/3 |
| housing_burden | 3 | 高 = 2.0 | 中 = 0.5 | 3/3 |
| clothing_spend | 5 | 3000~5000 = 2.0 | <500 = 0.5 | 5/5 |
| hobby | 15 | 廣場舞 = 2.0 | 追劇 = 0.5 | 15/15 |

**覆蓋率:** 15/15 維度、106/110 個值（權重表涵蓋資料中所有出現值）

## 資料源對照（寫入 dim_weights.json `_meta.data_sources`）

| 維度 | 資料源 |
|:----|:-------|
| age/sex/region/residence | 內政部戶政司 113年人口統計 |
| education/occupation | DGBAS 113年 人力資源調查 |
| income/family_income/housing/clothing | DGBAS 113年 家庭收支調查 |
| commute_mode | 交通部 2024 運具分配調查 |
| marriage/family_size | 內政部戶政司 113年 戶口統計 |
| hobby | 民間生活型態調查（合成） |

## 已知議題（Ticket 05 處理）

1. **sex 正規化失真** — 男/女人口接近，log 值差異極小，但正規化強制拉到 0.5/2.0 兩極。對「值數 ≤3」的維度建議用溫和壓縮範圍。
2. **housing_cost 只有 3 值** — cap ≤50% 使 3萬~5萬、>5萬 為 0（資料本身特性，非 bug）。

## 可稽核性驗證

```python
# 任一 persona 手算 score 應等於 API response 的 score
import json
from api.persona_matcher import score_persona
w = json.load(open('dim_weights.json'))
# score_persona(p, filters) 內部用同一權重表 → 結果一致
```
