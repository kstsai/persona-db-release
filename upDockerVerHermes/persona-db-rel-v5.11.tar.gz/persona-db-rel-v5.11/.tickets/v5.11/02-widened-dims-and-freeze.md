# T02 — 值集放寬留痕 + 受保護維度雙向凍結（#63）

> Spec: `specs/2026-09-15-v5.11-empty-list-and-widened-dims.md` | 檔案: `api/server.py`、`api/models.py`

## 變更

1. **留痕**：`BroadeningAttempt` 新增 `widened_dims: list[str] = []`；放寬迴圈計算「新值集為舊值集**嚴格超集**」的維度並寫入該筆 attempt；`_constraint_hint` 與相關 log 可一併揭露
2. **雙向凍結**：`_vetoed_dims()` 對受保護維度改為「**值集必須完全相同**」（移除／縮小／放寬皆違規）；非受保護維度不受此限
3. RFC：veto 條件由「移除或縮小」→「**任何變更**（受保護維度）」；新增 `widened_dims` 欄位說明

## Acceptance criteria

- [ ] 單元：非受保護維度值集放寬（`['中']` → `['中','高']`）→ attempt 記 `widened_dims=['該維度']`、**不**進 `relaxed_dims`
- [ ] 單元：受保護維度值集放寬 → **veto**（`protected_veto: true` + `vetoed_dims` 含該維度）
- [ ] 單元：受保護維度**值集完全相同** → 不 veto（合法不變更）
- [ ] 單元：非受保護維度移除 → 仍不 veto（既有行為）
- [ ] 不變式：`protected_dims ∩ relaxed_dims = ∅` 仍成立
- [ ] 既有 v5.9 測試的「純新增值→不 veto」更新為「非受保護維度不 veto／受保護維度 veto」
- [ ] 真 LLM e2e：TESLA（`commute_mode` 不被放寬值集）、醫美（`sex` 值集）
