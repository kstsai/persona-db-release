> 來源: linkEazyCenter wiki `concepts/persona-db/relevance-scoring.md`（created 2026-08-05）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Relevance Scoring（相關性排序）

`/personadb/candidates` 的 `persona_ids` 依相關性分數排序，不再只是 DB 檔案順序（issue #4）。

## 公式

```
score(persona) = Σ [ weight(dim, persona.value)  for dim in filters ]
weight = log(1069 / count(dim, value)) → 跨維度正規化 [0.5, 2.0]
```

- ≤3 值維度（sex/marriage/housing_burden）用溫和壓縮 [0.8, 1.4]
- 只算「LLM filter 有出現的維度」
- hobby（list）命中任一 filter 值即加分，取最大權重
- relaxed 維度不計分
- 同分 → DB 順序（確定性）

## Response 揭露

```json
{
  "summary": [{ "score": 2.77 }],
  "returned": 1,
  "pool_exhausted": true,
  "applied_filters": { "occupation": ["自營"] },
  "scoring_basis": { "method": "...", "weight_version": "v5.4", "score_scale": "relative-within-version", "score_schema": 1, "dims_counted": [...] }
}
```

## 回應契約（呼叫端必讀，v5.4 #43 / #44；v5.7 #53 補維度完備性）

| 欄位 | 語意 | 注意 |
|:----|:----|:----|
| `returned` | 實際回傳筆數 = `len(summary)` | **可小於 `top_k`**（= `min(top_k, total_matched)`） |
| `pool_exhausted` | `total_matched < top_k` | 系統拒絕為湊數而放寬核心維度；呼叫端不可假設固定回傳數 |
| `scoring_basis.weight_version` | 權重表版本（= 資料版號） | 用來偵測**分數尺度換版** |
| `scoring_basis.score_scale` | `"relative-within-version"` | **`score` 不可跨版本比較**；絕對門檻需重新校準 |
| `summary[].sex/region/education/marriage/hobby/politics/media_diet` | 可篩維度（v5.7 補齊） | **凡可篩即可見**（`valid_dims ⊆ summary`，由 `check_response_schema.py` 守門）；`hobby` 為 `list[str]` |
| `broadening_stop_reason` | 放寬停止原因（v5.8 #56；v5.9 新增 `protected_veto`） | `target_reached` / `no_op_limit` / `loop_limit` / `budget_limit` / `protected_veto` / `llm_*` / `no_filters`。`loop_limit` + `total_matched < top_k` ⇒ 池子真的小；`protected_veto` ⇒ 放寬被核心維度擋下（不該再放寬） |
| `protected_dims` | 受保護的核心維度（v5.9 #57；v5.10 補 protect-only 來源） | 五來源（domain 語意／分析必要性宣告／分析 `core_dims`／模型自我宣告／protect-only 語意表）；**雙向凍結**（v5.11 #63(b) 起：不可移除、不可縮小、**不可放寬值集**）—— v5.4 #43「拒絕為湊數放寬核心維度」的機制化 |
| `broadening_attempts[].widened_dims` | 該輪**值集被放寬**的維度（v5.11 #63(a)） | 稽核用；**不併入 `relaxed_dims`**（後者只收「維度被移除」）。`[]` 代表該輪沒有值集放寬 |
| `applied_filters` | 實際套用的篩選條件 | **值清單保證非空**（v5.11 #62 起：空清單在套用前被正規化掉；底層「空清單＝排除全部」的語意不再可被觸發） |

**維度三集合**：可篩（`valid_dims` 20）⊇ 計分（`SCORED_DIMS` 18）；`politics`/`media_diet` 可篩可見但**不計分**。完整維度（含未公開欄位）只由 `/personadb/detail` 提供。

實例：醫美 query 同時硬篩 `sex=女` ＋ `aesthetic_procedure=有` → 全庫僅 5 人 → `total_matched=5`、`returned=5`、`pool_exhausted=true`（`top_k=10`）。這是**正確且誠實**的行為，不是錯誤。

### 錯誤契約（v5.5 統一）

所有錯誤碼（400/404/422/500/503）回 `{"status":"error","error":{"code","message","details"}}`；
瞬時失敗帶 `retryable: true`。**不要解析 FastAPI 的 `detail`**（v5.5 起不再使用）。

## 限制

- 靜態稀有度 ≠ 語意相關性（花蓮高消費 vs 台北時尚圈可能同分）
- 真正的語意排名需 LLM 打分（未來工作）
- **分數尺度隨資料版本變動**（v4.9.2 ≈ 5.91 → v5.2 ≈ 5.42 → v5.3.1 ≈ 4.36）→ 跨版本不可比

## 關聯

- Persona DB — 所在 API
- Dim Weights — 權重表
- v4.4 週報
