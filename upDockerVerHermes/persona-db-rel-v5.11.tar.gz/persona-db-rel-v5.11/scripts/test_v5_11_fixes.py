#!/usr/bin/env python3
"""v5.11 regression tests — #62（空值清單正規化）、#63（值集放寬留痕 + 受保護維度雙向凍結）、
#64（顧客語意題的 core_dims）。

決定性、無外部 LLM 呼叫。

Run:  python3 scripts/test_v5_11_fixes.py
"""
import sys, os, json, asyncio, logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


print("=== #62 空值清單正規化 ===")
from api.server import _normalize_filters, _widened_dims, _vetoed_dims
check("空值清單維度被丟棄", _normalize_filters({"age": [], "income": [">8萬"]}) == {"income": [">8萬"]},
      _normalize_filters({"age": [], "income": [">8萬"]}))
check("純量值不受影響", _normalize_filters({"x": "v", "y": 3}) == {"x": "v", "y": 3})
check("全部空清單 → 空 dict", _normalize_filters({"a": [], "b": []}) == {})
check("非 dict 輸入 → 空 dict（不炸）", _normalize_filters(None) == {} and _normalize_filters("x") == {})
check("有值的清單保留（不誤刪）", _normalize_filters({"age": ["0-11"]}) == {"age": ["0-11"]})

# 底層語意確認：空清單＝排除全部（正規化就是為了不讓它發生）
from api.persona_matcher import filter_personas, load_persona_db
db = load_persona_db()
_n_empty = len(filter_personas(db, {"age": [], "income": [">8萬"]}))
_n_unset = len(filter_personas(db, {"income": [">8萬"]}))
check(f"底層語意不變：age=[] 排除全部（{_n_empty}）≠ 未指定（{_n_unset}）", _n_empty == 0 and _n_unset > 0,
      (_n_empty, _n_unset))

print("\n=== #63(a) 值集放寬留痕 ===")
check("嚴格超集 → 記入 widened",
      _widened_dims({"sex": ["女"]}, {"sex": ["女", "男"], "age": ["25-34"]}) == ["sex"])
check("值集不變 → 不記", _widened_dims({"sex": ["女"]}, {"sex": ["女"]}) == [])
check("值集縮小 → 不記（那是縮小，不是放寬）", _widened_dims({"sex": ["女", "男"]}, {"sex": ["女"]}) == [])
check("維度被移除 → 不記（由 relaxed_dims 收）", _widened_dims({"sex": ["女"]}, {"age": ["25-34"]}) == [])

print("\n=== #63(b) 受保護維度雙向凍結 ===")
prev = {"sex": ["女"], "age": ["25-34"]}
check("放寬值集 → veto", _vetoed_dims({"sex"}, prev, {"sex": ["女", "男"], "age": ["25-34"]}) == ["sex"])
check("縮小值集 → veto", _vetoed_dims({"sex"}, {"sex": ["女", "男"]}, prev) == ["sex"])
check("移除 → veto", _vetoed_dims({"sex"}, prev, {"age": ["25-34"]}) == ["sex"])
check("完全不變 → 不 veto", _vetoed_dims({"sex"}, prev, dict(prev)) == [])
check("非受保護維度的值集放寬 → 不 veto",
      _vetoed_dims({"sex"}, prev, {"sex": ["女"], "age": ["25-34", "35-44"]}) == [])

print("\n=== endpoint 級（fake LLM）===")
server_mod = sys.modules["api.server"]
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"
server_mod.app.state.db_loaded = True
os.chdir(ROOT)


def _run(query, domain, filters, broaden_fn, core=None):
    async def _parse(q_list, role=None, distribution=None):
        return {"domain": domain, "reasoning": "一般敍述。", "question_analysis": [],
                "usage_suggestion": None, "filters": filters, "dim_importance": {}, "core_dims": core or []}
    op, ol = server_mod.parse_questions_with_llm, llm_mod.call_llm
    server_mod.parse_questions_with_llm = _parse
    llm_mod.call_llm = broaden_fn
    try:
        loop = asyncio.new_event_loop()
        return loop.run_until_complete(server_mod.personadb_candidates(
            questions=query, top_k=3, opMode="僅篩選", role=""))
    finally:
        server_mod.parse_questions_with_llm, llm_mod.call_llm = op, ol


BASE_F = {"aesthetic_procedure": ["有"], "sex": ["女"], "age": ["25-34"]}
PROT = ["aesthetic_procedure", "sex"]          # 由分析宣告為核心


async def _b_empty_noncore(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    """把非受保護維度設為空清單（#62 的進入路徑）。"""
    return json.dumps({"broadening": "把 age 設為空清單", "protected_dims": [],
                       "filters": {"aesthetic_procedure": ["有"], "sex": ["女"], "age": []}},
                      ensure_ascii=False)


async def _b_empty_protected(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    return json.dumps({"broadening": "把 sex 設為空清單", "protected_dims": [],
                       "filters": {"aesthetic_procedure": ["有"], "sex": [], "age": ["25-34"]}},
                      ensure_ascii=False)


async def _b_widen_noncore(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    return json.dumps({"broadening": "放寬 age 值集", "protected_dims": [],
                       "filters": {"aesthetic_procedure": ["有"], "sex": ["女"], "age": ["25-34", "35-44", "45-54"]}},
                      ensure_ascii=False)


async def _b_widen_protected(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    return json.dumps({"broadening": "把 sex 由女放寬為女+男", "protected_dims": [],
                       "filters": {"aesthetic_procedure": ["有"], "sex": ["女", "男"], "age": ["25-34"]}},
                      ensure_ascii=False)


r1 = _run("醫美診所的目標客戶", "醫美/醫療美容", BASE_F, _b_empty_noncore, core=PROT)
check("endpoint：非受保護維度被設為空清單 → applied_filters 不含空清單",
      all(v for v in (r1.applied_filters or {}).values()), r1.applied_filters)
check("endpoint：該維度消失（＝未指定，不是排除全部）", "age" not in (r1.applied_filters or {}),
      r1.applied_filters)

r2 = _run("醫美診所的目標客戶", "醫美/醫療美容", BASE_F, _b_empty_protected, core=PROT)
check("endpoint：受保護維度被清空 → veto（正規化後視為移除）",
      r2.broadening_stop_reason == "protected_veto" and "sex" in (r2.applied_filters or {}),
      (r2.broadening_stop_reason, r2.applied_filters))

r3 = _run("醫美診所的目標客戶", "醫美/醫療美容", BASE_F, _b_widen_noncore, core=PROT)
_w = [b.widened_dims for b in (r3.broadening_attempts or [])]
check("endpoint：非受保護維度值集放寬 → attempt 記 widened_dims", any("age" in (x or []) for x in _w), _w)
check("endpoint：widened_dims 不併入 relaxed_dims（不變式仍成立）",
      not (set(r3.protected_dims or []) & set(r3.relaxed_dims or [])), (r3.protected_dims, r3.relaxed_dims))

r4 = _run("醫美診所的目標客戶", "醫美/醫療美容", BASE_F, _b_widen_protected, core=PROT)
check("★ endpoint：受保護維度值集放寬 → veto（#63(b)）",
      r4.broadening_stop_reason == "protected_veto" and (r4.applied_filters or {}).get("sex") == ["女"],
      (r4.broadening_stop_reason, r4.applied_filters))

print("\n=== #64 prompt 指示 ===")
src_llm = open(os.path.join(ROOT, "api", "llm.py")).read()
check("QUESTION_ANALYSIS_PROMPT 含顧客語意題的 core_dims 要求", "顧客語意題" in src_llm)
check("指示要求指出 1–2 個定義目標族群的維度", "定義目標族群的維度" in src_llm)
check("core_dims 仍允許空陣列（無可辨識族群時）", "才給空陣列" in src_llm)

print("\n=== 契約 ===")
from api.models import BroadeningAttempt
check("BroadeningAttempt 有 widened_dims（預設空 list）", BroadeningAttempt().model_dump()["widened_dims"] == [])
sch = BroadeningAttempt.model_json_schema()["properties"]
check("OpenAPI 可見 widened_dims（array）", sch["widened_dims"]["type"] == "array")

print("\n" + "=" * 62)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
