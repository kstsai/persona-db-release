# Persona DB v5.11 Release Notes

> 日期: 2026-09-15 | 上一版: v5.10 | 類型: **資料語意正確性（空值清單）＋ 放寬行為可稽核與雙向凍結 ＋ 保護覆蓋率 ＋ infra**
> 來源: 第十輪驗證報告（`round10-v5.10-nodeA-upstreamrunner`）；三條發現皆由我方獨立複驗後開票

## 修的 issue

| # | 標題 | 類型 |
|:-:|:---|:---|
| **#62** | `applied_filters` 可含空值清單 → 語意是「排除全部」而非「不限制」 | bug |
| **#63** | 「值集放寬」不留痕 + 受保護維度未被雙向凍結 | enhancement |
| **#64** | 部分領域的 `protected_dims` 為空（顧客語意題） | enhancement |
| — | infra：`persona-db-api` 容器補 `--restart unless-stopped` | infra（不涉版號） |

## 變更內容

### 1. #62 空值清單正規化（bug，語意正確性）

- 新增 `_normalize_filters()`：**值清單為空的維度＝「未指定」→ 丟棄**；analysis 與放寬路徑皆套用
- 底層 `filter_personas` 對 `accepted == []` 的行為（**排除所有人**）**未改動**（primitive 語意不變），但**上游不再讓空清單進入套用階段**
- **實測佐證**：`age=[]` + `income=['>8萬']` → **0 人**；真正「不指定 age」→ **129 人**（兩者語意完全相反）
- 附帶：受保護維度被清空 ⇒ 正規化後視為「移除」⇒ **自動落入既有 veto**

### 2. #63 值集放寬留痕 + 受保護維度雙向凍結

- **(a) 留痕**：`broadening_attempts[].widened_dims`（該輪值集被放寬的維度）；**不併入 `relaxed_dims`**（避免破壞 `protected_dims ∩ relaxed_dims = ∅`）
- **(b) 政策**：**受保護維度雙向凍結** —— 移除／縮小／**放寬值集**皆違規 → `protected_veto`
  - 依據：`sex ['女'] → ['女','男']`（醫美）、`commute_mode ['汽車'] → ['汽車','機車']`（TESLA）都屬語意稀釋；我方資料中**至少 15 輪**屬值集放寬型

### 3. #64 顧客語意題也要宣告 `core_dims`

- `QUESTION_ANALYSIS_PROMPT` 補：「即使是『找某店／某攤／某品牌的目標客群』這類顧客語意題，也要指出 1–2 個定義目標族群的維度（例：`clothing_spend`／`income`／`occupation`／`family_size`／`hobby`）」
- 不動 domain 關鍵字表（`老闆` 等歧義鍵維持只認 domain —— #34 的刻意設計）

### 4. infra

- `deploy-hermes-personadb-containers.sh`：`persona-db-api` 加 **`--restart unless-stopped`**（主機／daemon 重啟後自動恢復）
- `test-persona-db-api.sh`：新增「#62 空值清單守門」「#63 受保護維度未被放寬值集」斷言

## 行為影響（消費者需知）

| 項目 | 影響 |
|:---|:---|
| `applied_filters` | **值清單保證非空**（空清單不再出現；過去出現時等同「排除全部」） |
| `protected_dims` | 更嚴：受保護維度**值集不可變動** → 部分題目可放寬空間更小、`returned` 可能再降（既有「寧可少給不給錯」的延伸） |
| `broadening_attempts[].widened_dims` | **新增欄位**（向後相容，預設 `[]`） |
| 契約不變 | `protected_dims ∩ relaxed_dims = ∅` 仍成立 |

## 測試

- **單元**：`scripts/test_v5_11_fixes.py`（22 項）＋ v5.4–v5.10 全套件回歸；v5.9 的 veto 語意測試已更新（「純新增值→不 veto」→「受保護維度放寬值集→veto」）
- **真 LLM e2e**：TESLA（`commute_mode` 值集不放寬）、醫美（值集案例）、債務／銀行／業主回歸、顧客語意題 3 次（#64 驗收）
- **SOP（nodeB）**：出貨斷言（含 #62 守門與 K/L/M veto 不變式）＋ `docker inspect` 驗 `RestartPolicy=unless-stopped`
- **反向測試**：新增斷言以刻意違規的假案例確認會亮 ❌
