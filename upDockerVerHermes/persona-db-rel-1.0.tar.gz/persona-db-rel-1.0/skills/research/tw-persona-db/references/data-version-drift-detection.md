# Data Version Drift Detection — 開發環境 vs 交付 VM

## 問題

本尊（hermesa3）持續迭代 persona DB 資料，但 delivery VM（如 lzcdh5）的 container 可能：
- 使用舊 tarball build 的 image（v3.2）
- 被手動 hot-deploy 了更新版資料（v3.7）
- VERSION 檔案不存在於 container 內，或與預期不符

**風險**：交付給甲方的容器內資料版本與本尊 source 不同步，QA 驗證通過的是不同版本的資料。

## 偵測方法

### 1. 對比三處版本號

每次部署後或例行檢查時，比對以下三個來源的版本：

| 來源 | 指令 | 預期 |
|:-----|:------|:------|
| **Source repo** | `cat ~/persona-db/VERSION` | 本尊最新版本 |
| **Tarball** | `tar xf persona-db-rel-1.0.tar.gz -O persona-db-rel-1.0/VERSION` | 等於或略低於 source |
| **Container** | `docker exec persona-db-api cat /app/VERSION` | 應等於 source 最新版 |

**Drift 判斷**：
- Source > Tarball → 本尊有未打包的更新
- Tarball > Container → 容器 build 前 tarball 已被更新
- Container > Source → ❌ **資料被直接置入容器，未同步回 source**（本 session 發現的 v3.7 案例）

### 2. 跨環境 /personadb/status 比對

```bash
# 本尊
curl -s localhost:8000/personadb/status | grep Version

# 各 delivery VM
for vm in lzcdh5 192.168.1.136 192.168.1.173; do
  echo "--- $vm ---"
  ssh ubuntu@$vm "curl -s localhost:8000/personadb/status | grep Version"
done
```

預期所有環境的 Version 應一致。不一致表示 drift。

### 3. JSON 檔案大小比對

```bash
# 本尊
wc -c ~/persona-db/tw_persona_1069.json

# Container 內
docker exec persona-db-api wc -c /opt/data/persona-db/tw_persona_1069.json
```

檔案大小差異（即使版本號相同）可能表示不同 generation run 的結果。

## 同步修復流程

### Case A: Container 版本落後 Source

1. 用最新 source 重新 build tarball：
   ```bash
   cd ~/persona-db && bash pack-persona-db-release.sh
   ```
2. 推送 tarball 到 delivery VM：`scp persona-db-rel-1.0.tar.gz ubuntu@vm:~/persona-db-release/upDockerVerHermes/`
3. Rebuild image + restart：`docker compose build --no-cache && docker compose up -d`

### Case B: Container 版本超前 Source（drift）

1. 從 container 撈回最新資料：
   ```bash
   docker cp persona-db-api:/opt/data/persona-db/tw_persona_1069.json /tmp/
   docker cp persona-db-api:/app/VERSION /tmp/
   ```
2. 複製到本尊 repo：
   ```bash
   cp /tmp/tw_persona_1069.json ~/persona-db/
   cp /tmp/VERSION ~/persona-db/
   ```
3. Commit + push：
   ```bash
   cd ~/persona-db
   git add tw_persona_1069.json VERSION && git commit -m "sync: retrieve vX.Y from delivery container"
   git push origin main && git push gitea main
   ```
4. 重新打包 tarball（讓 tarball 與 source 同步）

## 常見原因

| 原因 | 症狀 | 修復 |
|:-----|:------|:------|
| 手動 docker cp 置入新 JSON 但沒 commit | Container 超前 source | Case B |
| Tarball 未更新但 container rebuild | Container 落後 source | Case A |
| 多人操作（本尊 + 分身各自改） | 版本分歧 | 以本尊為準，Case B |
| VERSION 檔案不存在於容器內 | Version 顯示硬編碼 fallback | 確認 Dockerfile COPY VERSION 指令 |
| **Deploy script hardcode VERSION** 🔥 | Container 版本固定在 script 硬寫的值（如 v3.7），不隨 tarball 改變 | 見下方「Root Cause: Deploy Script Hardcodes VERSION」

## 四維度部署比對（Full Comparison Pattern）

除了版本 drift，建議例行比對 deploy 環境與 source 在以下 4 個維度：

### 1. 人設資料（JSON）

```bash
# MD5 比對（最精確）
echo "Source:" && md5sum ~/persona-db/tw_persona_1069.json
echo "Container:" && ssh ubuntu@vm "docker exec persona-db-api md5sum /app/tw_persona_1069.json"

# Entry 數比對
echo "Source:" && python3 -c "import json; print(len(json.load(open('tw_persona_1069.json'))))"
ssh ubuntu@vm "docker exec persona-db-api python3 -c \"import json; print(len(json.load(open('/app/tw_persona_1069.json'))))\""
```

### 2. Python 檔案（數量 + 差異）

比對 `api/*.py` + root `*.py`（也就是 status endpoint 回報的數字）：

```bash
# 本尊
ls ~/persona-db/*.py ~/persona-db/api/*.py | wc -l
# Container
ssh ubuntu@vm 'docker exec persona-db-api sh -c "ls /app/*.py /app/api/*.py | wc -l"'
```

常見差異：container 通常缺少 `api/debug_filters.py`, `api/debug_llm.py`, `api/debug_llm_prompt.py`, `api/run_bank_scenario.py` 等 debug 工具（不影響核心功能）。

### 3. Hermes Skills（掛載到 /hermes-config/skills）

```bash
# 本尊
find ~/.hermes/skills -name SKILL.md | wc -l
# Container
ssh ubuntu@vm 'docker exec hermes sh -c "find /opt/data/skills -name SKILL.md | wc -l"'
# 列出差異
ssh ubuntu@vm 'docker exec hermes sh -c "find /opt/data/skills -name SKILL.md"'
```

Container 通常精簡 10-20 個技能（移除 jupyter、vllm、media-analysis 等），並可能追加 docx/pdf/xlsx 等文件工具。

### 4. LLM 設定

```bash
ssh ubuntu@vm 'docker exec persona-db-api sh -c "env | grep -iE \"LLM|MODEL|API_KEY\" | grep -v GPG"'
```

注意 `LLM_MODEL` 是否正確（`deepseek-v4-flash` 而非已棄用的 `deepseek-chat`），以及 `(no response)` 是否由 reasoning-model + 低 max_tokens 造成（見 SKILL.md 的推理模型 health-check 章節）。

### 快速一鍵比對腳本

```bash
#!/bin/bash
# 用法: ./compare-deployment.sh <host>
HOST=$1
echo "=== MD5 ==="
echo "本地: $(md5sum ~/persona-db/tw_persona_1069.json | cut -d' ' -f1)"
echo "容器: $(ssh ubuntu@$HOST 'docker exec persona-db-api md5sum /app/tw_persona_1069.json' 2>/dev/null | cut -d' ' -f1)"
echo "=== Python 檔案 ==="
echo "本地: $(ls ~/persona-db/*.py ~/persona-db/api/*.py 2>/dev/null | wc -l)"
echo "容器: $(ssh ubuntu@$HOST 'docker exec persona-db-api sh -c \"ls /app/*.py /app/api/*.py | wc -l\"' 2>/dev/null)"
echo "=== Skills ==="
echo "本地: $(find ~/.hermes/skills -name SKILL.md | wc -l)"
echo "容器: $(ssh ubuntu@$HOST 'docker exec hermes sh -c \"find /opt/data/skills -name SKILL.md | wc -l\"' 2>/dev/null)"
echo "=== LLM ==="
ssh ubuntu@$HOST 'docker exec persona-db-api sh -c "env | grep -iE \"LLM|MODEL|API_KEY\" | grep -v GPG"' 2>/dev/null

## 預防措施

1. **部署 script 加入版本檢查**：`deploy-persona-db-compose.sh` 在 deploy 前比對 tarball VERSION 與本機 VERSION
2. **定期排程 drift 檢查**：用 cronjob 每週 curl 各 delivery VM 的 /personadb/status，比對 version
3. **Container 掛載唯讀 VERSION**：確保 Dockerfile 的 `COPY VERSION ./` 在 api 目錄層級，避免被 hot-deploy 覆蓋（除非有意為之）

## Root Cause: Deploy Script Hardcodes VERSION

### 發現經過

`/home/ubuntu/persona-db-release/upDockerVerHermes/deploy-hermes-personadb-containers.sh` 第 289 行：
```bash
# Write correct VERSION (overwrite tarball's default)
echo "v3.7" > "${PERSONA_DB_DATA}/VERSION"
echo "  ✅ VERSION set to v3.7"
```

`deploy-persona-db-compose.sh` 同一行完全相同。

Git 記錄：commit `72f6714` (Jul 25) 將原本的版本從 v3.2 改為 v3.7，理由是「QA matches 23-rule level」。**但 source repo 的 VERSION 檔案從未被同步更新**，仍維持 v3.2。

### 影響

- **a3 本尊**：VERSION = v3.2（真實資料版本）
- **dh5 container**：VERSION = v3.7（deploy script 硬寫的）
- 本尊永遠不會知道 container 報告的版本不同，除非做跨環境比對

### 修復

每次 bump persona 資料版本時，必須同時更新三處，否則 drift 必然發生：

| 需要更新的位置 | 檔案 | 動作 |
|:--------------|:-----|:------|
| ① Source repo | `hermesa3/persona/VERSION` | `echo "vX.Y" >` |
| ② Tarball | `pack-persona-db-release.sh` → 重新產生 | 讓 tarball 包含最新的 VERSION |
| ③ **Deploy script** 🔥 | `deploy-hermes-personadb-containers.sh` 第 289 行 | 修改 hardcode 的版本號 |

**長期解法**：將 deploy script 的 hardcode 改為動態讀取 tarball 內的 VERSION：

```bash
# 從 tarball 內讀 VERSION（不要 hardcode）
TAR_VERSION=$(tar xf "$TARBALL" -O persona-db-rel-1.0/VERSION 2>/dev/null || echo "unknown")
echo "$TAR_VERSION" > "${PERSONA_DB_DATA}/VERSION"
```

### 檢查命令

快速確認 deploy script 是否有 hardcode VERSION：

```bash
grep -n 'echo "v[0-9]' /home/ubuntu/persona-db-release/upDockerVerHermes/deploy-hermes-personadb-containers.sh /home/ubuntu/persona-db-release/upDockerVerHermes/deploy-persona-db-compose.sh
```
