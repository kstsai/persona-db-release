"""
llm.py — LLM client for Persona DB API.

Calls DeepSeek API (or any OpenAI-compatible endpoint) to:
1. Analyze questions → determine target persona demographics
2. Generate simulation responses for matched personas
"""

import json, os, logging
from typing import Optional
import httpx
import yaml

logger = logging.getLogger(__name__)

# ── Config ─────────────────────────────────────────────────────────

HERMES_CONFIG_PATH = "/hermes-config/config.yaml"

def _load_llm_config() -> dict:
    """
    Load LLM configuration from Hermes config file.
    
    Priority:
    1. Environment variables (LLM_API_KEY, LLM_MODEL, LLM_BASE_URL)
    2. Hermes config file (mounted at /hermes-config/config.yaml)
    
    Returns dict with: api_key, base_url, model
    """
    config = {
        "api_key": "",
        "base_url": "",
        "model": "",
    }
    
    # 0. Check local .env file (project root)
    env_paths = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"),
        os.path.expanduser("~/.hermes/.env"),
        "/app/.env",  # Docker container path
    ]
    try:
        for env_path in env_paths:
            if os.path.exists(env_path):
                with open(env_path) as ef:
                    for line in ef:
                        line = line.strip()
                        if line and not line.startswith("#") and "=" in line:
                            k, v = line.split("=", 1)
                            k, v = k.strip(), v.strip().strip("'\"")
                            if k == "LLM_API_KEY" and not config["api_key"]:
                                config["api_key"] = v
                            elif k == "LLM_BASE_URL" and not config["base_url"]:
                                config["base_url"] = v
                            elif k == "LLM_MODEL" and not config["model"]:
                                config["model"] = v
    except Exception:
        pass
    
    # 1. Environment variables (highest priority)
    env_key = os.environ.get("LLM_API_KEY")
    env_url = os.environ.get("LLM_BASE_URL")
    env_model = os.environ.get("LLM_MODEL")
    
    if env_key:
        config["api_key"] = env_key
    if env_url:
        config["base_url"] = env_url
    if env_model:
        config["model"] = env_model
    
    # 2. Try Hermes config file (middle priority, only fills gaps)
    if os.path.exists(HERMES_CONFIG_PATH):
        try:
            with open(HERMES_CONFIG_PATH) as f:
                cfg = yaml.safe_load(f)
            
            model_cfg = cfg.get("model", {})
            
            # Get api_key from config (if not already set from env)
            if not config["api_key"]:
                config["api_key"] = model_cfg.get("api_key", "")
                
                # Also check custom providers for keys
                custom_providers = cfg.get("custom_providers", {})
                for prov_name, prov_cfg in custom_providers.items():
                    prov_key = prov_cfg.get("api_key", "")
                    if prov_key and not config["api_key"]:
                        config["api_key"] = prov_key
                
                # Check auth.json for OAuth tokens (Nous provider)
                if not config["api_key"]:
                    auth_path = os.path.join(os.path.dirname(HERMES_CONFIG_PATH), "auth.json")
                    if os.path.exists(auth_path):
                        try:
                            with open(auth_path) as af:
                                auth_data = json.load(af)
                            # Try Nous OAuth token
                            nous_cred = auth_data.get("credential_pool", {}).get("nous", {})
                            if nous_cred:
                                token = nous_cred.get("access_token", "") or nous_cred.get("token", "")
                                if token:
                                    config["api_key"] = token
                                    config["base_url"] = "https://inference-api.nousresearch.com/v1"
                                    if not config["model"]:
                                        config["model"] = cfg.get("model", {}).get("default", "tencent/hy3:free")
                                    logger.info("Found Nous OAuth token — using Nous provider")
                        except Exception as e:
                            logger.debug(f"Could not read auth.json: {e}")
            
            # Get base_url from config (if not already set)
            if not config["base_url"]:
                config["base_url"] = model_cfg.get("base_url", "")
            
            # Get model from config (if not already set)
            if not config["model"]:
                config["model"] = model_cfg.get("default", "")
        
        except Exception as e:
            logger.warning(f"Failed to read Hermes config: {e}")
    
    # 3. Fallback defaults
    if not config["base_url"]:
        config["base_url"] = "https://api.deepseek.com"
    if not config["model"]:
        config["model"] = "deepseek-chat"
    
    return config


LLM_CONFIG = _load_llm_config()


# ── Prompts ────────────────────────────────────────────────────────

QUESTION_ANALYSIS_PROMPT = """你是一個台灣市場研究助手。你的任務是分析使用者提出的問題，判斷哪些 demographics 會對這些問題感興趣。

請分析以下問題，輸出 JSON 格式：

問題列表：
{questions}

請考慮：
1. 這是什麼領域/產業的問題？
2. 哪些年齡層、性別、居住地、職業、收入、家庭狀況的人會關心這個主題？
3. 這些 persona 最適合怎麼使用？

**重要：filter 的值必須嚴格使用下方提供的有效選項，不要自己創造新值。**

有效選項：
- age: 0-11, 12-18, 19-24, 25-34, 35-44, 45-54, 55-64, 65+ （可選多個，最多3個）
- sex: 男, 女 （不確定就留空 []）
- occupation: 學生, 科技, 金融, 服務, 製造, 教育, 醫療, 公務, 自營, 家管, 退休, 其他
  （可選多個，上班族/SOHO/白領請對應到科技/金融/服務/製造等）
- residence: 台北市, 新北市, 桃園市, 台中市, 台南市, 高雄市, 基隆市, 新竹市, 新竹縣, 苗栗縣, 宜蘭縣, 彰化縣, 南投縣, 雲林縣, 嘉義市, 嘉義縣, 屏東縣, 花蓮縣, 台東縣, 澎湖縣, 金門縣, 連江縣 （不確定就留空 []）
- income: 無收入, <3萬, 3-8萬, >8萬 （可選多個）
- marriage: 未婚, 已婚, 離婚, 鰥寡 （不確定就留空 []）
- family_size: 1, 2, 3, 4, 5+ （不確定就留空 []）
- hobby: 登山, 游泳, 球類, 打電動, 追劇, 閱讀, 逛街購物, 戶外活動, 運動
  （不確定就留空 []。注意：目前資料庫不支援「賞鳥、露營、攝影」等，請盡量對應到相近的現有選項）

回應格式（嚴格 JSON，不要有其他文字）：
{{
  "domain": "判斷這是什麼領域的問題",
  "reasoning": "簡短說明判斷理由",
  "filters": {{
    "age": ["年齡區間，使用上方有效值"],
    "occupation": ["職業，使用上方有效值"],
    "sex": [],
    "residence": [],
    "income": ["收入區間，使用上方有效值"],
    "marriage": []
  }},
  "question_analysis": [
    {{"question": "問題一", "topic": "主題", "target_user": "誰會關心這個"}}
  ],
  "usage_suggestion": {{
    "mode": "模擬詢問 或 問卷答題者 或 兩者皆可",
    "reason": "簡短說明為什麼這些 persona 適合這個用法",
    "recommended_opMode": "僅篩選 或 篩選+模擬"
  }}
}}

注意：
- 不確定的維度就留空陣列 []。
- 判斷邏輯：
  - 模擬詢問（遭遇模擬②）：問題是在問「產品/服務怎麼樣、哪個好、你覺得如何」— 目的是讓 LLM 扮演 persona 直接回答，回答本身就是產出。例如：「哪家銀行利率最高？」→ persona 回答「台銀2.075%配99次。」
  - 問卷答題者（自我模擬①）：問題是在描述一個情境、需要找「對的人來問意見/推薦」— 目的是找到合適的 persona 當作問卷對象，再對他們發問卷。例如：「找新竹課輔班推薦」→ 目標是找到新竹家長，然後問他們推薦哪家。
  - 兩者皆可：如果問題兼具兩種特性。
- usage_suggestion.recommended_opMode: 模擬詢問建議用「篩選+模擬」；問卷答題者建議用「僅篩選」（拿 list 自己做問卷）。
"""

SIMULATION_PROMPT = """你正在進行市場研究模擬。以下是 persona 的完整背景：

Persona ID: {persona_id}
姓名: {name}
年齡: {age} | 居住地: {residence}
職業: {occupation} | 收入: {income}
家庭: {family_size}人 | 婚姻: {marriage}
興趣: {hobby}

背景故事: {background_story}
Persona 語氣: {prompt_prefix}

現在這個 persona 被問到以下問題：
{questions}

請以第一人稱「我」的口吻，用自然的口語中文，為每個問題回答 2-4 句話。
回答要符合 persona 的年齡、職業、收入、居住地等背景。
不要提到任何關於模擬、角色扮演的字眼。

輸出 JSON 格式：
{{
  "answers": [
    {{"question": "問題一", "answer": "以 persona 身份的回答"}},
    {{"question": "問題二", "answer": "以 persona 身份的回答"}}
  ]
}}
"""


# ── LLM Call ───────────────────────────────────────────────────────

async def call_llm(
    prompt: str,
    system_prompt: str = "你是一個有用的台灣市場研究助手，請用繁體中文回應。",
    temperature: float = 0.3,
    max_tokens: int = 2000,
) -> Optional[str]:
    """Call the LLM API and return the response text."""
    api_key = LLM_CONFIG["api_key"]
    base_url = LLM_CONFIG["base_url"]
    model = LLM_CONFIG["model"]
    
    if not api_key:
        logger.warning("No LLM API key configured — LLM features disabled")
        return None
    
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                f"{base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": prompt},
                    ],
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]
    except Exception as e:
        logger.error(f"LLM call failed: {e}")
        return None


async def parse_questions_with_llm(questions: list[str]) -> dict:
    """
    Use LLM to analyze questions and determine target demographics.
    Returns structured filters or empty dict on failure.
    """
    if not questions:
        return {}
    
    prompt = QUESTION_ANALYSIS_PROMPT.format(
        questions="\n".join(f"- {q}" for q in questions)
    )
    
    response = await call_llm(prompt, temperature=0.2)
    if not response:
        return {}
    
    # Try to extract JSON from response
    try:
        # Find JSON block (handle markdown code fences)
        if "```json" in response:
            json_str = response.split("```json")[1].split("```")[0].strip()
        elif "```" in response:
            json_str = response.split("```")[1].split("```")[0].strip()
        else:
            json_str = response.strip()
        
        result = json.loads(json_str)
        return result
    except (json.JSONDecodeError, IndexError) as e:
        logger.warning(f"Failed to parse LLM response as JSON: {e}")
        logger.debug(f"Raw response: {response[:500]}")
        return {}


async def simulate_with_llm(persona: dict, questions: list[str]) -> dict:
    """
    Use LLM to simulate a persona answering questions (遭遇模擬②).
    """
    dims = persona.get("dimensions", {})
    q_text = "\n".join(f"Q{i+1}. {q}" for i, q in enumerate(questions))
    
    prompt = SIMULATION_PROMPT.format(
        persona_id=persona.get("id", ""),
        name=persona.get("name", ""),
        age=dims.get("age", ""),
        residence=dims.get("residence", ""),
        occupation=dims.get("occupation", ""),
        income=dims.get("income", ""),
        family_size=dims.get("family_size", ""),
        marriage=dims.get("marriage", ""),
        hobby=", ".join(dims.get("hobby", [])),
        background_story=dims.get("background_story", ""),
        prompt_prefix=persona.get("prompt_prefix", "")[:500],
        questions=q_text,
    )
    
    response = await call_llm(prompt, temperature=0.7, max_tokens=3000)
    if not response:
        return {"status": "failed", "answers": []}
    
    try:
        if "```json" in response:
            json_str = response.split("```json")[1].split("```")[0].strip()
        elif "```" in response:
            json_str = response.split("```")[1].split("```")[0].strip()
        else:
            json_str = response.strip()
        
        result = json.loads(json_str)
        answers = result.get("answers", [])
        return {
            "status": "completed",
            "answers": [a.get("answer", "") for a in answers]
        }
    except (json.JSONDecodeError, IndexError) as e:
        logger.warning(f"Failed to parse simulation response: {e}")
        return {
            "status": "completed",
            "answers": [response[:500]]  # Return raw text as fallback
        }
