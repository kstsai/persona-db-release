"""
Persona DB REST API — FastAPI Server (LLM-powered)

Endpoints:
  GET /personadb/candidates — LLM analyzes questions → filter personas (+ simulate)
  GET /personadb/detail     — Get full persona profile by ID
  GET /health               — Health check

Run:  uvicorn api.server:app --reload
"""

import os, sys, json, logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import PlainTextResponse

from .models import (
    OpMode, CandidatesResponse, PersonaBrief,
    PersonaSimulation, DimensionSummary, LLMAnalysis,
    DetailResponse, PersonaDetail, HealthResponse, ErrorResponse
)
from .persona_matcher import (
    filter_personas, get_important_dimensions,
    format_matched_criteria, load_persona_db, get_persona_by_id,
    llm_filters_to_dimension_filters
)
from .llm import parse_questions_with_llm, simulate_with_llm, call_llm, LLM_CONFIG

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Persona DB API",
    description="台灣人口加權合成人設資料庫 — LLM-powered 查詢與模擬 API",
    version="3.2.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── Startup ────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    try:
        load_persona_db()
        db = load_persona_db()
        logger.info(f"Persona DB loaded: {len(db)} personas")
        app.state.db_loaded = True
        app.state.persona_count = len(db)
    except Exception as e:
        logger.error(f"Failed to load Persona DB: {e}")
        app.state.db_loaded = False
        app.state.persona_count = 0


# ── Health ─────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(
        status="ok",
        version="3.2",
        persona_count=getattr(app.state, "persona_count", 0),
        db_loaded=getattr(app.state, "db_loaded", False),
    )


# ── Candidates (LLM-powered filter + optional simulate) ────────────

@app.get(
    "/personadb/candidates",
    response_model=CandidatesResponse,
    responses={
        400: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
        503: {"model": ErrorResponse},
    }
)
async def personadb_candidates(
    questions: str = Query(..., description="問題列表，用 | 分隔多題"),
    top_k: int = Query(default=12, ge=1, le=20, description="最多回傳筆數"),
    opMode: str = Query(default="僅篩選", description="操作模式: 僅篩選 / 篩選+模擬"),
):
    # Validate
    if opMode not in ("僅篩選", "篩選+模擬"):
        raise HTTPException(400, detail={
            "code": "INVALID_PARAMETER",
            "message": f"不支援的 opMode: {opMode}",
            "details": "有效值: 僅篩選, 篩選+模擬"
        })
    
    if not getattr(app.state, "db_loaded", False):
        raise HTTPException(503, detail={
            "code": "DB_NOT_LOADED",
            "message": "Persona DB 尚未載入",
            "details": ""
        })
    
    # Parse questions (split by |)
    q_list = [q.strip() for q in questions.split("|") if q.strip()]
    if not q_list:
        raise HTTPException(400, detail={
            "code": "MISSING_PARAMETER",
            "message": "請提供至少一個問題",
            "details": "多個問題請用 | 分隔"
        })
    
    try:
        db = load_persona_db()
        
        # Step 1: LLM analyzes questions → dimension filters
        logger.info(f"LLM analyzing {len(q_list)} questions...")
        llm_result = await parse_questions_with_llm(q_list)
        
        llm_analysis = None
        if llm_result:
            llm_analysis = LLMAnalysis(
                domain=llm_result.get("domain", ""),
                reasoning=llm_result.get("reasoning", ""),
                question_analysis=llm_result.get("question_analysis", []),
                usage_suggestion=llm_result.get("usage_suggestion"),
            )
        
        # Step 2: Convert LLM output to filters
        filters = llm_filters_to_dimension_filters(llm_result) if llm_result else {}
        
        # Fallback: if LLM returned no filters, use keyword-based parsing from questions text
        if not filters:
            from .persona_matcher import parse_enduser
            combined_text = " ".join(q_list)
            filters = parse_enduser(combined_text)
            logger.warning("LLM returned no filters, falling back to keyword parsing")
        
        # Step 3: Filter personas
        matched = filter_personas(db, filters)
        
        if not matched:
            return CandidatesResponse(
                status="ok",
                total_matched=0,
                persona_ids=[],
                personas=[],
                important_dimensions=[],
                llm_analysis=llm_analysis,
            )
        
        # Step 4: Take top_k
        top = matched[:top_k]
        
        # Build persona list
        persona_ids = []
        personas_brief = []
        
        for p in top:
            pid_str = p.get("id", "")
            try:
                pid_num = int(pid_str.split("-")[-1]) if "-" in pid_str else int(pid_str)
            except ValueError:
                pid_num = 0
            
            persona_ids.append(pid_num)
            personas_brief.append(PersonaBrief(
                id=pid_str,
                name=p.get("name", ""),
                dimensions=p.get("dimensions", {}),
                prompt_prefix=p.get("prompt_prefix", ""),
                reference_pre_prompt=p.get("reference_pre_prompt", ""),
            ))
        
        # Step 5: Optional LLM simulation
        if opMode == "篩選+模擬" and q_list:
            logger.info(f"Simulating {len(top)} personas with LLM...")
            for i, p in enumerate(top):
                sim = await simulate_with_llm(p, q_list)
                if i < len(personas_brief):
                    personas_brief[i].simulation = PersonaSimulation(
                        status=sim.get("status", "failed"),
                        answers=sim.get("answers", []),
                    )
        
        # Step 6: Important dimensions
        important_dims = get_important_dimensions(top)
        dim_summaries = [
            DimensionSummary(dim=d["dim"], values=d["values"])
            for d in important_dims
        ]
        
        return CandidatesResponse(
            status="ok",
            total_matched=len(matched),
            persona_ids=persona_ids,
            personas=personas_brief,
            important_dimensions=dim_summaries,
            llm_analysis=llm_analysis,
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Candidates endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Detail ─────────────────────────────────────────────────────────

@app.get(
    "/personadb/detail",
    response_model=DetailResponse,
    responses={
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    }
)
async def personadb_detail(
    persona_id: str = Query(..., description="Persona ID (TW-P-XXXX 或數字)")
):
    try:
        p = get_persona_by_id(persona_id)
        if p is None:
            raise HTTPException(404, detail={
                "code": "PERSONA_NOT_FOUND",
                "message": f"Persona ID '{persona_id}' 不存在",
                "details": "有效範圍: TW-P-0001 ~ TW-P-1069"
            })
        
        return DetailResponse(
            status="ok",
            persona=PersonaDetail(
                id=p.get("id", ""),
                name=p.get("name", ""),
                type=p.get("type", "虛構人設"),
                dimensions=p.get("dimensions", {}),
                prompt_prefix=p.get("prompt_prefix", ""),
                reference_pre_prompt=p.get("reference_pre_prompt", ""),
            )
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Detail endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Status ────────────────────────────────────────────────────────

@app.get("/personadb/status")
async def persona_db_status():
    """
    Return persona-db status as raw text (like `hermes chat 'persona-db status'`).
    No parameters needed.
    """
    try:
        lines = []
        def L(s): lines.append(s)
        
        # Version
        version = "v3.2"
        try:
            vf = Path(__file__).resolve().parent.parent / "VERSION"
            if vf.exists():
                version = vf.read_text().strip()
        except: pass
        
        # Persona count
        db = load_persona_db()
        p_count = len(db)
        json_size = "N/A"
        json_path = Path(__file__).resolve().parent.parent / "tw_persona_1069.json"
        if json_path.exists():
            sz = json_path.stat().st_size
            json_size = f"{sz/1024/1024:.2f} MB" if sz > 1024*1024 else f"{sz/1024:.1f} KB"
        
        # Backup
        backup_path = json_path.parent / "tw_persona_1069_backup.json"
        backup_ok = backup_path.exists()
        
        # Name diversity
        names = set(p.get("name", "") for p in db)
        name_count = len(names)
        name_pct = round(name_count / p_count * 100, 1)
        from collections import Counter
        name_repeats = Counter(p.get("name", "") for p in db)
        max_repeat = max(name_repeats.values()) if name_repeats else 0
        
        # Python
        py_ver = sys.version.split()[0]
        
        # LLM status
        llm_status = "⛔ Not configured"
        if LLM_CONFIG.get("api_key"):
            llm_status = f"✅ {LLM_CONFIG.get('model', '?')} → {LLM_CONFIG.get('base_url', '?')}"
            # Live LLM test
            try:
                resp = await call_llm("回應「ok」就好", max_tokens=50)
                if resp is not None:
                    llm_status += " (responsive)"
                else:
                    llm_status += " (no response)"
            except Exception as e:
                llm_status += f" (error: {str(e)[:100]})"
        else:
            llm_status = "⛔ No API key configured"
        
        # Git
        git_info = "not a repo (filesystem boundary)"
        git_dir = Path(__file__).resolve().parent.parent / ".git"
        if git_dir.exists():
            try:
                import subprocess
                r = subprocess.run(["git", "log", "--oneline", "-1"], capture_output=True, text=True, cwd=str(git_dir.parent))
                if r.returncode == 0:
                    git_info = r.stdout.strip()
            except: pass
        
        # Hermes skills count (from mounted config volume or local)
        hermes_skills = "N/A"
        persona_skills = "N/A"
        for skills_candidate in ["/hermes-config/skills", str(Path.home() / ".hermes/skills")]:
            skills_path = Path(skills_candidate)
            if skills_path.exists() and skills_path.is_dir():
                try:
                    skill_files = list(skills_path.rglob("SKILL.md"))
                    hermes_skills = str(len(skill_files))
                    ps = [s for s in skill_files if "persona" in s.name.lower() or "persona" in str(s.parent).lower()]
                    persona_skills = str(len(ps))
                    break
                except Exception:
                    continue
        
        # QA
        qa_lines = []
        try:
            qa_script = Path(__file__).resolve().parent.parent / "qa_validate.py"
            if qa_script.exists():
                import subprocess
                r = subprocess.run([sys.executable, str(qa_script)], capture_output=True, text=True, cwd=str(qa_script.parent), timeout=30)
                if r.returncode == 0:
                    qa_lines = r.stdout.splitlines()[-6:]
                else:
                    qa_lines = ["❌ QA FAILED"]
        except subprocess.TimeoutExpired:
            qa_lines = ["⏱️ QA timeout"]
        except Exception as e:
            qa_lines = [f"❌ QA error: {e}"]
        
        # File artifacts
        tools_dir = Path(__file__).resolve().parent.parent
        py_files = list(tools_dir.glob("*.py")) + list(tools_dir.glob("api/*.py"))
        
        # ── Build output ──
        L(f"Persona DB Status")
        L(f"{'='*50}")
        L(f"")
        L(f"  Version         {version}")
        L(f"  Main personas   {p_count} (tw_persona_1069.json, {json_size})")
        L(f"  Backup          {'✅' if backup_ok else '❌'} {p_count} (tw_persona_1069_backup.json)")
        L(f"  QA (23 rules)   {'✅ ALL CHECKS PASSED' if qa_lines and 'PASSED' in qa_lines[-1] else '⏳ check below'}")
        L(f"  Name diversity  {name_count} unique names ({name_pct}%), max repeat {max_repeat}×")
        L(f"  Python          {py_ver}")
        L(f"  Git             {git_info}")
        L(f"  LLM             {llm_status}")
        L(f"  Hermes Skills   {hermes_skills} total, {persona_skills} persona-related")
        L(f"")
        L(f"  📁 Supporting Artifices: {len(py_files)} Python files")
        L(f"")
        if qa_lines:
            L(f"  QA Results:")
            for ql in qa_lines:
                if ql.strip():
                    L(f"    {ql.strip()}")
        
        return PlainTextResponse("\n".join(lines))
    
    except Exception as e:
        logger.exception("Status endpoint error")
        return PlainTextResponse(f"Error: {str(e)}", status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.server:app", host="0.0.0.0", port=8000, reload=True)
