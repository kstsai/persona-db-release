> 來源: linkEazyCenter wiki `concepts/persona-db/relevance-scoring.md`（created 2026-08-05）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Relevance Scoring（相關性排序）

`/personadb/candidates` 的 `persona_ids` 依相關性分數排序，不再只是 DB 檔案順序（issue #4）。

## 公式

```
score(persona) = Σ [ weight(dim, persona.value)  for dim in filters ]
weight = log(1069 / count(dim, value)) → 跨維度正規化 [0.5, 2.0]
```

- ≤3 值維度（sex/marriage/housing_burden）用溫和壓縮 [0.8, 1.4]
- 只算「LLM filter 有出現的維度」
- hobby（list）命中任一 filter 值即加分，取最大權重
- relaxed 維度不計分
- 同分 → DB 順序（確定性）

## Response 揭露

```json
{
  "summary": [{ "score": 2.77 }],
  "applied_filters": { "occupation": ["自營"] },
  "scoring_basis": { "method": "...", "dims_counted": [...] }
}
```

## 限制

- 靜態稀有度 ≠ 語意相關性（花蓮高消費 vs 台北時尚圈可能同分）
- 真正的語意排名需 LLM 打分（未來工作）

## 關聯

- Persona DB — 所在 API
- Dim Weights — 權重表
- v4.4 週報
