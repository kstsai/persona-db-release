# Hermes Session 與 Context 管理

> 2026-07-15 整理 | 源起：新安裝的 Hermes instance (qcow2) 的 Transfer 驗證對話

## 核心概念

**Session** = 一場獨立的對話記錄（thread 或 DM）
**Context** = 當前對話中模型能看到的資訊

兩者是分離的 — 你可以從某個 session **讀取**內容，而不需要**切換**到那個 session。

---

## 三種操作模式

### 1️⃣ 讀取（Read-only）— 最常用

```bash
# 在當前對話中引用舊 session 的內容
「看 session 20260713_013849_9729901c 的商業模式結論」
```

行為：
- 我呼叫 `session_search()` 去讀取那場對話
- 把結論摘要帶到**當前 session** 使用
- **不切換** — 你繼續在當前對話
- 適合：需要參考以前討論過的決策、數據、結論

### 2️⃣ 恢復（Resume）— 專注討論

```bash
hermes sessions resume 20260713_013849_9729901c
```

行為：
- 系統**關閉當前 session**，打開舊 session
- 舊 session 的完整 context 載入
- 你回到當時的討論脈絡繼續
- 適合：有一個未完成的主題想繼續深談

### 3️⃣ 查閱（Browse）— 瀏覽摘要

```bash
hermes sessions list          # 全部列表
hermes sessions browse        # 互動式挑選
```

行為：
- 只看標題、時間、來源
- 決定要讀取還是恢復

---

## 實務建議

### 何時開新 session vs 繼續舊的

| 情況 | 建議 |
|:-----|:-----|
| 全新主題，跟之前無關 | **開新 thread/DM**（自動新 session） |
| 之前討論過但中斷了，想繼續 | **resume 舊 session** |
| 之前討論過但結論已定，想引用 | **讀取舊 session** + 留在當前對話 |
| 多個相關主題交錯 | 開**一個主 thread**，用讀取方式參考其他 |

### Session 命名

Hermes 會自動用 session ID（時間戳）命名。如果要讓之後好找：

```bash
hermes sessions rename <session_id> "有意義的標題"
```

建議命名格式：`[專案] 主題 — 日期`

範例：`[persona-db] 商業模式定案 — 7/13`

### 常見誤解

- ❌ 「在新 thread 發問，舊 session 的 context 會自動帶過來」
  → ✅ 不會。要用 `session_search` 讀取，或在第一條訊息貼 context handoff

- ❌ 「讀取舊 session = 切換到舊 session」
  → ✅ 讀取只是唯讀查詢，不影響當前對話

- ❌ 「舊 session 的 memory 會自動合併到新 session」
  → ✅ memory 是跨 session 共享的（存到 `MEMORY.md`），但 session 對話內容不是

---

## 這個 Instance 的背景

這是透過 qcow2 安裝的新 Hermes instance（192.168.1.121），包含了：
- `~/persona-db/` → Transfer 交付物（工具 + 資料 + skill）
- Slack 同一 workspace 的 session 記錄共享（但 state.db 為空，資料在 sessions.json）
- Git remote: origin → GitHub (`kstsai/persona-db`), gitea → 內部伺服器

跟本尊的差異：
- Session DB 為空（state.db 0 bytes），但透過 Slack gateway 能看到所有 session 列表
- Request dump 檔案保留近期 API 記錄
- 工具和資料透過 git sync 保持同步
