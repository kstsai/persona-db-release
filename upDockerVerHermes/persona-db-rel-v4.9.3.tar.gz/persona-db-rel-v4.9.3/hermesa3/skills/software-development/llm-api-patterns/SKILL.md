---
name: llm-api-patterns
description: >-
  Common patterns, pitfalls, and best practices when coding against LLM APIs
  (OpenAI-compatible). Covers reasoning-model empty-content gotcha, response
  validation, error handling, token budgeting, and correct usage of
  content fields.
domain:
  - llm
  - api-integration
  - python
  - reasoning-models
---

# LLM API Integration Patterns

Patterns for calling LLM (OpenAI-compatible) APIs from Python code, with emphasis on
correctly handling **reasoning/thinking models** (deepseek-r1, deepseek-v4-flash, o1/o3,
claude-thinking, etc.) which behave differently from standard chat models.

## When to Use

- Writing code that calls an LLM via `/v1/chat/completions`
- Building health checks or probes that verify LLM responsiveness
- Handling response content that may be empty due to reasoning tokens
- Troubleshooting "empty response" errors from reasoning models

## Core Pitfalls

### 1. Empty Content from Reasoning Models

**Problem:** Reasoning models (deepseek-v4-flash, deepseek-r1, o1, o3) return empty
`content` (`""`) when all allocated tokens are consumed by the reasoning chain:

```python
# Response from a reasoning model with low max_tokens:
{
  "choices": [{
    "message": {
      "content": "",                      # ← empty!
      "reasoning_content": "The user asked for...",  # ← tokens went here
    }
  }]
}
```

Common symptom: `if resp:` evaluates to `False` because empty string is falsy,
incorrectly indicating the LLM is unresponsive.

**Fix (two-part):**

1. **Use `is not None`**, not truthiness:
   ```python
   # BAD — treats empty content as failure
   if response_text:
       log("responsive")
   
   # GOOD — only fails on actual None/exception
   if response_text is not None:
       log("responsive")
   ```

2. **Give reasoning models room to output** — `max_tokens=5` gets consumed entirely by
   reasoning. Use at least `max_tokens=50` for a health-check ping so the model has
   tokens left for the actual output.

### 2. Health Check Design

A health check should distinguish three states:

| Response | Meaning | Action |
|----------|---------|--------|
| `None` | API call failed (network, auth, timeout) | Report error |
| `""` (empty string) | Model responded but used all tokens on reasoning | Increase `max_tokens` |
| Non-empty string | Model is working normally | Report OK |

```python
try:
    resp = await call_llm("Say OK", max_tokens=50)
    if resp is not None:
        status = "responsive"
    else:
        status = "no response (empty or failed)"
except Exception as e:
    status = f"error: {e}"
```

### 3. Response Validation

For production code, validate the response shape before accessing fields:

```python
resp_data = resp.json()
choices = resp_data.get("choices", [])
if not choices:
    raise ValueError("No choices in response")

message = choices[0].get("message", {})
content = message.get("content")  # may be None or ""
reasoning = message.get("reasoning_content", "")  # reasoning models only

if content is None:
    # API returned no content field at all — real failure
    raise ValueError("Empty message content")
# content may still be "" for reasoning models — that's OK
```

**Probe before you code:** for any new reasoning model, fire a minimal "Say OK only"
request with `max_tokens=50` and inspect `choices[0].message.keys()`. If
`reasoning_content` is present even on a trivial prompt, the model reasons by default —
plan for either harvesting `reasoning_content` (pitfall #8) or disabling it via
`thinking={"type":"disabled"}` (pitfall #9).

### 4. Token Budget for Reasoning Models

Reasoning models use tokens for **both** thinking and output. When setting `max_tokens`,
account for the reasoning overhead:

| Use Case | Recommended `max_tokens` | Why |
|----------|-------------------------|-----|
| Health check / ping | 50–100 | Need room for short response after reasoning |
| Short classification | 200–500 | Allow brief reasoning + short output |
| Complex analysis | 1000–2000+ | Plenty of room for reasoning + substantive response |

### 5. Production Retry Recipe (validated on persona-db API, 2026-07/08)

> ⚠️ **SUPERSEDED on the retry side by #11 (2026-08-13).** The `max_tokens *= 2` doubling
> below is the **token-maximize anti-pattern** — it starts small (guaranteed fail for pro,
> whose reasoning eats the budget) and re-pays the full reasoning on every retry. Use #11
> instead: resolve budget upfront by model, retry only on `finish_reason=length`. The
> 5xx-backoff and truncated-JSON rules in this #5 still hold.

The empty-content fix alone is not enough in production — reasoning models fail in
multiple distinct ways, each needing its own retry. Pattern proven on the persona-db
`/candidates` API (deepseek-v4-flash, lzc-dh1/lzcdh5):

```python
for attempt in range(3):
    try:
        resp = await client.post(..., json={..., "max_tokens": max_tokens})
        resp.raise_for_status()          # 503/429/5xx → exception → backoff retry
        message = data["choices"][0].get("message", {})
        content = message.get("content") or ""
        reasoning = message.get("reasoning_content") or ""
        if content.strip():
            return content
        if reasoning and attempt < 2:
            max_tokens *= 2              # thinking ate the budget — retry bigger
            await asyncio.sleep(1)
            continue
        return content                   # genuinely empty
    except Exception as e:
        if attempt < 2:
            await asyncio.sleep([1, 3, 7][attempt])   # exponential backoff
            continue
        return None
```

Rules learned in production:

- **Three distinct failure modes, three distinct responses**: HTTP 5xx → backoff retry
  (1s/3s/7s); empty content + `reasoning_content` present → double `max_tokens` and
  retry; truncated/invalid JSON in the answer → re-call + re-parse once.
- **Analysis prompts need base `max_tokens` ≥ 4000** — 2000 gets consumed by reasoning
  for complex question-analysis prompts (root cause of intermittent FILTER_FAILED).
- **Never silently return "match everything" on analysis failure** — if filters can't
  be derived, return a clear 503 instead of an unfiltered result set. The bug surfaced
  as `persona_ids: [1,2,3]` (first 3 of all 1069 personas) when empty filters fell
  through to an unfiltered query.
- **Retry sleeps must be `asyncio.sleep`** inside the async function, never `time.sleep`.
- **Verify deployed code freshness before debugging** — a VM container may run an old
  `llm.py` from before the fix (stale `__pycache__`/image); check
  `docker exec <container> grep -c <new-marker> /app/api/llm.py` first.

### 6. Non-Deterministic Filters → Empty Downstream Intersection (filter relaxation)

Even with a successful LLM call, **LLM-generated structured output is non-deterministic**
(temperature 0.2 still varies run to run). When the LLM emits an over-specific filter
combination that has no valid intersection in the downstream dataset, you get a
confusing "0 results" — **not** an error (filters exist, LLM succeeded).

Real case (persona-db): query "TESLA的目標客戶" → LLM returned
`occupation=[自營] + age=[35-44]`, but the dataset's 9 自營 personas are 2×25-34 +
7×45-54 — zero 35-44 → `total_matched: 0` intermittently while other runs returned
19–249. Diagnosis: count the actual distribution of the filter combination in the data
before assuming a code bug.

**Fix pattern — deterministic relaxation, not retry:**

```python
# When strict filters match 0, drop dimensions one at a time (least-important first)
# until non-empty. No extra LLM call — pure computation.
dim_order = ["sex", "marriage", "education", "income", "age", "residence",
             "family_income", "occupation", "commute_mode", "housing_burden", "clothing_spend"]
for dim in dim_order:
    if dim not in filters:
        continue
    relaxed = {k: v for k, v in filters.items() if k != dim}
    matched = filter_personas(db, relaxed)
    if matched:
        filters = relaxed
        relaxed_dims.append(dim)
        break
```

Rules learned:

- **Surface what was relaxed** — add a `relaxed_dims: []` field to the response so
  callers know the result came from a loosened filter, not the original intent.
- **Don't use random tie-breaking** for ranked results — it re-introduces the same
  non-determinism you're trying to eliminate. Prefer stable dataset order.
- **If you later add scoring**, relaxed dimensions should still contribute at a discount
  (e.g. ×0.5) so the closest-to-intent candidates rank first despite relaxation.
- **Verify with repeated calls** — hit the endpoint 5× with the same query; with
  non-deterministic LLM output, intermittent bugs only reproduce sometimes.

### 7. LLM Structured JSON Values Come Back as Strings (coerce before arithmetic)

When you prompt an LLM to emit a structured JSON object with numeric fields (weights,
scores, importance values like `"importance": 0.9`), the model frequently returns them
as **strings** (`"0.9"`) or even **range strings** (`"0.8~1.0"`, `"high~low"`) because
the prompt's example/placeholder spelled them loosely. This bites the moment you do math:

```python
# BUG: imp is "0.95" (str), tm is 0.7 (float)
s += imp * tm * rw
# TypeError: can't multiply sequence by non-int of type 'float'
```

Real case (persona-db `score_persona`, issue #14 v4.7.1): `dim_importance` came back
from the LLM as `{"income": "0.95", "age": "0.8~1.0"}` → every `role=` query 500'd.

**Fix — coerce at the boundary with a tolerant helper:**

```python
import re
def _to_float(v, default=0.5):
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        m = re.match(r"(\d+\.?\d*)", v.strip())   # grabs "0.95" out of "0.8~1.0" too
        if m:
            return float(m.group(1))
    return default
```

Rules learned:
- **Never trust LLM JSON numeric fields to be actual numbers.** Coerce every numeric
  field you consume (weights, scores, counts, temperatures) through a tolerant parser.
- **Prefer the LLM prompt to ask for plain numbers** (e.g. `"importance": 0.0~1.0 的數值`),
  but still coerce defensively — prompt wording reduces, not eliminates, the drift.
- **Range strings like `"0.8~1.0"` are common when the prompt showed a placeholder
  `0.8~1.0`** — the model copies the placeholder shape literally. Either give a concrete
  example number (`"importance": 0.9`) or parse the leading number out of the range.

### 8. Reasoning-Only Empty Content: Extract the Answer, Don't Retry Forever

The "double `max_tokens` and retry" pattern (pitfall #5) works for a model that briefly
overshoots its budget, but **fails catastrophically for heavy reasoning models**
(deepseek-v4-pro) that *consistently* spend every token on thinking and return empty
`content` no matter how large `max_tokens` gets. Result: multi-minute hangs as the retry
loop ping-pongs 4000→8000→4000→8000.

The answer is usually **inside `reasoning_content`** — reasoning models often write the
final JSON/answer at the end of their chain-of-thought. Extract it instead of retrying:

```python
def _extract_json_or_text(text):
    if not text or not text.strip():
        return ""
    if "```json" in text:
        return text.split("```json", 1)[1].split("```", 1)[0].strip()
    if "```" in text:
        return text.split("```", 1)[1].split("```", 1)[0].strip()
    stripped = text.strip()
    return stripped  # bare JSON object or plain text; caller parses

# in the call loop:
content = message.get("content") or ""
reasoning = message.get("reasoning_content") or ""
if content.strip():
    return content
if reasoning:
    extracted = _extract_json_or_text(reasoning)
    if extracted:
        return extracted                       # ← don't retry, use what the model thought
    if attempt < 2 and "flash" not in model.lower():
        max_tokens *= 2
        await asyncio.sleep(1)
        continue
return content  # genuinely empty
```

Rules learned:
- **Try to harvest `reasoning_content` before retrying** — for heavy reasoning models the
  chain-of-thought contains the deliverable; a blind retry only adds latency.
- **Keep the retry as the fallback**, not the primary response, when extraction yields nothing.

**⚠️ CORRECTION (2026-08-12, verified): the `"flash" not in model.lower()` gate is WRONG.**
deepseek-v4-flash **is** a reasoning model too — it returns `reasoning_content` and, on a
large prompt, hits `finish_reason=length` with empty `content` exactly like pro. On a 5-query
probe, flash (unpatched) returned `finish_reason=length` with `content=None` + a 6–14KB
`reasoning_content` on 3/5 queries. Do NOT assume "flash = no reasoning". Detect reasoning
by *presence of `reasoning_content` in the response*, not by model name.

### 9. Disable Reasoning Mode Entirely with `thinking={"type":"disabled"}`

For OpenAI-compatible reasoning models, the cleanest fix for the empty-content problem is
often to **turn reasoning off** rather than fight it with bigger budgets. DeepSeek's API
accepts a `thinking` request param:

```python
payload = {
    "model": "deepseek-v4-flash",
    "messages": [...],
    "max_tokens": 4000,
    "thinking": {"type": "disabled"},   # ← no reasoning_content, direct content only
}
```

Verified (persona-db, issue #14): flash went from **3/5 queries `finish_reason=length`
+ empty content (~85s each)** to **5/5 valid JSON in ~3s each** with `thinking=disabled`.
`finish_reason` flipped to `stop`, `content` was non-empty, `reasoning_content` absent.

Rules learned:
- **Probe the model's reasoning behaviour before writing retry logic.** A tiny
  `"Say OK only"` probe with `max_tokens=50` reveals whether `reasoning_content` appears
  at all and whether `thinking` is accepted (probe `thinking={"type":"disabled"}` and
  `enable_thinking=false` — the exact param name/values vary by provider; DeepSeek wants
  `{"type":"disabled"}`, not a boolean).
- **`thinking=disabled` beats "bigger max_tokens" for flash** — flash's reasoning is
  verbose self-talk that eats any budget you give it; more tokens = longer thinking, not
  more answer. Disabling reasoning gives deterministic fast JSON.
- **Reasoning on/off is a quality-vs-latency dial.** pro (reasoning ON) gives richer,
  more dimension-complete filters but ~85s; flash (reasoning OFF) gives fast ~3s output
  that may miss some dimensions. Match the model+reasoning setting to the requirement.
- **`finish_reason=length` is the smoking gun** for "reasoning ate the budget" — read it
  from the response before assuming a network/parse bug.

### 10. Structured-Output Prompt Example Must Be Valid JSON (verify after edits)

When you prompt an LLM to return structured JSON, the **example/placeholder JSON you put in
the prompt must itself be valid JSON**. Adding a field to the example is exactly where it
breaks: a missing closing brace nests the new field inside the previous object, or a stray
`}` is left behind — and the model then copies the broken structure into its real output.

Real case (persona-db, issue #13): adding a `dim_importance` object to the prompt's output
example omitted the `},` that closed `filters`, so `dim_importance` rendered *inside*
`filters`, plus a leftover `}}`. The model's `dim_importance` came back empty or misplaced,
and every `?role=` query silently lost its importance weighting.

**Fix — render + re-parse the example after every edit:**

```python
rendered = PROMPT.format(**placeholders)      # actual text the model sees
# slice the JSON example region, wrap in braces, and json.loads() it
json.loads("{" + rendered[rendered.find('"filters"'):rendered.find('"question_analysis"')] + "}")
```

Rules learned:
- **Verify the prompt's JSON example is parseable after every edit that touches it** — the
  example is the model's template; a broken template produces broken output.
- **Watch for `{{`/`}}` escaping** when the prompt is a Python `.format()`/f-string template:
  `{{` → literal `{`, `}}` → literal `}`. A stray `}}` in the source is a stray `}` in the
  rendered prompt.
- This pairs with pitfall #7: the *example* must be structurally valid AND the *returned*
  numeric values must be coerced — both are the same "LLM structured output is not trustworthy"
  theme, guarded at two different boundaries.

**Adjacent lesson (v4.9.0): a strict value-enumeration in the prompt must be COMPLETE.**
When a prompt tells the model "only use these values" (`只能使用下列值，不要發明不存在的值`)
but the list omits a legitimately-valid option, the model treats the unlisted option as
*forbidden* and silently drops it from its output — the inverse failure of the model
inventing out-of-set values (pitfall #6/#25 territory). Real case: a broadening prompt's
valid-values list omitted `housing_burden` (which the downstream schema accepted), so the
model wrote "移除無效維度 housing_burden" and deleted a valid filter. Fix: enumerate
*every* valid option (derive from the actual data's distinct values, not from memory), or
soften the instruction. Same theme as #10/#7: the prompt's declarative content must match
ground truth, and a strictness instruction amplifies any mismatch.



### 11. Cost Firewall: Resolve Budget Upfront, Don't Double-Retry (issue #24)

The `max_tokens *= 2` doubling in #5 is a **cost anti-pattern** for reasoning models: it
*starts small* (guaranteed to fail for pro, whose reasoning consumes 85-90s of tokens),
then re-sends the FULL prompt and re-pays the reasoning on every retry. User directive
(2026-08-13): "別讓我們虧本了，我們不搞 token maximize".

Four-layer firewall (spec: `specs/2026-08-13-llm-retry-firewall.md`):

- **L1 — resolve `max_tokens` by model upfront** (no "start small, double later"):
  `pro → 8000` (reasoning + JSON in one shot), `flash → thinking=disabled + 2000`.
  Compute once per call site: `mt = 8000 if "pro" in model.lower() else requested`.
- **L2 — retry ONLY on `finish_reason == "length"` (truncation)**, max 1 retry, `+50%`
  (not ×2). `reasoning_content` present but no JSON **and** `finish_reason != length` means
  the model genuinely failed → return None, do NOT retry. Truncation is the *only*
  "not enough tokens" signal; everything else is a wasted re-call.
- **L3 — harvest `reasoning_content` before deciding to retry** (already paid for; see #8).
- **L4 — per-request token budget + circuit breaker**: cap total LLM spend per request
  (e.g. analysis 1×8000 + ≤3 broadening ×8000 = 32K ceiling); after N consecutive
  non-truncation failures, enter cooldown and return partial results instead of hammering.

**Concrete bug this catches (persona-db v4.8.2):** the *broadening loop* called the pro
model with `max_tokens = 1000 if loop > 1 else 2000` — too small, so pro's reasoning ate
the whole budget, `content` came back empty (`finish_reason=length`), the loop did
`if not result: break` **silently**, and `broadening_attempts` stayed `[]` while the query
returned `total_matched=3` (far below TARGET_MIN=20) with no broadening. This is the
*4th instance* of the same class as reasonableness_review 800 / analysis 4000 / broaden
2000 — **every call site that hits a reasoning model needs L1's model-aware budget, not
just the main analysis call.** Symptom: a downstream loop that "silently didn't fire" +
the count stuck low.

Verification: unit-test "reasoning-only + `finish_reason != length` → NO retry, return
None"; unit-test "`finish_reason == length` → retry 1× +50%"; then a before/after token
usage diff on a fixed query batch (target −40%+).

**Implemented & unit-verified (persona-db, 2026-08-13):** the firewall is live —
`api/llm.py` has `_resolve_max_tokens` (L1), a `truncation_retried` flag (L2, ensures the
+50% retry fires at most once even across network-retry interleavings), and
`_circuit_open` / `_record_failure` / `_record_success` (L4 circuit breaker:
`CIRCUIT_FAIL_THRESHOLD=3`, `CIRCUIT_COOLDOWN_S=60`, timer via `time.monotonic()`);
`api/server.py` has `TOKEN_BUDGET=32000` + a `tokens_spent` accumulator checked in the
broadening-loop `while` condition. Circuit-breaker semantics to copy:
- `_record_success()` resets the counter on ANY success — content **or** harvested
  reasoning — not just full content.
- `_record_failure()` fires on BOTH the garbage path (reasoning-only, non-truncated) and
  the post-backoff network path — any `return None` is a failure, not just exceptions.
- the `_circuit_open()` check runs at the TOP of `call_llm`, before the API call, so a
  tripped breaker returns None without spending a single token.


- **deepseek-v4-flash API accepts both `deepseek-chat` and `deepseek-v4-flash`** as model
  names. `deepseek-flash` (without v4) is NOT accepted (returns 400).
- **Reasoning models may include `reasoning_content` in the response** even when the
  API doesn't advertise it — always check for this field.
- **Streaming responses differ:** reasoning content arrives in separate delta chunks
  labeled with `reasoning_content` before the `content` deltas.
