---
name: collaboration-contract
description: "多角色協作協定 — Domain 分工（a2=lzc-cp, a3=persona-db, a945=整合）、角色間單一介面（Contract-per-Pair）、TODO|WIP|Pending(等誰)|Done 狀態機。證明 kstsai+夥計們強韌可靠。"
version: 1.1.0
author: hermesa2 + a945 (設計討論 2026-08-07 with kstsai, 更新 2026-08-07 by a945)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [collaboration, multi-agent, contract, pipeline, workflow, qa]
    related_skills: [wayfinder-tickets, grill-me, tutorlog-contributor]
---

# Collaboration Contract（多角色協作協定）

> 人讀版：Obsidian wiki `entities/collaboration-contract.md`
> Agent 執行版（本 skill）。目標：證明 kstsai + 夥計們**強韌、可靠**。

## Domain 定位（誰負責什麼）

| 角色 | Domain | 職責 |
|:-----|:-------|:-----|
| kstsai | 全貌 | 定方向、裁決、驗收 |
| hermesa2 | **lzc-cp** | k3s/KubeEdge、SOP、測試環境 |
| hermesa3 | **persona-db** | persona 生成/驗證、API、release |
| hermesa945 | **跨域整合** | wiki 消化、e2e review、capability matrix |

**原則：Domain 決定誰接手。kstsai 不需指派。**

## 你的義務

- **改 skill 後必跑 `bash ~/lab-riscv/scripts/sync-skills.sh <agent>`** 同步到 lab-riscv（`ai-agents/<agent>/skills/`）。這是**可檢查的步驟**，不是靠記憶的義務：改完 skill 就執行、執行完才算完成；無 drift 會回「no drift」、有 drift 會自動 commit+push。**新 custom skill 要先在 lab-riscv 註冊一次**（建 `ai-agents/<agent>/skills/<path>/`），之後這支 script 自動保持同步。
- 下次 incoming 包告訴 a945，a945 更新 capability matrix
- Grill-me 討論：domain 內直接找對應 agent，跨域找 a945

## 核心原則：角色間單一介面（Contract-per-Pair）

```
角色 A ────[ 單一介面 ]──── 角色 B
            ├─ 位置（inbox/、issue、目錄）
            ├─ 格式（契約：交付什麼）
            ├─ 流程（A 寫 → B 取 → 確認）
            └─ 確認（B 回報狀態）
```

- ❌ 禁止：直接丟任務給對方對話裡等回應（會製造 bottleneck）
- ✅ 正解：寫入明確介面，對方自行取出（非同步 pipeline）

**黃金範例：**
```
a2 寫 wiki-digest → a945/incoming/ → a945 取出 → obsidian wiki
```

## 狀態機：TODO | WIP | Pending(等誰) | Done

| 狀態 | 意義 | 載體表示 |
|:-----|:-----|:---------|
| TODO | 待取用 | open, no assignee |
| WIP | 進行中 | assignee + In Progress |
| Pending(等誰) | 等別人 | `Pending(a945 review)` 必帶等誰 |
| Done | 完成（含驗證） | Closed + ✅ |

**Pending 鐵律：必須帶「等誰」— 等待分散，消滅 kstsai bottleneck。**

## 標準流程

```
grill-me → to-spec → to-tickets → 執行 → e2e review → Done
```

**Review 鐵律：** reviewer 必須跑完整 e2e 驗證，不做靜態檢查式 approve。
