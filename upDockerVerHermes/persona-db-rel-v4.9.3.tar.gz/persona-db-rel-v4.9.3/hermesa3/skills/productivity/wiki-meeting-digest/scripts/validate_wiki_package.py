#!/usr/bin/env python3
"""Validate a wiki-meeting-digest portable package before handoff to integrator.

Usage: python3 validate_wiki_package.py <package_dir>
Checks: structure, frontmatter, wikilinks, sha256, manifest completeness, cross-refs.
Returns exit 0 (pass) / 1 (issues found).
"""
import sys, os, re, hashlib, json, time, urllib.request

PACKAGE = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser("~/wiki-digests")
issues = []
warnings = []

REQ_FRONTMATTER = ["title", "created", "updated", "type", "tags"]
RAW_FRONTMATTER = ["ingested", "sha256"]  # raw/ files use different schema
TYPES = {"summary", "entity", "concept", "query", "raw"}
EXPECTED_DIRS = {"raw", "entities", "concepts", "summaries"}
EXPECTED_FILES = {"MANIFEST.md", "log-entry.md"}
META_FILES = {"MANIFEST.md", "log-entry.md"}  # no frontmatter/wikilink requirements

# Pages the target wiki already has — 自動同步自 linkEazyCenter（canonical backup）。
# 不再 hardcode（issue lab-riscv#33）：新頁 ingest 後下包自動反映，避免「新頁→下包誤報 broken」。
CROSS_WIKI_FALLBACK = [
    "grill-me-workflow", "persona-db-release-workflow", "persona-db",
    "wiki-meeting-digest", "wiki-package-validation",
    "2026-08-05-wiki-digest-workflow-weekly-digest",
    "2026-08-05-persona-db-v4.2-weekly-digest",
    "deepseek-harness-architecture", "deepseek-harness-pod",
    "lzc-cp", "tailscale-mesh",
    "dsh-browser-trust-fence", "dsh-nginx-https-access",
    "llm-retry-firewall", "pre-release-sop", "data-verification-loop",
    "deploy-env-chain", "coherence-rule-design",
]


def _git_token():
    try:
        for line in open(os.path.expanduser("~/.git-credentials")):
            if "github.com" in line:
                # https://[user:]TOKEN@github.com → TOKEN
                cred = line.strip().replace("https://", "").replace("@github.com", "")
                return cred.split(":")[-1]
    except OSError:
        pass
    return None


def _fetch_wiki_slugs():
    """Fetch existing page slugs (md filenames) from linkEazyCenter, with 30-min cache."""
    cache = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".wiki_slugs_cache.json")
    # 1. fresh cache
    try:
        st = os.stat(cache)
        if time.time() - st.st_mtime < 1800:
            with open(cache) as f:
                slugs = json.load(f)
                if slugs:
                    return set(slugs)
    except (OSError, ValueError):
        pass
    # 2. fetch from GitHub
    slugs = set()
    try:
        token = _git_token()
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        req = urllib.request.Request(
            "https://api.github.com/repos/kstsai/linkEazyCenter/git/ref/heads/main", headers=headers)
        ref = json.loads(urllib.request.urlopen(req, timeout=10).read())
        sha = ref["object"]["sha"]
        req = urllib.request.Request(
            f"https://api.github.com/repos/kstsai/linkEazyCenter/git/trees/{sha}?recursive=1", headers=headers)
        tree = json.loads(urllib.request.urlopen(req, timeout=15).read())
        for item in tree.get("tree", []):
            p = item["path"]
            if p.endswith(".md"):
                slugs.add(os.path.splitext(os.path.basename(p))[0])
        if slugs:
            try:
                with open(cache, "w") as f:
                    json.dump(sorted(slugs), f)
            except OSError:
                pass
            return slugs
    except Exception as e:
        print(f"  ⚠️ wiki slug fetch failed ({e})")
    # 3. stale cache (any age) as last resort before fallback
    try:
        with open(cache) as f:
            slugs = json.load(f)
            if slugs:
                return set(slugs)
    except (OSError, ValueError):
        pass
    return set(CROSS_WIKI_FALLBACK)


CROSS_WIKI = _fetch_wiki_slugs()

# ── 1. Structure ──
print("=== 1. Structure ===")
for d in EXPECTED_DIRS:
    if not os.path.isdir(os.path.join(PACKAGE, d)):
        issues.append(f"missing dir: {d}/")
    else:
        files = [f for f in os.listdir(os.path.join(PACKAGE, d)) if f.endswith(".md")]
        print(f"  {d}/: {len(files)} file(s)")
for f in EXPECTED_FILES:
    if not os.path.isfile(os.path.join(PACKAGE, f)):
        issues.append(f"missing file: {f}")

# ── 2. Frontmatter ──
print("\n=== 2. Frontmatter ===")
all_md = []
for root, _, files in os.walk(PACKAGE):
    for f in files:
        if f.endswith(".md"):
            all_md.append(os.path.join(root, f))

pages = {}  # slug -> (path, tags, type)
for path in all_md:
    rel = os.path.relpath(path, PACKAGE)
    basename = os.path.basename(path)
    if basename in META_FILES:
        print(f"  {rel}: meta file (skipped)")
        continue
    content = open(path).read()
    if not content.startswith("---"):
        issues.append(f"{rel}: no frontmatter")
        continue
    fm_text = content.split("---", 2)[1]
    fm = {}
    for line in fm_text.strip().splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip()
    if os.path.dirname(rel) == "raw":
        missing = [k for k in RAW_FRONTMATTER if k not in fm]
        if missing:
            issues.append(f"{rel}: raw missing frontmatter {missing}")
    else:
        missing = [k for k in REQ_FRONTMATTER if k not in fm]
        if missing:
            issues.append(f"{rel}: missing frontmatter {missing}")
        if fm.get("type") not in TYPES:
            issues.append(f"{rel}: invalid type '{fm.get('type')}'")
        if not fm.get("updated"):
            warnings.append(f"{rel}: no updated date")
    slug = os.path.splitext(basename)[0]
    pages[slug] = (rel, fm.get("tags", ""), fm.get("type", ""))
    print(f"  {rel}: type={fm.get('type','?')} tags={fm.get('tags','?')[:40]}")

# ── 3. Wikilinks ──
print("\n=== 3. Wikilinks ===")
for path in all_md:
    rel = os.path.relpath(path, PACKAGE)
    basename = os.path.basename(path)
    content = open(path).read()
    links = re.findall(r"\[\[([^\]]+)\]\]", content)
    if len(links) < 2 and basename not in META_FILES and os.path.dirname(rel) != "raw":
        warnings.append(f"{rel}: only {len(links)} wikilink(s) — need >=2")
    for link in links:
        target = link.split("|")[0].strip()
        if target not in pages and target not in CROSS_WIKI:
            issues.append(f"{rel}: broken wikilink [[{target}]]")
    print(f"  {rel}: {len(links)} links {links[:4]}")

# ── 4. Raw sha256 ──
print("\n=== 4. Raw sha256 ===")
raw_dir = os.path.join(PACKAGE, "raw")
if os.path.isdir(raw_dir):
    for raw in os.listdir(raw_dir):
        raw_path = os.path.join(raw_dir, raw)
        content = open(raw_path).read()
        if not content.startswith("---"):
            issues.append(f"raw/{raw}: no frontmatter")
            continue
        body = content.split("---", 2)[2]
        actual = hashlib.sha256(body.encode()).hexdigest()
        actual_lstrip = hashlib.sha256(body.lstrip().encode()).hexdigest()
        m = re.search(r"sha256:\s*([0-9a-f]{64})", content.split("---", 2)[1])
        if not m:
            issues.append(f"raw/{raw}: no sha256 in frontmatter")
        elif m.group(1) not in (actual, actual_lstrip):
            issues.append(f"raw/{raw}: sha256 MISMATCH — body changed after ingest?")
        else:
            print(f"  raw/{raw}: sha256 OK")

# ── 5. MANIFEST completeness ──
print("\n=== 5. MANIFEST ===")
if os.path.isfile(os.path.join(PACKAGE, "MANIFEST.md")):
    manifest = open(os.path.join(PACKAGE, "MANIFEST.md")).read()
    # Only count source files in the 檔案對應表 (first column of table rows)
    listed = set()
    for line in manifest.splitlines():
        m = re.match(r"\|\s*`([^`]+\.md)`\s*\|", line)
        if m:
            listed.add(m.group(1))
    real = set(os.path.relpath(p, PACKAGE) for p in all_md if os.path.basename(p) not in META_FILES)
    # log-entry.md is a meta file but IS a listed deliverable in MANIFEST
    listed.add("log-entry.md")
    listed_not_real = (listed - real) - {"log-entry.md"}
    missing_from_manifest = real - listed
    if missing_from_manifest:
        issues.append(f"MANIFEST missing files: {missing_from_manifest}")
    if listed_not_real:
        issues.append(f"MANIFEST lists nonexistent: {listed_not_real}")
    print(f"  manifest lists {len(listed)} files; package has {len(real)}")

# ── 6. Cross-reference (both directions) ──
print("\n=== 6. Cross-references ===")
inbound = {slug: 0 for slug in pages}
for path in all_md:
    for link in re.findall(r"\[\[([^\]]+)\]\]", open(path).read()):
        t = link.split("|")[0].strip()
        if t in inbound:
            inbound[t] += 1
orphans = [s for s, c in inbound.items() if c == 0 and s not in ("log-entry", "session-summary-2026-07-30") and not s.startswith("session-summary-")]
if orphans:
    warnings.append(f"orphan pages (no inbound links): {orphans}")
print(f"  pages with inbound links: {sum(1 for c in inbound.values() if c>0)}/{len(inbound)}")

# ── Summary ──
print("\n" + "=" * 50)
print(f"RESULT: {len(issues)} issues, {len(warnings)} warnings")
if issues:
    print("\n❌ ISSUES:")
    for i in issues:
        print(f"  - {i}")
if warnings:
    print("\n⚠️ WARNINGS:")
    for w in warnings:
        print(f"  - {w}")
if not issues:
    print("✅ Package passes validation — ready for integrator handoff.")
sys.exit(1 if issues else 0)
