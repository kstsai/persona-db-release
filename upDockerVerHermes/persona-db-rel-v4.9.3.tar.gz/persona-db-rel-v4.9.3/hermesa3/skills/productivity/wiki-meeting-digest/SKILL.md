---
name: wiki-meeting-digest
version: 1.1.0
description: "Prepare a meeting/session digest as a portable wiki-ready package (Karpathy LLM Wiki pattern) — frontmatter + wikilinks + manifest, ingestible into any LLM wiki."
tags: [meeting, summary, wiki, karpathy, knowledge-base, portable]
---

# Wiki Meeting Digest

> 把一次工作 session / 週會摘要，產出一包**標準化、wiki-ready** 的 markdown 檔案，
> 讓任何 LLM wiki（hermesa2 / a3 / a945 / kstsai-self 等）都能直接 ingest。

## Team Workflow（團隊協作協議）

```
a2/a3 產包 → 自動驗證（0 issues 才出貨）
  → a945 整合進 Obsidian vault + backup 到 linkEazyCenter
  → kstsai 看 Obsidian 產出結果（post-hoc review）
      ├─ OK → 該頁標記 reviewed（或搬出 pending 資料夾）
      └─ 要改 → 找產包 agent 改 → 重跑驗證 → a945 更新 → 再 review
```

- **自動驗證是唯一 gate**（結構品質，不需人）
- **kstsai 審批從整合前移到整合後** — 避免 bottleneck
- a945 是唯一整合者；kstsai 看最終 Obsidian 結果，有問題找產包者改
- 修改只影響那一頁，不需整包重來（因為結構已被驗證保證乾淨）

## Trigger Conditions

- 「幫我整理會議摘要」
- 「準備週會報告」
- 「把這次做的事整理成文件」
- 「產出可以進 wiki 的摘要」
- **「把工作流本身的建立過程打包一次」** — meta-digest：當主題是「這個 workflow 怎麼來的」（skill 建立、協定設計、首跑結果），照樣用本 skill 產包，entity 頁放 skill 本體、concept 頁放驗證 gate、raw 放決策流水（2026-08-05 首例）

## Output: Portable Wiki Package

產出一組檔案（預設放在 `~/wiki-digests/YYYY-MM-DD-<topic>/`）：

```
wiki-digests/
└── 2026-07-30-persona-db-v4/
    ├── MANIFEST.md          # 包裝說明 + 每個檔案的目標 wiki 路徑
    ├── raw/
    │   └── session-summary-2026-07-30.md   # 原始 session 摘要（含 sha256 frontmatter）
    ├── entities/
    │   └── persona-db.md    # 主要 entity
    ├── concepts/
    │   └── family-income-tiers.md  # 重要概念
    ├── summaries/
    │   └── 2026-07-w4-weekly-digest.md   # 會議摘要主體
    └── log-entry.md         # 要 append 到 wiki log.md 的 entry
```

每個檔案都有完整 frontmatter（title/created/updated/type/tags/sources），
並用 `[[wikilinks]]` 互相連結。目標 wiki 直接照 MANIFEST 搬到對應目錄即可。

## Team Workflow (kstsai 團隊)

團隊成員：hermesa2 / hermesa3 (a3) / a945 / kstsai。共用一個 Obsidian vault。

**分工：**
| 角色 | 職責 |
|:----|:-----|
| a2 / a3 | 產生 ingest data（本 skill 產出的 portable package） |
| **唯一整合者 (a945)** | 把 package 整理進 MacBook 上的 Obsidian vault |
| kstsai | **post-hoc review**（看 Obsidian 產出結果，有問題找產包者改） |
| backup | 整合後 duplicate 一份到 `github.com/kstsai/linkEazyCenter` |

**流程（2026-08-05 起，審批 gate 已移除 — 避免 bottleneck）：**
```
a2/a3 產出 package → validate（綠燈）→ a945 整合進 Obsidian vault → backup 到 linkEazyCenter
  → kstsai 看 Obsidian 產出結果
      ├─ OK → 該頁標記 reviewed
      └─ 要改 → 找產包 agent 改 → 重跑驗證 → a945 更新 → 再 review
```

⚠️ 本 skill 產出的是「給整合者的交接包」，不是直接寫入 wiki。
MANIFEST.md 是交接單 — 標明每個檔案給誰、merge 到哪、backup 到哪。

## Validation (出貨前檢查)

Package 產出後、handoff 給 a945 前，**必須**跑驗證：

```bash
python3 scripts/validate_wiki_package.py <package_dir>
```

檢查 6 項：structure / frontmatter / wikilinks / raw sha256 / MANIFEST completeness / cross-refs。
Exit 0 = 綠燈可交接；exit 1 = 有 issue 要修。

**常見 validator 抓到並需修正的：**
- summary 頁的 wikilink 指向「既有 wiki 頁」→ cross-wiki 連結。**CROSS_WIKI 白名單已改為自動同步**（issue lab-riscv#33）：validator 產包時會動態 fetch linkEazyCenter 的 git tree，取全部 .md filename 當 slug 集合，30-min 本地 cache + 離線 fallback。**不再需要手動把新 slug 加進 `validate_wiki_package.py`** — 新頁 ingest 後，下次產包（或 cache 過期後）自動反映。
- 跨 digest 的 wikilink（指向前一個 package 產出的頁）也由上面的自動同步涵蓋。若 validate 仍報 `broken wikilink`，表示目標頁**真的還不在 wiki**（尚未被 a945 ingest），不是白名單漏了 — 此時要確認該頁是否已產出/已 ingest，而非改白名單。
- **`entities/` 目錄是 validator 的硬性檢查（`EXPECTED_DIRS` 含 4 目錄），缺了直接 `missing dir: entities/` exit 1** — 即使 digest 主題是純 concept（如 retry 防火牆這種功能），也要至少放一個 entity 頁，放「被修改/涉及的系統」即可（如 `entities/persona-db.md`，MANIFEST 註明 merge 更新）。不要以為 concept-only digest 可以省略 entities/。
- raw/ 檔的 frontmatter 用不同 schema（ingested + sha256），不是一般頁面的 title/created/type/tags
- MANIFEST 解析只認表格第一欄的 source file，不是內文的 target path

## Steps

### 0. Check Date FIRST

**每次產 wiki-digest 前，先確認真實日期** — session 可能跨天、conversation context 日期可能錯、git commit date 可能被 rebase 偏移。

```bash
TZ='Asia/Taipei' date '+%Y-%m-%d'
```

- 目錄名 `YYYY-MM-DD-<topic>/` 的日期**必須與真實日曆日期一致**
- Frontmatter `created`/`updated` 用此日期
- Raw file `ingested` 用 session 開始日期（通常和目錄名同一天）
- **不要**依賴 conversation context 日期或 git commit date
- **不確定的話寧可不寫日期也不要寫錯**（從 collaboration-contract.md 學到的教訓，hermesa945 也犯過相同錯誤）

### 1. Gather Context

- 問 user 這次 session 的主題/時間範圍
- 如果有 repo：`git log --oneline --since=<range>` 抓 commits
- 讀既有 worklog / spec / verification report
- 掃 `~/lab-riscv/tutorlogs/` 看有沒有相關筆記

### 2. Draft the Digest (wiki-ready)

依 LLM Wiki pattern 產出：

| 檔案 | 內容 | 目標路徑 |
|:----|:-----|:---------|
| `MANIFEST.md` | 每個檔案要搬到哪個 wiki 的哪個目錄 | wiki root |
| `raw/session-summary-*.md` | 完整 session 流水（含 sha256 frontmatter） | `raw/transcripts/` |
| `entities/*.md` | 這次觸及的主要 entity（persona-db, lzc-dh1, deploy script…） | `entities/` |
| `concepts/*.md` | 重要概念（family-income-tiers, grill-me workflow…） | `concepts/` |
| `summaries/*-weekly-digest.md` | 會議摘要主體（週報用） | `queries/` 或自訂 |
| `log-entry.md` | 給 wiki log.md 的 append entry | log.md |

**Frontmatter 模板：**
```yaml
---
title: <Title>
created: YYYY-MM-DD    # session 開始日期（目錄名對齊此日期）
updated: YYYY-MM-DD    # 打包時間（可能與 created 不同，例：session 跨天）
type: summary | entity | concept | raw
tags: [from SCHEMA taxonomy]
sources: [raw/transcripts/session-summary-YYYY-MM-DD.md]
---
```

**雙時間戳慣例（from collaboration-contract.md pattern，2026-08-11 定案）：**
- `created` = session 開始的日曆日期（目錄名 `YYYY-MM-DD-` 對齊此值）
- `updated` = **打包當下的真實日期**（`TZ='Asia/Taipei' date '+%Y-%m-%d'`）
- session 跨天時兩者不同（例：8/10 開始、8/11 凌晨打包 → created=8/10, updated=8/11）
- MANIFEST 註明雙時間戳（`產出日期: session date | 打包時間: packaging time`）
- **目錄名不因跨天而改**（維持 session date — source of truth）
- 學習自 collaboration-contract.md 的 `created`/`updated` frontmatter 慣例

**Raw file frontmatter：**
```yaml
---
source_url: <optional>
ingested: YYYY-MM-DD
sha256: <hex of body>
---
```

### 3. Cross-reference with Wikilinks

- 每頁至少 2 個 `[[wikilinks]]` 連到同包其他頁
- 摘要主體把 entity/concept 頁都連上
- MANIFEST 標註每個檔案的目標路徑 + 是否需要 merge 到既有頁

### 4. Present to User

- 先展示摘要主體（會議用）
- 再列出 package 檔案清單，問是否要調整
- 確認後產出檔案

### 5. Validate the Package (出貨前檢查)

產出後**必須**跑 validator，綠燈才可交付：

```bash
python3 <skill_dir>/scripts/validate_wiki_package.py <package_dir>
```

檢查 6 項：

| # | 檢查 | 內容 |
|:-:|:-----|:-----|
| 1 | Structure | 目錄結構 + 必備檔（MANIFEST, log-entry） |
| 2 | Frontmatter | 每頁必備欄位（raw 用不同 schema）+ type/tags 合法性 |
| 3 | Wikilinks | 每頁 ≥2 links、無 broken links（cross-wiki links 白名單） |
| 4 | Raw sha256 | raw body hash 與 frontmatter 一致 |
| 5 | MANIFEST | manifest 列的檔案 = 實際檔案（雙向比對） |
| 6 | Cross-refs | 無 orphan pages |

**驗證失敗的常見修法：**
- broken wikilink → 若目標是 wiki 既有頁（已被 a945 ingest），白名單會自動同步、不需手動加；若報 broken 表示該頁還不在 wiki 或 slug 打錯 → 確認目標頁是否已產出/ingest，或修 slug。真的不存在的 link 就刪掉
- raw sha256 mismatch → body 被改過，重新計算 hash
- MANIFEST 不一致 → 補齊檔案對應表

**只有 0 issues 才能交付**（warnings 可接受時需在交付說明標註）。

### 6. Deliverable

- 告訴 user package 路徑
- 附上驗證結果（0 issues 綠燈）
- 依 Team Workflow：package 交 a945 整合 + backup linkEazyCenter；kstsai 之後在 Obsidian 上 post-hoc review（無 blocking 審批）
- **交接方式**：同步到 `lab-riscv/ai-agents/a945/incoming/`，用 `templates/a945-handoff-message.md` 的指令訊息發給 a945（含同步指令 + 標準/簡短版交接文案）
- **⚠️ 同步 lab-riscv 前必先 `git pull origin main --rebase`（kstsai 2026-08-12 明確糾正）**：lab-riscv 更新頻繁，不 pull 就 commit/push 會 `! [rejected] ... fetch first`（v4.7 產包那次忘了 pull → 2 commits 被 reject）。順序：`git pull origin main --rebase` → 改/加內容 → `add` → `commit` → `push`。這不只 wiki-digest — 任何要動 lab-riscv 的操作都適用。

## Pitfalls

- **⚠️ 寫 wikilink 前必須先撈 wiki 實際 slug 清單，禁止憑記憶猜**（2026-08-19 教訓）：產包時 link 到 `[[tailscale-mesh]]`，但 wiki 實際頁叫 `[[tailscale-mesh-vpn]]` — 因為「記得看過 Tailscale 概念」就直覺寫 slug，沒去 linkEazyCenter 確認。而且舊版 validator 的 CROSS_WIKI 可被產包者自行 patch 加白名單 → 假 link 被「合法化」，驗證變形式。**正確做法**：
  1. 寫 wikilink 前先撈實際頁面清單：`gh api "repos/kstsai/linkEazyCenter/git/trees/main?recursive=1" --jq '.tree[].path' | grep '.md$'`
  2. slug 不存在 → 改用實際存在的頁，或刪掉該 link
  3. 禁止為了讓 validator 通過而自行修改 CROSS_WIKI（issue #33 已改為動態 fetch，hardcode 白名單不再存在）
- **⚠️ Never report a digest "done" before Step 5 + Step 6** (2026-08-07 incident): the package was written to `~/wiki-digests/` and reported complete, but the validator was never run and the package was never synced to `lab-riscv/ai-agents/a945/incoming/`. The user had to prompt for both. Treat "package files exist" as INCOMPLETE — completion = `validate_wiki_package.py` returns 0 issues AND the package is committed+ pushed to a945/incoming. First run of the session is the most likely to skip these; check both before answering.
- **tags 用通用 taxonomy**（summary/entity/concept/raw 等），不要 invent 新 tag；目標 wiki 的 SCHEMA 若不同，由 ingest 時對應
- **sha256 要算 body 的**（frontmatter 之後），不是整檔
- **名稱小寫-hyphen**，如 `persona-db-v4-weekly-digest.md`
- 摘要主體控制在 30 秒內可讀完 — 細節進 raw/ 或 entity 頁
- **日期錯誤（2026-08-10，kstsai + hermesa945 雙重糾正）：** 不要假設 conversation context 裡的日期就是真實日期。經常跨天 session 會讓「假設的日期」失準。Step 0 是必做檢查。RFC 區塊註解（`> 2026-08-10 新增`）、spec/verification report 檔名、worklog 檔名**全部**都必須用真實日曆日期。學習自 collaboration-contract.md 的 `created`/`updated` frontmatter 慣例。
- **cross-wiki broken link 先查實際 slug 再修（2026-08-17 實例：`[[tailscale-mesh]]` 誤報）** — validator 報 broken 時，先看 cache（`scripts/.wiki_slugs_cache.json`）或 fetch linkEazyCenter 確認**實際存在的頁名**。wiki 頁名可能跟直覺不同：`tailscale-mesh` 不存在，實際是 `tailscale-mesh-vpn`。**修 digest 的 wikilink（含 repo 的 a945/incoming 副本，兩邊都要改），不是加白名單。**
- **同步 skill 到其他 instance/repo 要複製整個目錄（SKILL.md + scripts/）** — 只複製 SKILL.md 會漏掉 validator/scripts 更新（2026-08-19 實例：本地 validator 還是 hardcode 版，動態 fetch 版沒同步，誤報假 broken）。同步後 `diff -rq` 驗證 scripts/ 也一致。

## References

- llm-wiki skill（`skill_view(name='llm-wiki')`）— Karpathy pattern 完整規範
- `~/lab-riscv/tutorlogs/` — 過去 session 筆記範例
- `references/cross-wiki-links.md` — cross-wiki 連結的宣告方式（MANIFEST + validator CROSS_WIKI 同步）
