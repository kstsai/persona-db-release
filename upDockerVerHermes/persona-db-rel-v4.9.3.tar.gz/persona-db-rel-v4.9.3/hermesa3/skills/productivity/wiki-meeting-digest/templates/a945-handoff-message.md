# a945 交接指令模板（handoff message）

Package 驗證綠燈後，把包同步到 `lab-riscv/ai-agents/a945/incoming/`，然後把下面的指令訊息發給 a945。

## 標準版（完整）

> **任務：整合 <topic> 週報 digest 到 Obsidian vault**
>
> 1. 先 `skill_view(name='wiki-meeting-digest')` 讀協定
> 2. 取包：`lab-riscv/ai-agents/a945/incoming/<package-dir>/`（已驗證 0 issues）
> 3. 照 `MANIFEST.md` 的 Ingest 步驟執行：
>    - copy raw（驗 sha256）
>    - entity/concept 頁：有既有頁就 merge（bump updated），否則新建
>    - 摘要 → `queries/` 或週報目錄
>    - append `log-entry.md` 到 `log.md`
>    - 更新 `index.md`
> 4. 完成後 backup 到 `github.com/kstsai/linkEazyCenter`
> 5. 回報：改了哪些檔案、index 更新、backup commit hash
>
> 不需要等 kstsai 審批 — 整合後 kstsai 會看 Obsidian 結果，有問題再回頭找產包 agent 改。

## 簡短版

> 請整合 `ai-agents/a945/incoming/<package-dir>/` 這個包（<producer> 產的，已驗證 0 issues），
> 照 MANIFEST.md 整合進 Obsidian vault + backup 到 linkEazyCenter，完成後回報檔案清單。
> 流程細節見 `wiki-meeting-digest` skill。

## 同步指令（a3 執行）

```bash
cd ~/lab-riscv
cp -r ~/wiki-digests/<package-dir> ai-agents/a945/incoming/
git add ai-agents/a945/incoming/<package-dir>/
git commit -m "feat: deliver <topic> digest to a945 (incoming)

- Producer: hermesa3, validated 0 issues
- Integrate per MANIFEST.md + wiki-meeting-digest skill"
git pull origin main --rebase && git push origin main
```

## 注意

- 若 remote 有新 commits（其他人也在推），先 `git pull --rebase` 再 push
- package 狀態標記：`pending review`（log-entry 內註明）— kstsai 看過後在 Obsidian 標 `reviewed`
- 多個包同時在 incoming 時，a945 依時間序或 user 指定順序處理
