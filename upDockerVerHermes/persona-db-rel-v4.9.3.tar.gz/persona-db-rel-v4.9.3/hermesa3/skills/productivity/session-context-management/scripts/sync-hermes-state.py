#!/usr/bin/env python3
"""
sync-hermes-state.py — Sync Hermes skills + memory to lab-riscv git repo.

This is the backup mechanism so skills/memory survive instance reset or thread deletion.
Called by cron (every 6h) AND at natural session break points.

What it syncs:
  1. Active skills → lab-riscv/ai-agents/hermesa3/skills/
  2. Memory dumps  → lab-riscv/ai-agents/hermesa3/memory/
  3. Config        → lab-riscv/ai-agents/hermesa3/config.yaml (sanitized)
"""

import os, shutil, json, glob, subprocess, re
from datetime import datetime

HOME = os.path.expanduser("~")
SKILLS_SRC = os.path.join(HOME, ".hermes", "skills")
MEMORY_SRC = os.path.join(HOME, ".hermes", "memories")
CONFIG_SRC = os.path.join(HOME, ".hermes", "config.yaml")

LAB_REPO = os.path.join(HOME, "lab-riscv")
DEST_SKILLS = os.path.join(LAB_REPO, "ai-agents", "hermesa3", "skills")
DEST_MEMORY = os.path.join(LAB_REPO, "ai-agents", "hermesa3", "memory")
DEST_CONFIG = os.path.join(LAB_REPO, "ai-agents", "hermesa3")

PERSONA_REPO = os.path.join(HOME, "persona-db")
PERSONA_SKILLS_DEST = os.path.join(PERSONA_REPO, "references", "skills")

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def sync_skills():
    """Copy all active skills to lab-riscv/ai-agents/hermesa3/skills/"""
    ensure_dir(DEST_SKILLS)
    count = 0
    for root, dirs, files in os.walk(SKILLS_SRC):
        for f in files:
            if f.endswith(".md") and f == "SKILL.md":
                rel = os.path.relpath(root, SKILLS_SRC)
                dest_name = rel.replace(os.sep, "-") + ".md"
                src = os.path.join(root, f)
                dst = os.path.join(DEST_SKILLS, dest_name)
                shutil.copy2(src, dst)
                count += 1
    log(f"✅ Skills synced: {count} files")
    
    # Also sync to persona-db/references/skills/
    ensure_dir(PERSONA_SKILLS_DEST)
    for f in os.listdir(DEST_SKILLS):
        if f.endswith(".md"):
            shutil.copy2(os.path.join(DEST_SKILLS, f), os.path.join(PERSONA_SKILLS_DEST, f))
    log(f"✅ Skills mirrored to persona-db/references/skills/")

def sync_memory():
    """Dump current Hermes memory files to repo"""
    ensure_dir(DEST_MEMORY)
    if os.path.exists(MEMORY_SRC):
        for f in os.listdir(MEMORY_SRC):
            src = os.path.join(MEMORY_SRC, f)
            dst = os.path.join(DEST_MEMORY, f)
            if os.path.isfile(src):
                shutil.copy2(src, dst)
        log(f"✅ Memory synced from {MEMORY_SRC}")
    else:
        log(f"⚠️ Memory source not found: {MEMORY_SRC}")

def sync_config():
    """Copy config.yaml (api_key redacted for safety)"""
    if os.path.exists(CONFIG_SRC):
        dst = os.path.join(DEST_CONFIG, "config.yaml")
        with open(CONFIG_SRC) as f:
            content = f.read()
        content = re.sub(r'api_key:.*', 'api_key: <redacted>', content)
        with open(dst, 'w') as f:
            f.write(content)
        log(f"✅ Config synced (api_key redacted)")
    else:
        log(f"⚠️ Config not found: {CONFIG_SRC}")

def git_commit_push(repo_path, message):
    """Commit and push if there are changes"""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=repo_path, capture_output=True, text=True, timeout=30
        )
        if not result.stdout.strip():
            log(f"⏭️ No changes in {os.path.basename(repo_path)}")
            return True
        
        subprocess.run(["git", "add", "-A"], cwd=repo_path, capture_output=True, timeout=30)
        subprocess.run(
            ["git", "commit", "-m", message],
            cwd=repo_path, capture_output=True, timeout=30
        )
        log(f"📦 Committed to {os.path.basename(repo_path)}")
        
        for remote in ["origin", "gitea"]:
            result = subprocess.run(
                ["git", "push", remote, "main"],
                cwd=repo_path, capture_output=True, text=True, timeout=60
            )
            if result.returncode == 0:
                log(f"  ✅ Pushed to {remote}")
            else:
                log(f"  ⏭️ {remote} push skipped: {result.stderr.strip()[-80:]}")
        return True
    except Exception as e:
        log(f"❌ Git error: {e}")
        return False

def main():
    log("=== Hermes State Sync Start ===")
    sync_skills()
    sync_memory()
    sync_config()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    git_commit_push(LAB_REPO, f"auto-sync(hermesa3): skills + memory — {ts}")
    git_commit_push(PERSONA_REPO, f"auto-sync(skills): mirror from lab-riscv — {ts}")
    log("=== Sync Complete ===\n")

if __name__ == "__main__":
    main()
