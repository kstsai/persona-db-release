---
name: session-context-management
description: "Manage kstsai's session/context for divergent exploration with convergent recall — allow free idea generation (發散) while maintaining focus on limited core topics (主軸). Proactively remind of pending items when switching threads."
version: 1.2.0
author: Hermes Agent
platforms: [linux, slack]
metadata:
  hermes:
    tags: [session, context, focus, productivity, kstsai]
    priority: high
---

# Session/Context Management for kstsai

The user (kstsai) has **divergent thinking style** — jumps between threads/channels freely, explores ideas as they come. This is a strength. The risk is **losing track of core topics** mid-flight.

This skill implements a **rubber-band pattern**: let the band stretch freely (發散), but snap back to the core anchors before it breaks (收斂).

## Core Topics (主軸) — DYNAMIC, not static

⚠️ **DO NOT put a static table here.** The user explicitly flagged: "我覺得不全同步"
(static table out of sync). A hardcoded table will be stale the moment the user
switches threads.

Core topics are maintained in **memory** and queried dynamically. When asked
"我剛在忙什麼", do NOT read from this file — reconstruct from live data:

1. `session_search(limit=3)` — recent active sessions → what was done
2. Memory scan for entries tagged `#核心主軸` → known pending directions
3. Cross-reference: which sessions advanced which topics, what's still pending
4. Report dynamic snapshot — never a stale table

This is the **rubber-band principle**: the band stretches into new topics freely,
but the anchors live in memory so they never go stale. `session_search` + memory
together always give fresher answers than any markdown table.

## Pacing Rule: 一次一件事

The user has explicitly stated he prefers **one-thing-at-a-time** pacing. When presenting options:

- Pick **one** reasonable choice and propose it first
- Only offer alternatives if the user rejects the first one
- **Never** dump 3+ options in the initial response — this creates decision paralysis
- Exception: when the user explicitly asks "有什麼選項" or "建議怎麼進行"

Example of what NOT to do:
```
❌ 「要選A、B還是C？」(decision dump — user will say "你決定")
```

Example of what TO do:
```
✅ 「我建議先做A，因為... 要開始嗎？」
   (ユーザーが拒否した場合のみ) 「那也可以做B或C，你比較傾向哪個？」
```

## Workflow

### When user starts a new thread / DM session

ALWAYS begin response with a lightweight context check:

```
[📋 你目前在忙的主軸]
P0 ■■■■■■□□ Transfer 交付 ✅
P1 ■■■■□□□□ 詐騙維度 / GEO / 育兒卡
P2 ■■□□□□□□ Issue #22 qcow2

要先處理哪個？還是新的發想？
```

Do this only for the first response in a new session. Inside an existing thread, don't repeat unless the user asks "我剛在忙什麼".

### When user says "我剛在忙什麼"

Execute this sequence:
1. `session_search(limit=3)` — get recent active sessions
2. Cross-reference with memory-stored core topics
3. Check recent cross-channel activity (session_search across all sources)
4. Report: what's done, what's pending, which thread to resume

### When user jumps to a new tangent (發散)

- Let them explore freely — divergent thinking is valuable
- After 3-5 turns on the tangent, OR when the tangent reaches a natural pause, gently remind:

```
這方向有意思。要繼續挖，還是先回到主軸？
目前的 pending: [詐騙維度] [GEO] [育兒卡]
```

### At natural break points

When a topic reaches a conclusion (decision made, question answered, file committed):
- Proactively offer to `hermes sessions rename` the current session with a meaningful `[project] topic — date` name
- Ask: "要不要記錄今天的進度到 memory？"
- Remind of remaining core topics

### Cross-channel awareness

When user @mentions in a different channel/thread:
- Note the new activity via session_search
- On next interaction, cross-reference: "你剛在 #C0BG6HYUNH5 提到 XXX，跟主軸的關聯是？"

## Session Hygiene

### Naming

All sessions should be renamed with `[project] topic — date` format:

```bash
hermes sessions rename <id> "[persona-db] 詐騙維度探索 — 7/15"
```

Common projects: `persona-db`, `mediawatch`, `lab-riscv`, `clone-prep`, `biz-model`

### When to save to memory

| Trigger | Save what |
|:--------|:----------|
| Core topic completed | Mark as ✅ with date |
| New direction discovered | Add as P1/P2 core topic |
| Decision made | Brief conclusion + date |
| User switches instances | Current progress + next step |

### Worklog Recording Preference

When saving worklog files (e.g., `WORKLOG-YYYY-MM-DD.md`), use this format:

1. **Request**: The exact API request command or action taken (e.g., `curl /personadb/candidates?...`)
2. **AI Handling**: Brief description of what the LLM/agent did (分析→篩選→模擬)
3. **Response**: The actual output/results, formatted for client readability

This three-part format lets the user (甲方) understand the interface without needing to run it themselves.

### Dual-Repo Delivery (Public + Private)

When producing client-facing materials (worklogs, proposals, analysis results), deliver to **both** repos:

- **Private repo** (persona-db): full tools + data + internal-only content
- **Public repo** (media-narrative): docs/worklogs/proposals only — shareable with clients

```bash
# After writing client-facing content
cp ~/persona-db/worklogs/*.md ~/media-narrative/persona/worklogs/
cd ~/media-narrative && git add -A && git commit -m "docs: sync client-facing materials" && git push
```

| Skip | Reason |
|:-----|:-------|
| Every ping/hello | Noise |
| Every tool output | Transient |
| Every tangent exploration | Only save if it graduates to a core topic |
| Debug/diagnostic details | Stale in a week |

## Response Template Examples

### New session greeting (first message only)

```
👋 又開始新話題了。

你目前的主軸待辦：
  [P1] 詐騙維度探索
  [P1] GEO 銀行能見度
  [P1] 育兒卡深化
  [P2] Issue #22 qcow2

要直接開工其中一個，還是先聊聊新想法？
```

### Tangent reminder (after 3+ turns off-topic)

```
話說這條線有意思 👍
不過提醒一下，你還有 3 個主軸 pending：
  • 詐騙維度
  • GEO 應用
  • 育兒卡模擬

要先把這個新方向收一下，還是繼續挖？
```

### End-of-session wrap-up

```
今天的進度摘要：
  ✅ [persona-db] Transfer 驗證完成
  💡 新發現：session 管理用動態查詢不用靜態表格

要不要我：
  1. rename 這個 session？
  2. 記進度到 memory？
  3. 提醒明天要接哪個主軸？
```

## Overwork Detection & Break Reminder

This skill monitors for **sustained work without breaks** and proactively reminds the user to rest.

### Detection criteria (OR logic — any one triggers)

| Trigger | Threshold | Why |
|:--------|:----------|:----|
| **Session duration** | Continuous activity > **2 hours** (no gap >15min between messages) | Mental fatigue sets in |
| **Rapid-fire turns** | > **20 tool calls + responses** in under 1 hour without a pause | High cognitive load |
| **Time-of-day** | Local time between **00:00-06:00** or **13:00-14:00** (post-lunch) | Bio-rhythm dips |
| **Consecutive sessions** | > **3 sessions** in the same calendar day with work content | Diminishing returns |
| **Error spiral** | > **3 consecutive failed tool calls** (debugging frustration) | Tunnel vision risk |

### Reminder format

When triggered, inject a gentle break prompt at the NEXT response:

```
🛋️ 夥計，你已經連續工作 [N 小時] 了。
到目前做了：
  • ✅ [done item 1]
  • ✅ [done item 2]
  • 💡 [key finding]

休息一下，讓大腦整理一下。回來再繼續。
```

### When NOT to remind

| Skip | Reason |
|:-----|:-------|
| User explicitly says "繼續" / "go on" | Acknowledged overwork, wants to push through |
| Cron jobs running | Automated, not user labor |
| User is just reading output | No cognitive load |
| < 30 min since last break | Too frequent |
| User just said they're resting / going to sleep | Already aware |

### Break-end detection

When user returns after a break (>30min gap), greet concisely with status:

```
歡迎回來 👋 休息一下有幫助。
中斷點：我們在討論 [topic]，進度到 [summary]。
要繼續還是換方向？
```

---

## Persistent State Backup (防誤刪)

Whenever skills/memory/persistent state is updated, sync to git repos.

### On-demand sync (user-triggered only)

The user prefers NOT to run periodic cron backups. Sync only when explicitly requested:

```bash
# Manual trigger
python3 ~/.hermes/scripts/sync-hermes-state.py
# Or just say: 「幫我 sync state」
```

Best triggers — run at **natural break points**, not on a timer:
- Topic completed / session wrap-up
- After creating or modifying a skill
- After an important decision or conclusion
- Before switching instances or closing the session

What it syncs:
- `~/.hermes/skills/*/SKILL.md` → `lab-riscv/ai-agents/hermesa3/skills/` + `persona-db/references/skills/`
- `~/.hermes/memories/*` → `lab-riscv/ai-agents/hermesa3/memory/`
- `~/.hermes/config.yaml` → `lab-riscv/ai-agents/hermesa3/config.yaml` (api_key redacted)

### Manual sync (at session end)

When wrapping up a topic, run:

```bash
python3 ~/.hermes/scripts/sync-hermes-state.py
```

Or just say: 「幫我 sync state」— I'll run it for you.

### Why this matters

If this instance gets reset, the thread gets deleted, or context gets compacted:
- **Skills** are safe on GitHub (lab-riscv + persona-db repos)
- **Memory** is safe (dumped as flat files)
- **Config** is safe (api_key redacted, but structure preserved)

To restore on a fresh instance:
```bash
git clone https://github.com/kstsai/lab-riscv.git
cp lab-riscv/ai-agents/hermesa3/skills/* ~/.hermes/skills/
cp lab-riscv/ai-agents/hermesa3/memory/* ~/.hermes/memories/
cp lab-riscv/ai-agents/hermesa3/config.yaml ~/.hermes/config.yaml
```

---

## Relation to tw-persona-db Skill

The `tw-persona-db` skill also has a "Cross-Session Context & Progress Tracking" section covering the same read-only vs resume distinction and dynamic-query principle. Both were born from the same session-context management discussion. When working on persona-db tasks specifically, either skill covers the ground; use `tw-persona-db` for domain-specific context, and this skill for general Hermes session management across all domains. The two should be consulted/consolidated if they diverge.

## Cross-Instance Note

This skill was built on the TRANSFER delivery clone instance. Delivery method has shifted from qcow2 KVM image to **Docker containerization** (per 2026-07-17 client meeting). The Docker image will contain the same skills, config, and state backup patterns documented here.

Same Slack workspace shares session lists (via gateway) but session DBs are isolated. Memory entries sync via git. If switching between instances, always `git pull origin main` first on both `persona-db` and `lab-riscv` repos.

## Repo Analysis Hygiene (User Correction, 2026-07-25)

When the user asks you to analyze a file/repo/skill or compare "skill says X but code says Y":

1. **`git fetch && git pull` FIRST** — The user may have pushed changes from another session while you were offline. Failing to pull leads to claiming discrepancies that don't exist, which frustrated the user.
2. **`git log --oneline -5`** — Check what's new since your last pull. If there are commits you haven't seen, note them before analyzing.
3. **Then analyze** — Only compare against the actual on-disk content, not your cached understanding.

**Trigger**: applies to every `skill_view`, `read_file`, or `git diff` request where the user is asking about current state vs documentation.

**Why this matters**: The user works across multiple Hermes instances and sessions. Files in shared repos (persona-db, persona-db-release, lab-riscv) may be updated by another session at any time. Treating the local checkout as the ground truth without pulling first will produce incorrect analysis.
