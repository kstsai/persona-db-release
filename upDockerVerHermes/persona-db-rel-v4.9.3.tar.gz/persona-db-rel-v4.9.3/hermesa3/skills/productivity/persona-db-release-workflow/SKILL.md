---
name: persona-db-release-workflow
version: 1.8.0
description: Release persona-db to persona-db-release repo — versioned tarball + auto-detect deploy
---

# Persona DB Release Workflow

Complete flow from `persona-db` source repo → versioned tarball → `persona-db-release` deploy repo.

## Versioning

- **persona-db repo**: `VERSION` file (root) is the single source of truth
- **Tarball**: `persona-db-rel-<VERSION>.tar.gz` (e.g., `persona-db-rel-v3.2.tar.gz`)
- **Inside tarball**: `RELEASE` file carries the version tag; `VERSION` file carries data version
- **RELEASE-VERSION** file (both repos): mirrors the tag for deploy scripts to reference
- **Git tags**: both repos tagged `v3.2` (etc.) for reproducible releases

**什麼要進版、什麼不用（kstsai 2026-08-14 問過，三分類）：**

| 改動 | 要不要進版 | 原因 |
|:----|:----|:----|
| **API code 行為變更**（`api/server.py`/`api/llm.py`/`_generate_997.py`/`tw_persona_1069.json` 等） | ✅ **要 bump VERSION + 重打包 tarball** | 它在 tarball 裡，不重打包的話 `undeploy→deploy`（fresh install）會讓修復消失 — scp 補的 code 不會進 tarball |
| **deploy 腳本**（`undeploy.sh`/`deploy-hermes-personadb-containers.sh`，在 `upDockerVerHermes/`） | ❌ 不用進 API 版號 | 是 infra、不在 tarball 裡；commit 到 persona-db-release 後 hosts `git pull` 即生效 |
| **純 billing**（402 餘額不足） | ❌ 無 code | 儲值即解，不是版本問題 |

**判準：一個 commit 若改了會進 tarball 的檔案（API code / 資料 / generator），就要 bump VERSION；只改 deploy infra 或只動 issue/文件就不必。** 常見錯誤：修了 `api/*.py` 只 scp 上 VM 就當完成 → tarball 還是舊的，下次 fresh deploy 修復蒸發（scp 補的洞不等於 release）。

**進版供 QA 循環（kstsai 2026-08-19）：** 一批資料 fix（coherence rule / regen）完成後，節奏是 `fix → 進版（bump VERSION + do-release.sh）→ QA（deploy + test-api + LLM verify，lzcdh1 或 lzcdh5）→ 有必要才再 bump`。即「先 release 一個版本當 QA 基準，QA 通過就定版、不通過再 bump」，不是「QA 全過才 release」。跟下方 Pre-Release SOP 是互補：SOP 是正式 release 前的完整 fresh-install 驗證；「進版供 QA」是資料 fix 的收尾節奏（先給個可測的版本號）。

## One-command Release

```bash
cd ~/persona-db
bash do-release.sh
```

Flags:
| Flag | Purpose |
|------|---------|
| `(none)` | Normal release — skips if tag already exists |
| `--force` | Re-release even if tag exists (e.g., re-pack with same VERSION) |
| `--dry-run` | Preview all steps, no writes or pushes |

The script runs: pack → sync to release repo → remove old tarballs → commit (both repos) → tag (both repos) → push (both repos).

## Manual Steps (equivalent to do-release.sh)

```bash
# 1. Bump version (if data changed)
echo "v3.3" > VERSION

# 2. Pack versioned tarball
bash pack-persona-db-release.sh
# → persona-db-rel-v3.3.tar.gz + RELEASE-VERSION

# 3. Sync to delivery repo
cp persona-db-rel-v3.3.tar.gz ~/persona-db-release/upDockerVerHermes/
cp RELEASE-VERSION ~/persona-db-release/upDockerVerHermes/
rm ~/persona-db-release/upDockerVerHermes/persona-db-rel-v3.2.tar.gz

# 4. Commit + tag + push both repos
cd ~/persona-db-release
git add -A && git commit -m "release: persona-db v3.3"
git tag v3.3 && git push origin main --tags

cd ~/persona-db
git add pack-persona-db-release.sh RELEASE-VERSION VERSION
git commit -m "release: persona-db v3.3"
git tag v3.3 && git push origin main --tags
```

## Deploy (dh5 or client VM)

```bash
cd ~/persona-db-release && git pull origin main
bash upDockerVerHermes/deploy-hermes-personadb-containers.sh
```

The deploy script auto-detects the highest-versioned `persona-db-rel-*.tar.gz` via `sort -V`.
VERSION is read from the tarball's extracted data — **never hardcoded** in deploy scripts.

## Pre-Release SOP (lzcdh1 — run before every release, kstsai 2026-08-13)

Before tagging a release, run the full fresh-install deploy+test cycle on lzcdh1
(`100.100.112.108`, `ssh ubuntu@...`) — NOT just scp-based dev deploys. Fresh install
exercises the full tarball → build → run → test path, which surfaces bugs scp deploys miss.

```bash
# 1. Get the new version (release repo already has the tarball after do-release.sh)
ssh ubuntu@100.100.112.108 "cd /home/ubuntu/persona-db-release && git pull origin main"

# 2. Undeploy — run undeploy.sh (FULL clean: `sudo rm -rf /srv/persona-db-data/` + `~/.hermes/`)
#    NOT `docker rm -f`! The deploy script SKIPS tarball extraction when `tw_persona_1069.json`
#    already exists (guard at deploy script line ~273), so `docker rm -f` + re-deploy leaves
#    stale VERSION/code/data — a "re-deploy" that updates nothing (pitfall #43).
#    undeploy.sh deletes the data dir → next deploy is a true fresh install → extraction runs.
ssh ubuntu@100.100.112.108 "cd /home/ubuntu/persona-db-release/upDockerVerHermes && bash undeploy.sh"

# 3. Deploy (API-only; hermes container is separate)
ssh ubuntu@100.100.112.108 "cd /home/ubuntu/persona-db-release/upDockerVerHermes && bash deploy-hermes-personadb-containers.sh --skip-hermes"

# 4. Test + VERIFY RESULT BY LLM (!! 重點)
ssh ubuntu@100.100.112.108 "cd /home/ubuntu/persona-db-release/upDockerVerHermes && bash test-persona-db-api.sh > /tmp/t3_pre.txt 2>&1"
```

**Step 4 is NOT "check exit code 0".** After the test runs, `grep` the result file and
**interpret the output with LLM judgment** across all 5 domains — do not trust exit code:

```bash
ssh ubuntu@100.100.112.108 "grep -E '^===|total_matched|FILTER_FAILED|Role QA|DIFFERENT|SAME|top=' /tmp/t3_pre.txt"
```

Red flags to look for (each is a real bug class, not a "flaky" pass):
- `status != "ok"` or `FILTER_FAILED`
- `total_matched` far below `TARGET_MIN=20` (e.g. `total=3`) **with** `broadening_attempts: []`
  → the broadening loop silently failed (see pitfall #42)
- Role QA shows `SAME` (房仲/銀行 top identical) → role differentiation broken (pitfall #30)
- no-op broadening loops where `match_count_before == match_count_after`
- `applied_filters` 出現 DB 值域外的值（如 `clothing_spend: ["500~1000","1000~1500"]` vs DB 的 `500~1500`）→ BROADEN_PROMPT 缺 valid-value grounding（pitfall #42 D6）
- `scoring_basis.dims_counted` 只有 3 個維度（age/occupation/income）且缺 commute_mode/clothing_spend/family_income → **`LLM_ANALYSIS_MODEL` 空白、analysis fallback 到 flash**（品質降級，見 pitfall #8）。test 表面「ok」（flash 也吐合法 JSON），但 dims_counted 過少是「analysis model 錯了」的簽名，不是 flaky — 這正是 lzcdh5 v4.9.0 那次被 LLM verify 抓出的品質落差。
- **`FILTER_FAILED` 出現在「多個」domain（不是單一 query）→ 系統性問題，先查 `docker logs persona-db-api` 找實際 error，別急著 debug code**（2026-08-19 實測）：log 滿滿 `Client error '402 Payment Required'` = **DeepSeek 餘額不足**（pocDemo.env 的 key 是給甲方測試用、餘額本來就少），不是 code bug。402 是 billing 問題，儲值後重測即可；同場「circuit breaker OPEN: 3 consecutive LLM failures」是**正確**反應（402 是持續性失敗、retry 無用，熔斷擋 call 正是防火牆 L4 要做的）— 不要誤判成「circuit breaker 太敏感」。診斷一步到位：直接 curl DeepSeek `/chat/completions` 看 HTTP code（`402 {"error":{"message":"Insufficient Balance"}}`）比猜 log 快。儲值生效後 `docker restart persona-db-api` 清掉 module-level 熔斷狀態再重跑。

**LLM verify 的具體執行命令**（freshness 檢查決定要不要 re-deploy、值域 grounding 的
`docker exec` one-liner 含 list-valued dim flatten、dims_counted-vs-relaxed 判讀）見
`references/llm-verify-checklist.md`。v4.9.0 驗證跑通實錄：容器已 fresh deploy 時可跳過
undeploy→deploy（用 code/data **size** 對 tarball 驗證新鮮度，不是 mtime — tar 會保留原始
mtime，判斷新舊要看 bytes）。

This SOP caught a real bug on v4.8.1 (broadening loop max_tokens too small for pro → 房仲
`total=3` with empty `broadening_attempts`), which the scp-based lzcdh5 dev deploys never
surfaced because those only updated `llm.py`/`server.py` via scp, never the full tarball path.

## Key Files

| File | Location | Purpose |
|------|----------|---------|
| `VERSION` | `persona-db/` (root) | Data version — single source of truth |
| `pack-persona-db-release.sh` | `persona-db/` | Builds versioned tarball from repo state |
| `do-release.sh` | `persona-db/` | One-command: pack → sync → commit → tag → push |
| `deploy-hermes-personadb-containers.sh` | `persona-db-release/upDockerVerHermes/` | Deploys to Docker (auto-detects tarball) |
| `persona-db-rel-<VER>.tar.gz` | `persona-db-release/upDockerVerHermes/` | Versioned release artifact |
| `RELEASE-VERSION` | Both repos (root / upDockerVerHermes/) | Current release tag for reference |
| `README.md` | `persona-db-release/upDockerVerHermes/` | SOP + A3 cloning guide + Hermes activation |

## Pre-Release: grill-me → to-spec → to-tickets (設計拷問鏈)

> 移植自 Matt Pocock 的 `mattpocockskills` 生態系（github.com/kstsai/mattpocockskills）

每次對 persona-db 做結構性變更前，依序走這三個階段：

### Stage 1: grill-me（設計拷問）

先拷問設計決策，一次一個問題，確認所有 interdependency 都考慮到再動手。

### 觸發條件

- 要加新的 dimension / tier
- 要調 OCC_PROB / INC_PROB / FAMILY_INCOME_PROB 的權重
- 要新增或修改背景故事模板池
- 要調整 coherence validation 邏輯

### 決策樹範例（加新維度/選項時走）

```
User 提出：「我想加 失業 選項」
  ├─ ① 收入分布怎麼設？
  │     └─ INC_PROB：失業 → 60%無收入 / 35%<3萬 / 5%兼職
  ├─ ② 從哪些現有職業挪比例？
  │     └─ OCC_PROB：製造/服務各挪 2-5%，依年齡層
  ├─ ③ 家庭所得分布？
  │     └─ FAMILY_INCOME_PROB：新增 (無收入,失業) + (<3萬,失業)
  ├─ ④ 背景故事模板？
  │     └─ 新增 ECON_UNEMPLOYED pool（5 句）
  ├─ ⑤ Life stage 短語？
  │     └─ 失業 →「正在找工作，生活充滿不確定」
  ├─ ⑥ 經濟 tone 一致性？
  │     └─ gen_econ_context() 新增 occ=="失業" 分支
  ├─ ⑦ QA 規則影響？
  │     └─ edu_professional_bump：失業不觸發 ✅
  ├─ ⑧ 模板池衝突？
  │     └─ 檢查 ECON_UNEMPLOYED 是否跟 LIFE_* 池重複開頭
  └─ ⑨ RFC 更新？
        └─ dimension 5 職業列表 + 定義備註
```

走完 → shared understanding → 一次改到位 → 一次 regen

## Ticket 寫法（to-tickets）

每次拆 ticket 時，尤其是「API 露出」類型的 ticket，需要涵蓋**三層**：

| 層級 | 檔案 | 驗收條件範例 |
|:----|:-----|:------------|
| ① 回應 schema | `api/models.py` | PersonaSummary 新增欄位，description 寫清楚 |
| ② 資料分析 & 過濾 | `api/persona_matcher.py` | `get_important_dimensions()` 加入分析 + `valid_dims` 加入新維度（兩處！） |
| ③ LLM 篩選提示 | `api/llm.py` | `QUESTION_ANALYSIS_PROMPT` 有效選項中加入新維度，否則 LLM 無法用它過濾 |

**常見遺漏（都是真實發生過的）：**

- `persona_matcher.py` 的 `valid_dims` set 漏加新維度 → LLM 吐出對應的 filter 但被默默忽略
- `llm.py` 的 `QUESTION_ANALYSIS_PROMPT` 沒加新維度 → LLM 根本不知道有這維度可用
- `test-persona-db-api.sh` 沒加對應的 test case → 上線後才發現 filtration 無效
- **`scripts/gen_dim_weights.py` 的 `SCORED_DIMS` 漏加新維度**（issue #4 後）→ 新維度不會被 scoring，relevance ranking 缺一維

**補救：** 如果 LLM query 後 `important_dimensions` 沒出現新維度，就是第③層或第②層漏了。此時查：
1. `api/llm.py` 的 `有效選項` 區塊
2. `api/persona_matcher.py` 的 `valid_dims` set

grill-me 收斂後，將 shared understanding 寫成一份規格書（PRD），遵循以下模板：

| 章節 | 內容 |
|:----|:------|
| Problem Statement | 使用者角度描述問題 |
| Solution | 解決方案 |
| User Stories | 大量、編號的 user story |
| Implementation Decisions | 模組/介面/架構決策（不含檔案路徑、不含 code snippet） |
| Testing Decisions | 測試策略（哪些 QA rules 會受影響） |
| Out of Scope | 明確列出不做什麼 |
| Further Notes | 補充事項 |

- **不訪談使用者** — 直接從 conversation 合成
- 存到 `specs/YYYY-MM-DD-<topic>.md`
- 先讓 user 確認 spec，再進 to-tickets

### Stage 3: to-tickets（拆 ticket）

spec 確認後，拆成多張**垂直切片 tracer bullet ticket**，每張 ticket：

- 貫穿所有層（schema → code → BG → QA）— 不是水平切片
- 做完可獨立 demo / verify
- 標註 **Blocked by**（被誰擋住）
- 有明確的 **Acceptance criteria**

拆完後呈現給 user 確認 granularity 和 blocking edges，確認後依 blocked by 順序逐一 publish。

**⚠️ spec/tickets 產出後先上 GitHub（kstsai 明確要求 2026-08-05）：** 動手 implement 之前，先把 `specs/YYYY-MM-DD-<topic>.md` 和 `.tickets/*.md` **commit + push 到 persona-db repo** — 這些文件是給人讀的（human-readable），不能只留在本地。commit message 範例：`docs: relevance scoring spec + 5 tickets (issue #4)`。

### 完整變更流程

```mermaid
flowchart LR
    A[User 有想法] --> B[grill-me<br/>拷問設計]
    B -->|shared understanding| C[to-spec<br/>寫規格書]
    C -->|spec 確認| D[to-tickets<br/>拆垂直切片]
    D -->|ticket 01| E[RFC 更新]
    D -->|ticket 02| F[改 _generate_997.py]
    D -->|ticket 03| G[Regen + QA]
    D -->|ticket 04| H[API 更新]
    D -->|ticket 05| I[Release]
```

### 走完 → shared understanding → 一次改到位 → 一次 regen

### RFC-First Convention

這是 kstsai 的明確慣例，修改 persona-db 的順序必須是：

```
先更新 tw-persona-db-rfc.md  →  再改 _generate_997.py  →  最後 regen
```

RFC 是 regen 的 trigger，不是事後補文件。每次新增 dimension / tier / 調整權重前：
1. 先在 RFC 定義新維度的 tier list + 備註
2. 再改 `_generate_997.py` 的機率表 + 生成邏輯 + BG 模板
3. 最後 regen → QA 驗證 → release

**RFC 表格 markdown 陷阱（kstsai 明確糾正過兩次）：**
- 維度 tier 值域中的 `~`（如 `500~1500`、`5千~1.5萬`）會被 markdown 渲染成**刪除線**
- 一律用 `-` 代替 `~`：`500-1500`、`5千-1.5萬`（與 dimension 10 的 `1-3萬` 一致）
- 新增維度時直接寫 `-`，不要先寫 `~` 再修
- 同理，RFC 表格內 `family_income` 等底線變數名在 markdown 中會變斜體 — 用 `family_income` 的純文字即可，不需要 escape

**日期標記規則（2026-08-10，kstsai 明確糾正 + hermesa945 相同錯誤）：**
- RFC 區塊註解（如 `> 2026-08-10 新增`）的日期**必須與實際日曆日期一致**
- **不要**依賴 conversation context 裡的日期（可能跨天）或 git commit date（可能被 rebase 偏移）
- **做法**：寫下日期註解前執行 `date '+%Y-%m-%d'` 或 `TZ='Asia/Taipei' date '+%Y-%m-%d'` 取得真實日期
- Spec (`specs/YYYY-MM-DD-*.md`)、Generation-Verification Report (`GENERATION-VERIFICATION-YYYY-MM-DD-vX.Y.md`)、reports (`reports/contrast-hunt-YYYY-MM-DD.md`) 的**檔名與內部日期註解同樣適用**
- 學習自 `collaboration-contract.md`：使用 `created` / `updated` frontmatter 欄位並確保日期準確
- **如果日期不確定，寧可不寫日期註解也不要寫錯**

**RFC 日期標記規則（2026-08-10，kstsai + hermesa945 都糾正過）：**
- RFC 區塊註解（如 `> 2026-08-10 新增`）的日期**必須與實際日曆日期一致**
- **不要**依賴 conversation context 裡的日期（可能跨天）或 git commit date（可能因 rebase 而偏移）
- **做法**：寫下日期註解前先執行 `date '+%Y-%m-%d'` 取得真實日期
- Spec、Generation-Verification Report、worklog 的檔名與內部日期註解**同樣適用此規則**
- 學習自 `collaboration-contract.md`（entities/collaboration-contract.md）：使用 `created` / `updated` frontmatter 欄位並確保日期準確
- **不要**用 `git log` 的日期寫 commit message 或 date annotation — commit date 會被 rebase 改寫

### Post-Generation Deliverables

每次 regen 後，必須產出以下三項：

**① Verification Report** — 比照 `GENERATION-VERIFICATION-2026-07-29-v3.8.md` 格式：
- 新增維度的 tier 分布統計
- 交叉驗證（性別/區域/職業 × 新維度）
- QA 23 rules 結果
- 整體人口分布（年齡/區域/性別）— 確認無回歸
- **資料來源對照表**（標明每個維度引用的 DGBAS/內政部資料）

```markdown
## 資料來源

| 維度 | 資料源 |
|:----|:-------|
| 年齡/性別/區域 | 內政部戶政司 113年人口統計 |
| 教育/職業 | DGBAS 人力資源調查 113年 |
| 服飾消費 | DGBAS 家庭收支調查 113年——衣著鞋襪消費支出分位 |
```

存到 `GENERATION-VERIFICATION-YYYY-MM-DD-vX.Y.md`

**⚠️ Verification Report 要跟著 tarball 一起打包（kstsai 明確要求 2026-08-05）：** report 不只 commit 進 persona-db repo — 它必須**隨 release tarball 進 persona-db-release**（`do-release.sh` 會自動把 repo 內的檔案打包進去，所以只要 commit 進 repo 就會進 tarball；release 後用 `tar tzf persona-db-rel-vX.Y.tar.gz | grep GENERATION-VERIFICATION` 驗證）。這樣部署方/甲方拿到 tarball 就有該版的驗證文件，不必另外去 source repo 找。

**② Update test script** — 在 `upDockerVerHermes/test-persona-db-api.sh` 新增該維度相關的查詢測試：

```bash
echo ""
echo "=== N. <dimension> 的目標客戶 ==="
time curl --get "http://localhost:8000/personadb/candidates" \
          --data-urlencode "questions=<domain query>" \
            --data-urlencode "top_k=10" \
              --data-urlencode "opMode=僅篩選" | jq > <topic>.json
```

**③ API model update** — 如果新增維度，記得同步更新：
- `api/models.py` — `PersonaSummary` 加上新欄位
- `api/server.py` — summary builder 讀取新欄位
- `api/persona_matcher.py` — `get_important_dimensions()` 加入分析

### 模板池衝突檢查（from v3.9 老伴走了 dedup）

每次新增 BG 短語池後，檢查新池是否與既有池有重複開頭：

```python
# 潛在衝突：HH_SINGLE_WIDOWED 有「老伴走了，現在獨居」
# LIFE_SENIOR_WIDOWED 不應再用「老伴走了」開頭
# → 改成「孩子都成年了，老伴也走了」
```

這類衝突不會被 QA rules 抓到（R1-R23 沒有重複短語檢查），需人工掃描。

### Post-Generation Self-Check

每次 regen 後自動檢查（建議加在 `_generate_997.py` 尾部）：

```python
post_checks = {
    "qa_all_pass": run_qa_validate(),
    "no_legacy_tiers": all(p['dimensions']['family_income'] != '百萬' for p in personas),
    "all_22_cities": len(set(p['residence'] for p in personas)) >= 22,
    "no_老伴_duplicate": all(bg.count('老伴走了') <= 1 for bg in bgs),
}
```

**Relevance scoring 相關（issue #4 之後）：**

- Regen 後**必須**重跑 `scripts/gen_dim_weights.py`（權重是資料的衍生產物，資料變 → 權重表就要重建）
- 新維度加入時同步更新 `SCORED_DIMS`（15 維度清單）
- Verification Report 補權重表統計（每維度權重範圍 + 來源對照）
- RFC「Scoring 演算法」章節若有公式變動要同步

**Autoresearch contradiction hunt（issue #5 之後）：**

- Regen 後建議跑 `python3 scripts/contradiction_hunt/hunt.py`（產生新基準）
- 與上次 `reports/contradiction-hunt-*.md` 對比三指標（Recall/Precision/新發現）
- 若 Recall > 0（上次矛盾殘留），表示規則未完全生效 → 檢查 _generate_997.py
- **Classify 效能陷阱：** `classify.py` 傳完整 15 維度 per persona 時，deepseek-v4-pro 會持續 reasoning-only retry（實際案例：996 violations 跑 60+ 分鐘無進展）。**硬編碼 `model_override="deepseek-v4-flash"`**（flash 需加 `thinking={"type":"disabled"}` 關 reasoning 才秒回，見 pitfall #36 — 2026-08-12 更正：flash 也是 reasoning model）。實測效果：top 5 hypotheses (731 violations) 跑 flash + batch=10 → 下一個 LLM retry 週期就完成分類。見 `classify.py` L126-127。

## References

| File | Content |
|------|---------|
| `references/family-income-interpretation.md` | 家庭可支配所得 tier vs monthly/annual + query matching limitation (family burden ignored) |
| `references/api-deployment.md` | API 部署到 lzcdh5 的 SOP + response 結構說明
| `references/dgbas-data-sources.md` | 各維度引用的 DGBAS/政府資料源對照表，用於 Verification Report |
| `references/api-filter-failure-debug.md` | API 篩選管線失敗診斷（total_matched=1069 / [1,2,3] 症狀、reasoning-model empty content、舊 code 驗證）|
| `references/ranking-scoring-design.md` | Issue #4 scoring/ranking 設計初稿（grill-me 收斂早期版）— **已被 `references/relevance-scoring.md` 取代**（後者含實作 gotchas + Q3-B 打折無效教訓） |
| `references/relevance-scoring.md` | Issue #4 scoring 設計定稿 + 實作筆記（dim_weights.json 格式、hobby/_meta/2值維度 gotchas、Q3-B 打折計分無效的驗證與替代方案） |
| `references/data-verification-workflow.md` | 10 步資料驗證流程（regen→hunt→合理性分析→人工裁決→known issue）+ 合理性分析揪系統性 bug 的教訓 + GitHub issue mirror gotcha |
| `references/llm-verify-checklist.md` | Pre-release SOP step 4 的 LLM verify 具體命令（freshness 檢查、值域 grounding one-liner、dims_counted-vs-relaxed 判讀） |
| `scripts/regenerate-dim-weights.sh` | 一鍵重建 dim_weights.json + 驗證（15 維度/值域範圍/可重現性） |

## Pitfalls

- Deploy scripts use `sort -V` for version picking — tags **must** be semver-compatible (e.g., `v3.2`, `v3.10`). `v3.10` sorts correctly after `v3.9`.
- `deploy-persona-db-compose.sh` is deprecated; use `deploy-hermes-personadb-containers.sh` (same content, renamed to avoid `compose` confusion).
- `do-release.sh` skips the release if the git tag already exists (unless `--force`). Bump VERSION first for a new release.
- In dry-run mode, the uncommitted-changes prompt is skipped (auto-confirmed). Real mode prompts interactively.
- `RELEASE` file inside the tarball is separate from `VERSION` — `RELEASE` is the release tag, `VERSION` is the persona data version (currently identical but may diverge).

### Deploy pitfalls (from lzcdh5 verification)

1. **Tarball contains stale `.env`** — The `.env` inside `persona-db-rel-*.tar.gz` has a hardcoded wrong key (`sk-b9b...`) and wrong model (`deepseek-chat`). Deploy script **must always overwrite** `${PERSONA_DB_DATA}/.env` with values from `~/.env`, not skip-if-exists. The `if [ ! -f ... ]` guard is wrong here.

2. **`--env-file` required on `docker run`** — `docker-compose.yml` adds `env_file:` but the deploy script uses `docker run` directly. Both `docker run` commands must include `--env-file <path>`. Hermes container also needs `--user 0:0` to prevent uid 10000 file ownership.

3. **`~` resolution inside Hermes container** — The terminal tool inside Hermes resolves `~` as `/opt/data/home/` (not `/opt/data/`). Create TWO symlinks post-start:
   - `/root/persona-db → /opt/data/persona-db` (for root shell)
   - `/opt/data/home/persona-db → /opt/data/persona-db` (for Hermes terminal tool)

4. **Entrypoint vs s6-overlay init** — The Hermes image uses s6-overlay with `/init` as entrypoint. Changing entrypoint to `ln ... && sleep infinity` breaks the init chain. Instead:
   - Keep entrypoint as `sleep infinity`
   - Run `docker exec hermes ln -sf ...` as a post-start step

5. **uid 10000 ownership** — Docker containers write files as uid 10000 on host, locking the ubuntu user out of `~/.hermes/`. On fresh deploy or after container restarts, `sudo chown -R ubuntu:ubuntu ~/.hermes/` is needed. The deploy script should auto-detect and fix this.

6. **Always fetch latest before analyzing** — This is kstsai's explicit rule: 請記得回覆 skill_view xxx 時候要用最新資料來回 (use latest data when replying to skill_view calls). Before reviewing any repo state or skill content:

   ```bash
   cd ~/persona-db && git fetch origin && git log origin/main --oneline -5
   cd ~/persona-db-release && git fetch origin && git log origin/main --oneline -5
   ```

   Then verify the HEAD vs origin comparison before stating any discrepancies. If the user worked on the repo in another session, local HEAD may be behind origin and stale analysis will waste their time. This applies to every `skill_view` call, not just this skill.

### Deploy pitfalls (env sourcing)

8. **pocDemo.env 是 LLM config 的唯一 canonical source — `~/.env` 只供 LLM_API_KEY（issue #26, 2026-08-14 根治「又發生」）** — v4.5.3 的修法（pocDemo.env canonical）**只修了一半**，留著「`~/.env` 存在就覆蓋 pocDemo.env」的路徑（`SRC_FILE=~/.env if [ -f ~/.env ]`），所以 lzcdh5 的 stale `~/.env`（Jul 24 舊檔、缺 LLM_ANALYSIS_MODEL）蓋過 pocDemo.env → 容器 `.env` 的 `LLM_ANALYSIS_MODEL=` 空白。根因鏈兩環：① `undeploy.sh` 不刪 `~/.env`（只 `rm -rf /srv + ~/.hermes`）；② deploy script 讓 `~/.env` 覆蓋 config。lzcdh1 一直正常是因為它的 `~/.env` 在 v4.5.3 除錯時手動補過（Aug 12），lzcdh5 從沒被動過 → stale 檔一直贏。**正解（已進 script，根治不補洞）：**
   - deploy script：`SRC_MODEL` / `SRC_ANALYSIS_MODEL` / `SRC_URL` **只從 `pocDemo.env` 讀**（真 canonical）；`~/.env` 只提供 `LLM_API_KEY`（user secret 才允許覆蓋）
   - `undeploy.sh` 加 `rm -f ~/.env`（完整清除應包含 ~/.env，否則 stale 檔永遠活著）
   
   **診斷（LLM verify 抓 flash-vs-pro 品質差）：** `LLM_ANALYSIS_MODEL` 空白 → analysis fallback 到 flash，`scoring_basis.dims_counted` 掉到 **3 個維度**（age/occupation/income），漏掉 commute_mode/clothing_spend/family_income 等消費維度（pro 是 6-10 維度）。test 表面「ok」（flash 也能吐合法 JSON、無 FILTER_FAILED），但 **dims_counted 過少 = analysis model 錯，不是 flaky** — 這是 LLM verify 要主動抓的品質落差。驗證：`docker exec persona-db-api sh -c 'grep LLM_ANALYSIS_MODEL /app/.env'` 必須回 `deepseek-v4-pro`，且 TESLA query 的 dims_counted 應含消費維度。通用教訓：**修「config 從哪來」這類問題時，要追完所有 code path — 修了「建立」路徑但留著「覆蓋」路徑，stale config 會在別的 host 復發。**

### Release pitfalls (do-release.sh)

7. **`do-release.sh` exits at step 4 intermittently** — The script uses `set -euo pipefail` which can cause it to exit with code 1 after step 3 (remove old tarballs) completes successfully. When this happens:

   - Steps 1-3 already completed (tarball synced, old tarball removed)
   - Manually complete the remaining steps in the release repo:
     ```bash
     cd ~/persona-db-release
     git add -A && git commit -m "release: persona-db vX.Y"
     git tag -a vX.Y -m "persona-db vX.Y"
     git push origin main --tags
     cd ~/persona-db
     git tag -a vX.Y -m "persona-db vX.Y"
     git push origin main --tags
     ```
   - No data loss — the tarball and RELEASE-VERSION are already in place.

### API pitfalls (from lzc-dh1 [1,2,3] debugging)

8. **API 回傳 `total_matched=1069` / `persona_ids=[1,2,3]` = 篩選管線失敗** — 這代表 LLM 分析失敗且 keyword fallback 也全空，`filter_personas(db, {})` 對空 filters 回傳**全部人設**。診斷順序：

   - `docker logs persona-db-api` 找 `Failed to parse LLM response as JSON` 或 `LLM returned empty content`
   - **deepseek-v4-flash 是 reasoning model**：思考鏈吃光 `max_tokens` 時 `content` 回空字串，被 `if not response` 誤判為失敗（見 `llm-api-patterns` skill 的 empty-content gotcha）
   - 修法（已進 `api/llm.py`）：`call_llm` 偵測 `reasoning_content` 存在但 `content` 空 → 重試並加倍 max_tokens（最多 3 次）；`parse_questions_with_llm` 基底 max_tokens=4000；httpx timeout 90s
   - 防呆（已進 `api/server.py`）：LLM + keyword fallback 都無 filters 時回 503 `FILTER_FAILED`，不該靜默回傳全部 1069
   - **部署 VM 可能跑舊 code**：lzc-dh1 案例是 7/22 的 `llm.py`（13979 bytes），tarball 部署 ≠ api code 更新。驗證方式：
     ```bash
     docker exec persona-db-api grep -c 'retrying with max_tokens' /app/api/llm.py
     # 回 0 = 舊 code，需從 repo sync api/*.py 到 /srv/persona-db-data/api/ 並重啟
     ```

9. **LLM 篩選 prompt 沒加新維度 = filtration 無效** — 即使 `PersonaSummary` 和 `valid_dims` 都加了，`api/llm.py` 的 `QUESTION_ANALYSIS_PROMPT` 有效選項沒列出新維度，LLM 就不會用它過濾（lzcdh5 的 clothing_spend 案例）。驗收測試：query 後檢查 `important_dimensions` 是否出現新維度；若出現但結果仍有低階值（如 fashion query 撈到 `<500`），就是 prompt 或 filters 層漏了。

10. **LLM 暫時性 503/429 需要 backoff retry（issue #2）** — DeepSeek 會回 503 Service Unavailable / 429 限流，`call_llm` 若無 retry 會直接 `FILTER_FAILED`。修法（已進 `api/llm.py`）：exception 時重試 3 次，exponential backoff `[1,3,7]` 秒（`await asyncio.sleep(backoff)`）。Reasoning-only empty content 重試間也 sleep 1s。

11. **JSON parse 失敗要 retry 一次（issue #2 Bug B）** — LLM 回傳被截斷/不完整 JSON（`Unterminated string` / `Expecting property name`）時，`parse_questions_with_llm` 直接 `return {}` → FILTER_FAILED。修法：call + parse 包成 2 次嘗試 loop，空回應或 `json.JSONDecodeError` 都 sleep 1s 重試一次才放棄。

12. **部署 VM 的 api code 驗證（stale code 防呆）** — tarball 部署 ≠ api code 更新。部署後確認 container 內是新 code：
    ```bash
    docker exec persona-db-api grep -c 'retrying with max_tokens' /app/api/llm.py
    docker exec persona-db-api grep -c 'backoff' /app/api/llm.py
    # 任一回 0 = 舊 code，需從 repo sync api/*.py 到 /srv/persona-db-data/api/ 並重啟
    ```
    ### API pitfalls (from lzc-dh1 [1,2,3] debugging)

    13. **LLM filters 太嚴格 → `total_matched=0`（非失敗，是空交集）** — LLM 非確定性（temperature 0.2 但每次輸出不同），有時回傳過度特定的 filter 組合（真實案例：`occupation=[自營] + age=[35-44]` — 但 DB 中 9 個自營只有 2 個是 25-34，**沒有 35-44 的**）→ 交集為空 → 回 `total_matched: 0` + 空列表。這**不是** FILTER_FAILED（filters 非空），也不是 1069（filters 非空）。診斷：直接對 DB 統計 filter 組合的實際分布：
        ```python
        # 自營 person 的 age 分布 — 若某 (filter 值組合) 無交集就是根因
        zy = [p for p in db if p["dimensions"]["occupation"] == "自營"]
        print([(p["dimensions"]["age"], p["dimensions"]["income"]) for p in zy])
        ```
        修法（已進 `api/server.py` + `api/models.py`）：**filter relaxation** — matched 低於門檻時依重要性順序（`sex → marriage → education → income → age → residence → family_income → occupation → commute_mode → housing_burden → clothing_spend`）逐個丟棄維度；response 新增 `relaxed_dims: []` 欄位揭露被放寬的維度（空 = 未放寬）。確定性演算法，不需額外 LLM call。驗證：同一 query 連打 5 次（LLM 非確定性），全部應非零或有 `relaxed_dims` 註記。
        **v4.4.2 進化 — 門檻制而非非零制**：原實作「matched=0 才放寬、丟 1 維就停」在 pro model（LLM_ANALYSIS_MODEL）引入後失效 — pro 自發產 9 維 filters（age×sex×residence×income×marriage×clothing×commute×family_income…），AND 交集坍縮到 1 筆（lzcdh1 實測康是美 total=1）。修法：`TARGET_MIN = 20`，`while len(matched) < TARGET_MIN and len(filters) > 1` 繼續丟（重要性順序優先，fallback 丟值最少維度）。**非零不是目標 — 要有意義的候選池**。診斷：total 很小（<20）且 relaxed_dims 少 → 先懷疑門檻邏輯；模擬驗證法：用真實 filters 直接跑 `filter_personas` + while loop 看丟幾個維度到 20。
        **v4.4.2 進化 — residence 過度限制**：pro model 有刻板印象「高收入=都會」，TESLA query 自動給 residence 只列六都（kstsai 指正：台北高雄捷運發達、汽車需求反而低）。修法：QUESTION_ANALYSIS_PROMPT 加引導「除非問題明確指定地區（如『台北的…』『南部…』），否則 residence 一律留空 [] — 台灣各縣市都有潛在客戶」。實測：修後康是美/TESLA residence 都變 []，total 回到 33/34。

    14. **LLM 漏用消費維度 → top_k 撈到不合直覺的人（issue #4 A+B 修復）** — flash model 對「時尚/服飾」query 常不 filter `clothing_spend`，導致 `<500` 服飾消費的人被選中（score 卻很高，因為 scoring 只算 filter 出現的維度）。雙重修法：
        - **A. Prompt 強化**（`api/llm.py` QUESTION_ANALYSIS_PROMPT）：明確要求消費行為相關 query（時尚/服飾/美妝/零售/汽車/3C/餐飲/旅遊/房產）**必須**考慮 clothing_spend 等消費維度
        - **B. Domain-aware reinforcement**（`api/server.py`）：`domain_filters` 映射表 — LLM 判定的 domain 含關鍵字時自動補 filter（如 `時尚` → `clothing_spend ≥ 1500~3000`），確定性兜底
        - 驗收：`applied_filters` 含 clothing_spend；top 無 `<500`

    15. **LLM_ANALYSIS_MODEL — question analysis 用 pro model（v4.4.1 正式設定）** — flash 產 filters 品質差（漏消費維度、抓錯職業），改用 `deepseek-v4-pro` 後 filters 自發全面（8 維度 vs 3-4）、語意準確（女+都會+逛街購物+高消費）。設定：
        - `api/llm.py`：`LLM_CONFIG["analysis_model"]`（`LLM_ANALYSIS_MODEL` env），`call_llm(model_override=)` 覆蓋，`parse_questions_with_llm` 用 analysis_model
        - simulation 維持 flash（省成本）— 只有 filters 產出用 pro
        - deploy script 從 `~/.env` 轉發 `LLM_ANALYSIS_MODEL` 到 container .env
        - **代價**：latency 增加（pro 思考時間長，case 3 可到 2 分鐘）
        - **Relevance scoring（issue #4 v4.4）**：`dim_weights.json`（regen 產物，log 反頻率 × 跨維度正規化 [0.5,2.0]，≤3 值維度用 [0.8,1.4] 溫和壓縮）→ query 時 `score_persona()` 對 filter 維度加權排序 → `PersonaSummary.score` + `applied_filters` + `scoring_basis` 揭露。relaxed 維度不計分（Q3-A'）

14. **`important_dimensions` 不是 filter！是結果集的事後統計** — 使用者（含 kstsai 本人）常誤讀 response 的 `important_dimensions` 為「篩選條件 key/value」。實際它是 `get_important_dimensions()`（persona_matcher.py）對**篩選後 matched 結果**統計「哪些維度有變化 + top 5 值」— 是結果的描述，不是原因。真正的 filters 由 LLM 產出、只在 server 內部（`llm_filters_to_dimension_filters`），**不回傳在 response**。同樣地，`persona_ids` 順序 = DB 檔案原始順序（`matched[:top_k]`，無 relevance ranking）。解釋 response 時要講清楚：important_dimensions =「結果長什麼樣」，不是「為什麼選這些」。Issue #4 的 scoring 設計（grill-me 已收斂、尚未實作）見 `references/ranking-scoring-design.md`。

15. **Issue #4 scoring 已部分實作（2026-08-05 起）** — ranking 設計已透過 grill-me 定案並進入 v4.4 開發：log-frequency × 跨維度正規化權重表（regen 產 `dim_weights.json`，query 即時查表）、score 進 PersonaSummary、response 揭露 `applied_filters` + `scoring_basis`、同分用 DB 順序、算法 document 進 RFC + generation-verify。**relaxed 維度不計分（Q3-A' 定案）**。實作時先讀 `references/relevance-scoring.md`（含實作 gotchas：hobby list 不能用 str() 查權重、load 時要排除 `_meta`、2 值維度正規化失真）再走 to-spec → to-tickets。**若 QUESTION_ANALYSIS_PROMPT 之後加新維度，SCORED_DIMS + dim_weights.json 要同步擴充**（加入 to-tickets 檢查清單）。

16. **grill-me 收斂的決策要在實作後驗證前提（Q3-B 打折計分無效教訓）** — issue #4 scoring 設計時 grill-me 收斂出「被 relaxation 丟掉的維度 ×0.5 計分」，實作後發現**前提根本不存在**：matched 的人在被丟維度上必然不命中（否則不會交集為 0）→ 0×0.5=0，打折永遠不生效（測試證據：所有自營 persona 的 relaxed 與 orig 分數完全相同）。教訓：涉及 interplay 的結構性決策（relaxation × scoring）要在實作後用真實資料驗證前提，不能只靠理論收斂。**定案結果（Q3-A'）：被丟的維度不計分，relaxed_dims 照樣回傳揭露**；B' tier 相鄰性計分只對有序維度有效，留待未來。

17. **LLM 漏消費維度 = top 撈到直覺不合理的人（fashion query 撈到 clothing_spend <500）** — 「時尚服裝設計師的目標客戶」回傳永信（cs=<500, score 4.04）與阿明（無收入學生 cs=<500）。根因**不是 scoring bug**：`applied_filters` 顯示 LLM 只 filter 了 age/occupation/income（理解成「年輕人+學生」），**完全沒用 clothing_spend**；scoring 只對 filter 出現的維度計分（Q2b-B 設計），所以 <500 的人也能高分。診斷順序：先看 response 的 `applied_filters`（或 log 的 domain reinforcement 訊息）→ 若缺消費維度就是 LLM filter 問題，不是 scoring。**修法（A+B 並行，2026-08-05 已進 v4.4.1 開發）：**
    - **A. Prompt 引導**（`api/llm.py` QUESTION_ANALYSIS_PROMPT）：明確指示「消費行為相關 query（時尚/服飾/美妝/零售/汽車/3C/餐飲/旅遊/房產）**必須**考慮 clothing_spend / housing_cost / commute_mode / family_income，不要只靠 age/occupation/income」。
    - **B. Domain-aware 兜底**（`api/server.py` step 2b）：`domain_filters` 映射表 — LLM 判定的 `domain` 含關鍵字（時尚/服飾/美妝/電動車/汽車/房產/房貸/旅遊）時，自動補上對應消費維度 filter（如時尚 → `clothing_spend: [1500~3000, 3000~5000, >5000]`）。確定性兜底，不依賴 LLM 自覺。domain reinforcement 的 log 訊息是「Domain reinforcement (<domain>): added <dim>=<vals>」。
    - 驗證：fashion query 連打 3 次，`clothing_spend` 應穩定出現在 applied_filters，top 不再有 <500。

18. **`LLM_ANALYSIS_MODEL`：question analysis 用 pro model、simulation 用 flash（品質/成本分離）** — `api/llm.py` 支援 `LLM_ANALYSIS_MODEL` env（`.env` 或 container `--env-file`），`parse_questions_with_llm` 用 `model_override` 走 analysis_model，其餘 `call_llm`（simulation 等）維持 `LLM_MODEL`。實驗結果（2026-08-05）：analysis 用 `deepseek-v4-pro` 後 filters 品質顯著提升 — **3/3 自發產生 clothing_spend**（flash 需 domain 兜底才補上），且自發加 sex/residence/hobby/commute/family_income 共 8 維度（flash 只有 3-4 維），run 2 top 全為女性+cs=>5000+都會區（score 9-10.7）。代價：latency 增加（pro 思考時間長）。設定方式：
    ```bash
    echo 'LLM_ANALYSIS_MODEL=deepseek-v4-pro' >> /srv/persona-db-data/.env
    docker restart persona-db-api
    docker exec persona-db-api python3 -c 'from api.llm import LLM_CONFIG; print(LLM_CONFIG["model"], LLM_CONFIG.get("analysis_model"))'
    ```

19. **Generator 維度獨立抽樣 → 人設內部矛盾（v4.4.3 coherence rules）** — `_generate_997.py` 對 family_size/income/commute_mode/clothing_spend **獨立抽樣**，coherence 檢查曾漏「fam=1 + 無收入」組合，產生矛盾人設（真實案例 TW-P-0177 若希：獨居無收入卻 3-5萬家庭所得 + 汽車 + 3000~5000 治裝 — kstsai 直接判定「這就讓這個人設假了」）。診斷：對 DB 統計可疑組合（`fam=="1" and inc=="無收入"` 的高 fi / 汽車 / 高治裝）即可量化。修法（RFC「Coherence Rules」章節 R-A/R-B/R-C，已進 v4.4.3）：
    ```python
    if fam == "1" and inc == "無收入":
        if fam_inc in ("3-5萬","5-7萬","7萬",">8萬"):  # R-A: 無收入來源 → 家庭所得只能低
            fam_inc = wchoice({"<1萬":0.4, "1-3萬":0.6})
        if commute_mode == "汽車":                       # R-B: 沒錢養車
            commute_mode = wchoice({"機車":0.3, "捷運/公車":0.4, "步行/腳踏車":0.3})
        if clothing_spend in (">5000","3000~5000"):      # R-C: 沒錢治裝
            clothing_spend = wchoice({"<500":0.5, "500~1500":0.3, "1500~3000":0.2})
    ```
    **設計原則**：只對 `family_size=1` 生效 — 學生「北漂靠家裡」的合理版本是 fam>1（原生家庭人口），不能誤傷（柔伊 fam=5+ fi=7萬 就完全合理）。
    **⚠️ 順序 gotcha：`adjust_family_income_by_tier()` 在 coherence 規則之後執行**（依城市物價 shift family_income），可能把 R-A 壓低的 fi 又調回高值 — v4.4.3 regen 後殘留 2 筆「fam=1+無收入+fi=3-5萬」就是它調回的。評估殘留時：R-B/R-C 已生效（無車、無高治裝）就可接受為「依賴儲蓄/補助的獨居者」edge case；若要求零殘留，需把 R-A 移到 adjust 之後或讓 adjust 尊重 coherence 標記。regen 後用 QA + 殘留組合統計驗證，寫進 Verification Report。

**R-D~R-G（v4.5, issue #5 首跑發現）**：
- R-D hb_high_cs_low：housing_burden=高 + clothing_spend=>5000 → cs 壓低（3 fixes）
- R-E edu_bump_medical：國中以下 + 醫療 → edu 提升（1 fix）
- R-F lowfi_high_hc：fi∈{<1萬,1-3萬} + hc∈{1.5萬~3萬,3萬~5萬,>5萬} → hc 壓低（2 fixes）
- R-G island_highfi：離島 + fi>8萬 → fi 下調 80% 機率（1 fix）
**R-H（v4.5.2, issue #6）**：fs=1+已婚 → fs 改為 2（118 fixes — 124 violations 自動化 hunt 發現）
**R-I/J/K（v4.5.3, issue #7-10）**：
- R-I lowfi_bigfam_lowcs：fi=1-3萬 + fs≥4 + cs∈{>5000,3000-5000} → cs 壓低（6 fixes）
- R-J lowfi_smallfam_lowcs：fi=1-3萬 + fs≤2 + cs∈{>5000,3000-5000} → cs 壓低（12 fixes）
- R-K lowfi_single_nocar：fi=1-3萬 + fs=1 + 汽車 → comm_mode 改機車/捷運/步行（random.choice，絕不保留汽車；3 fixes）
**R-L/M/N（v4.7, issue #15-17 合理性分析揪出的系統性 bug）**：
- R-L mfg_wfh：製造業 + 在家工作 → comm_mode 改機車/捷運/步行（工廠作業員不可能 WFH；10 fixes）
- R-M lowfi_car：fi<1萬 + 汽車 → comm_mode 改機車/捷運/步行（極低收入養不起車；6 fixes）
- R-N island_mrt：離島 + 捷運/公車 → comm_mode 改機車/步行（離島沒捷運；離島僅~16人故可能 0 fixes）
**第二輪（v4.8 開發, issue #18-23 — 合理性分析 re-review 揪出，Patterns 2-8 共 134 筆）**：
- `fam1_fi_cap`：fam=1 家庭收入上限（FAM1_FI_MAX，家庭=自己，fi 不該明顯高於 income；32 fixes）
- R-12 `edu_occ_income`：高學歷(研究所/大學)+專業職業(科技/金融/公務/醫療/教育)+income<3萬+age35+ → income bump 3-8萬（15 fixes）
- R-13 `minor_car`：12-18 歲 + 汽車 → comm_mode 改機車/捷運/步行（14 fixes）
- `story_loan_contra`：BG「貸款/帳單喘不過氣」vs「沒有貸款壓力」互斥（3 fixes）
- 住家裡免房租 gating：housing_burden=低 且 housing_cost≥5千 時，hb 候選排除「住家裡不用付房租」phrase（35 fixes）
- `story_unmarried_grandchild`/`story_unmarried_childcost`：未婚排除「含飴弄孫」「小孩的教育費」（17+3 fixes）
- 苗栗縣 region：REGION_TO_CITIES 從北部移到中部（23 fixes）
**第三輪（v4.9.1 後, issue #27 —「房貸早就還完了」套用到非屋主）**：
- `story_homeowner_phrase`：housing_burden=低 的 BG 短語池 `HOUSING_BURDEN_LOW = ["住家裡不用付房租","房貸早就還完了","住在自己的房子，沒有貸款壓力"]` 後兩句**隱含自有住宅**，卻被隨機套用到所有 housing_burden=低 的人（170 筆，含 46 筆 0-18 歲小孩、56 筆學生、13 筆租客「一個人租套房 + 房貸早就還完了」硬矛盾）。修法（condition 在 phrase 選擇上，不靠 post-fix）：非屋主 → 改用「住家裡不用付房租」（租屋者 →「房租不貴，負擔不重」）；只有 25+ 有收入、非租客、非跟家人住的成年人才允許房貸/自有屋敘述。判屋主訊號：`age in ("25-34","35-44","45-54","55-64","65+") and occ != "學生" and inc != "無收入" and "租" not in story and not any(跟父母/跟爸媽/跟家人/住家裡 in story)`。驗證：regen 後 0-18 歲 46→0、學生 56→0、租客矛盾 13→0；counter `story_homeowner_phrase`（212 fixes）。**通用教訓：任何 BG 短語只要隱含「身分狀態」（自有住宅/已婚/有小孩/有收入），就必須 condition 在該狀態的維度上，不能放進無差別 pool 隨機抽 — 跟 R-A~R-C「fam=1 無收入」是同一類「屬性短語 vs 抽樣維度」的 coherence 問題。**

**R-01 順序 gotcha（rule 在 housing_burden 重算前執行 → 殘留，非 regression）：** `R-01 hb_high_cs_low`（housing_burden=高 + clothing_spend=>5000 → cs 壓低）在 line ~1051 執行，但 housing_burden 在 line ~1116 所有 coherence 規則之後才**重算**。所以「初始 burden=中（R-01 不觸發）→ 重算後變高」的 persona 會帶著 cs=>5000 溜過去，regen 後固定殘留 3-4 筆「hb高+cs>5000」。**這是既有 ordering 問題，不是新 bug 也不是你的 fix 引入的 regression** — 驗證時看到這 3-4 筆殘留，先認它是 known issue，別誤判成自己改壞。若要根治，把 R-01 移到 housing_burden 重算之後（或讓重算尊重 R-01 標記）。**→ 已於 issue #28（2026-08-19）根治：R-01 移到重算後 + 加 family_income 條件。**

**R-01 的語意漏洞（issue #28 核心洞察）：`housing_burden 高` 是「比值」（housing_cost / family_income ≥ 40%），不是「窮」。** 高所得（>8萬）家庭 + 大房貸（3萬~5萬）→ burden「高」，但每月還剩 5萬+ → `>5000` 服飾**合理**，不是矛盾；只有低所得（<1萬/1-3萬）「房貸吃掉大半收入」時 `>5000` 服飾才矛盾。原硬規則沒 condition 在 family_income 上，把高所得合理組合也誤修。修法：`if housing_burden == "高" and clothing_spend == ">5000" and fam_inc in ("<1萬","1-3萬")`。**通用教訓：任何「burden/ratio」欄位（housing_burden、債務比、儲蓄率…）要判「矛盾」時，門檻要綁在「絕對所得」上，不是只看比值 — 比值高 ≠ 負擔不起；高所得可以同時「高負擔比 + 高消費」而完全合理。** 驗證 hb高+cs>5000 殘留時先分：低所得（真矛盾，要修）vs 高所得（合理組合，別修）。實務註記：因 50% housing_cost cap，高所得 burden 頂多到「中」，「高所得 hb高」幾乎不會出現 — 但加 family_income 條件仍是正確的語意修正（防未來 cap 放寬）。

**第四輪（issue #29, 2026-08-19 — 未成年高服飾 + R-06/R-07 fs=3 漏洞）：** 0-18 歲 clothing_spend>3000 共 22 筆（0-11×14、12-18×8）。kstsai 先問「高所得嗎？佔比合理嗎？」→ 19/22 是高所得（5-7萬/7萬/8萬）家庭、佔比方向合理（未成年 10-12% vs 成人 37-56%），但兩處要修：(A) 豆豆（1-3萬 + fs=3 + cs 3000~5000）是真矛盾 — R-06 管 fs≥4、R-07 管 fs≤2，**fs=3 是漏洞**；(B) 5 筆未成年 `>5000`（「很重視穿搭」是成人語意）。修法：① R-06/R-07 合併成單一規則（`fi=1-3萬 + 高 cs`，任何 fs）**並移到 fam_inc 最終調整之後**；② 0-18 歲 clothing_spend cap 在 `1500~3000`（counter `minor_cs_cap`）。驗證：低所得高服飾 0、0-18 高服飾 0。

**通用教訓 1（規則順序 — 比 R-01 更廣）：任何 condition 在 `fam_inc` 或 `housing_burden` 上的 coherence rule，都必須在「這些欄位被後續規則（`adjust_family_income_by_tier` / FI floor / fam1 cap / housing_burden recalc）調整完」之後執行** — R-01 踩過（burden recalc），R-06/R-07 也踩（fam_inc 被 adjust/floor/cap 改掉 → 殘留 5 筆低所得高服飾）。症狀：regen 後規則「該抓的沒抓到」，殘留全是「欄位後來才變成目標值」的 persona。修法：把規則移到欄位最終確定之後，而非在原位置加條件。**診斷順序：看到規則殘留，先 grep 該欄位（fam_inc / housing_burden）在規則之後還有哪些 `xxx = ` 賦值點，逐個確認是不是「後續又改了」。**

**通用教訓 2（成人語意不套小孩）：消費/生活型態 tier 若含「成人語意」（clothing `>5000`=很重視穿搭、`3000~5000`=定期治裝），未成年（0-18）要 cap 在上限（1500~3000），即使高所得家庭也一樣** — 高所得小孩可以吃好穿好，但「治裝/重視穿搭」是成人的消費行為語意。跟 #27（房貸還完=自有住宅狀態）同類：任何 tier/短語隱含「年齡/身分狀態」就要 condition 在該維度上。
**Manually verify the individual cases your rules target.** The contradiction hunt produces 5-10 candidate findings in violence_count order, but which should be fixed and which allowed depends entirely on the dossiers. Each hunt-found violation persona needs PER-DOSSIER analysis, never batch-heuristic. Example: old retiree with low family_income who owns a car — the car was likely purchased before retirement; don't fix. But a 4-person family with fi=1-3万 spending 3000-5000 on clothing — implausible; fix by lowering clothing_spend. Present each violation to the human agent with full persona context; respect human triage. Not all top-findings need repair. a car — the car was likely purchased before retirement, so this is acceptable. But a 4-person family with fi=1-3万 who spends 3000-5000 on clothing — that is implausible (the fix was to drop clothing_spend, keeping the car if public transit is unavailable in their area). The core lesson: present each violation to the human agent with full persona paper; respect human triage; not all top-findings need repair.y on real persona dossiers. Each violation persona (at most 3-5 per hunt finding) should be shown both personal income and the rest of the persona file: residence, transport availability, family context. The analysis reveals that 0-17 children in large families almost always have plausible explanations (car = parents's, housing = owned), while single-adult households with property-carrying dimensions often result from the regen sampling domain. **This manual per-target review should be performed before proposing any fixes**, and not all of the top findings will need repair.

20. **Issue #5：Autoresearch Contradiction Hunt — 自動化矛盾偵測（grill-me 已收斂，spec: `specs/2026-08-05-autoresearch-contradiction-hunt.md`）** — 人工發現矛盾（若希）不可擴展，改為 autoresearch pattern（karpathy/autoresearch：LLM 假設 + 程式驗證閉環）。grill-me 收斂的設計決策（Q1-Q4）：
    - **Q1 假設生成 = Hybrid（C）**：程式列舉維度對（SCORED_DIMS 15 取 2 = 105 對）→ LLM 對每對生成 1-3 個具體假設。不讓 LLM 自由 brainstorm（會漏維度對），也不純程式窮舉（缺語意判斷）。
    - **Q2 假設格式 = 結構化 condition + NL rationale + severity**：`{"id":"H-001","dimensions":[...],"condition":"occupation == '學生' AND income == '>8萬'","rationale":"...","severity":"high"}`。condition 用**受限 DSL**（`dim == '值'` / `!=` / `in` / AND/OR/括號，白名單 ops，拒絕任意 eval）— 安全又可稽核；rationale 給人審核。
    - **Q3 分類 = LLM 三分類 + 分層審核（C）**：掃描違反 → LLM 逐筆判 `contradiction`（真矛盾）/ `explainable`（可解釋，附豁免情境如 fam>1 北漂靠家、0-11 兒童搭爸媽車）/ `insufficient`（資訊不足）→ 篩出 contradiction+severity=high 的小集合（通常幾十筆）→ 人工精審 → 抽驗 10-20% 樣本確認 LLM 分類準確率。
    - **Q4 落地 = 規則草案 JSON → patch diff → 人工 review**：fix 一律**程式模板**（如「重抽 X 維度為低值分布」），**不讓 LLM 生成 code**；審批後產生 `_generate_997.py` patch diff（可 git apply）給人 review 再套用。
    - **驗證閉環（kstsai 明確要求）**：regen 後**再跑一次 hunt 對比** — Recall（上次矛盾應 0 殘留）/ Precision（真矛盾比例應上升）/ 新發現（證明自動化 > 肉眼）。歷史報告存 `reports/contradiction-hunt-<version>.md` 當對比基準。
    - **執行順序**：`scripts/contradiction_hunt/` 的 dsl.py → hunt.py → classify.py → rules.py → 首跑 v4.4.3 基準（tickets 在 `.tickets/autoresearch/`）。
    - 定位：這是現有 `qa_validate.py`（23 rules）的**進階層** — 抓「已知規則沒寫到的未知組合」。

### Autoresearch hunt 實作 gotchas（issue #5 首跑教訓）

**25. Domain reinforcement — hobby 需要 REPLACE 操作，不是 merge/add：** LLM 常產出通用 hobby 值（如「運動」），但 DB 只有具體活動（登山/球類/游泳/廣場舞）。現有 `domain_filters` 對 `dim not in filters` 時才補 filter，但 hobby 已在 filters（LLM 已給了 `hobby=["運動"]`）時會跳過 reinforcement。修法：
    - `domain_filters` 加 運動/健身/跑鞋 → hobby: `["登山","球類","游泳","廣場舞"]`
    - hobby 特殊處理：`elif dim == "hobby"` → `filters[dim] = vals`（**覆蓋**，不是 merge）
    - 實測：jogging query `total_matched` 從 0 → 117（`hobby=["運動"]` 無法在 DB 找到任何人）
    - **驗證**：domain reinforcements 在 log 輸出 `"replaced hobby with [...]"`（非 added）
    - **通用教訓**：任何 LLM 產出的「名目型 dimension filter」若 DB 值為封閉列舉，都存在這個 mismatch。修法是 domain reinforcement 對該 dim 用 replace。hobby 是第一個觸發的案例。，不能只傳 hypothesis 相關的 2 個：** 首跑時 `classify_batch()` 只傳了 `hypothesis.get("dimensions")` 的 2 個相關維度給 LLM，結果 328/329 被判 `insufficient`（LLM 資訊不足無法判斷）。修法：改傳全部 15 個 SCORED_DIMS — LLM 看到 `age=0-11 + family_size=3` 就知道「小孩搭爸媽車、非真矛盾」→ `explainable`。修後 201/209 被判 `explainable`、3 `insufficient`、5 `contradiction`。**這對三層篩選的 LLM 分類至關重要 — 分類速度瓶頸在 LLM 理解，不在 token 量。**

**22. rules.py — fix_counter 必須與 FIX_TEMPLATES key 一致：** 首跑 `rules_draft.diff` 產生了錯誤的 fix code（`hb_lowcs` 查不到 template，fallback 到 `reassign_inc` 改 income → 對 `housing_burden='高' AND clothing_spend='>5000'` 的修正是改 `inc` 而不是 `clothing_spend`）。根本原因：FIX_TEMPLATES 的 key 是 `"lowhb_lowcs"` 但 `counter` 欄位寫 `"hb_lowcs"` → `generate_patch_diff` 用 `r.get("fix_counter")` 查 template 查不到。**修法：counter 值 = template key（如 `"counter": "lowhb_lowcs"`）。diff 產出後一定要人工確認 fix code 與 condition 匹配。**

**23. hunt.py — positional arg 順序是 `hunt.py <data.json> <flags>`，不是 flags first：** `python3 scripts/contradiction_hunt/hunt.py tw_persona_1069.json --skip-llm` ✓，`python3 scripts/contradiction_hunt/hunt.py --skip-llm` ✗（會把 --skip-llm 當成 db_path 拋 `FileNotFoundError`）。

**24. 再跑對比驗證 Recall 的流程：** regen 後 → `hunt.py <new_data.json> --skip-llm`（用同一批 hypotheses 掃新資料）→ 確認目標 contradiction hypotheses 的 violations 歸零 → `Recall = 0` 即規則生效。首跑 v4.4.3 → 套用 R-D/E/F/G regen v4.5 → 再跑 recall = 4/4 zero ✅。

**27. `classify.py` 用 pro model + full SCORED_DIMS batch classify 會 timeout（2026-08-11 實測）**：deepseek-v4-pro 對 batch classify（10 personas × full 15 dims）持續回 reasoning-only empty content，retry loop 跑一小時以上沒進展（996 violations 要跑幾小時）。flash 硬編碼 + batch=3 + `llm.py` skip-reasoning-retry 後仍大量 fail（641 violations → 僅 33 筆成功分類）。**最終決策：contradiction hunt 跳過 classify 步驟**，直接用 `violations.json` 的 top N（by violation count）+ 人工分析。LLM 負責假設生成（擅長的），人工負責分類（擅長的）。若需 LLM 輔助，只用於低 violation count 的高 severity 個案（≤20 筆），且用 flash + batch=1。

**25. Prompt grounding（C 優於 B）— LLM 產出「不存在於 DB 的值」時的修正策略（2026-08-11）**：當 LLM 生成 filter 值時用了「運動」但 DB 只有「登山/球類/游泳」，有三種策略。A（domain reinforcement 補丁）是即刻見效的 stopgap，B（regner 加泛用值）會模糊資料分類（「運動」vs「登山」是上下位關係，混用破壞精細度 — 違反 persona 可信度原則），**C（prompt grounding — 在 QUESTION_ANALYSIS_PROMPT 列出實際 DB 值）是正確長期解**：LLM 看到有效選項就不會發明不存在的值。做法：對每個有封閉值域的 dim（hobby），在 prompt 的「有效選項」中列出實際值（從 tw_persona_1069.json 統計），並加註「資料庫只支援上述 N 個值，沒有泛用詞如『運動』」。不要用 B（加泛用值）— 這會 compromise 資料品質。Domain reinforcement 當 fallback，不是根因修正。**教訓：永遠把 prompt 寫成 ground truth — LLM 會照 prompt 裡的「有效值」去選，錯的是 prompt 不是 LLM。**首例：jogging query 的 hobby prompt 曾列出「運動」和「戶外活動」— 但 DB 沒有這兩個值。修 prompt → LLM 自發挑「登山/球類/游泳」→ total_matched 從 0 → 41。見 `references/housing-burden-ordering.md` 的同類型 prompt-vs-DB mismatch 案例。

**26. **regen 後 housing_burden distribution 異常 → 檢查計算順序（issue #6 bug 1）**：housing_burden 必須在 ALL coherence rules + adjust_family_income_by_tier 之後重新計算。順序錯誤 → stored burden 失準（TW-P-0374: hc<5千/mid=2500, fi=3-5萬/mid=40000 → ratio=0.0625 該是「低」但 DB 存「高」）。修法見 `references/housing-burden-ordering.md`。

**29. Query-based scoring — dim_importance + tier_match（issue #11, Q1-Q3) 架構：** filter-only scoring 在 relaxation 後無法區分相關性（TESLA relaxed 掉 income/age/occ → 12 歲學生芯芯排第一）。改為：LLM 產 `dim_importance`（每 dim 權重 0-1）+ `tier_match()`（有序 dim 依 tier 距離給 partial credit: same=1.0, 1 away=0.7, 2=0.4, 3+=0.1）。公式：`score = Σ imp[dim] × tier_match(val, target) × rarity_weight`。relaxed dims 用**原始 filters**（relaxation 前）計 tier_match → 被放寬的 dim 仍能區分遠近（芯芯 age=12-18 vs target=35-44 → dist 3 → 0.1）。改動：`api/persona_matcher.py` 新增 `tier_match()`、`score_persona()` 改簽名；`api/llm.py` 加 `dim_importance` 輸出格式；`api/server.py` 保留 `original_filters`、pass `dim_importance`。見 `references/tier-match-scoring.md`。

**30. API `role` 參數 — B2B 場景的角色感知過濾（v4.6.1, 甲方 feedback 2026-08-11）**：同一 query（房貸優惠）由不同角色（房仲 vs 銀行）問時，應產生不同的 target filters — 房仲想找換屋族/首購族，銀行想找高收入轉貸族。API 新增 optional `?role=房仲業者` 參數：`server.py` 傳入 `parse_questions_with_llm(q_list, role=role_or_None)` → `llm.py` 在 prompt 尾部注入角色指引（`角色為什麼問這個問題？他們想要找到什麼樣的人？`，含房仲/銀行/設計師/行銷/研究者 5 個角色的 filter 方向指引）。LLM 依角色調整 income/age/occupation/housing_burden 重點。實測：`role=房仲業者` → 公務員/換屋族（hb=低）top；`role=銀行業者` → 金融業/轉貸族（hb=中）top — 明顯分化。

**⚠️ 更正（2026-08-13，v4.8 後 Role QA 抓出）：初版 role_hint 其實沒真的分化。** lzcdh5 fresh install 跑 test-api.sh 時，房仲和銀行對「房貸優惠方案」產出**完全相同的 filters**（age/occupation/income/marriage/housing_burden/family_income 六維全同），Role QA 顯示 `top=201 兩邊一樣`。兩個根因：(1) **role_hint 位置太後面** — 原本 `append` 在「回應格式 + 注意」之後，LLM 已經想好 filters 才看到；(2) **role_hint 太泛** — 只給定性描述（「換屋族 vs 轉貸族」）+ 一次列出 5 個角色，LLM 沒把它翻譯成不同維度值，兩角色都收斂到「25-54歲高收入科技/金融」。**修法（已進 llm.py）：** ① `ROLE_GUIDANCE` dict — 每個角色給**具體維度指引**（房仲→「年齡偏 30-45、family_size 3-4、housing_burden 低」；銀行→「年齡偏 40-55、housing_burden 中/高、income/family_income >8萬」），關鍵是「哪個維度該偏哪個值」而非「找什麼樣的人」；② 用 `{role_guidance}` placeholder 注入在 **format spec 之前**（`{data_overview}` 之後）。實測：房仲 `age=[25-44]` top=小光(25-34) vs 銀行 `age=[35-64]` top=雅芳(35-44) — 真正分化。**通用教訓：給 LLM 的角色/情境指引，要具體到「改哪個維度、偏哪個值」，且位置要在 format spec 之前，否則 LLM 會無視它收斂到同一答案。**

**31. Interactive LLM-DB filter loop（issue #12 grill-me Q1-Q5 收斂，spec `specs/2026-08-12-interactive-llm-db-loop.md`）** — **取代 blind relaxation**。現有 relaxation 是 hardcoded dim_order 丟維度，不知道哪些 dim 對當前 query 重要（TESLA: 丟了 income/age → 12 歲學生排第一）。新 pipeline：`LLM → filters → DB scan → count < TARGET? → LLM broadening loop (max 3) → score + return（or TOO_STRICT）`。三個階段：① **Data grounding** — `build_distribution_summary(db)` 動態產 per-dim 分布摘要（~900 chars），注入 LLM prompt → LLM 看到「金融只有 70 人」就不會只用金融 filter；② **Broadening loop** — LLM 自行決定放寬哪個 dim（保有 domain 語意，不像 relaxation 盲目丟），每次 loop 記錄 `broadening_attempts`；③ **TOO_STRICT fallback** — loop exhaust → `status="too_strict"` + partial results（誠實告知，不強行鬆到沒意義）。保留：original_filters + scoring + tier_match + role parameter。消除：hardcoded dim_order relaxation。見 `references/interactive-loop-design.md`。

**32. `dim_importance` 值型別錯誤 → 500（issue #14 v4.7.1）** — LLM 回傳的 `dim_importance` JSON 值常是 **string**（`"0.95"`）或 range string（`"0.8~1.0"`，因 prompt 範例寫成 `0.8~1.0` 被 LLM 照抄）。`score_persona` 直接 `imp * tm * rw` → `TypeError: can't multiply sequence by non-int of type 'float'`，每個 `?role=` query 都 500。修法：`_to_float()` 邊界轉換（正則抓前導數字，default=0.5）。**通用教訓見 `llm-api-patterns` skill pitfall #7** — 永不信任 LLM JSON 數字欄位是真正的數字，消費前一律 coerce。

**33. reasoning-heavy model 空 content → 從 reasoning_content 抽答案，不要無限重試（issue #14 v4.7.1）** — deepseek-v4-pro 對 TESLA query 持續把 token 花在思考、`content` 回空，舊 code 的 `max_tokens *= 2` retry 陷入 4000→8000→4000→8000 ping-pong，單一 query 卡好幾分鐘。修法：`_extract_json_or_text(reasoning_content)` 直接從思考鏈抽 JSON/答案（reasoning model 常在 CoT 結尾寫出最終答案），抽不到才 retry。**通用教訓見 `llm-api-patterns` skill pitfall #8** — 先 harvest `reasoning_content`，retry 當 fallback 而非 primary。

**34. pro model 85s latency = prompt bloat，不是 bug（v4.7）** — v4.7 加了 data grounding（~900 chars 分布摘要）+ role hint + dim_importance 指令後，`deepseek-v4-pro`（reasoning model）思考時間從 ~30s 膨脹到 **85s**。這跟 issue #14 的「empty content + 無限重試」是**兩個不同問題**：修好重試後 latency 仍在，根因是 prompt 變大 → reasoning chain 變長。治本：analysis model 的 base `max_tokens` 從 4000 提到 **8000**（`"pro" in model.lower()` 才觸發）。**要證明 pro 值 85s**：不要靠單一 query 印象（v4.5.1 只有一個 fashion case「教科書級」就信了），要 A/B 對照 — 同一批 query（5-10 題跨 domain）用 pro 和 flash 各跑一次，並排 dump `llm_analysis`（filters + dim_importance + reasoning）給人/甲方逐題評。`scripts/compare_models.py` 是現成工具（`analyze(query, model)` 對 `QUESTION_ANALYSIS_PROMPT` + 分布摘要，兩 model 各 call 一次）。評分維度：filter 合理性 / top 排序 / 有無發明值 / 有無 FILTER_FAILED。若 pro 優勢只在少數 domain，考慮 C 方案（default flash、`?role=` 指定才用 pro）。

**35. 用 sed `c\` + `$(cat ...)` 改 deploy script 會把 literal 字串寫進檔（v4.7.1）** — 想用 sed 多行替換 `deploy-hermes-personadb-containers.sh`，結果 `$(cat /tmp/new_block.txt)` 被當成**字面字串**寫進檔 → `#: command not found`，deploy script 壞掉。修法：**不要用 sed 改多行 shell script**，用 `patch` tool 或直接 `scp` 正確版本覆蓋。若已寫壞，`git checkout HEAD~1 -- <file>` 恢復上一個好版本再重做。改完後 `bash -n <script>` 驗證語法再跑。

**36. deepseek-v4-flash 也是 reasoning model — `thinking={"type":"disabled"}` 是關掉它的正解（issue #14, 2026-08-12）** — 之前 pitfall #27 誤寫「flash 無 reasoning mode，秒回」是**錯的**：flash 也會把 token 花在 reasoning_content，長 prompt 下 `finish_reason=length`、content 空（3/5 query parse failed）。根因不是模型笨，是**沒關 reasoning**。正解：`call_llm` 對 flash 送 `payload["thinking"] = {"type": "disabled"}` → 直接輸出 JSON，每題 ~3s（vs pro 85s），5/5 合法。但品質降級：flash-disabled 只補 core demographics（age/occupation/income），**漏消費維度**（clothing_spend/commute_mode/family_income）— 正是 domain reinforcement（pitfall #14/#25）一直在補的洞。結論：pro 的價值 =「reasoning 後記得交作業」（可靠結構化輸出 + 主動補消費維度），flash =「快但思考一半就下課」。A/B 對照驗證法見 pitfall #34（`scripts/compare_models.py` 現成工具）。

**37. DSL parser paren token bug（contradiction_hunt/dsl.py, 2026-08-12）** — tokenizer 產的 token type 是 `"paren"`（值才是 `"("`），但 `parse_atom` 判斷括號用 `t[0] == "("` → 所有帶外層括號的 condition（如 `(age == '0-11' AND ...)`）parse 失敗，`hunt.py` 印「Expected identifier (dimension name), got ('paren', '(')」，6 條 hypothesis 被跳過（看似 hunt 只抓到 59/65 條）。修法：`if t[0] == "paren" and t[1] == "(":`，閉括號同理 `t[0] != "paren" or t[1] != ")"`。症狀辨識：`hunt.py` 輸出有「Expected identifier ... got ('paren', '(')」代表有 hypothesis 因外層括號被 DSL 略過，不是資料問題。

**38. 資料正確性/合理性驗證是「顧客最會挑」的重心 — 用 10 步閉環（issue #15-17, v4.7 定案）** — API 功能穩定後，重心轉向驗證 persona 資料本身。10 步流程與教訓見 `references/data-verification-workflow.md`。最關鍵的洞察：**合理性分析（pro 逐筆審 persona）的真正價值是「把數百筆 symptom 收斂成幾個系統性 generator bug」，不是揪零星個案**。v4.7 案例：pro 標 47 筆「不合理」，實為 3 個系統性 bug（`hh_income_tier` 城市分級被誤讀、`family_income < income` 下調無下限檢查、退休/家管 + 職場敘述）。**先看 pro 的 verdict 是否聚合成共同 pattern，聚合後修 generator 一處勝過修數百筆個案。** 另外：合理性分析**只審 hunt-flagged 嫌疑筆**（pro 85s/題 × 1069 = 25 小時不現實）；殘留修不完的列 GitHub issue 當 known issue，對顧客宣稱用「沒被現有規則抓到矛盾」而非「沒問題」（有範圍、可防禦）。

**39. BG 短語 replace 修法會引入新 QA violation（Pattern 7 修法教訓, v4.8）** — 修「未婚+含飴弄孫」時，第一版把「含飴弄孫」`story.replace` 成「一個人過日子」，但未婚者可能 fs>1（跟父母/兄弟住），立刻撞到 QA R19「family>1 但一個人過日子」→ regen 後 QA 冒出 2 筆新 violation。**教訓：任何 BG 短語 replace 後，不只掃目標 pattern 的殘留，一定要重跑完整 `qa_validate.py`** — 修法補丁常會踩到另一條 QA rule。replacement phrase 要用中性敘述（如「日子過得簡單」），避開「一個人」「老伴」「小孩」這類隱含 family_size/marriage 狀態的字眼。

**40. 城市層級屬性（city_price_tier / city_income_tier）不該是 filterable dim，且要加 `city_` 前綴（issue #15 定案, option B）** — `hh_income_tier`（城市家戶所得分級，依 `residence` 查表得來：新竹=極高、台東=低）與 `price_tier`（城市物價分級）是**從 residence 可推導的城市屬性，不是 persona 個人屬性**。三個問題：(1) 欄位名讀起來像「個人」的（`hh_income_tier` = 「家戶所得分級」），pro model 和讀 raw JSON 的顧客會誤以為是這個人的所得等級 → 每次合理性分析產生 ~18 筆 false positive（`hh_income_tier: 極高` + `family_income: 1-3萬` 看似矛盾）；(2) 它們在 `valid_dims` 裡 = **可被 API 篩選**，顧客 filter `hh_income_tier=極高` 拿到的是「住高所得城市的人」不是「高家戶所得的人」— 語意錯誤的查詢結果；(3) 只是改顯示 label（query_persona/報告）不夠 — pro 讀 raw 欄位名，不是讀 label。**正解（no external consumer 前提）：rename 成 `city_income_tier` / `city_price_tier` + 從 `valid_dims` 移除**（城市分級可從 residence 查表，不該當可篩維度）。改動點：generator 輸出 key（`_generate_997.py` 的 dimensions dict）、`api/persona_matcher.py` 的 `valid_dims`、`api/models.py` PersonaSummary、`api/server.py` summary builder、`query_persona.py`、`scripts/gen_verification_report.py` DIM_LABELS + cat_dims、`scripts/persona_review.py`、`scripts/contradiction_hunt/hunt.py` EXCLUDED_DIMS。**對比：新增「個人」維度時才進 valid_dims（見 ticket 三層清單）；新增「城市/可推導」屬性時要 rename + 排除 valid_dims。** 反向判準：一個維度若值完全由 residence 查表決定（`HH_INCOME_TIER.get(residence)`、`PRICE_TIER.get(residence)`），它就不該獨立可篩。

**41. LLM prompt 的 JSON 輸出範例必須是合法 JSON — 加欄位後 render + json.loads 驗證（issue #13, 2026-08-13）** — 在 `QUESTION_ANALYSIS_PROMPT` 的 JSON 範例加 `dim_importance` 欄位時，漏加 `filters` 的閉合 `},`（導致 `dim_importance` 被嵌進 `filters` 內）+ 多一個 stray `}}`。結果 LLM 輸出的 `dim_importance` 解析不穩定（有時空 `{}`、有時嵌錯位置），`?role=` query 的 scoring 無法用 importance 區分。**症狀辨識**：`?role=` query 的 `dim_importance` 回 `{}`、Role QA 兩角色 top 相同。**修法/通用教訓**：任何修改 LLM 結構化輸出範例（加欄位/改格式）後，**render 整個 prompt 並把範例 JSON 區段抽出來 `json.loads()` 驗證** — 範例本身錯，LLM 就照錯的結構輸出。可用 `QUESTION_ANALYSIS_PROMPT.format(...)` render 後，定位 `"filters"` 到 `"question_analysis"` 之間的字串補齊外層 `{}` 後 `json.loads()`。這跟 pitfall #7（LLM JSON 值型別漂移）是同一類「LLM 結構化輸出的信任問題」：**範例要 valid + 數值要 coerce，兩者都要防。**

**42. broadening loop 的 pro max_tokens 太小 → 靜默 break → total 卡在個位數（issue #24, v4.8.2）** — `server.py` 的 broadening loop 原本用 `max_tokens=1000 if loop > 1 else 2000` 呼叫 pro model，pro 的 reasoning 吃光預算 → `content` 空（`finish_reason=length`）→ `if not result: break` **靜默失敗** → `broadening_attempts` 留空、`total_matched` 停在 3（遠低於 TARGET_MIN=20）。**症狀辨識**：test 結果某 domain `total_matched` 個位數 + `broadening_attempts: []`（loop 沒記錄任何嘗試）= 不是「filters 太嚴」，是 broadening loop 根本沒成功執行。修法：`broaden_max_tokens = 8000 if "pro" in analysis_model.lower() else 2000`。這是第 4 次踩同一個坑（reasonableness 800 / analysis 4000 / broaden 2000）— **每個 hit reasoning model 的 call site 都要 model-aware 的預算，不只主 analysis call**。通用教訓 + 4 層防火牆（L1 一次到位 / L2 只截斷才 retry / L3 免費提取 reasoning / L4 硬預算+熔斷）見 `llm-api-patterns` skill pitfall #11 + `specs/2026-08-13-llm-retry-firewall.md`（issue #24）。**核心方向（kstsai 定調）：不要 doubling retry（token maximize 反模式），要 upfront 足額預算 + 精準 retry。**

**broadening loop 還有第二個 bug 類別（D6，v4.8.2 LLM verify 抓出）：BROADEN_PROMPT 缺有效值清單 → LLM 發明 DB 不存在的值。** 實例：TESLA broadening loop 產出 `clothing_spend=["500~1000","1000~1500"]`，但 DB 有效值是 `500~1500`（`~` 前後是「範圍」不是兩個值）— 這些值不 match 任何人，整次 broadening call 白燒 8000 token。根因：`QUESTION_ANALYSIS_PROMPT` 有列每維度有效值（見 pitfall #25 prompt grounding），但 `BROADEN_PROMPT` 沒有，LLM 就自己發明。修法：BROADEN_PROMPT 附上與 QUESTION_ANALYSIS_PROMPT 相同的有效值清單 + 一句「只能使用上述有效值，不要發明不存在的值」。**⚠️ second-order bug（v4.9.0 LLM verify 抓出）：這份有效值清單本身必須「完整」** — 第一版清單漏了 `region`/`education`/`housing_burden`/`housing_cost`（QUESTION_ANALYSIS_PROMPT 也漏，但它沒有「只能使用」的嚴格指令所以沒出事），加上「只能使用下列值」後 LLM 反過來把 `housing_burden` 當成「不在清單 = 無效」而**誤刪**（broadening change 寫「移除無效維度 housing_burden」）。**通用教訓：加「只能使用下列值」這類嚴格指令時，清單必須涵蓋所有合法維度（含 region/education/housing_burden/housing_cost 這些常被漏列的），否則 LLM 會把漏掉的合法維度當無效刪掉。** 補法：從資料檔統計實際值域後兩 prompt 都補齊：`python3 -c "import json; db=json.load(open('tw_persona_1069.json')); [print(d, sorted(set(p['dimensions'].get(d,'') for p in db))) for d in ['region','education','housing_burden','housing_cost']]"`。這是「避免無效 LLM call」的第三種實例（前兩種：D2 garbage/reasoning-only 不重試、D4 no-op loop）— **通用教訓：每個會產出 filter 值的 LLM call site（不只主 analysis prompt）都要做 valid-value grounding。** 症狀辨識（LLM verify 時）：applied_filters 出現值域外的值（如 `500~1000` 不在 `<500/500~1500/1500~3000/3000~5000/>5000` 的封閉集合）。

**43. deploy script 的「資料已存在就跳過 extraction」→ re-deploy 等於沒更新（2026-08-13）** — `deploy-hermes-personadb-containers.sh` 的 Step 2 有 guard：

```bash
if [ ! -f "${PERSONA_DB_DATA}/tw_persona_1069.json" ]; then
  ... tar xzf tarball --strip-components=1 ...
else
  echo "  ✅ Data already present"   # ← 跳過，tarball 完全被忽略
fi
```

只要資料檔已存在，**re-deploy 不會更新任何東西**（VERSION 停在舊版、code/data 都 stale）。這跟 pitfall #12「tarball 部署 ≠ code 更新」是同一個根因的結構化版本 — 不是「偶爾 stale」，是**每次 re-deploy 都 stale**。實例：fresh install v4.8.2 後 status 顯示 v4.8.1，因為 `docker rm -f` + re-deploy 跳過 extraction。**正解：pre-release SOP 用 `undeploy.sh`（`sudo rm -rf /srv/persona-db-data/` + `~/.hermes/`）做 full clean，再 deploy → 資料夾空 → extraction 必然執行。** 若要修 script 本身，把 guard 改成 `if [ "$TARBALL" -nt "${PERSONA_DB_DATA}/tw_persona_1069.json" ] || [ ! -f ... ]`（tarball 較新才解壓）。驗證部署是否 fresh：`docker exec persona-db-api cat /app/VERSION` 必須等於 tarball 的 VERSION。

**44. broadening overshoot — LLM 一次移除多維度 → total 暴增（issue #25, 2026-08-14）** — BROADEN_PROMPT 只寫「放寬 1-2 個維度」，沒強制「每次只動 1 個」，LLM 一次刪掉 2+ 維度（實例：房仲 loop 1 刪「職業+家庭人數」、loop 2 刪「婚姻」→ total 4→18→97，遠超 TARGET_MIN=20）。這是 retry 防火牆「避免無效 LLM call」的第 4 種實例（前 3 見 pitfall #42：D2 garbage 不重試、D4 no-op loop、D6 無效值）— overshoot 的維度放寬一樣是 token/精準度浪費。**修法（雙重，prompt + code 都要）**：
- `server.py` 強制每 loop 最多移除 1 維度：`removed_this_loop = [dim for dim in filters if dim not in new_filters]`，`len > 1` 時把多餘的還原舊值（`new_filters[dim] = filters[dim]`）
- `BROADEN_PROMPT` 改「**只放寬或移除 1 個篩選維度**」+ 加「**嚴格限制：每次回覆只能放寬或刪除 1 個維度**」
**症狀辨識（LLM verify）**：`broadening_attempts` 的 `change` 寫「刪除 X 與 Y」「移除 X、Y 兩個維度」、`match_count_after` 遠超 TARGET_MIN（暴增數十倍）。驗證：房仲 total 97→37，每 loop 只動 1 維度（5→12→37 漸進）。注意這跟 D6（發明無效值）是**不同 bug** — D6 已修「值」、#25 修「移除維度的數量」，兩者都是 broadening loop 的品質問題，但 root cause 不同，別混為一談。

## 團隊協作（collaboration-contract skill）

a2/a945 設計的多角色協作協定（本機已安裝 `autonomous-ai-agents/collaboration-contract`，lab-riscv `ai-agents/hermesa3/skills/` 有備份）：
- **Domain 分工**：a3 = persona-db（生成/驗證/API/release）；a945 = 跨域整合（wiki 消化、e2e review）
- **Contract-per-Pair**：角色間單一介面（inbox/issue/目錄），禁止直接丟任務到對話等回應（bottleneck）；寫入明確介面讓對方自行取出（非同步 pipeline）
- **a3 義務**：① Skill 變動時 **push 到 lab-riscv**（`ai-agents/hermesa3/skills/`）；② 下次 incoming 包告訴 a945 更新 capability matrix；③ grill-me 討論跨域找 a945
- **狀態機**：TODO | WIP | Pending(等誰) | Done — Pending 必帶「等誰」；**Review 鐵律：reviewer 跑完整 e2e 驗證，不做靜態檢查式 approve**
- **同步檢查**：改完 skill 後用 `find ai-agents/hermesa3/skills -name SKILL.md` 對比 `~/.hermes/skills` 的自製 skills（兩向同步：本機→repo 備份 + repo→本機安裝）
