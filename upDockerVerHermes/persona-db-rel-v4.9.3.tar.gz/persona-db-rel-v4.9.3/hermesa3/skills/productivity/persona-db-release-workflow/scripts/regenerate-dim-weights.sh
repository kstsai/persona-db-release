#!/usr/bin/env bash
# regenerate-dim-weights.sh — regen 後重建權重表 + 驗證（issue #4）
# 用法: bash regenerate-dim-weights.sh [persona-db-repo-path]
set -e
REPO="${1:-$HOME/persona-db}"
cd "$REPO"

echo "=== 1. 重建 dim_weights.json ==="
python3 scripts/gen_dim_weights.py

echo ""
echo "=== 2. 驗證: 15 維度 + 值域 ==="
python3 - <<'EOF'
import json
w = json.load(open("dim_weights.json"))
dims = [k for k in w if not k.startswith("_")]
print(f"dims: {len(dims)} (expect 15)")
assert len(dims) == 15, f"got {len(dims)} dims"
for d in dims:
    vals = w[d].values()
    lo, hi = min(vals), max(vals)
    n = len(vals)
    # ≤3 值維度 → [0.8, 1.4]；≥4 值維度 → [0.5, 2.0]
    if n <= 3:
        assert lo >= 0.8 and hi <= 1.4, f"{d}: {lo:.2f}-{hi:.2f} out of [0.8,1.4]"
    else:
        assert lo >= 0.5 and hi <= 2.0, f"{d}: {lo:.2f}-{hi:.2f} out of [0.5,2.0]"
    print(f"  ✅ {d:16s} {n} values  {lo:.2f}-{hi:.2f}")
print("weight table OK")
EOF

echo ""
echo "=== 3. 可重現性 (跑兩次 diff) ==="
cp dim_weights.json /tmp/dw_check.json
python3 scripts/gen_dim_weights.py >/dev/null
if diff -q /tmp/dw_check.json dim_weights.json >/dev/null; then
    echo "✅ reproducible"
else
    echo "❌ NOT reproducible — 檢查 gen_dim_weights.py 是否有非確定性"
    exit 1
fi
rm -f /tmp/dw_check.json

echo ""
echo "=== 4. 提醒 ==="
echo "- dim_weights.json 是資料衍生產物: 資料 regen 後必須重跑本 script"
echo "- 新維度加入時同步更新 SCORED_DIMS (scripts/gen_dim_weights.py)"
echo "- 權重表變動 → Verification Report 權重統計 + RFC Scoring 章節同步"
