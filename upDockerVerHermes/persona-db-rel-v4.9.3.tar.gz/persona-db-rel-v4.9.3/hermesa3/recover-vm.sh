#!/bin/bash
# ─── hermesa3 VM 復原腳本 ───
# 用法: 在 ubuntu-ai-agent VM 上執行
# 或: scp 到 VM 後執行

set -e

echo "=== Step 1: 安裝 Hermes agent ==="
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash

echo "=== Step 2: 建立 ~/.hermes 目錄 ==="
mkdir -p ~/.hermes

echo "=== Step 3: 填入 Slack tokens (手動) ==="
echo "請從 Slack API Dashboard 填入 token:"
echo "  SLACK_BOT_TOKEN = xoxb-..."
echo "  SLACK_APP_TOKEN = xapp-..."
echo "  填入 ~/.hermes/.env"
echo ""
echo "格式:"
echo "SLACK_BOT_TOKEN=xoxb-xxx"
echo "SLACK_APP_TOKEN=xapp-xxx"
echo "GATEWAY_ALLOW_ALL_USERS=true"

echo "=== Step 4: 設定 systemd service ==="
sudo tee /etc/systemd/system/hermes-gateway.service << 'SVC'
[Unit]
Description=Hermes Agent Gateway - ubuntu-ai-agent VM
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/.hermes
ExecStart=/usr/bin/python3 -m hermes_cli.main gateway run
Restart=always
RestartSec=5
Environment=HERMES_HOME=/home/ubuntu/.hermes
Environment=GATEWAY_ALLOW_ALL_USERS=true

[Install]
WantedBy=multi-user.target
SVC

sudo systemctl daemon-reload
sudo systemctl enable --now hermes-gateway

echo "=== Step 5: Git repo setup ==="
cd ~
git clone http://192.168.1.178:30080/lzcadmin/lab-riscv.git
cd lab-riscv
git remote set-url origin https://github.com/kstsai/lab-riscv.git
git remote add gitea http://192.168.1.178:30080/lzcadmin/lab-riscv.git
cp ~/lab-riscv/sync-gitea-github.sh ~/

echo "=== 復原完成 ==="
echo "請手動填入 Slack token 後重啟:"
echo "  sudo systemctl restart hermes-gateway"
echo "  journalctl -u hermes-gateway -f"
