Gitea at gitea.local (internal). Git workflow per repo: pull origin → push gitea → commit → push gitea → push origin. Repos: lab-riscv (infra), persona-db (persona), mediawatch (media analysis).
§
Persona DB 1069 personas in ~/persona-db/ (extracted from lab-riscv). Gitea: lzcadmin/persona-db.
§
Delegation: deepseek-v4-pro (provider=custom:deepseek-pro, model=deepseek-v4-pro). Parent uses deepseek-v4-flash.
§
Persona DB latest: v3.7 (2026-07-13), 1069 personas, seed=42, QA 20/20 all deviations <0.5%. 分身v3.2釋出.
§
Worklog convention: worklogs/WORKLOG-YYYY-MM-DD.md (summary + tables) + worklogs/RAW-RESULTS-YYYY-MM-DD.md (full LLM raw responses). Taiwan time CST+8.
§
本尊工作成果 push 到 GitHub private + Gitea dual remote。
§
Media Watch: ~/media-narrative/ (public). Scraper mediawatch/_eight_media_report.py. Cron daily 10:00 + deep 01:00.
§
tw-persona-db skill v3.10.0 updated: First-Time Setup section now includes git init + dual-remote workflow for fresh instances; section H adds Transfer Readiness 10-step verification checklist. Both patched from 2026-07-14 clone verification session.
§
Clone instance (192.168.1.121): ~/persona-db/ Transfer 驗證完成 (QA 23/23 PASS). Git init + dual remote. Session 管理: 讀取 vs 恢復 雙模式。
§
Session 管理 lesson: 不用靜態 markdown 追進度（會過期）。改用 session_search + memory 即時查。當 kstsai 問「我剛在忙什麼」：session_search(limit=5) + memory scan → 動態合成。跨 channel @mention 也能搜到。
§
Dual-repo delivery: client materials go in BOTH persona-db (private) AND media-narrative (public). Private=full tools+data. Public=docs/worklogs/proposals only.
§
2026-07-18 API設計定案: GET /personadb/candidates (取代/init). LLM-powered. opMode=僅篩選/篩選+模擬. top_k=12. Docker container 取代 qcow2. Issue query idea 保留改進.
§
2026-07-18: LLM-powered REST API v0.2 complete — /personadb/candidates replaces /personadb/init. questions are pipe-separated string. usage_suggestion field in response tells clients whether personas fit 模擬詢問 or 問卷答題者. Key lesson: LLM prompt must include exact DB dimension values or filters mismatch → 0 results.