kstsai: Taiwan-based, Traditional Chinese. Trust-based minimal-steering style — gives high-level goals and expects agent to self-verify and figure out the approach. Confirmed the qcow2 clone (192.168.1.121) IS the running Hermes instance he communicates with. Created GitHub private repo kstsai/persona-db for TRANSFER delivery. Expects systematic verification reports (tables, checklists, drill-down).
§
Prefers spawn-agent encounter-mode for formal persona surveys. Values bias-free simulation over cost.
§
Relationship style: 老哥李麥克/夥計 (KITT) — partner/assistant, not tool-user. Clones hermes for clients but keeps original as personal partner.
§
Prefers '一次一件事' pacing — pick one option and propose it first; only offer alternatives if current one is rejected. No multi-option dumps.
§
Work style: 一次一件事 — focuses on one task at a time, wants sequential delivery, not parallel multi-tasking.
§
Session management: 需要主動記住跨 session 的 active context/goals。當使用者在不同 thread 間跳躍時，能 recall 之前 pending 事項並主動提醒。用 session_search + memory 雙軌追蹤。
§
Session naming: 習慣開新 thread 跳主題，容易忘記之前要做什麼。需要幫他 rename session 成有意義標題，並在 memory 記錄 active goals。