# hermesa3 — Agent 交付包

> hermesa3（a3）agent 的可交付項目。來源：`lab-riscv/ai-agents/hermesa3/`（2026-08-25 同步）。
> 與 persona-db 產品一起交付的 agent instance 素材。

## 交付內容

| 目錄/檔案 | 內容 | 用途 |
|:---------|:-----|:-----|
| `config.yaml.template` | hermes config 範本（Slack/model provider） | 新 VM 部署 hermesa3 用 |
| `env.template` | .env 範本（Slack tokens） | 同上 |
| `hermes-gateway.service` | systemd service（gateway 常駐） | VM 上跑 gateway |
| `slack-manifest.json` | Slack app manifest（Hermesa3） | 建立/更新 Slack app |
| `recover-vm.sh` | VM 復原 script | 災後重建 |
| `skills/` | **11 個 custom skills**（collaboration-contract、persona-db-*、wiki-meeting-digest、tw-persona-db 等） | agent 能力包 |
| `memory/` | agent 持久記憶（MEMORY.md + USER.md） | agent 知識庫參考 |
| `docs/` | session management workflow + context 管理 | 操作文件 |
| `persona/` | persona-db 商務/里程碑文件（BUSINESS-MODEL、LITE/TRANSFER/UPGRADE 定價） | 商務交付 |
| `releases/` | appliance 打包檔（v3.2 起） | 版本交付 |

## 注意事項

- **上游是 lab-riscv**（`ai-agents/hermesa3/`）— 本目錄是交付快照，改動時同步
- **不包含 live config.yaml / .env**（含實值）— 只給 template，部署時填值
- **skills/ 是 11 個 custom skills**（不含 built-in skills 與 legacy flat .md）

## 部署參考

```bash
# 新 VM 部署 hermesa3
cp config.yaml.template ~/.hermes/config.yaml   # 填 Slack/model 值
cp env.template ~/.hermes/.env                  # 填 Slack tokens
sudo cp hermes-gateway.service /etc/systemd/system/
sudo systemctl enable --now hermes-gateway
```
