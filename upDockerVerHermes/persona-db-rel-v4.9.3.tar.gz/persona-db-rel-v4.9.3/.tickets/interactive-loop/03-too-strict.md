# Ticket 03 — TOO_STRICT response + models

**What to build:** `api/models.py`：`CandidatesResponse` 新增 `broadening_attempts` 欄位 + `status="too_strict"`。`api/server.py`：loop exhaust 時回傳 TOO_STRICT + partial results。

**Blocked by:** 02

**Acceptance criteria:**
- [ ] `BroadeningAttempt` model（loop, change_desc, match_count）
- [ ] `CandidatesResponse.broadening_attempts: list[BroadeningAttempt]`
- [ ] `CandidatesResponse.status` 支援 `"ok" | "too_strict" | "filter_failed"`
- [ ] Loop exhaust → status="too_strict" + partial results + score
- [ ] broadening_attempts 回傳完整的 loop 過程
