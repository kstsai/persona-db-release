# Ticket 04 — 驗證 + Tests + Docs

**What to build:**
1. `test-persona-db-api.sh` 加 interactive loop test cases
2. RFC 加「Interactive LLM-DB Filter Loop」章節
3. `specs/` → `specs/2026-08-12-interactive-llm-db-loop.md`（已完成）
4. Release notes (v4.7)

**Blocked by:** 03

**Acceptance criteria:**
- [ ] TESLA query: strict → loop broadens → ≥20 → 學生排後
- [ ] 房仲 vs 銀行: same query, different filters
- [ ] Loop exhaust: → TOO_STRICT
- [ ] 無 role: 行為不變
- [ ] test-persona-db-api.sh 全部 PASS
- [ ] RFC chapter complete
