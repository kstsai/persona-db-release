# Ticket 01 — Data grounding：LLM 看見資料分布

**What to build:** `api/llm.py` 的 `QUESTION_ANALYSIS_PROMPT` 尾部注入 per-dim 分布摘要（值+人數），供 LLM 調整 filter 時參考。分布資料從 `tw_persona_1069.json` 動態計算（避免 hardcode）。

**Blocked by:** None

**Acceptance criteria:**
- [ ] 新增 `build_distribution_summary()` → 產 per-dim 一行「值(人數)」格式
- [ ] `QUESTION_ANALYSIS_PROMPT` 尾部加 `資料庫概覽（1069 位台灣人設）：`
- [ ] 分布摘要注入不變動現有 prompt 結構
- [ ] 每個 dim 最多列出 8 個值（超過則只列 top 8）
- [ ] LLM call 時自動注入（parse_questions_with_llm）
