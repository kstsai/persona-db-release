# Ticket 02 — Broadening loop：LLM 自我修正 filters

**What to build:** `api/server.py`：置換現有 Step 3b relaxation 為 interactive broadening loop。`api/llm.py`：新增 `BROADEN_PROMPT`。

**Blocked by:** 01

**Acceptance criteria:**
- [ ] `_broaden_filters(filters, match_count, original_llm_context)` → 呼叫 LLM 放寬 1-2 個 dim
- [ ] `BROADEN_PROMPT`：注入當前 filters + match count + TARGET_MIN
- [ ] Loop max 3 次，每次記錄 broadening_attempts
- [ ] dim_importance 不在 loop 重新產出（用 original response）
- [ ] Loop 1 max_tokens=2000，loop 2-3 max_tokens=1000
- [ ] 保留 original_filters（第一次 LLM 產出）
