# Ticket 01 — call_llm 精準 retry（砍 doubling，一次到位）

**What to build:** 重構 `api/llm.py` 的 `call_llm` retry 邏輯，砍掉 `max_tokens * 2` doubling，改為依 model 給足預算 + 只在「真截斷」才 retry。

**Blocked by:** None

**Acceptance criteria:**
- [ ] 新增 `_resolve_max_tokens(model, requested)`：pro 至少 8000（reasoning 不餓死），flash 回傳 requested
- [ ] 移除 `max_tokens * 2` doubling（現行 367 行）
- [ ] retry 條件從「content 空」改為「`finish_reason == "length"`」（截斷才 retry，1 次 +50%，非翻倍）
- [ ] reasoning-only 且非截斷 → 直接 return None（不重試，model 真失敗）
- [ ] reasoning 提取（`_extract_json_or_text`）保留並前移（先挖再決定 retry，現已是此順序）
- [ ] 網路/5xx/timeout 例外仍退避重試，但預算不翻倍、最多 2 次
- [ ] `parse_questions_with_llm` 的 analysis_max_tokens=8000 保留；`broaden_max_tokens` 已在 v4.8.2 加好，保留

**對應 RFC:** D1 + D2 + D3（`specs/2026-08-13-llm-retry-firewall.md`）
