# Ticket 02 — 硬預算 + 熔斷（per-request token budget + circuit breaker）

**What to build:** 在 `api/server.py` 的 `/candidates` 流程加 per-request token 計數上限，並在 `api/llm.py` 加模組層級熔斷。

**Blocked by:** Ticket 01（需先知道每次 call 的實際 token 用量）

**Acceptance criteria:**
- [ ] `/candidates` 流程加 `token_budget = 32000`，analysis + broadening 累加
- [ ] broadening loop 條件加 `tokens_spent < token_budget`（超標停止 loop，回傳 partial + status=too_strict）
- [ ] 熔斷：module-level `_fail_count` / `_cooldown_until`，連續 N=3 次 `call_llm` 回 None（真失敗，非截斷）→ 冷卻期內直接回 partial、不呼叫 API
- [ ] 冷卻期（建議 60s）過後自動恢復
- [ ] 熔斷不影響「截斷 retry」（那是 D2 的正常流程，不算失敗）

**對應 RFC:** D4（`specs/2026-08-13-llm-retry-firewall.md`）
