# Ticket 03 — BROADEN_PROMPT 注入有效值清單（防發明無效值）

**What to build:** `BROADEN_PROMPT` 附上與 `QUESTION_ANALYSIS_PROMPT` 相同的有效值清單，避免 broadening LLM 發明 DB 不存在的值。

**Blocked by:** None

**Acceptance criteria:**
- [ ] `BROADEN_PROMPT` 附上 per-dim 有效值清單（與 QUESTION_ANALYSIS_PROMPT 一致，或從 `build_distribution_summary` 複用值域）
- [ ] prompt 加一句「只能使用上述有效值，不要發明不存在的值」
- [ ] 驗證：broadening 不再產出 `clothing_spend=["500~1000","1000~1500"]` 這類值域外值

**背景：** v4.8.2 pre-release LLM verify 實測抓到：broadening loop 產出 DB 不存在的值（clothing_spend="500~1000"/"1000~1500"，DB 有效值是 500~1500）→ 這些值不 match 任何人 → 整次 call 白燒。

**對應 RFC:** D6（`specs/2026-08-13-llm-retry-firewall.md`）
