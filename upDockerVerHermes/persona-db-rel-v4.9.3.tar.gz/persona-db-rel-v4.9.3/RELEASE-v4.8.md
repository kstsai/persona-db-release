# Persona DB v4.8 Release Notes

> 日期: 2026-08-13 | 上一版: v4.7.1 | 類型: 資料 coherence 大修

## 重點變更：資料正確性/合理性驗證閉環

首次完整跑「regen → contradiction hunt → 合理性分析（pro model）→ 修復 → test-api」流程，揪出並修復 **10 個系統性 bug**（#15-23）。

## 系統性修復

### 第一批（合理性分析 re-review，#15-17）
| Issue | Bug | fixes |
|:-----|:----|:-----:|
| #16 | family_income 低於個人 income（fi_lt_income clamp） | 118 |
| #17 | 退休/家管/失業 + 職場敘述（非職場通勤 + 家管 life-stage） | 239 |
| #15 | hh_income_tier 語意誤導（見下） | — |

### 第二批（Patterns 2-8，#18-23）
| Issue | Pattern | fixes |
|:-----|:--------|:-----:|
| #18 | fam=1 家庭收入高於個人收入（FAM1_FI_MAX 上限） | 32 |
| #19 | 高學歷+專業職業+<3萬（bump income） | 15 |
| #20 | BG 貸款矛盾 + 住家裡免房租 vs 住房成本 | 40 |
| #21 | 12-18歲 + 汽車通勤 | 14 |
| #22 | 未婚 + 含飴弄孫/小孩教育費 | 21 |
| #23 | 苗栗縣 region 北部→中部 | 23 |

### 欄位改名（#15 完整修法）
```
hh_income_tier → city_income_tier
price_tier     → city_price_tier
```
- 語意 self-evident（城市等級，非個人）
- 從 `valid_dims` 移除（不再可篩選，因 residence 可推導）
- 無外部 consumer，改名無 backward-compat 風險

## 驗證

- QA 23 rules ALL PASS
- Patterns 2-8 全 0 殘留（134 筆 → 0）
- test-api.sh 5 domains 全 PASS（康是美/TESLA/時尚/房貸-房仲/房貸-銀行）
- broadening loop、role parameter 正常運作

## 版本鏈

```
v4.5.3 → v4.6 (query-score) → v4.7 (interactive loop + role) → v4.7.1 (fix) → v4.8 (data coherence)
```
