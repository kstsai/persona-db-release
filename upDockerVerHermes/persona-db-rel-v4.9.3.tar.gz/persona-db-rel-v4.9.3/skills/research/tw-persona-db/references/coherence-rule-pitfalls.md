# Coherence-Rule Pitfalls (persona-db data generation)

Lessons from the #27/#28/#29 fixes in `_generate_997.py`. These are the recurring
ways coherence rules silently produce residuals or false corrections.

## 1. Rule ordering — run rules AFTER the field is finalized

Some fields are recalculated/overwritten *after* the initial coherence block:
- `housing_burden` is recomputed at the end (after rules change `housing_cost` / `family_income`).
- `family_income` is adjusted by `adjust_family_income_by_tier()` then floored (`INC_FI_FLOOR`) and capped (`FAM1_FI_MAX`).

A rule that reads `housing_burden` or `family_income` *early* misses personas whose
value changes afterward → residuals that look like the rule "didn't fire". Fix: place
the rule AFTER the field's final adjustment.

**This class has recurred THREE times** — R-01 (#28), R-06/R-07 (#29), and
R-03/R-08 (#30: `fam1_fi_cap` caps fs=1 fi to 1-3萬 but ran BEFORE them, so fi was
still 3-5萬 at check time, then fell to 1-3萬 after → re-entered the low-income
contradiction). Standing rule: ALL coherence rules that read `family_income` /
`housing_burden` must sit AFTER the LAST modifying step
(`adjust_family_income_by_tier` → `INC_FI_FLOOR` floor → `FAM1_FI_MAX` cap →
housing_burden recalc). When you ADD a new fi-modifying step, RE-AUDIT every rule's
position — do not assume existing placements are still safe. Detection: the
contradiction-hunt known-rule residual scan (`scripts/contradiction_hunt/run.py`)
is what catches these; QA (23 rules) does NOT.

## 2. Ratio vs absolute — "high burden" ≠ "broke"

`housing_burden` = `housing_cost / family_income` (a RATIO, ≥0.40 → "高").
"高 burden" means "housing eats ≥40% of income", NOT "poor". A `>8萬` family with a
3萬~5萬 mortgage has burden 高 but still has 5萬+/month discretionary — so
"高 burden + `>5000` clothing" is **legitimate** for high income, and only a real
contradiction for LOW income. Any rule keyed on `housing_burden` must ALSO gate on
absolute `family_income` (e.g. `fam_inc in ("<1萬","1-3萬")`), else it over-fires.

## 3. Homeownership phrases must be gated on age/occupation/income/rental

`HOUSING_BURDEN_LOW = ["住家裡不用付房租", "房貸早就還完了", "住在自己的房子，沒有貸款壓力"]`
— the last two ASSERT homeownership, but the whole pool is selected for *any*
`housing_burden == "低"`. Result: 0-11 kids, students, renters ("租套房") got
"房貸早就還完了". Fix: non-homeowners (age 0-24 / 學生 / 無收入 / "租" in story /
跟父母/家人住) get `["住家裡不用付房租"]` or `["房租不貴，負擔不重"]`; only 25+ working
adults (non-renter) may get the homeownership phrases.

## 4. Minor (0-18) caps for adult-tier consumption

Minors must not reach adult consumption tiers. Cap `clothing_spend` at `1500~3000`
for age 0-11/12-18 (the `3000~5000`/`>5000` tiers carry 治裝/重視穿搭 adult semantics).
Related existing rules: 12-18 不能 `commute_mode=汽車` (#21), 0-18 不能有房貸 (#27).

## 5. Statistical reasonableness BEFORE declaring a bug

When a pattern flags N personas, compute the PROPORTION and the field's distribution
(e.g. `family_income` histogram) before deciding bug vs known limitation. Example:
"22 minors with >3000 clothing" → 19/22 are 5-7萬+ households, minor high-clothing
rate is 10-12% vs adults 37-56% → directionally correct; only the low-income outliers
and the adult-semantics tier are real bugs. kstsai asks "佔比是否合理?" before
approving any fix — answer with numbers, not just "found violations".

## 6. Post-regen verification checklist

After regen (seed=42): (a) targeted pattern count → 0; (b) PRIOR fixes still hold
(#27/#28/#29 not regressed); (c) total = 1069 and age/region/sex distribution intact;
(d) `scripts/contradiction_hunt/run.py` known-rule residual scan → 0 for hard rules
(R-03/R-08 regression in #30 was caught by this scan, not by QA).
