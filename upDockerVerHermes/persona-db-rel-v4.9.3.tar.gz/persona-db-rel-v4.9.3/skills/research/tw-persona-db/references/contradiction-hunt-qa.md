# Contradiction-Hunt QA Pipeline (standalone)

One-shot QA tool for freshly re-generated persona DB raw content:
`scripts/contradiction_hunt/run.py`. Replaces the old "run 4 scripts by hand"
flow (dsl → hunt → classify → rules). Built from `.tickets/autoresearch/` (issue #5).

## One-shot usage

```bash
python3 scripts/contradiction_hunt/run.py tw_persona_1069.json                 # full (cached hypotheses, low token)
python3 scripts/contradiction_hunt/run.py tw_persona_1069.json --skip-classify # deterministic-only, 0 LLM
python3 scripts/contradiction_hunt/run.py tw_persona_1069.json --fresh         # regen hypotheses (~105 calls)
```

Output: `reports/contradiction-hunt-<version>.md`.

## 5 stages

| stage | script | LLM cost |
|---|---|---|
| 1. known-rule residual scan | `run.py` + `known_rules.json` | 0 (pure DSL) |
| 2. hypothesis gen | `hunt.py` | cached 0 / fresh ~105 |
| 3. violation scan | `hunt.py` + `dsl.py` | 0 |
| 4. LLM classify | `classify.py` | flash; `--skip-classify` skips |
| 5. rules draft + report | `rules.py` | 0 |

## Regression gate — the high-value, 0-token layer

`known_rules.json` holds 19 coherence rules already fixed in `_generate_997.py`,
each with a DSL `condition` and `hard: true/false`. A deterministic scan runs after
every regen:
- `hard: true` + residual > 0 → **generator regression** (open an issue)
- `hard: false` (e.g. R-04 `island_highfi`, 20% keep by design) → expected residual

This catches rule-ordering regressions BEFORE burning any LLM token — it is the
first line of QA, run before the LLM hunt. Hard-rule residual = the "recall" check
from ticket 05 made deterministic and free.

## Recurring pitfall: family_income adjustment ordering

Class of bug (seen #28, #29, and v4.9.2 R-03/R-08): any step that mutates
`family_income` AFTER a coherence rule already ran can re-introduce the exact
contradiction that rule was meant to kill. In v4.9.2, `fam1_fi_cap` (issue #18,
caps fs=1 income via `FAM1_FI_MAX`) runs after R-03 (`lowfi_high_hc`) and R-08
(`lowfi_single_nocar`), lowering fi to `1-3萬` and producing 3 + 7 residuals.
Fix = move/duplicate the rule to run AFTER ALL family_income adjustments
(`adjust_family_income_by_tier` → `fi_lt_income` floor → `fam1_fi_cap`), same
pattern as #28/#29. The residual scan in stage 1 is what surfaces this — always
run it after touching any coherence rule.

## DSL pitfalls (fixed 2026-08-19)

- Ordering ops `< <= > >=` now **RAISE** instead of silently returning False.
  Dimension values are tier strings (`>8萬` is a literal, not a comparison), so
  `==`/`!=`/`in` are the only meaningful ops. Silent False used to swallow a whole
  hypothesis and hide its violations.
- `in` keyword tokenizer requires trailing whitespace (`in [...]`, not `in[...]`).
- `--skip-llm` (hunt.py) / `--skip-classify` (run.py) use argparse now — the old
  positional parsing treated a leading flag as the db path and broke.

## Model strategy (token-conscious)

- hypothesis gen → `$LLM_ANALYSIS_MODEL` or `deepseek-v4-pro` (better Chinese)
- classify → `deepseek-v4-flash` (pro does reasoning-only retries in batch — v4.5 lesson)
- known-rule + violation scan → pure DSL, 0 LLM

## v4.9.2 baseline (2026-08-19)

- 871 total violations / 26 hypotheses (down from 996 in v4.5, rules working)
- hard-rule regressions: R-03=3 (`TW-P-0202/0287/0918`), R-08=7 (incl. `TW-P-0918`
  hits both). Root cause = `fam1_fi_cap` ordering (above).
- R-04 island_highfi=4 is soft (design-expected).
