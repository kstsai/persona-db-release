# Coherence Rules & Validation Techniques (persona-db)

Session-derived rules and validation techniques for keeping the 1069-persona DB
internally coherent. Each rule has a generator-side guard + a deterministic
re-scan to prove it is fixed (regen → scan == 0).

## Income-tier validation: the lower-bound rule (下界鐵律)

When checking that `family_income >= income`, compare **tier lower-bounds**, NOT
midpoints, and do NOT use a too-narrow threshold. All three got it wrong in the
v4.7 reasonableness review:

| approach | result | why |
|---|---|---|
| narrow threshold (fi ≤ 3-5萬 only) | 37 筆 | MISSES `income>8萬 + fi=5-7萬/7萬` (82 筆) |
| midpoint compare | 476 筆 | OVER-FLAGS: `income 3-8萬`(mid 5.5萬) vs `fi 3-5萬`(mid 4萬) → flags 358 false positives. A person earning 4萬 with a non-working spouse = family 4萬 is correct. |
| **lower-bound compare** | **118 筆 (correct)** | `fi` tier's lower bound must be >= `income` tier's lower bound. |

```python
FI_ORDER   = {"<1萬":0, "1-3萬":1, "3-5萬":2, "5-7萬":3, "7萬":4, ">8萬":5}
INC_FI_FLOOR = {"3-8萬": "3-5萬", ">8萬": ">8萬"}   # income → lowest allowed fi tier
# income "<3萬"/"無收入" has NO floor (spouse may earn more / family supports)
```

Generator guard (issue #16, added after `adjust_family_income_by_tier`):
```python
floor = INC_FI_FLOOR.get(inc)
if floor and FI_ORDER.get(fam_inc, 0) < FI_ORDER.get(floor, 0):
    fam_inc = floor
    coherence_fixes["fi_lt_income"] += 1
```
`fs==1` → fi == income; `fs>=2` → fi >= income (more earners → `>`). The rule holds
for every family_size — the 37→118 confusion was never about fs, it was about the
scan threshold.

## Occupation-aware narrative pools (issue #17)

Non-working occupations (`退休`/`家管`/`失業`) must not get workplace phrases
(`上下班/上班/通勤/升遷/交接工作/離公司`). Two sources leaked these:

1. **Commute phrase** — `COMMUTE_BG` had only workplace phrases. Fix: a parallel
   `COMMUTE_BG_NONWORK` pool (開車出門辦事 / 騎機車去辦事 / 搭捷運去找朋友 …),
   selected when `occ in ("退休","家管","失業")`.
2. **Life-stage phrase** — `LIFE_CAREER`/`LIFE_PRE_RETIRE` (為了升遷 / 開始交接工作)
   leak into 家管. Fix: give 家管 a dedicated `LIFE_HOMEMAKER` dict keyed by age
   (25-34…65+), checked FIRST in the life-stage branch.

Re-scan keyword set (workplace) for verification — be careful with over-broad
keywords: `搭捷運` alone is NEUTRAL and will false-positive against the non-work
pool's `搭捷運去找朋友`. Use the precise set:
```python
work_kws = ['上下班','上班','通勤','升遷','交接工作','離公司',
            '騎車上班','開車上下班','搭公車通勤','騎機車通勤','搭捷運上下班']
```

## hh_income_tier semantic trap (issue #15)

`hh_income_tier` is the **CITY-level** household-income tier (by residence:
新竹=極高, 台東=低), NOT the persona's own tier. It only *looks* contradictory next
to `family_income`. Decision: **do not rename** (API compatibility); fix the display
label to 「城市家戶所得分級」 and note the semantics in docs instead.

## OPEN bug line (not yet fixed as of 2026-08-13)

未成年 + 汽車通勤: `12-18` 歲 student personas with `commute_mode=汽車` /
「開車上下班」 — a minor cannot hold a driver's license. Same root as issue #17
(commute narrative ignores age/license) but the occupation-aware fix did not cover
age. Next coherence pass should add: `age in ("0-11","12-18")` → never 汽車/開車.

## Verification workflow

1. `python3 _generate_997.py` (regen; `fi_lt_income` counter shows clamp hits)
2. `python3 qa_validate.py` — 23 rules, all PASS
3. deterministic re-scan of each fixed bug (tier/occupation keyword scan) == 0
4. `python3 scripts/contradiction_hunt/run.py tw_persona_1069.json`
   — 一鍵矛盾偵測 QA（standalone 管線，commit 9a488fd）：
   - `known_rules.json` 19 條已落地規則 DSL 確定性殘留掃描（regression gate，0 LLM）
   - hypothesis hunt（cached 預設 / `--fresh` 重新生 ~105 call）+ violation 掃描
   - LLM 分類（flash，可 `--skip-classify` 跳過）
   - 報告 → `reports/contradiction-hunt-<version>.md`
   - **硬規則殘留 > 0 = generator regression**（見報告 §1）。取代舊的 `hunt.py --skip-llm` 入口。
5. `python3 scripts/reasonableness_review.py` (pro model, ~85s/persona — run in
   background with notify_on_complete; reviews only hunt-flagged personas)

### Rule-ordering pitfall (regression gate caught this on v4.9.2)

`fam1_fi_cap` (issue #18, `_generate_997.py` L1106) caps `family_income` down to
`1-3萬` for fs=1 + low-income personas, but it runs **after** R-03 (`lowfi_high_hc`)
and R-08 (`lowfi_single_nocar`). So a persona with `fi=3-5萬` at rule time gets
capped to `1-3萬` and re-enters the low-fi contradiction (3 + 7 residuals). Same
class as #28/#29 — any family_income adjustment must run *before* the rules that
depend on its final value.
   background with notify_on_complete; reviews only hunt-flagged personas)
