# Spec: Interactive LLM-DB Filter Loop（取代 blind relaxation）

> 日期: 2026-08-12 | 來源: grill-me Q1-Q5 收斂（甲方 role insight → data grounding → interactive loop）
> 對應: issue #12

## Problem Statement

現有 pipeline 的 blind relaxation 是根據 hardcoded dim_order 丟維度，完全不知道哪些 dim 對當前 query 重要。導致：
- TESLA query 丟了 income/age → 12 歲學生排第一
- 康是美 query 丟了 sex/income → 無收入學生排第一
- LLM 產的 strict filters 因看不見資料分布而常過緊

需用 **LLM-informed filter broadening** 取代 blind relaxation。

## Solution

```
LLM → filters (original) → DB scan → match_count
  ├─ count ≥ TARGET_MIN (20) → scoring → return ✅
  └─ count < TARGET_MIN → LLM broadening loop (max 3):
        prompt: "當前 filters 只 match 到 N 人。請放寬 1-2 個維度"
        → new filters → DB scan → count
        ├─ count ≥ TARGET_MIN → scoring → return ✅
        └─ loop again or exhaust
  ↓ exhaust (3 loops failed)
    → return status=TOO_STRICT + partial results + scoring
```

**消除：** 現有的 hardcoded dim_order relaxation 區塊
**保留：** original_filters（第一次 LLM 產出）+ scoring（tier_match + dim_importance）+ role parameter

## User Stories

1. LLM 知道金融只有 16 人 → 不會只用 finance filter → 減少過緊的 strict filters
2. LLM 知道 filter 交集為 5 → 自行決定放寬哪個 dim（preserve domain-critical dims）
3. Loop exhaust → 誠實回傳 TOO_STRICT，不強行鬆到沒意義
4. role 參數仍運作（房仲 vs 銀行對同一 query 產不同 broadening 決策）

## Implementation Decisions

### D1. Data grounding（LLM 看見資料）

在 `QUESTION_ANALYSIS_PROMPT` 尾部注入 per-dim 分布摘要：

```
資料庫概覽（1069 位台灣人設）：
- age: 0-11(117), 12-18(95), 19-24(88), 25-34(120), 35-44(127), 45-54(130), 55-64(120), 65+(104)
- occupation: 製造(210), 學生(180), 服務(160), 家管(95), 退休(87), 科技(58), 其他(52), 公務(49), 教育(46), 金融(16), 醫療(12), 自營(9)
- income: <3萬(285), 3-8萬(420), >8萬(247), 無收入(117)
- ...
```

格式：per dim 一行，值(人數)，按人數降冪。Prompt 增量約 500 chars（現有 prompt ~1800 chars）。

### D2. Broadening prompt（LLM 自我修正）

LLM 回傳的 strict filters + match count → 注入 broadening prompt：

```
你的篩選條件只找到 {N} 人（少於目標 {TARGET_MIN}）。在不改變核心判斷的前提下，
請放寬 1-2 個篩選維度（加入更多值、或刪除非核心維度）。
回傳修正後的 filters JSON。
```

### D3. Loop control

- max 3 loops（每個 loop 一次 LLM call）
- 每次 loop 記錄 broadening 過程（哪個 dim 被放寬/刪除）
- Loop 1 用 2000 tokens、loop 2-3 用 1000 tokens（節省 cost）
- dim_importance 只在 original LLM call 中產出，不在 loop 中重產

### D4. TOO_STRICT response

```json
{
  "status": "too_strict",
  "total_matched": 3,
  "persona_ids": [...],
  "broadening_attempts": [
    {"loop": 1, "change": "added income values 3-8萬", "match_count": 3},
    {"loop": 2, "change": "dropped occupation filter", "match_count": 5},
    {"loop": 3, "change": "added age values 25-34", "match_count": 5}
  ],
  "scoring_basis": {...}
}
```

### D5. 檔案變更

| 檔案 | 變更 |
|:----|:-----|
| `api/llm.py` | QUESTION_ANALYSIS_PROMPT 加 data grounding；新增 BROADEN_PROMPT |
| `api/server.py` | 置換 Step 3b relaxation 為 interactive loop；新增 TOO_STRICT response |
| `api/models.py` | CandidatesResponse 新增 `broadening_attempts`、`status=too_strict` |
| 不移除 | persona_matcher.py（filter_personas、scoring 保持） |

### D6. Blocked by / dependencies

- ✅ role parameter (v4.6)
- ✅ tier_match + dim_importance scoring (v4.6)
- data grounding 分布資料需從 tw_persona_1069.json 動態計算（避免 hardcode）

## Testing Decisions

1. TESLA query: strict filters → count < 20 → loop broadens income/age → ≥20 → scoring → 學生排後
2. 房仲 vs 銀行: same query, different role → different original filters → different broadening decisions
3. Loop exhaust: 3 loops → still < 20 → status=TOO_STRICT + partial
4. 無 role: 行為保持不變（role=""）
5. 回歸: test-persona-db-api.sh 全部 PASS

## Out of Scope

- 用 LLM 分析資料分布（data grounding 是靜態注入）
- Loop 超過 3 次（hard cap）
- 移除 relaxation（作為 fallback 保留但避免觸發）
