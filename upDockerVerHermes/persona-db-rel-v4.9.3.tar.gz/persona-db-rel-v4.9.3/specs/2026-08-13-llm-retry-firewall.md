# Spec: LLM Retry 防火牆（防虧本，不搞 token maximize）

> 日期: 2026-08-13 | 來源: kstsai 提出「別讓我們虧本了，我們不搞 token maximize」
> 對應: issue #24（待開）

## Problem Statement

現行 LLM 呼叫的 retry 邏輯是 **token maximize 反模式**，會白燒錢：

1. **doubling retry**（`call_llm` 322-370 行）：content 空時 `max_tokens * 2` 重送（2000→4000→8000），最多 3 次。pro model 從 2000 起跳「必敗」，等於**每次都保證浪費第一次 call + 重新付一次 85-90s 的 reasoning**。
2. **無條件 parse retry**（`parse_questions_with_llm` 444 行）：JSON parse 失敗就重試，即使 content 完整（model 產 garbage，重送同 prompt 也是賭）。
3. **broadening loop 無預算上限**：max 3 loop，每 loop 一次 8000-token pro call。已實測出現 no-op loop（TESLA 12→12，白燒一次 8000）。

三個已踩的 bug（reasonableness 800、analysis 4000、broadening 2000）**全是同一件事**：給的預算不夠 → 空 content → 靠 retry 補 → 白燒錢。

## 核心原則

**一次到位（right budget upfront）＞ 重試（retry）。**

成本真相：花錢的是 **reasoning tokens**（pro 每次 85-90s 的思考），不是 output。每次 retry = 重付一次 reasoning + 重送整包 prompt。

## Solution

```
call_llm(prompt, model, max_tokens):
  └─ 依 model 決定正確預算（L1）：
       pro  → 8000（reasoning + JSON 一次到位）
       flash → thinking=disabled + 2000（3s 乾淨 JSON）
  └─ 送一次
       ├─ content 有值 → return ✅
       ├─ content 空 + reasoning 有 JSON → _extract_json_or_text（L3，免費）✅
       ├─ content 空 + reasoning 無 JSON：
       │    ├─ finish_reason == length（截斷）→ retry 1 次，預算 +50%（L2）✅
       │    └─ 否則 → return None（不重試，model 真失敗）❌
       └─ 例外（網路/5xx）→ 退避 retry，最多 2 次，但「同 prompt 同預算」不翻倍
```

**每 request token 預算（L4）**：
```
/candidates request 的 LLM 花費上限：
  analysis   1 × pro 8000
  broadening ≤3 × pro 8000
  ─────────────────────────
  總上限     ≤ 32000 tokens（超標即回傳 partial + status=too_strict）
```

## User Stories

1. 正常 query 一次到位，不觸發 retry（最常見的省錢路徑）
2. 截斷才 retry，且只 1 次；garbage / reasoning-only 不重試
3. 單一 request 燒錢有硬上限，超標回傳 partial 而非無限 loop
4. 連續 N 次失敗 → 熔斷，回傳 partial，不繼續 hammer API

## Implementation Decisions

### D1. 依 model 決定 max_tokens（L1 一次到位）

`call_llm` 的 `max_tokens` 參數改為「建議值」，實際預算依 model 決定：

```python
def _resolve_max_tokens(model: str, requested: int) -> int:
    if "pro" in model.lower():
        return max(requested, 8000)   # pro 至少 8000，reasoning 不餓死
    return requested                   # flash 關 thinking，requested 就夠
```

- 移除 `call_llm` 內的 `max_tokens * 2` doubling。
- `parse_questions_with_llm` 已用 8000（analysis_max_tokens），保留。
- `broaden_max_tokens` 已改 8000（v4.8.2），保留。

### D2. 精準 retry（L2）

retry 條件從「content 空」改為「**finish_reason == length**」：

```python
finish_reason = data["choices"][0].get("finish_reason", "")
if content.strip():
    return content
if reasoning:
    extracted = _extract_json_or_text(reasoning)
    if extracted:
        return extracted
    # reasoning 有但挖不出 JSON：只有截斷才 retry
    if finish_reason == "length" and attempt == 0:
        max_tokens = int(max_tokens * 1.5)  # 單次 +50%，非翻倍
        continue
    return None   # 非截斷 → 真失敗，不重試
return None
```

- 例外（網路/5xx/timeout）仍退避重試，但最多 2 次、預算不翻倍。

### D3. 免費提取（L3，已存在）

`_extract_json_or_text(reasoning)` 已在 `call_llm` 內使用（355-362 行）。這條保留並**前移**——先挖 reasoning 再決定要不要 retry（現在已是這個順序）。

### D4. 硬預算 + 熔斷（L4）

在 `server.py` 的 `/candidates` 流程加 per-request token 計數：

```python
token_budget = 32000
tokens_spent = 0
# analysis call
tokens_spent += 8000  # (或依 call_llm 回傳的 usage 累加)
# broadening loop 條件加: tokens_spent < token_budget
while len(matched) < TARGET_MIN and loop < max_loops and filters and tokens_spent < token_budget:
    ...
    tokens_spent += 8000
```

- 熔斷（circuit breaker）：模組層級連續 N=3 次 `call_llm` 回 None（真失敗，非截斷）→ 之後 N 分鐘內直接回 partial、不呼叫 API。用 module-level `_fail_count` / `_cooldown_until`。

### D5. 可選（不預設）：broadening 用 flash

broadening 任務簡單（放寬 1-2 維度），可考慮 `model_override="deepseek-v4-flash"`（關 thinking，3s、便宜）。但需先驗證 flash 在 broadening 的品質，**本 RFC 不預設啟用**，留後續 ticket。

### D6. BROADEN_PROMPT 注入有效值清單（避免無效 broadening 白燒 token）

v4.8.2 pre-release LLM verify 實測抓到：broadening loop 產出 DB 不存在的值（`clothing_spend=["500~1000","1000~1500"]`，DB 有效值是 `500~1500`），這些值不 match 任何人 → **整次 broadening call 白燒**。

根因：`QUESTION_ANALYSIS_PROMPT` 有列出每維度有效值，但 `BROADEN_PROMPT` 沒有，LLM 就自己發明。

修法：`BROADEN_PROMPT` 附上與 `QUESTION_ANALYSIS_PROMPT` 相同的有效值清單（或從 `build_distribution_summary` 複用 per-dim 值域），並加一句「只能使用上述有效值，不要發明不存在的值」。

這是「避免無效 LLM call」的第三種實例（前兩種是 D2 的 garbage/reasoning-only 不重試、D4 的 no-op loop），與防火牆目標一致。

## Non-Goals

- 不改 pro/flash 的選型決策（pro 維持 analysis model，其價值在補消費維度）
- 不關 pro 的 reasoning（那是品質來源）
- 不引入「cache prompt」等平台層優化（那是 DeepSeek 端的事）

## Token 預算換算

| 場景 | 現行 | 防火牆後 |
|:--|:----|:----|
| 正常 query（1 analysis + 0-1 broaden） | 2×8000（若 parse retry）= 16K | 1×8000 = 8K |
| 嚴格 query（1 analysis + 3 broaden） | 2×8000 + 3×8000 = 40K | 1×8000 + 3×8000 = 32K（上限） |
| TESLA no-op loop 實例 | 白燒 1×8000 | 無 no-op（D2 精準 retry + D4 預算） |
| TESLA 無效值 broadening 實例 | 白燒 1×8000（發明無效值不 match） | 無（D6 有效值清單防呆） |

## 驗證方式

1. 單元測：mock `call_llm` 回 reasoning-only（非 length）→ 斷言**不回傳、不重試**
2. 單元測：mock 回 finish_reason=length → 斷言**retry 1 次、預算 +50%**
3. 整合測：跑 `test-persona-db-api.sh` 5 domains → 全 ok + Role QA DIFFERENT + 無 FILTER_FAILED
4. 成本測：同一批 query 跑前後，比對 LLM 總 token 用量（預期 -40% 以上）
