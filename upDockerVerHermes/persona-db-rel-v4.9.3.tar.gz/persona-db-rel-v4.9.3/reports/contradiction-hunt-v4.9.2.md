# Contradiction Hunt Report — v4.9.2

> 日期: 2026-08-19 | 資料: tw_persona_1069.json (1069 筆)
> 工具: scripts/contradiction_hunt/run.py

## 1. 已知規則殘留掃描（regression gate）

| 規則 | 描述 | 殘留 | 狀態 |
|:-----|:-----|:----:|:----:|
| R-A | 獨居無收入卻有中高家庭所得（若希類） | 0 | ✅ |
| R-B | 獨居無收入卻養車 | 0 | ✅ |
| R-C | 獨居無收入卻高治裝 | 0 | ✅ |
| R-01 | 高房貸負擔 + 低收入 + 高治裝 | 0 | ✅ |
| R-02 | 國中以下學歷任醫療職 | 0 | ✅ |
| R-03 | 低家庭所得卻高住房支出 | 3 | ⚠️ 回歸 |
| R-04 | 離島卻超高家庭所得（20% 設計保留） | 4 | 🟡 軟規則(設計允許) |
| R-05 | 已婚卻單人家庭 | 0 | ✅ |
| R-06 | 低家庭所得高治裝 | 0 | ✅ |
| R-07 | 未成年已婚 | 0 | ✅ |
| R-08 | 獨居低所得養車 | 7 | ⚠️ 回歸 |
| R-09 | 製造業卻在家工作 | 0 | ✅ |
| R-10 | 極低所得養車 | 0 | ✅ |
| R-11 | 離島卻搭捷運 | 0 | ✅ |
| R-12 | 高學歷專業職卻低收入（35+） | 0 | ✅ |
| R-13 | 未成年人開車 | 0 | ✅ |
| R-16a | 個人所得高於家庭所得下界（income >8萬） | 0 | ✅ |
| R-16b | 個人所得高於家庭所得下界（income 3-8萬） | 0 | ✅ |
| R-29 | 未成年高治裝 | 0 | ✅ |

**⚠️ 硬規則回歸 2 條：** R-03=3, R-08=7

- **R-03 lowfi_high_hc** (低家庭所得卻高住房支出): 3 筆 → TW-P-0202, TW-P-0287, TW-P-0918
- **R-08 lowfi_single_nocar** (獨居低所得養車): 7 筆 → TW-P-0204, TW-P-0343, TW-P-0351, TW-P-0496, TW-P-0638, TW-P-0732, TW-P-0918

## 2. Hunt 掃描

- LLM 假設: 65 個（cached）
- 有 violations 的假設: 26 / 總 violations: 871

### Top 15 findings（依 violation 數排序）

| # | Violations | condition | severity | dimensions |
|:-:|:---------:|:----------|:--------:|:-----------|
| 1 | 328 | `region == '都會區(六都)' AND housing_burden == '低'` | low | region, housing_burden |
| 2 | 255 | `region == '都會區(六都)' AND clothing_spend == '<500'` | low | region, clothing_spend |
| 3 | 47 | `family_size == '4' AND housing_cost == '<5千'` | low | family_size, housing_cost |
| 4 | 40 | `family_size == '5+' AND housing_cost == '<5千'` | medium | family_size, housing_cost |
| 5 | 39 | `family_income == '1-3萬' AND commute_mode == '汽車'` | medium | family_income, commute_mode |
| 6 | 34 | `occupation == '家管' AND marriage == '未婚'` | low | occupation, marriage |
| 7 | 25 | `income == '<3萬' AND clothing_spend == '>5000'` | medium | income, clothing_spend |
| 8 | 24 | `education == '國中以下' AND family_income == '>8萬'` | low | education, family_income |
| 9 | 18 | `sex == '男' AND occupation == '家管'` | low | sex, occupation |
| 10 | 13 | `region == '都會區(六都)' AND family_income == '<1萬'` | low | region, family_income |
| 11 | 7 | `region in ['花東','離島'] AND income == '>8萬'` | low | region, income |
| 12 | 5 | `family_size == '1' AND housing_cost == '1.5萬~3萬'` | low | family_size, housing_cost |
| 13 | 4 | `region == '離島' AND family_income == '>8萬'` | medium | region, family_income |
| 14 | 4 | `region in ['花東','離島'] AND clothing_spend == '>5000'` | medium | region, clothing_spend |
| 15 | 3 | `age == '65+' AND clothing_spend == '>5000'` | low | age, clothing_spend |

## 3. LLM 分類

（已跳過 — `--skip-classify`。以 Top-N 人工分析為主。）

## 4. 規則草案

（無規則草案 — 可能無 high-severity contradiction，或未跑 classify）

---

*本報告由 run.py 自動產生。硬規則殘留 = generator regression（見 §1）；Top-N 為 LLM 假設的 violation 排序，供人工逐筆審查。*
