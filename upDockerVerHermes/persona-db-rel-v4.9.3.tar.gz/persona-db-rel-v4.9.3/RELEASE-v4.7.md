# Persona DB v4.7 Release Notes

> 日期: 2026-08-12 | 上一版: v4.6 | 類型: 架構升級

## 重點變更：Interactive LLM-DB Filter Loop（issue #12）

取代 blind relaxation，LLM 自行修正 filters：

### Data grounding
LLM prompt 注入 per-dim 分布摘要（金融只有 70 人 → 不過度使用稀有 dim）

### Interactive broadening
```
strict filters → DB scan → < TARGET_MIN？
  → LLM self-corrects (max 3 loops)
  → records broadening_attempts
  → exhaust → status=too_strict
```

### Role parameter（甲方 B2B 需求）
```bash
curl "localhost:8000/personadb/candidates?questions=房貸優惠方案&role=房仲業者"
# → 換屋族/首購族
curl "localhost:8000/personadb/candidates?questions=房貸優惠方案&role=銀行業者"  
# → 轉貸族/穩定高收入
```

## 驗證

- lzcdh1: 5 test cases ALL PASS
- TESLA broadening loop 實戰觸發：11→2→22（LLM 成功修正）
- ROLE QA: 房仲 top ≠ 銀行 top ✅

## 版本鏈

```
v4.5.3 → v4.6 (query-score) → v4.7 (interactive loop)
```
