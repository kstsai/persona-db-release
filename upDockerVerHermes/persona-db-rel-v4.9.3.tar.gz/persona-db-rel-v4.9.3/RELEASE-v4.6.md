# Persona DB v4.6 Release Notes

> 日期: 2026-08-11 | 上一版: v4.5.3 | 類型: 架構升級

## 重點變更：Query-based Scoring（issue #11）

從 **filter-only scoring**（只對 filter 內的 dim 計稀有度分數）改為 **query-aware scoring**。

### 新公式

```
score = Σ importance[dim] × tier_match(value, target) × rarity_weight
```

- **importance**：LLM 產出每 dim 的重要性權重 (0.0-1.0)
- **tier_match**：persona 的值離 filter target 多近（有序 dim 如 age/income 用 tier 距離計分）
- **rarity_weight**：保留現有 log-frequency 權重

### 效果（TESLA query）

| Before | After |
|:------|:------|
| #1 芯芯 (12-18 學生) score 3.28 | #1 惠雯 (35-44 科技 >8萬) score 7.06 |
| 學生排在科技/金融前面 | 高收入中壯年正確排前 |

## 完整規則清單 (v4.6)

A/B/C (v4.4.3) + D/E/F/G (v4.5) + H (v4.5.2) + I/J/K (v4.5.3) = **11 條 coherence rules**

## 驗證

- QA 23 rules ALL PASS
- lzcdh1 TESLA case: top 5 全部合理
- test-persona-db-api.sh: all cases pass
