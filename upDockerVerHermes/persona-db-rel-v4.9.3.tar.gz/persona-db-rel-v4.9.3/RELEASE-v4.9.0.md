# Persona DB v4.9.0 Release Notes

> 日期: 2026-08-14 | 上一版: v4.8.2 | 類型: 功能（LLM retry 防火牆）

## 重點：LLM Retry 防火牆（RFC #24）

防止 LLM retry 白燒 token（「不搞 token maximize」）。4 層設計全落地：

| 層 | 做法 |
|:--|:-----|
| L1 一次到位 | pro 直接 8000（`_resolve_max_tokens`），flash 關 thinking+2000 |
| L2 精準 retry | 只在 finish_reason=length 才 retry 1 次 +50%；砍掉 doubling |
| L3 免費提取 | content 空先挖 reasoning_content（已付費白拿） |
| L4 硬預算+熔斷 | 每 request ≤32000 tokens + circuit breaker（3 連敗 → 60s 冷卻） |

## Implementation（3 tickets）

- **#01 precise-retry**：`call_llm` 重構，砍 doubling retry，截斷才重試
- **#02 budget+breaker**：server.py token budget 32000 + llm.py circuit breaker
- **#03 broaden-valid-values**：BROADEN_PROMPT 注入有效值清單（防發明無效值）

## 修復（D6 regression）

有效值清單補齊 4 個缺漏維度（region/education/housing_burden/housing_cost），
避免 broadening LLM 誤刪 housing_burden（之前視為無效）。

## 驗證

- 5 domains 全 ok + Role QA DIFFERENT
- housing_burden 正確保留 + region/education 新維度正確使用
- circuit breaker 單元測通過

## 預期效益

- 正常 query 16K → 8K token（-50%）
- 嚴格 query 40K → 32K 上限

## 版本鏈

```
v4.8.2 (broadening fix) → v4.9.0 (retry firewall)
```
