# Persona DB v4.9.1 Release Notes

> 日期: 2026-08-14 | 上一版: v4.9.0 | 類型: bug fix（broadening overshoot）

## 重點：broadening loop overshoot 修復（issue #25）

broadening LLM 一次移除多個維度（如「職業 + 家庭人數」），導致 total 暴增（房仲 4→97，遠超 TARGET_MIN=20）。

## 修法（雙重）

1. **server.py**：強制每 loop 最多移除 1 個維度，多餘的還原舊值
2. **BROADEN_PROMPT**：指令改為「每次只放寬或刪除 1 個維度」+ 嚴格限制句

## 驗證

- 房仲 total 97 → 39（漸進 5→17→39，每 loop 只動 1 維度）
- TESLA broadening 每 loop 只放寬 1 維度（12→18→19→19）
- 5 domains 全 ok + Role QA DIFFERENT

## 版本鏈

```
v4.9.0 (retry firewall) → v4.9.1 (broadening overshoot fix)
```
