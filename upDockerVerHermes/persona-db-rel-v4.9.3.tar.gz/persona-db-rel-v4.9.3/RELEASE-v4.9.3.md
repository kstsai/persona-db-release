# Persona DB v4.9.3 Release Notes

> 日期: 2026-08-27 | 上一版: v4.9.2 | 類型: bug fix（coherence ordering bug #30）

## 重點：R-03/R-08 ordering bug 修復（issue #30）

`fam1_fi_cap` 把 fs=1 的 family_income cap 到「1-3萬」，但排在 R-03/R-08 **之後** — 這些 persona 在 R-03/R-08 檢查時 fi 還是 3-5萬（不觸發規則），cap 完才落到 1-3萬 → 重新進入低所得矛盾（10 筆殘留）。

| Issue | 內容 | 驗證結果 |
|:----:|:----|:----|
| #30 | R-03/R-08 在 fam1_fi_cap 之前（ordering bug） | R-03 3→0、R-08 7→0；#27/#28/#29 無回歸；QA 23 規則 ALL PASS |

## 修法

- R-03（lowfi_high_hc）、R-08（lowfi_single_nocar）**純搬移**到 `fam1_fi_cap` 之後（與 R-06/R-07 並列），condition 不變、不改機率分布。
- 順手清掉 #29 搬移 R-06/R-07 時留下的殘留註解。

## 關鍵洞見

- 與 #28（R-01 移 recalc 後）、#29（R-06/R-07 移 fi 調整後）同一類：**任何會改 `family_income` 的步驟都必須在依賴其最終值的規則之前** — 這是第三次踩同一個 ordering 坑。

## 版本鏈

```
v4.9.0 (retry firewall) → v4.9.1 (broadening overshoot) → v4.9.2 (coherence 三連修) → v4.9.3 (ordering 修復 #30)
```

## QA 狀態

此版供 QA 驗證（lzcdh1 pre-release SOP），若有必要再進版。
