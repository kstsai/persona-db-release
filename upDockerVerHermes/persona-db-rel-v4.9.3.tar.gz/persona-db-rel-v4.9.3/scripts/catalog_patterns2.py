#!/usr/bin/env python3
"""Refined pattern catalog — accurate counts for Patterns 2-8."""
import json

db = json.load(open("tw_persona_1069.json"))

FI_ORDER = {"<1萬": 0, "1-3萬": 1, "3-5萬": 2, "5-7萬": 3, "7萬": 4, ">8萬": 5}

# Pattern 2: fam=1 且 family_income 高於個人 income 的合理上限（家庭=自己）
FAM1_FI_MAX = {"無收入": "1-3萬", "<3萬": "1-3萬", "3-8萬": "7萬", ">8萬": ">8萬"}

def count(fn):
    return sum(1 for p in db if fn(p["dimensions"]))

# Pattern 2
def p2(d):
    if d.get("family_size") != "1":
        return False
    inc, fi = d.get("income"), d.get("family_income")
    mx = FAM1_FI_MAX.get(inc)
    return bool(mx) and fi in FI_ORDER and FI_ORDER[fi] > FI_ORDER[mx]

# Pattern 3: 高學歷 + 專業職業 + 低收入 (age 35+)
def p3(d):
    return (d.get("education") in ("研究所以上", "大學")
            and d.get("occupation") in ("科技", "金融", "公務", "醫療", "教育")
            and d.get("income") == "<3萬"
            and d.get("age") in ("35-44", "45-54", "55-64"))

# Pattern 4: BG 貸款矛盾（喘不過氣/帳單 + 沒有貸款壓力）
def p4(d):
    bg = d.get("background_story") or ""
    return ("喘不過氣" in bg or "帳單" in bg) and "沒有貸款" in bg

# Pattern 5: 住家裡不用付房租 但 housing_cost >= 5千
def p5(d):
    bg = d.get("background_story") or ""
    return "不用付房租" in bg and d.get("housing_cost") not in ("<5千", "")

# Pattern 6: 12-18 歲 + 汽車
def p6(d):
    return d.get("age") == "12-18" and d.get("commute_mode") == "汽車"

# Pattern 7: 未婚 + 含飴弄孫 或 未婚 + 小孩教育費(小家庭)
def p7(d):
    bg = d.get("background_story") or ""
    mar = d.get("marriage")
    fam = d.get("family_size")
    return (("含飴弄孫" in bg and mar == "未婚")
            or ("小孩的教育費" in bg and fam in ("1", "2") and mar == "未婚"))

# Pattern 8: 苗栗縣 region != 中部
def p8(d):
    return d.get("residence") == "苗栗縣" and d.get("region") != "中部"

for i, fn in [(2, p2), (3, p3), (4, p4), (5, p5), (6, p6), (7, p7), (8, p8)]:
    n = count(fn)
    # sample ids
    ids = [p["id"] for p in db if fn(p["dimensions"])][:8]
    print(f"Pattern {i}: {n} 筆  e.g. {ids}")
