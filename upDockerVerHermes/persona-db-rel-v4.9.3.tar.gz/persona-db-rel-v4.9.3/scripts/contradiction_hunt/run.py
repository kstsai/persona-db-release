#!/usr/bin/env python3
"""
run.py — Standalone contradiction-hunt QA pipeline (issue #5, autoresearch).

Single entry point that runs the full QA flow on freshly re-generated
tw-persona-db raw content. Replaces the old "run 4 scripts by hand" flow.

Stages:
    1. Known-rule residual scan  (deterministic, DSL — no LLM cost)
       Scans the 19 already-fixed coherence rules and reports any residual
       violations (regression gate: after a clean regen these should be 0
       for hard rules).
    2. Hypothesis hunt           (LLM-generated hypotheses; cached by default)
    3. Violation scan            (DSL scan of all personas per hypothesis)
    4. LLM classification        (3-way: contradiction/explainable/insufficient)
    5. Rules draft               (high-severity contradictions → fix templates)
    6. Markdown report           → reports/contradiction-hunt-v<version>.md

Usage:
    python3 scripts/contradiction_hunt/run.py [DATA.json] [options]

Options:
    --fresh            Regenerate hypotheses from scratch (ignore cached
                       hypotheses.json). Costs ~105 LLM calls.
    --skip-classify    Skip LLM classification (violation-count top-N only;
                       the report's deterministic findings are unaffected).
    --top N            Number of top findings in the report (default 15).
    --model MODEL      Override hypothesis-generation model
                       (default: $LLM_ANALYSIS_MODEL or deepseek-v4-pro).
    --out DIR          Artifact output dir (default: this directory).

Examples:
    # Full QA on freshly regenerated content (reuses cached hypotheses):
    python3 scripts/contradiction_hunt/run.py tw_persona_1069.json

    # Deterministic-only (known-rule scan + cached hunt, no LLM):
    python3 scripts/contradiction_hunt/run.py tw_persona_1069.json --skip-classify

    # Full fresh hunt (regenerate hypotheses + classify):
    python3 scripts/contradiction_hunt/run.py tw_persona_1069.json --fresh
"""
import argparse
import asyncio
import json
import sys
from datetime import datetime
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent.parent
HUNT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

from scripts.contradiction_hunt.dsl import evaluate  # noqa: E402
from scripts.contradiction_hunt import hunt  # noqa: E402
from scripts.contradiction_hunt import classify  # noqa: E402
from scripts.contradiction_hunt import rules as rules_mod  # noqa: E402

KNOWN_RULES_FILE = HUNT_DIR / "known_rules.json"
HYPOTHESES_FILE = HUNT_DIR / "hypotheses.json"
VIOLATIONS_FILE = HUNT_DIR / "violations.json"
CLASSIFIED_FILE = HUNT_DIR / "classified.json"
RULES_FILE = HUNT_DIR / "rules_draft.json"
REPORTS_DIR = BASE / "reports"

DEFAULT_ANALYSIS_MODEL = "deepseek-v4-pro"


# ── Stage 1: known-rule residual scan ───────────────────────────────

def scan_known_rules(db, rules):
    """Scan the DB against known coherence rules. Returns list of results."""
    results = []
    for r in rules:
        matches = []
        try:
            for p in db:
                if evaluate(r["condition"], p.get("dimensions", {})):
                    matches.append(p["id"])
        except Exception as e:
            matches = None
            print(f"  ⚠️  known rule {r['id']} condition error: {e}")
        results.append({
            "id": r["id"],
            "name": r["name"],
            "desc": r["desc"],
            "hard": r.get("hard", True),
            "generator_counter": r.get("generator_counter", ""),
            "residual": matches if matches is not None else None,
            "count": len(matches) if matches is not None else -1,
        })
    return results


# ── Report generation ───────────────────────────────────────────────

def detect_version():
    for name in ("VERSION", "RELEASE-VERSION"):
        p = BASE / name
        if p.exists():
            v = p.read_text().strip()
            if v:
                return v
    return "unknown"


def write_report(args, db, known_results, hypotheses, vdata, classified, rules_out):
    version = detect_version()
    today = datetime.now().strftime("%Y-%m-%d")
    report_path = REPORTS_DIR / f"contradiction-hunt-{version}.md"
    REPORTS_DIR.mkdir(exist_ok=True)

    lines = []
    lines.append(f"# Contradiction Hunt Report — {version}")
    lines.append("")
    lines.append(f"> 日期: {today} | 資料: {args.data} ({len(db)} 筆)")
    lines.append(f"> 工具: scripts/contradiction_hunt/run.py")
    lines.append("")

    # Stage 1
    lines.append("## 1. 已知規則殘留掃描（regression gate）")
    lines.append("")
    hard_residual = [r for r in known_results if r["hard"] and r["count"] > 0]
    soft_residual = [r for r in known_results if not r["hard"] and r["count"] > 0]
    lines.append("| 規則 | 描述 | 殘留 | 狀態 |")
    lines.append("|:-----|:-----|:----:|:----:|")
    for r in known_results:
        if r["count"] < 0:
            status = "⚠️ 條件錯誤"
        elif r["count"] > 0 and r["hard"]:
            status = "⚠️ 回歸"
        elif r["count"] > 0 and not r["hard"]:
            status = "🟡 軟規則(設計允許)"
        else:
            status = "✅"
        lines.append(f"| {r['id']} | {r['desc']} | {r['count']} | {status} |")
    lines.append("")
    if hard_residual:
        lines.append(f"**⚠️ 硬規則回歸 {len(hard_residual)} 條：** " +
                     ", ".join(f"{r['id']}={r['count']}" for r in hard_residual))
        lines.append("")
        for r in hard_residual:
            lines.append(f"- **{r['id']} {r['name']}** ({r['desc']}): {r['count']} 筆 → {', '.join(r['residual'][:10])}")
        lines.append("")
    else:
        lines.append("**✅ 所有硬規則零殘留**（generator rules 全數生效）")
        lines.append("")

    # Stage 2/3
    lines.append("## 2. Hunt 掃描")
    lines.append("")
    total_hyp = vdata.get("total_hypotheses", len(hypotheses))
    violations_map = vdata.get("violations", {})
    total_viol = sum(len(v) for v in violations_map.values())
    lines.append(f"- LLM 假設: {total_hyp} 個（{'cached' if not args.fresh else 'fresh'}）")
    lines.append(f"- 有 violations 的假設: {len(violations_map)} / 總 violations: {total_viol}")
    lines.append("")

    hyp_map = {h["id"]: h for h in hypotheses}
    ranked = sorted(violations_map.items(), key=lambda x: -len(x[1]))
    top_n = args.top
    if ranked:
        lines.append(f"### Top {min(top_n, len(ranked))} findings（依 violation 數排序）")
        lines.append("")
        lines.append("| # | Violations | condition | severity | dimensions |")
        lines.append("|:-:|:---------:|:----------|:--------:|:-----------|")
        for i, (hid, pids) in enumerate(ranked[:top_n], 1):
            h = hyp_map.get(hid, {})
            dims = ", ".join(h.get("dimensions", []))
            lines.append(
                f"| {i} | {len(pids)} | `{h.get('condition', hid)}` | "
                f"{h.get('severity', '?')} | {dims} |"
            )
        lines.append("")

    # Stage 4
    lines.append("## 3. LLM 分類")
    lines.append("")
    if args.skip_classify:
        lines.append("（已跳過 — `--skip-classify`。以 Top-N 人工分析為主。）")
    elif classified:
        summary = classified.get("summary", {})
        lines.append(f"- 分類筆數: {classified.get('total', 0)}")
        lines.append(f"- 分布: {json.dumps(summary, ensure_ascii=False)}")
        contradictions = [e for e in classified.get("entries", [])
                          if e.get("label") == "contradiction"]
        if contradictions:
            lines.append("")
            lines.append(f"**contradiction（真矛盾）{len(contradictions)} 筆：**")
            for e in contradictions[:20]:
                lines.append(f"- {e['persona_id']} ({e['hypothesis_id']}): {e['reason']}")
        else:
            lines.append("- 無 contradiction 分類")
    else:
        lines.append("（無分類結果）")
    lines.append("")

    # Stage 5
    lines.append("## 4. 規則草案")
    lines.append("")
    if rules_out:
        lines.append(f"- 待審批規則: {rules_out.get('total_rules', 0)} 條")
        lines.append(f"- 產出: `scripts/contradiction_hunt/rules_draft.json` + `rules_draft.diff`")
    else:
        lines.append("（無規則草案 — 可能無 high-severity contradiction，或未跑 classify）")
    lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("*本報告由 run.py 自動產生。硬規則殘留 = generator regression（見 §1）；"
                 "Top-N 為 LLM 假設的 violation 排序，供人工逐筆審查。*")
    lines.append("")

    report_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"📄 Report → {report_path}")
    return report_path


# ── Main ────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Standalone contradiction-hunt QA pipeline")
    ap.add_argument("data", nargs="?", default=str(BASE / "tw_persona_1069.json"),
                    help="Persona DB JSON path (default: tw_persona_1069.json)")
    ap.add_argument("--fresh", action="store_true",
                    help="Regenerate hypotheses from scratch (costs ~105 LLM calls)")
    ap.add_argument("--skip-classify", action="store_true",
                    help="Skip LLM classification (violation-count top-N only)")
    ap.add_argument("--top", type=int, default=15, help="Top-N findings in report")
    ap.add_argument("--model", default=None,
                    help=f"Hypothesis-gen model (default: $LLM_ANALYSIS_MODEL or {DEFAULT_ANALYSIS_MODEL})")
    args = ap.parse_args()

    # Load data
    db = json.load(open(args.data))
    print(f"📦 Loaded {len(db)} personas from {args.data}")

    # Stage 1: known-rule residual scan
    if KNOWN_RULES_FILE.exists():
        known = json.load(open(KNOWN_RULES_FILE)).get("rules", [])
    else:
        known = []
    print(f"\n🧪 Stage 1/5 — 已知規則殘留掃描 ({len(known)} rules)")
    known_results = scan_known_rules(db, known)
    hard_hits = [r for r in known_results if r["hard"] and r["count"] > 0]
    soft_hits = [r for r in known_results if not r["hard"] and r["count"] > 0]
    for r in known_results:
        flag = "⚠️" if (r["hard"] and r["count"] > 0) else ("🟡" if (not r["hard"] and r["count"] > 0) else "✅")
        print(f"  {flag} {r['id']} {r['name']}: {r['count']}")
    print(f"  硬規則殘留 {len(hard_hits)} 條 / 軟規則殘留 {len(soft_hits)} 條")

    # Stage 2: hypothesis hunt (cached or fresh)
    print(f"\n🤖 Stage 2/5 — 假設生成 ({'fresh' if args.fresh else 'cached'})")
    skip_llm = not args.fresh
    hypotheses = asyncio.run(
        hunt.generate_hypotheses(db, skip_llm=skip_llm, model_override=args.model)
    )

    # Stage 3: violation scan
    print(f"\n🔍 Stage 3/5 — violation 掃描")
    violations = hunt.scan_violations(db, hypotheses)
    vdata = {
        "data_version": args.data,
        "total_hypotheses": len(hypotheses),
        "hypotheses_with_violations": len(violations),
        "violations": {hid: sorted(pids) for hid, pids in violations.items()},
    }
    json.dump(vdata, open(VIOLATIONS_FILE, "w"), ensure_ascii=False, indent=2)
    print(f"  → {VIOLATIONS_FILE}")

    # Stage 4: LLM classification (optional)
    classified = None
    if not args.skip_classify and violations:
        print(f"\n🏷️  Stage 4/5 — LLM 分類")
        # Point classify at the dataset under test (persona dims cache)
        classify.DB_PATH = args.data
        classified = asyncio.run(
            classify.classify_all(str(VIOLATIONS_FILE), str(HYPOTHESES_FILE))
        )
    else:
        print(f"\n🏷️  Stage 4/5 — LLM 分類 {'（跳過）' if args.skip_classify else '（無 violations）'}")

    # Stage 5: rules draft
    rules_out = None
    if classified:
        print(f"\n📝 Stage 5/5 — 規則草案")
        rules_out = rules_mod.generate_rules(str(CLASSIFIED_FILE), str(HYPOTHESES_FILE))
        if rules_out:
            rules_mod.generate_patch_diff(rules_out)
    else:
        print(f"\n📝 Stage 5/5 — 規則草案（跳過，需 classify 結果）")

    # Report
    print(f"\n📄 產出報告")
    write_report(args, db, known_results, hypotheses, vdata, classified, rules_out)

    # Summary
    print("\n" + "=" * 60)
    print(f"✅ 完成。硬規則殘留 {len(hard_hits)} 條 / 新發現 violations {sum(len(v) for v in violations.values())} 筆")
    if hard_hits:
        print("⚠️  硬規則殘留 → generator regression，建議開 GitHub issue：")
        for r in hard_hits:
            print(f"    {r['id']} {r['name']}: {r['count']} 筆")
    print("=" * 60)


if __name__ == "__main__":
    main()
