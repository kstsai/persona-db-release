# Contradiction Hunt — Standalone QA Pipeline

自主矛盾偵測 QA 流程（issue #5, autoresearch）。對**新 re-generated 的 tw persona db raw content**（`tw_persona_1069.json`）跑完整矛盾偵測，產出可人工審查的報告。

## 一鍵執行

```bash
# 完整 QA（沿用 cached hypotheses，不重新生 → 省 LLM token）
python3 scripts/contradiction_hunt/run.py tw_persona_1069.json

# 純確定性（已知規則掃描 + cached hunt，完全不燒 LLM）
python3 scripts/contradiction_hunt/run.py tw_persona_1069.json --skip-classify

# 全新鮮（重新生 hypotheses + 分類，~105 次 LLM call）
python3 scripts/contradiction_hunt/run.py tw_persona_1069.json --fresh
```

## 管線五階段

| 階段 | 腳本 | 產出 | LLM 成本 |
|:---|:---|:---|:---|
| 1. 已知規則殘留掃描 | `run.py` + `known_rules.json` | 報告 §1 | 0（純 DSL） |
| 2. 假設生成 | `hunt.py` | `hypotheses.json` | cached 0 / fresh ~105 call |
| 3. violation 掃描 | `hunt.py` + `dsl.py` | `violations.json` | 0（純 DSL） |
| 4. LLM 分類 | `classify.py` | `classified.json` | flash，可 `--skip-classify` 跳過 |
| 5. 規則草案 | `rules.py` | `rules_draft.json` + `.diff` | 0 |

最終產出：`reports/contradiction-hunt-<version>.md`。

## 兩個互補的偵測層

1. **已知規則殘留（regression gate）**：`known_rules.json` 收錄 19 條已在
   `_generate_997.py` 落地過的 coherence 規則，用 DSL 確定性掃描。
   - `hard: true` 規則殘留 > 0 → **generator regression**，需開 issue。
   - `hard: false` 規則（如 R-04 island_highfi 20% 保留）→ 設計允許，非 bug。
2. **LLM 假設發現（new findings）**：LLM 對 105 個維度對生成矛盾假設，
   掃描後按 violation 數排序 Top-N，供人工逐筆審查。

## 三個品質指標

- **Recall（偵測力）**：已知規則的 violation 模式是否有對應假設能抓到。
- **Precision（精準度）**：分類後 contradiction 佔總 violations 的比例。
- **新發現**：本輪 hunt 相較上輪新增的矛盾模式。

## 模型策略（省 token）

- 假設生成 → `$LLM_ANALYSIS_MODEL` 或 `deepseek-v4-pro`（中文理解較佳）。
- 分類 → `deepseek-v4-flash`（輕量、無 reasoning 重試）。
- 已知規則掃描 + violation 掃描 → 純 DSL，0 LLM。

## 建議工作流

```bash
# 1. regen
python3 _generate_997.py

# 2. 23 條 rule 快速驗證（既有工具）
python3 qa_validate.py

# 3. 矛盾偵測 QA（本工具）
python3 scripts/contradiction_hunt/run.py tw_persona_1069.json

# 4. 人工審查 reports/contradiction-hunt-<version>.md
#    - §1 硬規則殘留 > 0 → 開 GitHub issue（rule-ordering / 漏抓）
#    - §2 Top-N → 逐筆判讀 bug vs known limitation
```

## 檔案結構

```
scripts/contradiction_hunt/
├── run.py           # 一鍵管線入口（本工具）
├── dsl.py           # 受限 condition DSL（白名單 op，無 code execution）
├── hunt.py          # 假設生成 + violation 掃描
├── classify.py      # LLM 三分類（contradiction/explainable/insufficient）
├── rules.py         # 規則草案 + fix 模板 → patch diff
└── known_rules.json # 已知 coherence 規則（regression gate）
```

## 已知陷阱

- `--fresh` 會重新生成 hypotheses（~105 call），僅在維度值/規則大改時才需要；
  一般 regen 沿用 cached hypotheses 即可（維度對與值域穩定）。
- DSL 只支援 `==` / `!=` / `in` / `AND` / `OR` / 括號。`>` `<` 等 ordering op
  會被**明確拒絕**（不是靜默 False），因為維度值是 tier 字串（`>8萬` 是字面值）。
- classify 用 flash：pro 在 batch classify 會持續 reasoning-only retry（v4.5 教訓）。
