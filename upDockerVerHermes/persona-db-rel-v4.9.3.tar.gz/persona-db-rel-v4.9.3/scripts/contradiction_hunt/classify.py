"""
classify.py — LLM-based violation classification (issue #5, ticket 03).

For each hypothesis-violation pair, ask the LLM to classify it as:
    - "contradiction"  — 真矛盾（persona 不該存在）
    - "explainable"    — 可解釋（有豁免情境，如 fam>1 北漂靠家、0-11 兒童搭爸媽車）
    - "insufficient"   — 資訊不足（需要更多維度才能判斷）
Each classification includes a rationale.

Also outputs a 15% spot-check sample for human verification.

Usage:
    python3 scripts/contradiction_hunt/classify.py [violations.json] [hypotheses.json]
"""
import json, os, sys, asyncio, random
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE))

from api.llm import call_llm, LLM_CONFIG

# 從 hunt.py 導入 SCORED_DIMS（分類時需要知道所有維度以傳完整 persona context）
SCORED_DIMS = [
    "age", "sex", "region", "residence", "education", "occupation",
    "income", "family_income", "family_size", "marriage",
    "commute_mode", "housing_cost", "housing_burden", "clothing_spend",
    "hobby",
]

OUT_DIR = Path(__file__).resolve().parent
CLASSIFIED_FILE = OUT_DIR / "classified.json"
# Persona DB path — overridable by run.py when classifying a non-default dataset.
DB_PATH = str(BASE / "tw_persona_1069.json")

CLASSIFY_PROMPT = """你是一個資料品質審核助手。以下是台灣人口資料庫中的 **一個矛盾假設** 和一位 **違反該假設的 persona**。

## 假設

{hypothesis_text}

## 這位 persona 的維度值

{persona_dims}

## 任務

請判斷這個 persona **是否真的是矛盾**，並用以下三個類別標記：

- **contradiction**：這是真矛盾 — 這種組合不該出現在資料庫中
- **explainable**：可解釋 — 有其他情境讓這個組合合理（例如：學生無收入但住家裡、小孩開車是搭爸媽的車、退休老人有被動收入…）。**必須附上解釋情境。**
- **insufficient**：資訊不足 — 需要更多維度才能判斷

## 可解釋情境參考

- 18 歲以下 → 學生、收入、通勤都是家庭行為的延伸（住在原生家庭）
- 家庭人數 > 1 → 個人收入為 0 但家庭有收入 → 合理
- 家庭可支配所得高 → 學生開車、高消費 → 合理
- 退休 → 可能仍有租金/股利等被動收入，不依賴勞動收入

## 輸出格式（嚴格 JSON）

```json
{{
  "label": "contradiction | explainable | insufficient",
  "reason": "簡短繁體中文理由"
}}
```"""


CLASSIFY_BATCH_PROMPT = """你是一個資料品質審核助手。以下是台灣人口資料庫中的 **一個矛盾假設** 和多個 **違反該假設的 personas**。

## 假設

{hypothesis_text}

## 違反的 personas（每個含 persona_id 與相關維度值）

{personas_text}

## 任務

對每個 persona 判斷是否真的矛盾。分類標準：
- **contradiction**：真矛盾
- **explainable**：可解釋（附情境，例：小孩開車是家庭行為、退休仍有被動收入）
- **insufficient**：資訊不足

## 可解釋情境參考

- 0-17 歲 → 收入/通勤/消費是家庭行為延伸
- family_size > 1 → 個人無收入但家庭有 → 合理
- family_income 高 → 學生高消費/開車 → 合理
- 退休/家管 → 可能仍有被動收入

## 輸出格式（嚴格 JSON array）

```json
[
  {{"persona_id": "TW-P-XXXX", "label": "...", "reason": "..."}},
  ...
]
```"""


async def classify_batch(hypothesis, persona_batch, persona_dims_map):
    """Classify a batch of up to 10 personas against a hypothesis."""
    hyp_text = f"""{hypothesis['rationale']}
Condition: {hypothesis['condition']}
Severity: {hypothesis['severity']}"""

    persona_lines = []
    for pid in persona_batch:
        dims = persona_dims_map.get(pid, {})
        # Send all meaningful dimensions (not just hypothesis-related 2)
        # so LLM can judge whether the persona has explainable context
        # (e.g., age=0-11 + family_size=3 → kid, riding parents' car)
        display_dims = {}
        for d in SCORED_DIMS:
            if d in dims:
                display_dims[d] = dims[d]
        persona_lines.append(f"  {pid}: {json.dumps(display_dims, ensure_ascii=False)}")

    prompt = CLASSIFY_BATCH_PROMPT.format(
        hypothesis_text=hyp_text,
        personas_text="\n".join(persona_lines)
    )

    try:
        # classify 用 flash model（無 reasoning-only retry，pro 太慢）
        resp = await call_llm(prompt, temperature=0.2, max_tokens=600, model_override="deepseek-v4-flash")
        if not resp:
            return None
        resp = resp.strip()
        if "```json" in resp:
            resp = resp.split("```json")[1].split("```")[0].strip()
        elif "```" in resp:
            resp = resp.split("```")[1].split("```")[0].strip()
        return json.loads(resp)
    except Exception as e:
        return None


async def classify_all(violations_file, hypotheses_file):
    """Classify all violations. Returns list of {persona_id, hypothesis_id, label, reason}."""
    with open(violations_file) as f:
        vdata = json.load(f)
    violations_map = vdata.get("violations", {})

    with open(hypotheses_file) as f:
        hypotheses = json.load(f)
    hyp_map = {h["id"]: h for h in hypotheses}

    # Build persona dims cache
    with open(DB_PATH) as f:
        db = json.load(f)
    persona_dims = {p["id"]: p.get("dimensions", {}) for p in db}

    classified = []
    total = sum(len(v) for v in violations_map.values())
    print(f"🔍 {len(violations_map)} hypotheses with violations, {total} total violations to classify")

    done = 0
    for hid, pids in violations_map.items():
        h = hyp_map.get(hid)
        if not h:
            continue

        # Batch classify in groups of 10
        for i in range(0, len(pids), 10):
            batch = pids[i:i + 10]
            results = await classify_batch(h, batch, persona_dims)
            if results and isinstance(results, list):
                for r in results:
                    pid = r.get("persona_id", "")
                    classified.append({
                        "persona_id": pid,
                        "hypothesis_id": hid,
                        "label": r.get("label", "?"),
                        "reason": r.get("reason", ""),
                    })
            done += len(batch)
            if done % 50 == 0:
                print(f"  ... {done}/{total}")

    # Add spot-check markers (15% random sample)
    random.seed(42)
    for entry in classified:
        entry["spot_check"] = random.random() < 0.15

    # Summary stats
    from collections import Counter
    labels = Counter(e["label"] for e in classified)
    spot = sum(1 for e in classified if e["spot_check"])
    print(f"✅ {len(classified)} classified: {dict(labels)}, {spot} spot-check samples")

    with open(CLASSIFIED_FILE, "w") as f:
        json.dump({
            "total": len(classified),
            "summary": dict(labels),
            "spot_check_count": spot,
            "entries": classified,
        }, f, ensure_ascii=False, indent=2)
    print(f"✅ → {CLASSIFIED_FILE}")
    return classified


def main():
    vf = sys.argv[1] if len(sys.argv) > 1 else str(OUT_DIR / "violations.json")
    hf = sys.argv[2] if len(sys.argv) > 2 else str(OUT_DIR / "hypotheses.json")
    asyncio.run(classify_all(vf, hf))


if __name__ == "__main__":
    main()
