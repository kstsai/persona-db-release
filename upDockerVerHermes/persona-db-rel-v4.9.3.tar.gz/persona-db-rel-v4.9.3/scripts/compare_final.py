#!/usr/bin/env python3
"""Compare pro vs flash-disabled full filters (quality evaluation)."""
import asyncio, json, sys, os, time

sys.path.insert(0, "/home/ubuntu/persona-db")
os.chdir("/home/ubuntu/persona-db")

from api.llm import QUESTION_ANALYSIS_PROMPT, build_distribution_summary, call_llm

QUERIES = [
    "TESLA的目標客戶",
    "康是美的目標客戶",
    "房貸優惠方案",
    "健身跑鞋的目標客戶",
    "高級珠寶的目標客戶",
]

def load_db():
    return json.load(open("tw_persona_1069.json"))

async def analyze(query, model):
    db = load_db()
    dist = build_distribution_summary(db)
    prompt = QUESTION_ANALYSIS_PROMPT.format(questions=f"- {query}", data_overview=dist)
    t0 = time.time()
    r = await call_llm(prompt, temperature=0.2, max_tokens=8000 if "pro" in model else 4000, model_override=model)
    dt = time.time() - t0
    if not r:
        return {"_error": "empty"}, dt
    r = r.strip()
    if "```json" in r:
        r = r.split("```json")[1].split("```")[0].strip()
    elif "```" in r:
        r = r.split("```")[1].split("```")[0].strip()
    try:
        return json.loads(r), dt
    except Exception:
        s = r.find("{"); e = r.rfind("}")
        if s >= 0 and e > s:
            try:
                return json.loads(r[s:e+1]), dt
            except Exception:
                pass
        return {"_error": "parse failed", "_raw": r[:200]}, dt

async def main():
    for q in QUERIES:
        print("=" * 74)
        print(f"QUERY: {q}")
        print("=" * 74)
        for model in ["deepseek-v4-pro", "deepseek-v4-flash"]:
            tag = "PRO " if "pro" in model else "FLASH"
            r, dt = await analyze(q, model)
            if "_error" in r:
                print(f"\n[{tag}] {r['_error']} ({dt:.1f}s)")
                continue
            print(f"\n[{tag}] {dt:.1f}s  domain={r.get('domain','?')}")
            print(f"  filters: {json.dumps(r.get('filters',{}), ensure_ascii=False)}")
            print(f"  dim_importance: {json.dumps(r.get('dim_importance',{}), ensure_ascii=False)}")
        print()

asyncio.run(main())
