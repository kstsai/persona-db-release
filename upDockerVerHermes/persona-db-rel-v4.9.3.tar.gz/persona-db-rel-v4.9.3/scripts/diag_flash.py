#!/usr/bin/env python3
"""Diagnose flash raw output for the 3 failed queries."""
import asyncio, json, sys, os

sys.path.insert(0, "/home/ubuntu/persona-db")
os.chdir("/home/ubuntu/persona-db")

from api.llm import QUESTION_ANALYSIS_PROMPT, build_distribution_summary, call_llm

QUERIES = ["TESLA的目標客戶", "康是美的目標客戶", "房貸優惠方案"]

async def main():
    db = json.load(open("tw_persona_1069.json"))
    dist = build_distribution_summary(db)
    for q in QUERIES:
        prompt = QUESTION_ANALYSIS_PROMPT.format(questions=f"- {q}", data_overview=dist)
        print("=" * 70)
        print(f"QUERY: {q}")
        # Call flash with raw httpx to see EVERYTHING (content + reasoning_content)
        import httpx
        key = open(".env").read()
        for line in key.splitlines():
            if line.startswith("LLM_API_KEY="):
                key = line.split("=",1)[1].strip()
        url = "https://api.deepseek.com/chat/completions"
        payload = {
            "model": "deepseek-v4-flash",
            "messages": [{"role":"system","content":"你是台灣市場研究助手"},{"role":"user","content":prompt}],
            "temperature": 0.2,
            "max_tokens": 4000,
        }
        async with httpx.AsyncClient(timeout=120) as c:
            r = await c.post(url, headers={"Authorization": f"Bearer {key}"}, json=payload)
            d = r.json()
        msg = d["choices"][0]["message"]
        content = msg.get("content")
        reasoning = msg.get("reasoning_content")
        finish = d["choices"][0].get("finish_reason")
        print(f"finish_reason: {finish}")
        print(f"content (len={len(content) if content else 0}): {repr(content[:400] if content else None)}")
        print(f"reasoning_content (len={len(reasoning) if reasoning else 0}): {repr(reasoning[:200] if reasoning else None)}")
        print()

asyncio.run(main())
