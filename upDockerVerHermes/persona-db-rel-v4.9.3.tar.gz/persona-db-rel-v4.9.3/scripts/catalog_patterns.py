#!/usr/bin/env python3
"""Precisely catalog Patterns 2-8 (real contradictions) from reasonableness re-review."""
import json

db = json.load(open("tw_persona_1069.json"))

INC_ORDER = {"無收入": 0, "<3萬": 1, "3-8萬": 2, ">8萬": 3}
FI_ORDER = {"<1萬": 0, "1-3萬": 1, "3-5萬": 2, "5-7萬": 3, "7萬": 4, ">8萬": 5}

patterns = {k: [] for k in range(2, 9)}

for p in db:
    d = p["dimensions"]
    pid = p["id"]
    bg = d.get("background_story", "") or ""
    age = d.get("age", "")
    occ = d.get("occupation", "")
    edu = d.get("education", "")
    inc = d.get("income", "")
    fi = d.get("family_income", "")
    fam = d.get("family_size", "")
    cm = d.get("commute_mode", "")
    hc = d.get("housing_cost", "")
    region = d.get("region", "")
    res = d.get("residence", "")
    marriage = d.get("marriage", "")

    # Pattern 2: fam=1 但 family_income > income
    if fam == "1" and inc in INC_ORDER and fi in FI_ORDER and INC_ORDER[inc] >= 0:
        if FI_ORDER[fi] > INC_ORDER[inc] + 1:  # family income at least 2 tiers above personal
            patterns[2].append((pid, inc, fi, fam))

    # Pattern 3: 高學歷 + 專業職業 + 低收入
    if edu in ("研究所以上", "大學") and occ in ("科技", "金融", "公務", "醫療", "教育") and inc in ("<3萬",) and age in ("35-44", "45-54", "55-64"):
        patterns[3].append((pid, edu, occ, inc, age))

    # Pattern 4: BG 貸款矛盾（壓得喘不過氣 vs 沒有貸款壓力）
    if ("喘不過氣" in bg or "帳單" in bg) and "沒有貸款" in bg:
        patterns[4].append((pid, "貸款矛盾"))

    # Pattern 5: 住家裡免房租 vs 有住房成本
    if ("住家裡" in bg or "不用付房租" in bg or "免房租" in bg) and hc not in ("<5千", ""):
        patterns[5].append((pid, hc))

    # Pattern 6: 12-18 歲 + 汽車
    if age == "12-18" and cm == "汽車":
        patterns[6].append((pid, age, cm))

    # Pattern 7: 未婚獨居+含飴弄孫 / 新婚2人+小孩教育費
    if ("含飴弄孫" in bg and marriage == "未婚") or ("小孩的教育費" in bg and fam in ("1", "2") and marriage == "未婚"):
        patterns[7].append((pid, marriage, fam))

    # Pattern 8: 苗栗縣 region 分類錯誤
    if res == "苗栗縣" and region != "中部":
        patterns[8].append((pid, region, res))

for k in range(2, 9):
    print(f"\n=== Pattern {k} ({len(patterns[k])} 筆) ===")
    for x in patterns[k][:15]:
        print("  ", x)
