#!/usr/bin/env python3
"""Test flash with thinking disabled — does it produce valid JSON quickly?"""
import httpx, json, time, sys, os

sys.path.insert(0, "/home/ubuntu/persona-db")
os.chdir("/home/ubuntu/persona-db")

from api.llm import QUESTION_ANALYSIS_PROMPT, build_distribution_summary

key = None
for line in open(".env"):
    if line.startswith("LLM_API_KEY="):
        key = line.split("=", 1)[1].strip()

db = json.load(open("tw_persona_1069.json"))
dist = build_distribution_summary(db)

for q in ["TESLA的目標客戶", "康是美的目標客戶", "房貸優惠方案", "健身跑鞋的目標客戶", "高級珠寶的目標客戶"]:
    prompt = QUESTION_ANALYSIS_PROMPT.format(questions=f"- {q}", data_overview=dist)
    payload = {
        "model": "deepseek-v4-flash",
        "messages": [
            {"role": "system", "content": "你是台灣市場研究助手"},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.2,
        "max_tokens": 4000,
        "thinking": {"type": "disabled"},
    }
    t0 = time.time()
    r = httpx.post(
        "https://api.deepseek.com/chat/completions",
        headers={"Authorization": f"Bearer {key}"},
        json=payload,
        timeout=120,
    )
    d = r.json()
    msg = d["choices"][0]["message"]
    content = msg.get("content") or ""
    fr = d["choices"][0].get("finish_reason")
    dt = time.time() - t0
    ok = False
    try:
        c = content.strip()
        if "```json" in c:
            c = c.split("```json")[1].split("```")[0]
        elif "```" in c:
            c = c.split("```")[1].split("```")[0]
        json.loads(c)
        ok = True
    except Exception:
        pass
    print(f"{q}: finish={fr} time={dt:.1f}s content_len={len(content)} json_ok={ok}")
