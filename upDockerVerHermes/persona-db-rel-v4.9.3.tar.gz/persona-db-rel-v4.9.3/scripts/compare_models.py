#!/usr/bin/env python3
"""A/B compare pro vs flash llm_analysis on a fixed query set."""
import asyncio, json, sys, os

sys.path.insert(0, "/home/ubuntu/persona-db")
os.chdir("/home/ubuntu/persona-db")

from api.llm import QUESTION_ANALYSIS_PROMPT, build_distribution_summary, call_llm

QUERIES = [
    "TESLA的目標客戶",
    "康是美的目標客戶",
    "房貸優惠方案",
    "健身跑鞋的目標客戶",
    "高級珠寶的目標客戶",
]

def load_db():
    return json.load(open("tw_persona_1069.json"))

async def analyze(query, model):
    db = load_db()
    dist = build_distribution_summary(db)
    prompt = QUESTION_ANALYSIS_PROMPT.format(
        questions=f"- {query}",
        data_overview=dist,
    )
    r = await call_llm(prompt, temperature=0.2, max_tokens=8000 if "pro" in model else 4000, model_override=model)
    # extract JSON
    if not r:
        return {"_error": "empty response"}
    r = r.strip()
    if "```json" in r:
        r = r.split("```json")[1].split("```")[0].strip()
    elif "```" in r:
        r = r.split("```")[1].split("```")[0].strip()
    try:
        return json.loads(r)
    except Exception:
        # try find first { ... last }
        s = r.find("{"); e = r.rfind("}")
        if s >= 0 and e > s:
            try:
                return json.loads(r[s:e+1])
            except Exception:
                pass
        return {"_error": "json parse failed", "_raw": r[:300]}

async def main():
    for q in QUERIES:
        print("=" * 70)
        print(f"QUERY: {q}")
        print("=" * 70)
        for model in ["deepseek-v4-pro", "deepseek-v4-flash"]:
            tag = "PRO" if "pro" in model else "FLASH"
            try:
                r = await analyze(q, model)
            except Exception as e:
                r = {"_error": str(e)}
            filters = r.get("filters", r.get("_error", "?"))
            dims = r.get("dim_importance", {})
            reasoning = r.get("reasoning", "")[:120]
            print(f"\n--- {tag} ---")
            print(f"  domain: {r.get('domain','?')}")
            print(f"  filters: {json.dumps(filters, ensure_ascii=False)}")
            print(f"  dim_importance: {json.dumps(dims, ensure_ascii=False)}")
            print(f"  reasoning: {reasoning}")
        print()

asyncio.run(main())
