#!/usr/bin/env python3
"""Reasonableness analysis: pro model reviews hunt-flagged personas.

Only reviews SUSPICIOUS personas (hunt medium-severity violations), NOT all 1069.
Output: per-persona verdict (合理 / 不合理) + reason.
"""
import asyncio, json, sys, os

sys.path.insert(0, "/home/ubuntu/persona-db")
os.chdir("/home/ubuntu/persona-db")

from api.llm import call_llm, LLM_CONFIG

# Medium-severity hypotheses to review (from v4.7 hunt)
TARGET_HYPOTHESES = {
    "H-income-clothing_spend-2": "income <3萬 但 clothing_spend >5000",
    "H-family_income-commute_mode-2": "family_income 1-3萬 但 commute_mode 汽車",
}

REVIEW_PROMPT = """你是台灣社會人口資料審查員。以下是虛構 persona 的人設，請判斷是否「合理」（一個真實台灣人會不會長這樣）。

persona:
{persona_dims}

判斷標準：
- 收入 vs 消費 vs 資產（車/房/治裝）是否自洽
- 職業/教育/收入是否合理搭配
- 這個人設作為「真實台灣人」是否說得通

注意：這是「家庭」維度，個人 income 低但家庭 family_income 高是合理的（家人有錢）。
退休/失業的人有車是合理的（可能是退休前/失業前買的舊車）。

回覆格式（嚴格 JSON）：
{{
  "verdict": "合理" 或 "不合理",
  "reason": "簡短說明（繁體中文，一句話）"
}}
"""

async def analyze_persona(p):
    dims = p.get("dimensions", {})
    dims_str = json.dumps(dims, ensure_ascii=False, indent=2)
    prompt = REVIEW_PROMPT.format(persona_dims=dims_str)
    r = await call_llm(prompt, temperature=0.2, max_tokens=8000, model_override="deepseek-v4-pro")
    if not r:
        return {"verdict": "ERROR", "reason": "empty response"}
    r = r.strip()
    if "```json" in r:
        r = r.split("```json")[1].split("```")[0].strip()
    elif "```" in r:
        r = r.split("```")[1].split("```")[0].strip()
    try:
        return json.loads(r)
    except Exception:
        s = r.find("{"); e = r.rfind("}")
        if s >= 0 and e > s:
            try:
                return json.loads(r[s:e+1])
            except Exception:
                pass
        return {"verdict": "ERROR", "reason": r[:100]}

async def main():
    db = json.load(open("tw_persona_1069.json"))

    # Load violations and collect suspicious persona IDs
    violations = json.load(open("scripts/contradiction_hunt/violations.json"))
    suspicious_ids = set()
    for hid, pids in violations["violations"].items():
        if hid in TARGET_HYPOTHESES:
            suspicious_ids.update(pids)

    print(f"🔍 {len(suspicious_ids)} suspicious personas to review")
    print(f"   targets: {list(TARGET_HYPOTHESES.values())}")
    print()

    results = []
    for pid in sorted(suspicious_ids):
        p = next((x for x in db if x["id"] == pid), None)
        if not p:
            continue
        r = await analyze_persona(p)
        dims = p.get("dimensions", {})
        # find which hypothesis this persona violates
        reasons = []
        for hid, pids in violations["violations"].items():
            if pid in pids and hid in TARGET_HYPOTHESES:
                reasons.append(TARGET_HYPOTHESES[hid])
        verdict = r.get("verdict", "?")
        reason = r.get("reason", "")
        results.append({
            "id": pid,
            "name": p.get("name", ""),
            "verdict": verdict,
            "reason": reason,
            "violation": "; ".join(reasons),
            "dims": {k: dims.get(k) for k in ["age","occupation","income","family_income","clothing_spend","commute_mode","family_size"]},
        })
        print(f"{pid} {p.get('name',''):4s} [{verdict}] {reason[:60]}")

    # Summary
    unreasonable = [r for r in results if r["verdict"] == "不合理"]
    print()
    print("=" * 60)
    print(f"結果: {len(results)} reviewed, {len(unreasonable)} 不合理, {len(results)-len(unreasonable)} 合理")
    if unreasonable:
        print()
        print("=== 不合理筆 ===")
        for r in unreasonable:
            print(f"  {r['id']} {r['name']}: {r['reason']}")
            print(f"    dims: {json.dumps(r['dims'], ensure_ascii=False)}")

    # Save
    with open("reports/reasonableness-review-v4.7.json", "w") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n✅ → reports/reasonableness-review-v4.7.json")

asyncio.run(main())
