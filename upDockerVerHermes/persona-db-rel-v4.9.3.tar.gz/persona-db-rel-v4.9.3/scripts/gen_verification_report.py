#!/usr/bin/env python3
"""
Generate a comprehensive population-statistics verification report
from a generated persona JSON file.

Usage:
    python3 gen_verification_report.py                    # reads tw_persona_1069.json
    python3 gen_verification_report.py path/to/file.json  # custom path
    python3 gen_verification_report.py --help

Output: GENERATION-VERIFICATION-YYYY-MM-DD.md  (markdown report)

Reports all 18+ dimensions, cross-tables, and distribution comparisons
against expected population targets.
"""
import json, sys, os
from collections import Counter
from itertools import chain
from datetime import date

# ── Configuration ──────────────────────────────────
EXPECTED = {
    "age": {"0-11": 0.11, "12-18": 0.07, "19-24": 0.07, "25-34": 0.14,
            "35-44": 0.16, "45-54": 0.16, "55-64": 0.15, "65+": 0.14},
    "region": {"都會區(六都)": 0.694, "北部": 0.103, "中部": 0.103,
               "南部": 0.067, "花東": 0.023, "離島": 0.011},
    "sex": {"男": 0.495, "女": 0.505},
}

REGION_CITIES = {
    "都會區(六都)": ["台北市","新北市","桃園市","台中市","台南市","高雄市"],
    "北部": ["基隆市","新竹縣","新竹市","苗栗縣","宜蘭縣"],
    "中部": ["彰化縣","南投縣","雲林縣"],
    "南部": ["嘉義市","嘉義縣","屏東縣"],
    "花東": ["花蓮縣","台東縣"],
    "離島": ["澎湖縣","金門縣","連江縣"],
}

ALL_CITIES = sorted([c for cs in REGION_CITIES.values() for c in cs])

AGE_ORDER = ["0-11","12-18","19-24","25-34","35-44","45-54","55-64","65+"]
DIM_LABELS = {
    "age": "年齡", "sex": "性別", "region": "區域", "residence": "戶籍地",
    "education": "教育", "occupation": "職業", "income": "個人收入",
    "family_income": "家庭收入", "marriage": "婚姻", "politics": "政治傾向",
    "family_size": "家庭口數", "hobby": "興趣嗜好", "media_diet": "媒體習慣",
    "city_price_tier": "城市物價分級", "city_income_tier": "城市家戶所得分級",
}

def load_data(path):
    if not os.path.exists(path):
        sys.exit(f"❌ File not found: {path}")
    with open(path) as f:
        return json.load(f)

def pct(v, total):
    return v / total * 100

def write_report(data, output_path):
    total = len(data)
    lines = []

    def w(s=""):
        lines.append(s)

    today = date.today().isoformat()

    w("# 1069 Persona 生成驗證報告")
    w(f"**日期**: {today} | **總數**: {total} 筆 | **種子**: 42")
    w(f"**檔案**: {output_path.replace('GENERATION-VERIFICATION-', 'tw_persona_').replace('.md', '.json')}")
    w()
    w("## 1. 人口分布驗證")
    w()

    # ── Age ──
    w("### 年齡分布")
    ages = Counter(p["dimensions"]["age"] for p in data)
    w("| 年齡 | 數量 | 佔比 | 目標 | 差異 |")
    w("|---|---:|---:|---:|---:|")
    for k in AGE_ORDER:
        ap = pct(ages[k], total)
        ep = pct(EXPECTED["age"][k], 1)
        diff = ap - ep
        flag = " ⚠️" if abs(diff) > 1.0 else ""
        w(f"| {k} | {ages[k]} | {ap:.1f}% | {ep:.1f}% | {diff:+.1f}%{flag} |")
    w()

    # ── Region ──
    w("### 區域分布")
    regions = Counter(p["dimensions"]["region"] for p in data)
    w("| 區域 | 數量 | 佔比 | 目標 | 差異 |")
    w("|---|---:|---:|---:|---:|")
    for k in ["都會區(六都)","北部","中部","南部","花東","離島"]:
        ap = pct(regions[k], total)
        ep = pct(EXPECTED["region"][k], 1)
        diff = ap - ep
        flag = " ⚠️" if abs(diff) > 1.0 else ""
        w(f"| {k} | {regions[k]} | {ap:.1f}% | {ep:.1f}% | {diff:+.1f}%{flag} |")
    w()

    # ── Cities ──
    w("### 縣市分布")
    city_counts = Counter(p["dimensions"]["residence"] for p in data)
    w("| 縣市 | 數量 | 佔比 |")
    w("|---|---:|---:|")
    for region, cities in REGION_CITIES.items():
        r_total = sum(city_counts[c] for c in cities)
        w(f"| **{region}** (合計 {r_total}) | | |")
        for c in cities:
            n = city_counts[c]
            w(f"| {c} | {n} | {pct(n, total):.2f}% |")
    w()

    # ── Sex ──
    w("### 性別")
    sexes = Counter(p["dimensions"]["sex"] for p in data)
    w("| 性別 | 數量 | 佔比 | 目標 | 差異 |")
    w("|---|---:|---:|---:|---:|")
    for s in ["男", "女"]:
        ap = pct(sexes[s], total)
        ep = pct(EXPECTED["sex"][s], 1)
        diff = ap - ep
        flag = " ⚠️" if abs(diff) > 1.0 else ""
        w(f"| {s} | {sexes[s]} | {ap:.1f}% | {ep:.1f}% | {diff:+.1f}%{flag} |")
    w()

    # ── City coverage ──
    covered = [c for c in ALL_CITIES if city_counts[c] > 0]
    missing = [c for c in ALL_CITIES if c not in covered]
    w(f"**城市覆蓋**: {len(covered)}/22")
    if missing:
        w(f"⚠️ **缺少**: {', '.join(missing)}")
    w()

    w("## 2. 維度分布")
    w()

    # ── Categorical dimensions ──
    cat_dims = ["education", "occupation", "income", "family_income",
                "marriage", "politics", "family_size", "media_diet",
                "city_price_tier", "city_income_tier"]
    for dim in cat_dims:
        label = DIM_LABELS.get(dim, dim)
        w(f"### {label}")
        vals = Counter(p["dimensions"][dim] for p in data)
        w(f"| {label} | 數量 | 佔比 |")
        w("|---|---:|---:|")
        for k, v in vals.most_common():
            w(f"| {k} | {v} | {pct(v, total):.1f}% |")
        w()

    # ── Hobby (top 10) ──
    w("### 興趣嗜好 Top 10")
    hobby_all = list(chain.from_iterable(p["dimensions"]["hobby"] for p in data))
    w("| 興趣 | 數量 | 佔比 |")
    w("|---|---:|---:|")
    for k, v in Counter(hobby_all).most_common(10):
        w(f"| {k} | {v} | {pct(v, total):.1f}% |")
    w()

    # ── Marriage × Age cross-table ──
    w("### 婚姻 × 年齡 交叉表")
    mar_order = ["未婚", "已婚", "離婚", "鰥寡"]
    header = "| 年齡 | " + " | ".join(mar_order) + " | 總計 |"
    sep = "|" + "---|" * (len(mar_order) + 2)
    w(header)
    w(sep)
    for a in AGE_ORDER:
        row = [a]
        for m in mar_order:
            c = sum(1 for p in data
                    if p["dimensions"]["age"] == a and p["dimensions"]["marriage"] == m)
            row.append(str(c))
        row.append(str(sum(1 for p in data if p["dimensions"]["age"] == a)))
        w("| " + " | ".join(row) + " |")
    w()

    w("## 3. 名字多樣性")
    names = Counter(p["name"] for p in data)
    unique = len(names)
    w(f"**不重複名字**: {unique} 個 ({pct(unique, total):.1f}%)")
    w()
    w("**Top 10 常用名:**")
    w("| 名字 | 出現次數 |")
    w("|------|:--------:|")
    for n, c in names.most_common(10):
        w(f"| {n} | {c} |")
    w()

    w("---")
    w("*報告由 `gen_verification_report.py` 自動生成*")

    report = "\n".join(lines)
    with open(output_path, "w") as f:
        f.write(report)
    print(f"✅ Report written: {output_path}  ({len(lines)} lines)")
    return len(lines)

if __name__ == "__main__":
    # Parse args
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if "-h" in sys.argv or "--help" in sys.argv:
        print(__doc__)
        sys.exit(0)

    input_path = args[0] if args else "tw_persona_1069.json"
    today = date.today().isoformat()
    output_path = f"GENERATION-VERIFICATION-{today}.md"

    data = load_data(input_path)
    write_report(data, output_path)
    print(f"Source: {input_path} ({len(data)} personas)")
