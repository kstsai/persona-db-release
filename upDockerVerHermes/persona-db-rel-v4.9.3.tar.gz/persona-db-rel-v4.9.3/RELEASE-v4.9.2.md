# Persona DB v4.9.2 Release Notes

> 日期: 2026-08-19 | 上一版: v4.9.1 | 類型: bug fix（資料 coherence 三連修）

## 重點：三個資料 coherence fix（#27 / #28 / #29）

從 `role_5xx.json` 的「TW-P-0134 vs TW-P-0158 像同一人」追查，挖出 3 個 background_story / clothing_spend 的系統性 coherence bug。

| Issue | 內容 | 驗證結果 |
|:----:|:----|:----|
| #27 | 「房貸早就還完了」套到小孩/學生/租客 | 170→102 筆；0-18 歲 46→0、學生 56→0、租客矛盾 13→0 |
| #28 | R-01 rule 未考慮 family_income（比值 vs 絕對值） | 低所得 hb高+cs>5000 殘留 0 |
| #29 | 未成年高服飾：R-06/R-07 fs=3 漏洞 + 0-18 無上限 | 低所得高服飾 0、0-18 高服飾 0 |

## 關鍵洞見

- **housing_burden 是比值不是「窮」**：高所得「高房貸 + 高消費」是合理組合，coherence rule 只能對低所得開火（#28）。
- **規則順序是通病**：R-01、R-06/R-07 都在 housing_burden / family_income 重算之前執行 → 殘留。已移到最終值之後。
- **成人語意不套小孩**：`>5000`（很重視穿搭）是成人語意，0-18 歲 cap 在 `1500~3000`（#29）。

## 版本鏈

```
v4.9.0 (retry firewall) → v4.9.1 (broadening overshoot) → v4.9.2 (coherence 三連修)
```

## QA 狀態

此版供 QA 驗證，若有必要再進版。
