#!/usr/bin/env python3
"""v5.5 regression tests — #47（統一錯誤契約）/ #46（解析失敗可診斷 + 重試帶變化）/
#48（可觀測性欄位型別化）。決定性、無外部 LLM 呼叫。

Run:  python3 scripts/test_v5_5_fixes.py
"""
import sys, os, json, logging, asyncio

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FAIL = []
RECORDS = []


class _Capture(logging.Handler):
    def emit(self, record):
        RECORDS.append((record.levelname, record.getMessage()))


logging.basicConfig(level=logging.WARNING)
logging.getLogger().addHandler(_Capture())


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


import api.llm as llm_mod
import api.server as server_mod

print("=== #47 錯誤契約：所有錯誤碼統一為 ErrorResponse 形狀 ===")
from fastapi.testclient import TestClient


def _assert_shape(name, r, expect_code=None, expect_status=None):
    try:
        d = r.json()
    except Exception as e:
        check(name, False, f"非 JSON 回應: {e}")
        return
    ok = ("status" in d and isinstance(d.get("error"), dict)
          and "code" in d["error"] and "message" in d["error"]
          and "detail" not in d)
    if expect_code:
        ok = ok and d["error"].get("code") == expect_code
    if expect_status:
        ok = ok and r.status_code == expect_status
    check(name, ok, f"status={r.status_code} body={json.dumps(d, ensure_ascii=False)[:160]}")


with TestClient(server_mod.app) as client:
    # 400（opMode 非法）
    _assert_shape("400 非法 opMode → error 形狀", client.get("/personadb/candidates", params={
        "questions": "康是美的目標客戶", "opMode": "亂寫"}), expect_code="INVALID_OPMODE", expect_status=400)
    # 422（參數驗證）：top_k 超界（Query le=100 先擋，故走 422 而非 400）
    _assert_shape("422 top_k=101 → VALIDATION_ERROR", client.get("/personadb/candidates", params={
        "questions": "康是美的目標客戶", "top_k": 101}), expect_code="VALIDATION_ERROR", expect_status=422)
    # 404（detail 不存在）
    _assert_shape("404 未知 persona → error 形狀", client.get("/personadb/detail", params={
        "persona_id": "TW-P-9999"}), expect_status=404)

    # 503 FILTER_FAILED（stub LLM 回非 JSON 兩次 + 無關鍵字可 fallback 的 query）
    async def _garbage(*a, **k):
        return "抱歉我無法回答"
    _orig_call = llm_mod.call_llm
    llm_mod.call_llm = _garbage
    try:
        _assert_shape("503 FILTER_FAILED → error 形狀", client.get("/personadb/candidates", params={
            "questions": "TESLA的目標客戶"}), expect_code="FILTER_FAILED", expect_status=503)
        r503 = client.get("/personadb/candidates", params={"questions": "TESLA的目標客戶"})
        check("503 error.retryable 標示可重試（#46）", r503.json()["error"].get("retryable") is True,
              r503.json().get("error"))
    finally:
        llm_mod.call_llm = _orig_call

    # 500（內部錯誤）
    _orig_fp = server_mod.filter_personas
    def _boom(*a, **k):
        raise RuntimeError("測試用內部錯誤")
    server_mod.filter_personas = _boom
    try:
        _assert_shape("500 內部錯誤 → error 形狀", client.get("/personadb/candidates", params={
            "questions": "康是美的目標客戶"}), expect_code="INTERNAL_ERROR", expect_status=500)
    finally:
        server_mod.filter_personas = _orig_fp

    # 正常路徑不受影響
    r_ok = client.get("/personadb/status")
    check("正常端點仍為 200（回歸）", r_ok.status_code == 200, r_ok.status_code)

print("\n=== #46 解析失敗：可診斷 + 重試帶變化 ===")
llm_mod.LLM_CONFIG["analysis_model"] = "deepseek-v4-pro"   # 強制走 pro 分支
# v5.8: 預算改由模組常數決定（pro 基礎 12000、重試 18000）
from api.llm import ANALYSIS_MAX_TOKENS, ANALYSIS_RETRY_MAX_TOKENS
BASE_TOK = ANALYSIS_MAX_TOKENS["pro"]      # 12000
RETRY_TOK = ANALYSIS_RETRY_MAX_TOKENS["pro"]  # 18000
RECORDS.clear()
calls = []


async def _fake_nonsense(prompt, temperature=0.2, max_tokens=None, model_override=None, **kw):
    calls.append({"max_tokens": max_tokens, "model": model_override})
    return "這不是 JSON，只是普通文字" * 3


llm_mod.call_llm = _fake_nonsense
try:
    out = asyncio.run(llm_mod.parse_questions_with_llm(["TESLA的目標客戶"]))
finally:
    llm_mod.call_llm = _orig_call

check("兩次皆非 JSON → 回空 dict（交給 keyword fallback）", out == {}, out)
check(f"第一次 attempt 用基礎預算 {BASE_TOK}", calls and calls[0]["max_tokens"] == BASE_TOK, calls)
check(f"重試帶變化：第二次提高為 {RETRY_TOK}（#46）", len(calls) > 1 and calls[1]["max_tokens"] == RETRY_TOK, calls)
warn_msgs = [m for lvl, m in RECORDS if lvl == "WARNING"]
err_msgs = [m for lvl, m in RECORDS if lvl == "ERROR"]
check("失敗原因以 WARNING 記錄（生產 INFO level 可見）", any("Failed to parse LLM response as JSON" in m for m in warn_msgs), warn_msgs)
check("raw response 內容被截斷記錄（可診斷根因）",
      any("Raw LLM response (first 300 chars)" in m and "這不是 JSON" in m for m in warn_msgs),
      warn_msgs)
check("重試訊息顯示新預算", any(f"retrying with max_tokens={RETRY_TOK}" in m for m in warn_msgs), warn_msgs)
check("放棄時以 ERROR 記錄（可被監控）", any("unparseable twice" in m for m in err_msgs), err_msgs)

# 空回應路徑
RECORDS.clear()
calls.clear()


async def _empty(*a, **k):
    calls.append(k.get("max_tokens"))
    return ""


llm_mod.call_llm = _empty
try:
    out2 = asyncio.run(llm_mod.parse_questions_with_llm(["康是美的目標客戶"]))
finally:
    llm_mod.call_llm = _orig_call
check("空回應兩次 → 回空 dict", out2 == {}, out2)
check("空回應重試也帶變化", len(calls) > 1 and calls[0] == BASE_TOK and calls[1] == RETRY_TOK, calls)
check("空回應放棄有 ERROR 記錄", any("empty response twice" in m for lvl, m in RECORDS if lvl == "ERROR"), RECORDS[-2:])

# 第一次失敗、第二次成功 → 不應放棄
calls.clear()
_state = {"n": 0}


async def _flaky(*a, **k):
    calls.append(k.get("max_tokens"))
    _state["n"] += 1
    if _state["n"] == 1:
        return "還是壞的"
    return json.dumps({"filters": {"sex": ["女"]}, "question_analysis": {}, "dim_importance": {}})


llm_mod.call_llm = _flaky
try:
    out3 = asyncio.run(llm_mod.parse_questions_with_llm(["康是美的目標客戶"]))
finally:
    llm_mod.call_llm = _orig_call
check("首次失敗、重試成功 → 取得解析結果（不誤放棄）", out3.get("filters") == {"sex": ["女"]}, out3)

print("\n=== #48 可觀測性欄位型別化（OpenAPI properties）===")
schema = server_mod.app.openapi()["components"]["schemas"]
check("OpenAPI 有 BroadeningAttempt 模型", "BroadeningAttempt" in schema)
check("OpenAPI 有 ScoringBasis 模型", "ScoringBasis" in schema)
ba_props = set(schema.get("BroadeningAttempt", {}).get("properties", {}))
sb_props = set(schema.get("ScoringBasis", {}).get("properties", {}))
check("BroadeningAttempt.properties 完整", {"loop", "change", "match_count_before", "match_count_after",
                                            "filters_changed", "no_op", "overshoot"} <= ba_props, ba_props)
check("ScoringBasis.properties 完整", {"method", "weight_source", "weight_version", "score_scale",
                                       "score_schema", "dims_counted", "relaxed_dims_scored_at"} <= sb_props, sb_props)
resp_props = schema["CandidatesResponse"]["properties"]
check("CandidatesResponse.broadening_attempts 指向子模型（非 additionalProperties）",
      resp_props["broadening_attempts"]["items"]["$ref"].endswith("BroadeningAttempt"),
      resp_props["broadening_attempts"])
check("CandidatesResponse.scoring_basis 指向子模型",
      "ScoringBasis" in json.dumps(resp_props["scoring_basis"]), resp_props["scoring_basis"])

from api.models import CandidatesResponse
expected_keys = {"status", "total_matched", "persona_ids", "summary", "returned", "pool_exhausted",
                 "important_dimensions", "llm_analysis", "relaxed_dims", "broadening_attempts",
                 "applied_filters", "scoring_basis",
                 # v5.8（#56 B）新增：broadening 停止原因
                 "broadening_stop_reason",
                 # v5.9（#57）新增：受保護的核心維度清單（純新增，向後相容）
                 "protected_dims",
                 # v5.12（#65）新增：主體揭露 + 語意護欄告警（純新增，向後相容）
                 "subject", "warnings",
                 # v5.13（#67 B／#66 A）新增：主體判定依據 + 保護集來源拆解（純新增，向後相容）
                 "subject_basis", "protected_dims_sources",
                 # v5.14（#71 B）新增：來源④累積上限（純新增，向後相容）
                 "declared_protected_cap",
                 # v5.15（#72）新增：實際 LLM 呼叫次數（純新增，向後相容）
                 "llm_calls"}
check("model_dump() key 集合 = v5.4 基準 + v5.8 新增（向後相容）",
      set(CandidatesResponse(status="ok", total_matched=0, persona_ids=[]).model_dump().keys()) == expected_keys,
      set(CandidatesResponse(status="ok", total_matched=0, persona_ids=[]).model_dump().keys()) ^ expected_keys)

from api.models import BroadeningAttempt, ScoringBasis
d = CandidatesResponse(status="ok", total_matched=1, persona_ids=[1],
                       broadening_attempts=[BroadeningAttempt(loop=1, no_op=True, overshoot=True)],
                       scoring_basis=ScoringBasis(weight_version="v5.5")).model_dump()
check("子模型序列化出正確欄位", d["broadening_attempts"][0]["overshoot"] is True
      and d["scoring_basis"]["weight_version"] == "v5.5", d["broadening_attempts"])
check("所有子模型欄位都有 default（舊資料不炸）",
      BroadeningAttempt().model_dump() == {"loop": 0, "change": "", "match_count_before": 0,
                                          "match_count_after": 0, "filters_changed": False,
                                          # v5.9（#57）新增：核心維度保護的否決紀錄（純新增、有 default）
                                          "protected_veto": False, "vetoed_dims": [],
                                          # v5.11（#63）新增：值集放寬留痕（純新增、有 default）
                                          "widened_dims": [],
                                          # v5.14（#69／#70 A）新增：放寬幅度 + 過衝還原（純新增、有 default）
                                          "widened_deltas": [], "overshoot_restore": False,
                                          "restored_dims": [],
                                          # v5.15（#72）新增：失敗輪標記（純新增、有 default）
                                          "parse_error": False, "error_type": "",
                                          "no_op": False, "overshoot": False},
      BroadeningAttempt().model_dump())

print("\n" + "=" * 60)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
