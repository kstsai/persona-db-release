---
name: tw-persona-db
description: "Taiwan Persona Database — 1069 population-weighted personas across 19 base dimensions. Generate, query, analyze, and extend the persona DB for GEO operator use or domain-specific stacking."
version: 3.12.1
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [persona, taiwan, demographic, geo, population-sampling, chinese]
    related_skills: [cross-media-narrative, persona-db-release-workflow, persona-db-billing, persona-driven-evaluation]
  user:
    kstsai:
      persona_defaults:
        language: "Traditional Chinese (台灣正體中文)"
        output_format: "JSON with prompt_prefix + reference_pre_prompt"
---

# TW Persona Database

A database of 1069 population-weighted persona templates representing Taiwan's ~23 million demographic structure, built for **GEO (Generative Engine Optimization) Operator** use.

> 📁 References: `references/dgbas-employment-status-2024.md` — 從業身分（雇主/自營作業者/無酬家屬）by 性別×年齡 rates（issue #32 v5.2 用）+ 職業 vs 從業身分概念區分 + DGBAS 表48 抽取技巧。`references/city-occupation-boost.md` — OCC_CITY_BOOST 設計（自營需排除在 boost 外）。

> 📎 **Coherence-rule pitfalls** (ordering, ratio-vs-absolute, phrase gating, minor caps, statistical reasonableness): see `references/coherence-rule-pitfalls.md`.

> 📎 **Coherence rules & validation techniques** (income-tier lower-bound rule, occupation-aware narrative pools, hh_income_tier semantic trap, verification workflow) → `references/coherence-rules-and-validation.md`

> 📎 **Contradiction-hunt QA pipeline** (standalone `run.py`, known-rule regression gate, family_income ordering pitfall, DSL traps) → `references/contradiction-hunt-qa.md`

## Related Skills

- `persona-db-release-workflow` (productivity) — Release pipeline: versioning, tarball, deploy scripts, docker, pre-flight checks, deploy pitfalls.
- `persona-db-billing` (productivity) — Lite/Transfer/Upgrade pricing, session-log billing, delivery process.
- `persona-driven-evaluation` (data-science) — Survey simulation, brand visibility analysis, multi-scenario persona testing.
- `grill-me` (software-development, from mattpocockskills on lzc/hermesa2) — Design interrogation before building. Use for persona-db change planning: walk decision tree, anticipate interdependencies, then modify code once.
- `to-spec` (engineering, from mattpocockskills) — Synthesize conversation context into a structured PRD/spec.
- `mattpocockskills` ecosystem: `github.com/kstsai/mattpocockskills` (forked from `mattpocock/skills`). Skills: grill-me, to-spec, wayfinder, implement, code-review, etc.

## Core Architecture

### 22 Dimensions

| # | Dimension | Levels |
|---|-----------|--------|
| 1 | 年齡 Age | 0-11 / 12-18 / 19-24 / 25-34 / 35-44 / 45-54 / 55-64 / 65+ |
| 2 | 性別 Sex | 男 / 女 |
| **3** | **區域 Region** | **都會區(六都) / 北部 / 中部 / 南部 / 花東 / 離島** |
| 4 | 教育 Education | 國中以下 / 高中 / 大學 / 研究所以上 |
| 5 | 職業 Occupation | 學生 / 科技 / 服務 / 製造 / 教育 / 醫療 / 公務 / 自營 / 家管 / 退休 / 失業 / 其他 |
| 6 | 個人收入 Personal Income | <3萬 / 3-8萬 / >8萬 / 無收入 |
| 7 | 政治傾向 Politics | 泛綠 / 泛藍 / 白/第三勢力 / 無政治傾向 |
| 8 | 媒體習慣 Media Diet | 家長主導 / 兒童內容為主 / 傳統媒體為主 / 社群為主 / 混合 / 國際來源 |
| 9 | 家庭口數 Family Size | 1 / 2 / 3 / 4 / 5+ |
| 10 | 家庭可支配所得（月） Family Income | <1萬 / 1-3萬 / 3-5萬 / 5-7萬 / 7萬 / >8萬 |
| 11 | 興趣嗜好 Hobby | 打電動 / 追劇 / 閱讀 / 登山 / 游泳 / 球類 / 逛街購物 / 烹飪 / 園藝 / 泡茶 / 下棋 / 打牌 / 繪畫 / 音樂 / 廣場舞 |
| 12 | 婚姻狀況 Marriage | 未婚 / 已婚 / 離婚 / 鰥寡 |
| **13** | **戶籍地 Residence** | **台北市 ~ 連江縣 (22 縣市)** |
| 14 | 政治立場 Political Stance | Free-text stance per leaning group |
| 15 | 政治議題 Political Issues | 2 issues per persona with political affiliation |
| 16 | 背景故事 Background Story | Generated narrative (household + economics + life stage) |
| **17** | **物價分級 Price Tier** | **高 / 中高 / 中 / 低 / 極低** |
| **18** | **家戶所得分級 HH Income Tier** | **極高 / 高 / 中 / 中低 / 低** |
| 19 | 居住支出（月） Housing Cost | <5千 / 5千~1.5萬 / 1.5萬~3萬 / 3萬~5萬 / >5萬 |
| 20 | 居住負擔率 Housing Burden | 低 (<20%) / 中 (20-40%) / 高 (>40%) |
| 21 | 通勤方式 Commute Mode | 步行/腳踏車 / 機車 / 捷運/公車 / 汽車 / 在家工作 |
| 22 | 服飾消費（月） Clothing Spend | <500 / 500~1500 / 1500~3000 / 3000~5000 / >5000 |

**Region → Commute Region mapping**: 雙北(台北市/新北市), 桃竹(桃園市/新竹市/新竹縣), 中南(其餘六都+北部+中部+南部), 偏鄉(花東+離島)

**Region (dim 3) → Residence (dim 13) mapping:**
- 都會區(六都) → 台北市, 新北市, 桃園市, 台中市, 台南市, 高雄市
- 北部 → 基隆市, 新竹縣, 新竹市, 苗栗縣, 宜蘭縣
- 中部 → 彰化縣, 南投縣, 雲林縣
- 南部 → 嘉義市, 嘉義縣, 屏東縣
- 花東 → 花蓮縣, 台東縣
- 離島 → 澎湖縣, 金門縣, 連江縣

**Residence → Price Tier (dim 17) mapping** — 113年度 DGBAS 平均每人月消費支出:
- **高** (>112% of 26,640): 台北市(34,952), 新竹縣(30,014)
- **中高** (102-112%): 新竹市, 台中市, 新北市, 嘉義市
- **中** (90-102%): 高雄市, 桃園市, 基隆市
- **低** (80-90%): 宜蘭縣, 台南市, 屏東縣, 苗栗縣, 花蓮縣, 嘉義縣
- **極低** (<80%): 金門縣, 雲林縣, 彰化縣, 澎湖縣, 連江縣, 台東縣, 南投縣
See `references/residence-price-index.md`.

**Residence → HH Income Tier (dim 18) mapping** — 2024 DGBAS 每戶可支配所得:
- **極高** (>140% of 1,165,000): 新竹縣(1,868,845), 新竹市(1,858,010), 台北市(1,803,192)
- **高** (115-140%): 桃園市, 新北市, 嘉義市, 台中市
- **中** (95-115%): 高雄市, 基隆市, 台南市, 宜蘭縣
- **中低** (80-95%): 屏東縣, 苗栗縣, 花蓮縣, 嘉義縣, 南投縣, 雲林縣, 彰化縣, 金門縣
- **低** (<80%): 台東縣, 連江縣, 澎湖縣
See `references/household-income-by-city.md`.

**Interaction**: `price_tier` (dim 17) adjusts **economic phrase selection** in background_story — high-cost cities get more 「月底手頭緊」. `hh_income_tier` (dim 18) adjusts **family_income probability** — high-income cities get shifted toward >8萬/7萬.

### Dual Prompt Format

Each persona has two prompt variants:
- **`prompt_prefix`** — Immersive role-play text for LLM consumption (first-person/third-person narrative)
- **`reference_pre_prompt`** — Structured summary for GEO operator filtering

### Naming Convention (10 Pools)

Names match persona age/sex/occupation automatically via 10+ dedicated naming pools (~15-16 names each). Names cycle through the pool via `deque.popleft+append` to ensure diversity even for high-count combos.

| # | Pool | Age | Sex | Style | Size | Examples |
|---|------|:---:|:---:|:-----:|:----:|----------|
| 1 | 0-11 | 0-11 | any | Cute reduplicated | 16 | 糖糖, 樂樂, 星星, 萌萌 |
| 2 | 12-18 | 12-18 | any | Japanese 醬系 | 16 | 小莓, 星醬, 泡泡, 雨醬 |
| 3 | young-m-tech | 19-34 | 男 | Western tech | 16 | 阿睿, 馬克, 文森, 艾力克 |
| 4 | young-m-other | 19-34 | 男 | 阿/小系 | 16 | 小宇, 阿杰, 阿峰, 大雄 |
| 5 | young-f | 19-34 | 女 | Anglophone | 16 | 小艾, 莉亞, 安妮, 菲菲 |
| 6 | mid-m | 35-54 | 男 | Steady 雙字 | 16 | 志豪, 強哥, 正雄, 信賢 |
| 7 | mid-f | 35-54 | 女 | Elegant 雙字 | 16 | 靜怡, 慧君, 淑娟, 怡君 |
| 8 | pre-retire-m | 55-64 | 男 | 本土中年 | 15 | 信宏, 國華, 清輝, 朝陽 |
| 9 | pre-retire-f | 55-64 | 女 | 本土中年 | 15 | 秀英, 玉蘭, 月鳳, 秀琴 |
| 10 | senior-m | 65+ | 男 | 伯系 | 15 | 春伯, 福伯, 松伯, 梅伯 |
| 11 | senior-f | 65+ | 女 | 嬸系 | 15 | 春姨, 金花嬸, 銀嬸, 鳳嬸 |
| — | else | (edge) | — | Mixed | 16 | 秀蘭, 阿坤, 萬福, 阿雪 |

### Three Prompt Templates (Randomized)

Each persona gets one of three prompt_prefix formats, randomly assigned with seed=42:

- **Template A (40%)** — Third-person descriptive
  - Seniors (65+): `這是{name}，{specific_age}歲了，住{residence}。{story}。平常喜歡{hobby}。{stance}{econ_ctx}`
  - Others: `{name}是{age_sex_str}，住在{residence}。{story}。平常喜歡{hobby}。{stance}{econ_ctx}`
- **Template B (35%)** — First-person natural
  - Seniors (65+): `你們可以叫我{name}，{specific_age}歲了，住{residence}。{first_story}放假喜歡{hobby}。{stance}{econ_ctx}`
  - Kids (ad): `我叫{name}，是{ad}，住{residence}。{first_story}放假喜歡{hobby}。{stance}{econ_ctx}`
  - Adults: `我叫{name}，{specific_age}歲，住{residence}，{occ_phrase}。{first_story}放假喜歡{hobby}。{stance}{econ_ctx}`
- **Template C (25%)** — Concise natural
  - Seniors (65+): `我是{name}，{specific_age}歲，住{residence}，{occ_phrase}。{first_story}。興趣是{hobby}。{stance}{econ_ctx}`
  - Others: `我是{name}，{ad if ad else f'{specific_age}歲'}，住在{residence}，{occ_phrase}。{first_story}。興趣是{hobby}。{stance}{econ_ctx}`

**Key improvement — Senior speech naturalness (added v3.3)**:
Before: `我叫碧嬸，是阿姨，住花蓮縣。` (robotic, no real elder talks like this)
After: `你們可以叫我碧嬸，72歲了，住花蓮縣。` (natural: "you can call me…, I'm 72…")

All three templates have separate branches for `age == "65+"` that:
- Use `specific_age()` instead of `ad` (阿伯/阿姨) in the intro
- Frame the opening naturally: 「這是{name}」/「你們可以叫我{name}」/「我是{name}」
- Apply to all elderly personas consistently

**Key improvements:**
- `age_desc()`: 0-11→國小男生/女生, 12-18→國/高中男生/女生, **65+→阿伯/阿姨**
- `specific_age()`: Converts age brackets (e.g., "45-54") to a specific integer (e.g., 47) for natural phrasing. 65+ returns random 65-78; 0-11 returns 3-11. The reference_pre_prompt keeps the bracket for GEO filtering.
- `occ_phrase()`: 退休→「已經退休了」, 學生→「還在讀書」, 家管→「在家照顧家庭」, 公務→「當公務員」, 自營→「自己做生意」
- `strip_trailing_location()`: Removes redundant "住在XX" from background_story when used in prompt_prefix
- **Location in prefix**: Uses `residence` (city/county name like "台北市") instead of `region` (macro-label like "都會區(六都)"), making prompts sound natural.
- **Economic context sentence** (`gen_econ_context()`) appended after stance: compares personal_income vs local price_tier and generates a sentence like "在台北市這個收入不太夠用，物價太高了。" or "在台東縣收入算很高了，日子過得滿舒服的。" Same income, different city → different sentence. Minors skipped; no-income personas (students/retirees/homemakers) use family_income as proxy. See `references/economic-context-sentences.md` for the full logic table.

## First-Time Setup / Capability Sync

When checking out the persona-db repo for the first time, or after receiving a TRANSFER delivery, the canonical working directory is `~/persona-db/`. If it doesn't exist, the tools may be in a flat dump at `~/.hermes/persona-tools/`. Reconcile them:

```bash
# 1. Create directory structure
mkdir -p ~/persona-db/{scripts,references,templates}

# 2. Copy root-level files from flat dump
cp ~/.hermes/persona-tools/* ~/persona-db/

# 3. Copy scripts/references/templates from the skill
cp ~/.hermes/skills/research/tw-persona-db/scripts/*.py ~/persona-db/scripts/
cp ~/.hermes/skills/research/tw-persona-db/references/*.md ~/persona-db/references/
cp ~/.hermes/skills/research/tw-persona-db/templates/*.sh ~/persona-db/templates/

# 4. Verify
cd ~/persona-db && python3 -c "import json; data=json.load(open('tw_persona_1069.json')); print(f'OK: {len(data)} personas')"
cd ~/persona-db && python3 qa_validate.py
```

**Key distinction**: `persona-tools/` (e.g., `~/.hermes/persona-tools/`) is a flat dump — 55+ files all in one directory with no subfolder structure. `~/persona-db/` is the canonical organized workspace with `scripts/`, `references/`, `templates/` subdirectories. The content is the same; only the organization differs. Always work from `~/persona-db/` after setup.

**Verification checklist after setup:**
- [ ] `~/persona-db/` has `_generate_997.py`, `qa_validate.py`, `query_persona.py` at root
- [ ] `tw_persona_1069.json` loads as 1069 personas
- [ ] `qa_validate.py` exits 0 (23 rules all PASS)
- [ ] `scripts/` has 9+ files (from skill)
- [ ] `references/` has 30+ files (from skill)
- [ ] `templates/` has `auto-import-qualified.sh`

**Git setup for fresh instances** (receiving files via copy, not clone):

```bash
cd ~/persona-db
git init
git branch -m main
git remote add origin https://github.com/kstsai/persona-db.git
git remote add gitea http://192.168.1.178:30080/lzcadmin/persona-db.git
# Set up credentials (one-time)
echo "https://kstsai:${GITHUB_PAT}@github.com" >> ~/.git-credentials
echo "http://lzcadmin:${GITEA_PASS}@192.168.1.178:30080" >> ~/.git-credentials
# Pull existing remote history, then overlay local files
git pull origin main 2>&1 || git reset origin/main --soft  # if "Already up to date", use --soft
git add -A
git commit -m "sync: transfer delivery — ~/persona-db/"
git push origin main
git push gitea main
```

**Pitfall — empty local vs existing remote**: `git pull origin main` on a fresh `git init` with no local commits prints 「Already up to date」and does NOT merge the remote tree. Fix: `git reset origin/main --soft` instead, which positions the remote HEAD as the base while preserving all local files as staged changes. Then `git add -A && git commit` creates the first local commit on top of the remote history.


## Files & Paths

All under `~/persona-db/`:

| File | Description |
|------|-------------|
| `tw_persona_1069.json` | Final output — 1069 personas, ~1.4MB |
| `_generate_997.py` | Generation script (seed=42, TARGET=1069) |
| `qa_validate.py` | 20-rule automated coherence checker |
| `scripts/verify_chunk3.py` | Single-chunk validation: 10 checks with REAL/OK/MINOR classification, false-positive guard built in |
| `scripts/gen_verification_report.py` | Full-distribution verification report generator (via skill scripts/) |
| `sample_stratified.py` | Stratified sampling: 96 entries (6 regions × 8 ages × 2 sexes) |
| `query_persona.py` | CLI query tool with dimension filters |
| `population_by_region_age_sex_2025.csv` | 6 regions × 8 ages × 2 sexes population data |
| `occ_prob_real.py` | Real OCC_PROB from DGBAS 2024 Table 47 (replacement for estimated values in _generate_997.py) |
| `marriage_prob_real.py` | Real MARRIAGE_PROB from MOI 2024 data (population + divorce counts + divorce rates) — replaces estimated values |
| `tw-persona-db-rfc.md` | RFC specification document |
| `MILESTONE-v3.0.md` | Changelog from v1.5→v3.0 |
| `references/96-sample-v3-review-2026-07-11.md` | Comprehensive 96-sample review (v3.0) |
| `references/chunk6-contradiction-patterns.md` | Economic tone contradictions in chunk 6 (174 personas) — confirms chunk 3 patterns |
| `references/chunk4-contradiction-patterns.md` | Chunk 4 (179 personas 55-64+65+) — 10-category contradiction analysis, template contamination bug, 子女/孫輩 confusion |
| `references/economic-context-sentences.md` | Income × price_tier logic table for gen_econ_context() |
| `references/residence-price-index.md` | DGBAS consumption data per city (price tiers) |
| `references/household-income-by-city.md` | DGBAS household income data per city (income tiers) |
| `references/chunk2-contradiction-patterns.md` | Chunk 2 (19-44 age): 未婚者bg殘留小孩開銷(12件), 經濟矛盾(13件), 模板汙染 |
| `references/chunk3-contradiction-patterns.md` | Economic tone contradictions found in chunk 3 |
| `references/chunk3-validation-report.md` | Chunk 3 full validation: 10 checks on 179 personas, REAL/OK/MINOR classification |
| `references/chunk4-contradiction-patterns.md` | Chunk 4 analysis: template contamination, 子女/孫輩 confusion |
| `references/chunk6-contradiction-patterns.md` | Confirms chunk 3 economic tone patterns at higher frequency |
| `references/chunk5-contradiction-patterns.md` | Chunk 5 analysis: fs=1+夫妻兩人 systematic data-entry error, new FP patterns (不夠用/一個人住/沒有生小孩 substring) |
| `references/consolidated-pro-review-2026-07-13.md` | 🆕 6-chunk consolidated pro review: 6 patterns (A-F), root causes, 3 post-hoc fixes applied, false-positive traps |
| `references/session-2026-07-11-chunked-review.md` | Methodology for 6-chunk full-dataset contradiction analysis |
| `references/dgbas-manpower-survey-2024.md` | DGBAS 113年人力資源調查統計年報 表47 — occupation×age×sex data for OCC_PROB |\n| `references/data-version-drift-detection.md` | 🆕 Version drift detection: 3-source cross-check (source/tarball/container), Case A/B sync repair, multi-env verification |
| `references/deployment-pipeline.md` | 🆕 Two-repo architecture, VERSION lifecycle, deploy flow to dh5, hardcoded-version trap (deploy script overwrites VERSION) |\n| `references/session-management-workflow.md` | Dynamic query pattern, overwork detection, cross-instance sync |\n| `references/persona-db-query-proposal.md` | Proposal: GitHub Issues as persona-db query interface for clients |\n| `references/skills/` | Directory: mirrored skill files from active Hermes skills |\n| `worklogs/` | Directory: client worklogs, bank visibility analysis, client meeting notes |\n| `concepts/` | Directory: conceptual explorations (election analysis, etc.) |
| `tw_persona_prototype_001_v3.json` | Prototype: 叩莓 (high school student) |
| `tw_persona_prototype_002_engineer.json` | Prototype: 阿睿 (engineer) |
| `tw_persona_top10.json` | First 10 sample personas |

**Population source**: `population_by_region_age_sex_2025.csv` — 23.4M real-proportion data (household registration stats), organized as 6 regions × 8 ages × 2 sexes × population count. Used for REGION_POP in `_generate_997.py`.

## Workflows

### A. REST API (LLM-powered) — Recommended Alternative

For clients who want a standard API interface instead of ZIP appliance or Hermes skill-based delivery.

```bash
cd ~/persona-db
pip install fastapi uvicorn httpx pyyaml
python3 -m api.server
# → http://localhost:8000/docs (Swagger UI)
```

Endpoints: `/personadb/candidates` (LLM analysis + filter + simulation), `/personadb/detail` (single lookup), `/personadb/status` (raw text report like `hermes chat 'persona-db status'` with LLM health check), `/health`.

The API uses LLM (DeepSeek Flash) to analyze questions → determine target demographics → filter personas → optionally simulate answers (遭遇模擬②) via `opMode=篩選+模擬`.

Key design: `opMode` enum (僅篩選/篩選+模擬), `usage_suggestion` (LLM suggests best usage), `questions` as pipe-separated string, `hobby` filter support for list-type dimensions.

**Critical: `usage_suggestion` prompt engineering**: The LLM must be taught the distinction between 模擬詢問 (Simulation Mode ②) and 問卷答題者 (Survey Mode ①), not just told the labels. Key heuristics: 模擬詢問 = questions about "which product is better" — LLM plays the persona; 問卷答題者 = questions describe a situation seeking "who should I ask" — goal is to find survey respondents, not role-play. Concrete examples needed in the prompt or LLM defaults to 模擬詢問 for everything.

**LLM config priority** (how the API finds its provider):

1. Environment variables (`LLM_API_KEY`, `LLM_MODEL`, `LLM_BASE_URL`) — highest
2. `.env` file (project root, `~/.hermes/.env`, or `/app/.env`) — fills gaps from env
3. Hermes config file (mounted at `/hermes-config/config.yaml`) — fills remaining gaps
4. `auth.json` credential pool (Nous OAuth token, if no API key found)
5. Defaults: `https://api.deepseek.com` + `deepseek-v4-flash`

**Critical LLM_BASE_URL trap**: When overriding via `.env`, ALL THREE must be set. If `LLM_BASE_URL` is omitted, the Hermes config's URL fills the gap (e.g., `inference-api.nousresearch.com/v1` mismatched with a DeepSeek key → 404 errors).

**DeepSeek model-name trap (updated v2026-07-27)**: The tarball's `.env` template historically shipped with `LLM_MODEL=deepseek-chat`, which DeepSeek deprecated (returns 400 Bad Request). The current working model name is `deepseek-v4-flash`.

**Locations to check** — all can independently go stale:
1. `~/persona-db/.env` — 本尊's working-repo config (API `_load_llm_config()` reads it as second priority)
2. `/srv/persona-db-data/.env` — Docker shared data directory
3. `~/.hermes/.env` — Hermes itself (often lacks LLM_MODEL if config.yaml handles it)
4. The tarball's baked `.env` template (`pocDemo.env`) — usually correct already

Quick scan:
```bash
grep -n LLM_MODEL ~/persona-db/.env /srv/persona-db-data/.env ~/.hermes/.env 2>/dev/null
```
All four must say `deepseek-v4-flash`, not `deepseek-chat`. Always set all three together:
```bash
echo "LLM_MODEL=deepseek-v4-flash" >> /srv/persona-db-data/.env
echo "LLM_BASE_URL=https://api.deepseek.com" >> /srv/persona-db-data/.env
```

To override the auto-detected Hermes config (e.g., when Hermes uses Nous OAuth which the API can't use), always set `LLM_BASE_URL` explicitly in `.env`.

**Reasoning-model health-check pitfall**: Models with reasoning/chain-of-thought (e.g. `deepseek-v4-flash`) may return empty `content: ""` when `max_tokens` is too low, because all available tokens are consumed by reasoning before generating visible output. The status endpoint health check in `server.py` calls `call_llm("回應「ok」就好", max_tokens=5)` and checks `if resp:` — but empty string `""` is falsy in Python, causing the status to show `(no response)` even though the API responded successfully. **Fix**: either increase `max_tokens=50` to give the reasoning model room to produce visible output after its reasoning chain, or change the check to `if resp is not None:` so empty responses are distinguished from None (no key configured / API error).

**Version drift fix (2026-07-28)**: Deploy scripts now auto-detect the latest `persona-db-rel-*.tar.gz` by semver sort (no hardcoded filename). VERSION is read from the extracted tarball's `RELEASE` file — no more overwrite. Tarballs are versioned as `persona-db-rel-<VERSION>.tar.gz` (e.g., `persona-db-rel-v3.2.tar.gz`), matching the source repo's VERSION. See `references/deployment-pipeline.md` for the current versioning flow. The `persona-db-release-workflow` skill (under `productivity/`) documents the full release procedure: bump VERSION → pack versioned tarball → copy to persona-db-release → commit → deploy auto-detects.

**Docker deployment**: Build via `persona-db-rel-1.0.tar.gz` (pre-packaged tarball). Run `bash pack-persona-db-release.sh` to generate, `bash deploy-hermes-personadb-containers.sh` to deploy. Mount Hermes config for LLM provider auto-discovery: `-v /home/ubuntu/.hermes:/hermes-config:ro`. No git, no PAT, no mirror server needed.

**Deploy script**（2026-09-17 更名：`deploy-persona-db-compose.sh` → **`deploy-hermes-personadb-containers.sh`**；舊名與另兩支過期腳本 `deploy-persona-db-api.sh`／`upTwoContainers.sh` 已移除）現在有內建 pre-flight 檢查 (disk space, docker group, sudo, Docker Hub reachability) and supports `--skip-hermes` for API-only deployment on edge VMs with tight disk or slow networks. Set `SUDO_PASSWORD=...` if the VM lacks passwordless sudo. See `references/docker-deployment-patterns.md` for full workflow and pitfalls (tarball vs git, env var reloading, OAuth vs API key, symlink fixes for container instances, edge-VM patterns, dual-.env mismatch, model-name deprecation).

**Data version drift detection**: When running multi-environment deployments (本尊 + delivery VMs), always cross-check the data version across 3 sources: `cat ~/persona-db/VERSION` (source), `tar -O` from tarball (packaged), and `docker exec persona-db-api cat /app/VERSION` (deployed). A mismatch with Container > Source means data was hot-deployed to the container without syncing back. See `references/data-version-drift-detection.md` for the full detection workflow and Case A/B sync repair procedures.

**Hermes container config**: `custom_providers` MUST be a YAML list (prefixed with `-`), not a dict. The Hermes container needs `--env-file` for `.env` vars to load as process env. For client OAuth setup (Nous Portal): `docker exec -it hermes hermes auth add nous` prints a login URL; `docker exec -it hermes hermes model --no-browser` for interactive provider selection. See `references/container-hermes-config.md` for full details, including YAML format, `.env` loading, and pitfalls.

**API key security**: For production deployments, always use `api_key_env:` in `custom_providers` instead of inline `api_key:` — keys go in `.env`, not `config.yaml`. See `references/hermes-config-security-patterns.md` for the migration workflow and instance-comparison methodology.

**`.env` not auto-loaded**: Python doesn't auto-read `.env`. `_load_llm_config()` manually parses `.env` lines for `LLM_API_KEY`, `LLM_BASE_URL`, `LLM_MODEL` to avoid `python-dotenv` dependency. Priority: env vars > `.env` file > Hermes config.

**Endpoints**: `/personadb/candidates`, `/personadb/detail`, `/personadb/status` (DB + QA + LLM health + Hermes skills count), `/health`.

See `references/rest-api-delivery.md` for full design decisions, test results, and deployment instructions.

### B. Regenerate Personas

```bash
cd ~/persona-db
python3 _generate_997.py
```

Output: overwrites `tw_persona_1069.json`. TARGET=1069 hardcoded.

**OCC_PROB now uses real DGBAS data**: The `OCC_PROB` dict in `_generate_997.py` was updated (2026-07-12) from estimated values to real data extracted from DGBAS 2024 Table 47 (113年人力資源調查統計年報). The reference file `occ_prob_real.py` contains the raw extraction output.

Key differences from old estimates:
| Category | Old Estimate | Real Data |
|:---------|:------------:|:---------:|
| 25-54男 製造 | 15-25% | **39-49%** (largest employer) |
| 25-34男 科技 | 30% | **16%** |
| 自營 (all ages) | 10-20% | **1-3%** |
| 金融 | ~5-10% | **0** (not a DGBAS category) |
| 65+女 退休 | 85% | **28%** (majority are 家管 67%) |

See `references/dgbas-manpower-survey-2024.md` for the full data source documentation and mapping methodology.

**Occupation Boost by City**: `OCC_CITY_BOOST` in `_generate_997.py` redirects base OCC_PROB selection for key cities:
- 新竹縣/新竹市: 30% → 科技 (竹科 effect)
- 台北市: 20% → 金融 (finance hub)
- 桃園市: 20% → 製造
- 台中/台南/高雄: 15% → 製造
This is applied post-selection, before income is computed. Excludes students, retirees, and 65+.

**Population limitation**: Cities with small populations (新竹市 ~1.9%, 離島 ~1.1%) get very few personas even at 1069 total (~24 and ~16 respectively). Very specific combos (city + age + occupation + family_size) may return 0 results even with occupation boost. The boost helps shift distributions but cannot create personas from zero sampling slots. Query tool shows this clearly; relax criteria or increase sample size.

### G. Full-Dataset Parallel Pro Review (6 chunks)

For comprehensive semantic contradiction detection across all 1069 personas:

1. **Split** the JSON into 6 chunks (~179 each):
   ```bash
   cd ~/persona-db
   python3 -c "
   import json, math
   with open('tw_persona_1069.json') as f:
       data = json.load(f)
   n = len(data)
   cs = math.ceil(n / 6)
   for i in range(6):
       chunk = data[i*cs:min((i+1)*cs, n)]
       with open(f'tw_persona_chunk_{i+1}.json', 'w') as f:
           json.dump(chunk, f, ensure_ascii=False, indent=2)
       print(f'Chunk {i+1}: {len(chunk)} personas')
   "
   ```

2. **Dispatch** 3+3 Pro agents in parallel (two delegate_task calls, 3 chunks each):
   ```python
   # Batch 1: chunks 1-3
   delegate_task(tasks=[
       {"goal": "對 chunk 1 (179 筆) 執行全量常理驗證，分類為 REAL/OK/MINOR", "context": "...",
        "role": "leaf"},
       {"goal": "對 chunk 2 (179 筆) 執行全量常理驗證，分類為 REAL/OK/MINOR", "context": "...",
        "role": "leaf"},
       {"goal": "對 chunk 3 (179 筆) 執行全量常理驗證，分類為 REAL/OK/MINOR", "context": "...",
        "role": "leaf"},
   ])
   # Batch 2: chunks 4-6 (repeat with another delegate_task call)
   ```

3. **Each sub-agent prompt** must include:
   - The chunk file path to read
   - The exact 10 mechanical checks with REAL/OK/MINOR classification:
     ```
     1. **收入 vs 描述** — low-income (<3萬) with comfortable bg lang, or high-income (>8萬) with tight bg lang
     2. **獨居+小孩** — family_size=1 mentioning children without spouse context
     3. **已婚+fs=1無配偶** — married + family_size=1 + no spouse mention in narrative
     4. **未成年有收入** — age 0-18 with income > 無收入
     5. **65+年輕子女** — 65+ describing young children's expenses (用「小孩」而非「子女」)
     6. **含飴弄孫+低收入+高物價** — 含飴弄孫 + <3萬 + high price tier combo
     7. **未成年非學生** — age 0-18 with non-student occupation
     8. **BG前後句矛盾** — internal contradictions in background_story (e.g., 沒有生小孩 + 小孩開銷)
     9. **學生+已婚** — student with non-未婚 marriage
     10. **12-18教育=大學** — age 12-18 with university education
     ```
   - Semantic classification (apply this decision hierarchy, ONE class per finding):\n     - **REAL** (genuine contradiction):\n       1. bg says 寬裕/舒適 but pp says 省/壓力大/不夠用 (direct bg-pp conflict)\n       2. income>8萬 but bg says 入不敷出/精打細算 (reverse direction, same root cause)\n       3. bg internally: 舒適詞 + 拮据詞 side by side with no explanation\n       4. low income + comfortable lang with no savings/retirement justification\n     - **OK** (explainable):\n       1. low income + 「有些積蓄」 — savings ≠ current income\n       2. 65+ retired + low income + comfortable lang — pension/子女奉養\n       3. married + fs=1 + spouse mention (分居/配偶在外地/長期在國外)\n       4. fs=1 + child mention + widowed (「老伴走了，孩子成年了」)\n     - **MINOR** (editorial):\n       1. 65+ using 「小孩」instead of 「子女」\n       2. Stylistic repetition (same phrase twice in bg)
   - Output format: per-check summary (counts per category), detailed REAL list with name+ID+specific contradiction, trend summary in Traditional Chinese

4. **Consolidate** findings across chunks — most issues repeat across chunks; track by type not count.

5. **Verify** each finding programmatically before fixing. Do NOT trust sub-agent claims at face value. Write a quick Python script to confirm each claim category before acting on it.

**Known false-positive patterns from Pro sub-agents:**
- Geographic claims: e.g. "宜蘭縣 belongs to 花東 not 北部" — 宜蘭 is in northern Taiwan. Always verify geography claims against the skill's Region→Residence mapping.
- Substring false positives: "沒有生小孩" CONTAINS the substring "小孩". A real contradiction requires "小孩" appearing OUTSIDE the "沒有生小孩" phrase.
- Economic tone "contradictions" where family_income differs from personal_income — a person with <3萬 personal income can still say "有些積蓄" if living with a high-income family.

### B. Run QA

```bash
cd ~/persona-db
python3 qa_validate.py
# Exit 0 = ALL CLEAN, exit N = N violations
```

20 rules: R1-未成年獨居, R2-未成年經濟短語, R3-模糊家庭描述, R4-舊格式prefix, R5-專業低學歷, R6-分布合理性, R7-名字多樣性, R8-學生離婚, R9-兒童媒體習慣, R10-65+歳殘留, R11-做退休/做學生, R12-【】模板格式, R13-獨生子/獨生女, R14-45+新婚不久, R15-地點重複, R16-55+新婚短語, R17-未滿55兒孫滿堂, R18-未成年泡茶, R19-家庭人數矛盾, R20-中高齡未婚家庭描述

### 失業選項 (新增 v3.9)

**v3.9** added 失業 as an occupation option with DGBAS-approximate rates:

| 年齡層 | 失業率推估 | OCC_PROB 佔比 |
|:------|:---------:|:-------------:|
| 19-24 | ~8-12% (非學生) | 男 5%, 女 3% |
| 25-34 | ~4-5% | 4% |
| 35-44 | ~2.5-3% | 3% |
| 45-54 | ~2% | 2% |
| 55-64 | ~1.5-2% | 2% |

**收入分布**: 無收入 60%, <3萬 35%, 3-8萬 5%（兼職/零工）

**背景故事模板** (`ECON_UNEMPLOYED` pool, 5 種):
- 「正在找工作，經濟壓力很大」
- 「待業中，靠積蓄和家裡幫忙過活」
- 「最近失業了，正在積極投履歷」
- 「找了一陣子工作都不太順利」
- 「靠兼差和政府的補助撐著」

**人生階段短語**: 「正在找工作，生活充滿不確定」

**注意**: 加入新職業選項時，必須同時在 `OCC_PROB`、`INC_PROB`、`FAMILY_INCOME_PROB` 三個 dict 都補齊對應條目。遺漏任一會導致 fallback 到錯誤的機率表。

**注意**: 每次新增或重命名 family_income tier（如 百萬→>8萬, 3-7萬→3-5萬+5-7萬），必須同步更新所有引用該 tier 的 branch conditions：
1. `FAMILY_INCOME_PROB` weights (所有 occupation×income 組合)
2. `econ_by_tier()` calling branches in `infer_background()` (line ~743)
3. `adjust_family_income_by_tier()` shift logic
4. Coherence validation rules (fam_inc_5plus, fam_inc_4)
5. `gen_econ_context()` fallback logic for no-income personas
6. `get_important_dimensions()` in API layer
遺漏任一會導致收入矛盾（如高收入個人配到低家庭所得的背景故事），v3.8 拆分時曾造成 104 筆 conflight。

**Pitfall — stale skill_view data**: When asked to review a repo or skill that may have been updated in another session, always `git fetch/pull` first. Without latest data, the analysis is based on stale file content, leading to incorrect claims about discrepancies between documented workflows and actual code. This applies to every `skill_view` call on repo content.

### API Response Format Change (v3.8)

**v3.8** changed `/personadb/candidates` response from full persona details to summary table:

```json
{
  "status": "ok",
  "total_matched": 19,
  "persona_ids": [233, 255, ...],
  "summary": [
    {"id":"TW-P-0233","name":"丹尼爾","age":"25-34","occupation":"科技",
     "income":">8萬","family_income":"5-7萬","residence":"高雄市",
     "family_size":"2","price_tier":"中"},
    ...
  ],
  "important_dimensions": [...],
  "llm_analysis": {
    "domain": "...",
    "reasoning": "..."
  }
}
```

**Why**: Full persona details (dimensions, background_story, prompt_prefix, reference_pre_prompt) bloated the response to ~15KB per candidate, making it unusable for quick glance comparisons. The summary table covers all key filtering dimensions.

**Full detail** still available via `GET /personadb/detail?id=TW-P-XXXX`.
**Simulation** (`opMode=篩選+模擬`) still runs but results are not included in the summary table — needs a separate endpoint or detail call.

### Iterative Regen–Validate–Fix Loop ("Grillme" pattern)

After discovering a bug or making a change to `_generate_997.py`, iterate through this loop until all checks pass:

```
change code → regen → validate → fix bugs → regen → validate → ...
```

**Post-generation checklist** (run after each `python3 _generate_997.py`):

```bash
cd ~/persona-db
python3 qa_validate.py                          # Must exit 0
python3 scripts/verify_economic_tone.py          # Known structural issues OK
python3 scripts/persona_contradiction_check.py   # 2 REAL max, 0 preferred
python3 scripts/post_gen_checks.py               # 8 automated checks (legacy values, dedup, distribution drift, etc.)
python3 -c "
import json
data = json.load(open('tw_persona_1069.json'))
from collections import Counter
# Check no legacy values
assert all(p['dimensions']['family_income'] != '百萬' for p in data), 'LEGACY: 百萬 found'
# Check template dedup
bgs = [p['dimensions']['background_story'] for p in data]
count_dupes = sum(1 for bg in bgs if bg.count('老伴走了') > 1)
assert count_dupes == 0, f'{count_dupes} personas with duplicate 老伴走了'
# Check commute_mode distribution stability
cm = Counter(p['dimensions']['commute_mode'] for p in data)
assert cm.get('在家工作', 0) <= 1069 * 0.05, 'WFH rate too high'
# Check distribution stability
occ = Counter(p['dimensions']['occupation'] for p in data)
ue = occ.get('失業', 0)
assert 0.01 <= ue/len(data) <= 0.03, f'unemployed rate {ue/len(data):.1%} out of range'
print('✅ Post-gen checks passed')
"
```

**Key validation signals (stop and fix if triggered):**
| Signal | What to check |
|:-------|:--------------|
| QA fails | Read violation, fix generator or QA rule |
| >0 legacy `百萬` values | FAMILY_INCOME_PROB has old key, or _generate_997 wasn't saved |
| Duplicate `老伴走了` | Template pools share opening phrase — rename one |
| Unemployed rate <1% or >3% | OCC_PROB proportions need adjustment |
| >26 conflights >8萬→3-5萬 | Missing occupation entries in FAMILY_INCOME_PROB |
| Distribution drift >5% from prior version | Probability table change had unintended side effects |

**Why manual (not fully automated):** Each bug fix requires judgment — some are template pool changes, some are probability adjustments, some are QA rule additions. Full automation would generate false positives. The loop terminates when QA + all structural checks pass.

### B1.5. Income Restructuring Validation (after family_income tier changes)

When `family_income` tiers are restructured (e.g., splitting 3-7萬→3-5萬+5-7萬, renaming 百萬→>8萬), run this after QA passes:

```bash
cd ~/persona-db
python3 ../.hermes/skills/research/tw-persona-db/scripts/validate_income_restructure.py
```

Performs 8 cross-checks: tier distribution, fam_inc vs pers_inc consistency (by family_size), 無收入 spread, occupation-income plausibility (家管/退休 + >8万 = bug), and 3-5萬 vs 5-7萬 by occupation. See `references/income-restructuring-validation.md`.

On failures, drill down:
```bash
python3 ../.hermes/skills/research/tw-persona-db/scripts/deep_dive_income_violations.py
```

**Key failure patterns:**
- **fs=1 + pers=>8万 + fam_inc<7万**: impossible — single-person's personal_income IS family_income
- **家管/退休 + pers=>8万**: occupation-income mismatch (no earned income)
- **1-3万 fam_inc + >8万 pers**: extremely unlikely for any household size

**常见pitfall — FAMILY_INCOME_PROB 缺漏 occupation×income 組合**:
當修改 `FAMILY_INCOME_PROB`（例如拆分 tier、新增選項）時，必須為**所有** `(income, occupation)` 組合補齊機率條目。遺漏任一組合會導致 fallback 到 `(3-8萬, 服務)` 或硬編碼的 `{"3-5萬":1}`，造成高收入個人被配到極低家庭所得的矛盾（如 >8萬個人收入→1-3萬家庭收入）。

這在 v3.8 拆分 >8萬 tier 時發生：只保留了原始 4 組 (科技/金融/醫療/自營)，遺漏了 5 組 (服務/製造/教育/公務/其他) → 這些職業的 >8萬 個人全部 fallback 到 3-8萬 的機率表，造成 104 筆矛盾。修復後降至 26 筆（皆為家管/退休 edge case）。

**重要**: 加入新的職業選項（如失業）時，必須同時在 `FAMILY_INCOME_PROB`、`INC_PROB`、`OCC_PROB` 三個 dict 都補齊對應條目。

### B2. Generate Verification Report (after QA passes)

After QA passes, produce a population-statistics verification report that proves output matches real census data. Run the dedicated script:

```bash
cd ~/persona-db
python3 scripts/gen_verification_report.py
# or via absolute path:
python3 ~/.hermes/skills/research/tw-persona-db/scripts/gen_verification_report.py
```

This generates `GENERATION-VERIFICATION-YYYY-MM-DD.md` covering **all 15+ dimensions**:
- Age, region, sex, city-by-city distributions (vs population targets)
- Education, occupation, income, family_income, marriage, politics, family_size, media_diet
- Price-tier and HH-income-tier distributions
- Hobby ranking (top 10)
- Marriage×Age cross-table
- Name diversity statistics
- 22-city coverage check

For a custom input path:
```bash
python3 ../.hermes/skills/research/tw-persona-db/scripts/gen_verification_report.py path/to/personas.json
```

The script is at `scripts/gen_verification_report.py` under the skill directory.

Key thresholds for a healthy generation:
▼ 0.5% per bracket
- Region error ≤ 0.5% per region
- Sex error ≤ 1.0%
- QA exit code = 0 (all 23 rules pass)
- 22/22 cities covered

### H. Transfer Readiness Verification (New Instance / Clone)

When verifying that a fresh Hermes instance (e.g., qcow2 clone, TRANSFER delivery) has all persona-db capabilities, run this systematic 9-step checklist:

**⚠️ Pre-flight**: Before running the checks below, complete the Fresh VM pre-flight checklist in `references/fresh-vm-preflight.md` — SSH access, disk space (5GB for full, 1GB for API-only), docker group, sudo, `.env`, and Tailscale must all be ready first.

| # | Check | Command | Pass Criteria |
|:-:|:------|:--------|:--------------|
| 1 | **Directory structure** | `ls ~/persona-db/ && ls ~/persona-db/scripts/ && ls ~/persona-db/references/` | Root files present, scripts ≥9, references ≥30, templates ≥1 |
| 2 | **Skill loaded** | `skill_view(name='tw-persona-db')` | SKILL.md loads without errors, all linked files present |
| 3 | **Key tool files** | `for f in _generate_997.py qa_validate.py query_persona.py sample_stratified.py build_appliance.py export_qualified_memory.py occ_prob_real.py marriage_prob_real.py; do [ -f ~/persona-db/$f ] && echo OK || echo MISSING; done` | All 8 files present |
| 4 | **Data integrity** | `python3 -c "import json; d=json.load(open('tw_persona_1069.json')); print(len(d))"` | 1069 personas, 22/22 cities, no missing fields |
| 5 | **QA passes** | `cd ~/persona-db && python3 qa_validate.py` | Exit 0, "✅ ALL CHECKS PASSED" |
| 6 | **Query tool works** | `cd ~/persona-db && python3 query_persona.py --residence 台北市 --age 35-44 --occ 科技 --top 1` | Returns ≥1 result, no crashes |
| 7 | **Sampling + review** | `cd ~/persona-db && python3 sample_stratified.py && python3 scripts/persona_review.py tw_persona_112_stratified.json` | 96/96 combos sampled, 5 review categories run without crash |
| 8 | **Export/build dry-run** | `cd ~/persona-db && python3 export_qualified_memory.py --dry-run && python3 build_appliance.py --dry-run` | Both complete — "DRY RUN" shown, no errors |
| 9 | **Git state** | `cd ~/persona-db && git remote -v && git log --oneline -1` | Has both `gitea` and `origin` remotes, or needs init |
| 10 | **Distribution verification** | `cd ~/persona-db && python3 scripts/gen_verification_report.py tw_persona_1069.json` | Generates report with age error ≤0.5%, region error ≤0.5%, 22/22 cities |

**Pitfalls specific to fresh instances:**
- `~/persona-db/` may need to be assembled from `~/.hermes/persona-tools/` flat dump (see First-Time Setup section)
- Git is NOT initialized on a file-copy transfer — needs `git init + remote add + pull`
- `persona_review.py` expects stratified sample file; generate it first with `sample_stratified.py`
- Some scripts reference `../.hermes/skills/research/tw-persona-db/scripts/` — verify the path exists or use the local `scripts/` copy
- **Container instances**: Files live at `/opt/data/persona-tools/` inside Docker, but skill references `~/persona-db/`. Container runs as `root`, not `ubuntu`. Fix: `docker exec hermes ln -sf /opt/data/persona-tools /root/persona-db`. This is NOT persistent across container restarts. `upTwoContainers.sh`（已於 2026-09-17 移除）原本負責此 symlink；現由部署流程手動處理。 Full documentation in `lab-riscv/scripts/persona-db-path-issue.md`.\n- **Deploy method change (2026-07-22)**: Git mirror approach deprecated. Use `pack-persona-db-release.sh` + `deploy-persona-db-api.sh` with pre-packaged tarball. No git/Gitea/PAT needed.

**Reporting format**: Use a table with check items, status (✅/❌), and notes. Group into: Structure ≥ Tools ≥ Data ≥ Git.

Expected output for a healthy instance:
- 10/10 checks pass (or 9/10 with Git init being the only gap)
- All tools executable, QA at current version level
- Distribution report within 0.5% error on all major dimensions

## Business Operations — Client Delivery via Qualified Memory
- 1069 total personas
- ~180-200 coherence fixes (varies slightly per run; includes 3 post-hoc tone fixes: bg_pp_econ_tone ~100, unmarried_child_cost ~33, story_hantai_contra ~15, edu_professional_bump ~21)
- ~15-17% name uniqueness (168+ unique names)
- Documentation: commit `GENERATION-VERIFICATION-YYYY-MM-DD.md` alongside the JSON if publishing to public repo.

### C. Stratified Sampling Review (Dual-Pass)

```bash
cd ~/persona-db
python3 sample_stratified.py
# → tw_persona_96_stratified.json (96 entries: 6 regions × 8 ages × 2 sexes)
```

**Pass 1 — Automated checks:**
```bash
python3 scripts/persona_review.py
# Checks 5 categories: A(分布異常), B(內容), C(語言), D(物價/所得), E(Region)  
# Validates all 22 county/city price & income tiers
# Validates all 96 region↔residence mappings
```

**Pass 2 — Deep semantic review:**
```bash
python3 scripts/persona_review_deep.py
# Checks: background coherence, economic contradictions, prefix quality
```

**Pass 3 — Sub-agent naturalness review:**
Spawn DeepSeek Pro sub-agent for naturalness & reasonableness review:
```
delegate_task(context=<file path + domain knowledge>,
              goal="Analyze 96 samples for naturalness & reasonableness")
```

**Pitfalls discovered in practice:**
- **Population weighting limits city-level coverage**: Cities with small populations (新竹市 ~1.9%, 離島 ~1.1%) get very few personas (17-19 each). Very specific combos (city + age + occupation + family_size) may return 0 results even with occupation boost. Query tool shows this clearly.
- **OCC_CITY_BOOST helps but cannot create personas from zero sampling slots**: A city with 17 people and a 30% tech boost still may not have a 45-54 tech worker with 4-person family. Increase sample size or relax query criteria.
- background_story often still uses region macros (「住在都會區」) even when prefix uses specific residence. The generator's template_source for background_story needs updating — it's a different code path from prefix generation.
- Economic context sentence in prefix may contradict background_story's economic tone if background_story was generated from old template pools. Always check both sides.
- 「國中/高中」 prefix label vs `education` dimension mismatch: `age_desc()` infers school level from age range, not actual `education` field. Fix by checking `education` field when generating age description.
-「沒有生小孩」+ 後文提到「小孩開銷」is a template pool composition error: the 3 background groups are independently drawn and can contradict each other.
- **「現在一個人過日子」template contamination (chunk 4)**: The widowed-person ending routine unconditionally appends "現在一個人過日子" even when earlier template pools filled in 「兒孫滿堂」「三代同堂」. This creates direct contradictions in 65+ personas. Fix: skip this phrase when `family_size > 1` or when the background already describes cohabitation.
- **65+ 子女/孫輩 language**: 65+ personas should use 「子女」「兒女」for adult children and 「孫子/孫女」for grandchildren, never 「小孩」which implies young children. The 65+ template pools still use youth-oriented family language.

### F. Query Personas

```bash
# Exact match by dimension
python3 query_persona.py --residence 新竹市 --occ 科技 --age 35-44

# List available dimension values
python3 query_persona.py --list-dimensions

# Fuzzy match (prefix with ~)
python3 query_persona.py --occ ~工程

# Top N results
python3 query_persona.py --residence 台北市 --income ">8萬" --top 3
```

Note: Due to population weighting (~1.9% = 19 personas per city), very specific combinations (e.g., 新竹市 + 45-54 + 科技 + 4口) may return 0 results. The tool only filters — it does not relax criteria. For missing combos, try broader filters or check `--list-dimensions` for valid values.

```bash
python3 _generate_997.py 2>&1 | tail -30
```

Or use Python directly for custom queries.

### D. Contradiction Analysis (10-Check)

Run the generic checker against any persona chunk:

```bash
cd ~/persona-db
python3 ../.hermes/skills/research/tw-persona-db/scripts/persona_contradiction_check.py tw_persona_chunk_4.json
```

For structured REAL/OK/MINOR classification output (with semantic judgment and trend summary), use the enhanced version:

```bash
python3 ../.hermes/skills/research/tw-persona-db/scripts/verify_chunk3.py tw_persona_chunk_N.json
```

The script runs 10 mechanical checks and outputs all flagged items:

1. **收入 vs 描述** — low-income (<3萬) with comfortable lang, or high-income (>8萬) with tight lang
2. **獨居+小孩** — family_size=1 mentioning children without spouse context
3. **已婚+fs=1無配偶** — married + alone + no spouse mention in narrative
4. **未成年有收入** — age 0-18 with income > 無收入
5. **65+年輕子女** — 65+ describing young children's expenses
6. **含飴弄孫+低收入+高物價** — 含飴弄孫 + <3萬 + high price tier combo
7. **未成年非學生** — age 0-18 with non-student occupation
8. **BG前後句矛盾** — internal contradictions in background_story
9. **學生+已婚** — student with non-未婚 marriage
10. **12-18教育=大學** — age 12-18 with university education

After mechanical flags, apply **semantic judgment** to classify each as:
- **REAL** — genuine contradiction (e.g., bg says "寬裕" but pp says "要省")
- **OK** — explainable (e.g., "有些積蓄" with low income — savings ≠ income)
- **MINOR** — editorial issues (e.g., "老伴走了" repeated in same sentence)

Known patterns from chunk 4 analysis (see `references/chunk4-contradiction-patterns.md`):
- Template contamination: "現在一個人過日子" appended to 兒孫滿堂 personas
- 65+ 子女/孫輩 language confusion: "小孩開銷" used when "子女開銷" is correct
- Income vs narrative mismatch: bg and pp use different template pools

### E. Price & Income Tier Verification

After regeneration, verify that both `price_tier` and `hh_income_tier` affect persona outputs as expected:

```bash
cd ~/persona-db
python3 scripts/verify_economic_tone.py
```

For single-chunk analysis, pass the chunk path directly:

```bash
python3 scripts/verify_economic_tone.py tw_persona_chunk_6.json
```

This script checks 4 patterns: bg comfortable→pre tight, bg tight→pre comfortable, married family_size=1 but bg says cohabitation, and personal vs family income mismatch for single-person households.

**Refined chunk 4 analysis (2026-07-13)** — programmatic analysis of chunk 4 (179 personas, 55-64+65+) using the decision hierarchy: REAL=16, OK=45, MINOR=15. Pattern: 12 bg-comfortable→pp-tight, 3 high-income→bg-tight, 1 unmitigated low-income. Confirms the bidirectional econ_by_tier() root cause.

**Cross-chunk trend**: Chunk 6 analysis (see references/chunk6-contradiction-patterns.md) confirms the same economic tone patterns found in chunk 3 but at higher frequency (23 vs 13 instances of bg-comfortable→pre-tight). The primary root cause remains the econ_by_tier() variable scoping trap — it defaults to inc_level=3-8萬 when inc is not passed, so low-income personas get comfortable background phrases.

**Refined chunk 4 analysis (2026-07-13)** — programmatic analysis of chunk 4 (179 personas, 55-64+65+) using the decision hierarchy: REAL=16 (12 bg-comfortable→pp-tight, 3 high-income→bg-tight, 1 low-income unmitigated), OK=45 (43 married+fs=1 spouse context, 2 widowed child mention), MINOR=15 (65+ 小孩→子女). Confirms the bidirectional econ_by_tier() root cause.

**Refined chunk 6 analysis (2026-07-13)** — after removing false positives from sub-string traps and context-explained cases, the true REAL count is 14 (not 28 as initially flagged). All 14 are bg-comfortable→pre-tight mismatches. ~8% of generated personas (14/174) exhibit this contradiction. The false-positive rate of the mechanical check is ~50% (14 REAL out of 28 initial flags), primarily from check 2 and check 8 substring traps. Always apply semantic judgment after mechanical flagging.

Expected: Taipei should have more tight phrases and higher income distribution than Nantou.

<!-- Duplicate removed -->

## Business Operations — Client Delivery via Qualified Memory

This skill supports a **memory continuity** business model: the user (本尊) iterates the persona DB, and clients (甲方) receive periodic releases containing curated (qualified) knowledge + data + tools.

### Core Concept: Qualified Memory

The user's `~/.hermes/memories/MEMORY.md` can contain entries tagged with `#qualified`. These are curated knowledge nuggets deemed safe and useful for clients:

```
🟢 已知限制：查新竹市+科技業+45-54可能回0，因人口權重低（新竹市~1.9%）。 #qualified
🟢 最佳 query：--residence 台中市 --age 30-44 --politics 泛綠 #qualified
```

Only entries with `#qualified` (or `#export`) are packaged into releases. Everything else stays local to the 本尊.

### Export Workflow

```bash
cd ~/persona-db

# List what's tagged #qualified
python3 export_qualified_memory.py --list-qualified

# Build a release (auto-bumps minor version)
python3 export_qualified_memory.py

# Build with explicit version
python3 export_qualified_memory.py --version v3.4

# Also generate the client-side import script
python3 export_qualified_memory.py --gen-import-script

# Dry run (no files written)
python3 export_qualified_memory.py --dry-run
```

The script lives at `persona/export_qualified_memory.py` and is also mirrored under this skill's `scripts/` directory for portability.

### Appliance Build (分身 — Standalone Deployable)

For clients who don't want a full Hermes instance, build a **standalone persona appliance** — a self-contained ZIP with data + tools + skill, no Hermes dependency:

```bash
cd ~/persona-db

# Build Standard appliance (read-only query, NO generate engine)
python3 build_appliance.py

# Build Pro appliance (includes _generate_997.py + qa_validate.py + full scripts)
python3 build_appliance.py --pro

# Build with explicit version
python3 build_appliance.py --version v3.2

# Build with optional Flask API server
python3 build_appliance.py --with-api

# Dry run
python3 build_appliance.py --dry-run
python3 build_appliance.py --pro --dry-run
```

Output (Standard): `releases/persona-appliance-v3.2.zip` (~167 KB)
Output (Pro): `releases/persona-appliance-pro-v3.2.zip` (~191 KB)

##### Standard vs Pro Feature Comparison (Superseded by Lite/Transfer pricing — see `persona-db-billing` skill)

| Feature | **Lite (NT$25K)** | **Transfer (NT$60-80K)** |
|:--------|:-----------------:|:------------------------:|
| tw_persona_1069.json + query CLI | ✅ | ✅ |
| RFC + qualified-memory + FAQ | ✅ | ✅ |
| _generate_997.py (generation engine) | ✅ (no QA warranty) | ✅ |
| qa_validate.py (20 rules) | ❌ | ✅ |
| Full scripts + full SKILL.md | ❌ | ✅ |
| Can sell improved 1069.json | ✅ (self-warranted) | ✅ |
| **Price (one-time)** | **NT$25K** | **NT$60K-80K** |

Old Standard/Pro nomenclature replaced by Lite/Transfer. The ZIP files `persona-appliance-v3.2.zip` (Standard) and `persona-appliance-pro-v3.2.zip` (Pro) still exist at old price points; for new clients use Lite (`appliance-lite`) and Transfer (`appliance-pro`) naming.

Pro adds: `tools/_generate_997.py`, `tools/qa_validate.py`, `tools/occ_prob_real.py`, `tools/marriage_prob_real.py`, full scripts dir, un-simplified SKILL.md.

Both exclude: `export_qualified_memory.py`, `build_appliance.py`, `appliance-checklist.md`, `BUSINESS-MODEL.md`, internal analysis files, old data versions.

##### 7 Warnings for Pro Clients (Communicate at Handover)

1. **Regenerate != Quality Guarantee**: First run returns ~v1.5 quality. Each bug fix lives in QA rules + iteration experience, not code logic. Always run full QA pipeline after regenerate.

2. **QA 20 Rules Only Block Known Pits**: Client may discover bug #21. Report it for the next official release — don't DIY the QA rule.

3. **Don't Modify Core Generator Logic**: Probability tables, OCC_CITY_BOOST, template pools, coherence logic are interconnected. Changing one cascades. New dimensions/probabilities -> revert to class-hourly (NT$3,000/hr).

4. **Every Regenerate is Different**: Keep seed=42 for reproducibility. Changing seed or TARGET produces different names/stories (same distribution).

5. **Custom Modifications Conflict with Official Releases**: Keep `tw_persona_1069_custom.json` as backup. Official release overwrites the standard file. Reapply customizations manually or pay for diff+merge.

6. **Generate Script is Non-Transferable IP**: Licensed for internal product development only. No resale, sublicensing, or standalone distribution. Same terms as the data.

7. **Pro Buys the Tool, Not the Service**: Includes 2 handovers + 1st year minor bug fixes. Excludes: new dimensions, architecture changes, new-country versions, domain stacking. Those revert to hourly.

Internal reference: `persona/appliance-pro-deliverable.md` (full comparison + suggested contract).

#### Appliance vs Release: Which to Use

| Deliverable | Script | Contents | Client needs | Pricing model |
|:------------|:-------|:---------|:-------------|:--------------|
| **Release** | `export_qualified_memory.py` | qualified-memory + skill + data + tools | Has Hermes Agent instance | Monthly subscription (NT$15K-25K/mo) |
| **Appliance** | `build_appliance.py` | README + FAQ + data + tools + skill (no Hermes) | Just Python 3 | One-time sale (NT$60K-80K) + hourly updates |

**Appliance delivery checklist** is documented in `persona/appliance-checklist.md` (internal — not shipped to client).

**Appliance pricing model:**
- One-time sale (NT$60K-80K) — client self-hosts, self-maintains
- Major version upgrades (v3.x → v4.0): revert to 類心理師 hourly (NT$3,000/hr)
- Bug fix support: 3 months included in sale price
- This avoids the "vendor relationship" trap with the ex-boss dynamic — one clean transaction, then occasional upgrade projects

#### Appliance Directory Structure

```
persona-appliance-v3.2.zip
├── VERSION
├── README.md                 ← Quick-start guide for client
├── FAQ.md                    ← Pre-empting likely questions
├── data/
│   ├── tw_persona_1069.json
│   ├── population_by_region_age_sex_2025.csv
│   ├── tw-persona-db-rfc.md
│   └── qualified-memory.md   ← 24 curated entries (from conversation history)
├── tools/
│   ├── query_persona.py
│   ├── sample_stratified.py
│   ├── auto-import-qualified.sh
│   └── (api_server.py — optional Flask wrapper)
├── skills/tw-persona-db/     ← Simplified SKILL.md (internal sections stripped)
│   ├── SKILL.md
│   ├── references/            ← Selected (10 refs — dimension, language, pricing)
│   └── scripts/               ← Selected (review scripts only)
└── samples/query-examples.sh
```

#### What Appliance Excludes (本尊保留)

| File | Reason |
|:-----|:-------|
| `_generate_997.py` | Core iteration engine — your IP |
| `qa_validate.py` | QA is your responsibility, not client's tool |
| `export_qualified_memory.py` | Your release pipeline — client doesn't produce releases |
| `BUSINESS-MODEL.md`, `MILESTONE-*.md` | Internal documents |
| Chunk analysis refs (`chunk3/4/6-*.md`) | Internal bug archives |
| Sub-agent review methodology | Your methodology IP |
| Old data files (`tw_persona_997.json`, prototypes) | Client only needs current version |

**Appliance path-fixing pitfall (critical -- verifiable)**: Both `_generate_997.py` and `query_persona.py` historically hardcoded absolute paths (`/home/ubuntu/lab-riscv/...`) that crash in the client's standalone environment. After building any appliance, ALWAYS verify: (1) `_generate_997.py` uses `PERSONA_OUTPUT` env var (fallback cwd) for output; (2) `query_persona.py` uses `PERSONA_DB` env -> `../data/` -> cwd chain for data file; (3) `import requests` is wrapped in try/except with population-estimate fallback for offline environments. Also note: CLI flag is `--occ` (not `--occupation`) — handover should demo this. Run this pre-delivery check: `unzip -> python3 tools/query_persona.py --residence Taipei --age 35-44 --occ tech --top 1 -> python3 tools/_generate_997.py -> python3 tools/qa_validate.py -> all must pass`.

#### Qualified Memory Extraction from Long Conversations

When a long multi-session conversation thread (e.g., 405+ replies) contains accumulated domain knowledge, extract `qualified-memory.md` as a structured reference:

1. **Search** session history for the target thread
2. **Scroll** through anchors to capture key decisions, bugs fixed, workarounds, best practices
3. **Categorize** entries: architecture, known limits, iteration flow, Pro review tips, query best practices, commercial decisions, bug history
4. **Tag** with `#qualified` suffix so the export script picks them up
5. **Write** to `persona/qualified-memory.md` — this file auto-bundles into both Release and Appliance artifacts

Example extraction (from 2026-07-13): 24 entries from a 748-message #persona-db-dev thread, covering architecture through commercial model. See `persona/qualified-memory.md`.

### L. REST API Deployment (LLM-powered FastAPI)

When the client requires programmatic access, deploy a FastAPI server that uses **LLM (DeepSeek Flash) to analyze questions** and determine which personas to match, with optional simulation (遭遇模擬②). See `references/api-llm-patterns.md` for design patterns and pitfalls.

### Release Artifact Structure

```
releases/release-v3.2.zip
├── VERSION                     ← v3.2
├── manifest.json               ← metadata + SHA256
├── CHANGELOG.md                ← auto-generated from #qualified entries
├── qualified-memory.md         ← merge-able memory entries
├── skills/tw-persona-db/       ← skill + scripts + references
├── data/                       ← tw_persona_1069.json + RFC + population CSV
└── tools/                      ← query_persona.py + sample_stratified.py
```

### Client Import Workflow

The client unzips and runs:

```bash
bash auto-import-qualified.sh release-v3.2.zip
```

This copies skill files to `~/.hermes/skills/`, data to `~/persona-db/`, and prompts manual review of `qualified-memory.md` before merging into `~/.hermes/memories/MEMORY.md`.

### Memory Isolation Principle

- **本尊 memory**: Contains ALL entries — iteration history, debug notes, cron results, client conversations. Some tagged `#qualified`.
- **Client memory**: Only contains `#qualified` entries from releases + their own local query history.
- **Never push**: debug logs, experimental attempts, cron/mediawatch output, other clients' conversations.

### Pricing Model (Final — Three-Tier Simplified 2026-07-13)

| Model | What Client Gets | Price | Best For |
|:------|:-----------------|:-----:|:---------|
| **Lite** | `tw_persona_1069.json` + `query_persona.py` + `_generate_997.py` + RFC + qualified-memory + README/FAQ. No QA tools. | **NT$25K** one-time | Budget-friendly data+gen; no quality warranty |
| **Transfer** | Full appliance: data + ALL tools (`_generate_997.py` + `qa_validate.py` + full scripts + prob tables + skills + docs). Client self-hosts, self-maintains, self-iterates. | **NT$60K-80K** one-time | Full ownership; one clean transaction |
| **Session-Log Upgrade** | Major version bumps (v3.x->v4.0), new dimensions, domain stacking, diff+merge. Billed from actual session log. | **NT$2,000/hr** (~NT$6K per 3hr upgrade) | Post-sale upgrades; transparent billing |

**Key changes from v3.7**: Rate reduced NT$3,000/hr to NT$2,000/hr. Lite tier added at NT$25K (includes _generate_997.py but no QA warranty). Simplified from 4 plans (A/B/C/D) + Standard/Pro to 2 products (Lite/Transfer) + 1 hourly rate.

**Key client rights** (must be in contract):\n- ✅ Client CAN self-iterate and improve the 1069.json data (Lite & Transfer)\n- ✅ Client CAN sell their improved 1069.json to their own customers (Lite & Transfer)\n- ✅ Lite: includes `_generate_997.py` but NO QA tools — quality is self-warranted\n- ❌ Client CANNOT resell or sublicense the tools themselves (_generate_997.py, qa_validate.py, etc.)\n- Client's own iterations do NOT grant access to your main branch — that's a separate hourly engagement

**Why simplified (Standard NT$60-80K vs Pro NT$120-150K -> one Transfer):**\n- Two tiers with one-dimension difference (generate engine) caused decision paralysis\n- Added Lite at NT$25K for a clean low-entry option (with gen engine, no QA)\n- Client (ex-boss) gets a clear choice: NT$25K data+gen or NT$60-80K full toolset+QA

**Worklog billing pattern**: Each upgrade produces `WORKLOG-YYYY-MM-DD.md` with timestamped segments, git commits, files produced, and hours x rate. The file IS the invoice. Example: 7/11-7/13 session produced `WORKLOG-2026-07-11-13.md` (10.1h x NT$2,000 = NT$20,200).

**Key relationship**: "老哥李麥克" (KITT's partner), not a vendor. "Here's your tool. When you need the main branch update -- new project, new price."

**Documents**: `persona/LITE-MODEL.md`, `persona/TRANSFER-MODEL.md`, `persona/UPGRADE-PRICING.md`. Mirrored as `references/lite-model.md`, etc. Old `BUSINESS-MODEL.md` superseded.

### Adding #qualified Entries

When iterating the persona DB, tag any finding that would benefit a client:

| What to tag | Example | When |
|:------------|:--------|:-----|
| Known limitations | 「查特定城市+組合可能回0」 | On discovery |
| Best practice queries | 「選區分布用 --politics 泛綠」 | When pattern emerges |
| Version milestones | 「v3.3: 20條QA全pass」 | After QA passes |
| Dimension definitions | 「price_tier 分級依據DGBAS」 | On data change |
| Chinese tone rules | 「含飴弄孫不配低收」 | On bug fix |

Do NOT tag: debug details, experimental attempts, cron/mediawatch data, other client conversations.

<!-- Section L consolidated below — single instance. -->

## Cross-Session Context & Progress Tracking

This skill operates across many Slack threads and channels. Progress tracking must be **dynamic**, not static:

### Principle: Dynamic Query > Static Table

Do NOT maintain a markdown table of "active goals" — it goes stale the moment the user opens a new thread. Instead, when asked "what am I working on":

1. `session_search(limit=5)` — query the 5 most recent active sessions
2. `memory scan` — read any goals/state recorded in persistent memory
3. Cross-reference → determine what's complete vs pending
4. Synthesize dynamically — do NOT read from a pre-written file

### Two Session Interaction Modes

| Mode | Trigger | Effect |
|:-----|:--------|:-------|
| **Read-only (default)** | `看 session <id>` or `session_search()` | Load history into current conversation context. No session switch. |
| **Resume** | `hermes sessions resume <id>` | Close current session, open old one with full context. Used for sustained deep-dives on a topic. |

### When User Mentions Cross-Channel @mentions

When the user says "我在另個 channel @你" or references activity in a different channel, use `session_search` with keywords from their message to discover the referenced session. Do NOT rely on the current session's context — the referenced content lives in a different session.

### User's Progress-Awareness Needs

The user frequently jumps between topics across different Slack threads/channels and forgets what they were working on. When they start a new thread or DM, proactively scan recent sessions and offer a summary of what was in progress, along with the option to resume or reference previous work.

### References

- `references/hermes-session-context-management.md` — Session vs context distinction, three operation modes
- `references/session-management-workflow.md` — Dynamic query pattern, keyword triggers, sync strategy

## Deployed Configuration

- **Parent session model**: deepseek-v4-flash
- **Delegation model**: deepseek-v4-pro (set via `delegation.provider: custom:deepseek-pro` and `delegation.model: deepseek-v4-pro` in config.yaml)
- Sub-agents automatically use Pro. Parent session keeps Flash.

## QA Rules (23 Total)

| Rule | Check | Source | Added |
|:----|:------|:-------|:-----:|
| R1-R9 | Basic coherence (minors, marriage, education, distribution) | qa_validate.py | v1.0 |
| R10-R15 | Template residue (65+, 做退休, 【】, location, 獨生子, 新婚) | qa_validate.py | v2.0 |
| R16-R18 | Age gates (55+新婚, 兒孫滿堂 age, minor 泡茶) | qa_validate.py | v2.0 |
| R19 | Family size contradiction (family>1 + 「一個人過日子」) | qa_validate.py | v3.3 |
| R20 | 45+未婚說「跟爸媽住」 (45+ unmarried living with parents) | qa_validate.py | v3.5 |
| R21 | BG/PP economic tone consistency — bg舒適↔pp拮据 (excludes 房間不夠用/工作壓力 FP) | qa_validate.py | v3.7 |
| R22 | 未婚 child cost phrases (only 未婚, not 離婚/鰥寡) | qa_validate.py | v3.7 |
| R23 | fs=1 cohabitation phrases — 夫妻/一家X口 for single-person | qa_validate.py | v3.7 |

## Privacy Model

- All names are fictional (stylized, not real-person names)
- All locations are synthetic compound names, not real administrative areas
- Minors use fictional school names
- Each persona JSON includes `"type": "虛構人設"` disclaimer

## User's Quality Standards for Generated Text

### Language Naturalness (中文)
- No census-form language. No "65+歳" code residue.
- No region macro-labels in prompt_prefix where possible — "住在都會區" is unnatural. Use residence (city/county) instead.
- Household descriptions must sound like a real person speaking.
- No ambiguous sibling/grandparent references — always pick specific form.
- No 「做退休」/「做學生」 — use 已經退休了/還在讀書.
- No 【】bracket format in prompt_prefix.
- Female personas: 獨生女 (not 獨生子). Male divorce: 搬回老家 (not 搬回娘家).
- No trailing location redundancy in prompt_prefix.
- 45+: not 「新婚不久」. 25-34: not 鰥寡.
- 0-11 hobbies: no 泡茶/下棋/廣場舞.

### Presentation Preference (comparison tables)

When reporting persona quality improvements or analysis results, always use a **before/after comparison table** or side-by-side format. The user finds these far more informative than prose descriptions alone. Examples:

- 「台北市(高物價): 50% 緊縮短語 vs 南投縣(極低物價): 10% 緊縮短語」
- 「Before: 有伯是阿伯，65+歲，做退休。獨生子，爸媽的寶。手頭還算寬鬆。→ After: 有伯是阿伯，住新北市。小孩都在外地。貸款和帳單壓得喘不過氣。」

This applies to code changes, quality metrics, and economic tone comparisons.

<!-- This section is consolidated below under Chinese Semantic Tone Mismatches. -->
 
### Consistency Enforcement (added v3.0)

**0. 「一個人過日子」 vs family_size/cohabitation (found in chunk 4)**:
- The phrase 「現在一個人過日子」 must only appear when `family_size = 1` and the background_story does NOT already describe cohabitation (兒孫滿堂, 三代同堂, 兒女成群).
- Current bug: appended unconditionally to widowed/divorced personas even when `family_size > 1`.
- Fix: `if family_size_str != '1' or any(cohabitation_kw in story for kw in [...]): skip`.

**1. background_story ↔ prompt_prefix economic tone alignment**
- If prefix says 「省著點」/「生活壓力很大」/「收入不太夠用」, background_story must NOT say 「經濟上滿寬裕的」/「手頭還算寬鬆，不用太省」/「生活品質還不錯，該花的會花」/「有些積蓄，偶爾會出國玩」. These are template-pool mismatches from different code paths.
- If background_story says 「經濟壓力非常大」/「常常入不敷出」, prefix must NOT end with 「收入算很高了，日子過得滿舒服的」/「收入還不錯，不用太省」.
- **Root cause**: background_story and prompt_prefix are generated by different functions using different template pools (background pools lean optimistic, prefix's `gen_econ_context()` leans pessimistic). They must be cross-validated at merge time.

**2. Background_story location**: must use specific `residence` (city/county), NOT region macro (「住在都會區」等). All 3 background groups need updating.

**3. Prefix school-level label** (e.g., 「國中男生」/「高中男生」): must match actual `education` dimension, not just age range.

**4. Background_story 3 groups must be internally coherent**: drawing 「沒有生小孩的打算」in one group and 「小孩的開銷很大」in another creates contradiction. Cross-group coherence enforcement needed.

**5. Income ≤ <3萬 + family_size ≥ 3**: background_story should NOT describe the household as 「經濟上滿寬裕的」/「手頭還算寬鬆，不用太省」. Use 「能省則省」「手頭比較緊」instead. Exception: single-person households with very low fixed costs may still say 「品質還不錯」but this is borderline.

**6. Dimension-level consistency (income vs family_income for single/divorced/widowed living alone)**:
- When `marriage` ∈ {離婚, 鰥寡, 未婚} AND `family_size` = 1, `personal_income` MUST roughly equal `family_income` — they are the same person's money.
- If they differ by more than one income bracket (e.g., >8萬 vs 3-7萬, or <3萬 vs 7萬), it's a dimension-level data contradiction, not just a narrative tone mismatch.
- Common failure: personal_income=`>8萬` + family_income=`<1萬` for a divorced single (largest gap seen); or personal=`3-8萬` + family=`1-3萬` for a widowed single.

**7. Occupation ↔ background_story coherence**:
- `occupation="家管"`: background_story must NOT mention 「職位不上不下」/「工作量穩定」/「職場老鳥」/「交棒給年輕人」— homemakers do not have workplace positions.
- `occupation="退休"`: background_story must NOT mention 「職位不上不下，有點尷尬但穩定」. Use 「退休後每天都去公園」/「開始學以前沒時間做的事」instead.

**8. Family income vs family size mismatch (批量模板化問題)**:
- family_income=`3-7萬` + family_size=`5+` (夫妻+3子女): background_story saying 「經濟上滿寬裕的」/「生活品質還不錯」is unrealistic. The 3-7萬 range for 5+ people in any city is tight to moderate at best.
- family_income=`1-3萬` + family_size=`4`: background_story saying 「經濟壓力非常大」is consistent, but same data saying 「生活品質還不錯，該花的會花」is a contradiction.
- This is the most common bulk pattern in chunk 3 (~12 instances) and indicates a template-pool vs dimension cross-validation gap.

**9. 「有些積蓄，偶爾會出國玩」template abuse**:\n- This phrase is used indiscriminately across all income levels. When income is `<3萬` or `3-8萬` with large family, this phrase creates a direct contradiction with prefix's economic context sentence.\n- Only use this template when personal_income is `>8萬` AND family_income ≥ `7萬` AND family_size ≤ `3`.\n\n**10. `econ_by_tier()` branch condition遺漏 (v3.8.1 修復)**:\n- 生成背景故事時，`econ_by_tier()` 依據 `family_size` × `family_income` 選擇經濟短語池。\n- 小家庭(1-2人) + 中高收入(5-7萬+) 應走 COMFORTABLE pool。\n- 原 line 743 條件 `fam in (\"1\",\"2\") and fam_inc in (\"7萬\",\">8萬\")` 遺漏了 `5-7萬`。\n- 導致小家庭 + 5-7萬 + >8萬個人收入的組合（如丹尼爾 TW-P-0233）落入 else 分支的 ECON_TIGHT_BIGFAM 池，抽到「經濟壓力非常大」的矛盾。\n- **修復**：加入 `5-7萬` 到 line 743 條件。\n- **教訓**：每次新增 family_income tier（如 3-7萬→3-5萬+5-7萬），必須同步更新所有引用該 tier 的 branch conditions。

### Realism Enforcement
- Minors (0-18) cannot live alone (family_size=1).
- Minors cannot have economic concerns.
- 19-24 students cannot be divorced. Coherence corrects to 未婚.
- 19-24/25-34 鰥寡 → corrected to 離婚 or 未婚.
- 35+ tech/finance/medical with 國中以下/高中 → bump to 大學.
- 0-11 media diet: no 社群為主. Use 家長主導 or 兒童內容為主.
regenerate, QA, commit

### I. Select Personas for Business Context & Simulated Surveys

A reusable workflow for **domain-specific persona selection** and **simulated survey role-playing**. Designed for market research, store location analysis, product concept testing, and ad targeting.

#### Phase 1: Define Business Criteria

Map the business domain to persona dimensions. Example for a drugstore chain (康是美/Cosmed) store-location survey:

| Business Need | Persona Dimension | Filter |
|:--------------|:------------------|:-------|
| Core drugstore shopper | `sex = 女` (women = 70%+ of drugstore customers) |
| Purchasing power | `age` in 25-54 (exclude minors, seniors on fixed income less relevant) |
| Geographic insight | `residence` diversity — pick 3+ cities at different growth stages |
| Life-stage variety | `marriage` × `family_size` × `occupation` diversification |
| Price sensitivity | `income` × `price_tier` mismatch reveals value-conscious segments |

Other business mappings:
- **Baby products**: filter `family_size ≥ 3` + `age` 25-44 + `hobby` not dink-pattern
- **3C electronics**: filter `age` 19-44 + `occupation` in (科技,製造) + `income > 3萬`
- **Insurance**: filter `marriage = 已婚` + `family_size ≥ 3` + `income ≥ 3萬`
- **Pet products**: filter `background_story` containing pet keywords

#### Phase 2: Scoring & Selection Algorithm

Use a **relevance scoring function** to rank and diversify:

```python
def score_persona(pp, weights):
    """
    pp: persona dict with 'dimensions' key
    weights: dict of {dimension: weight}
    Returns (score, pp)
    """
    d = pp['dimensions']
    score = 0
    # Core demographic: women 25-54 (drugstore example)
    if d['sex'] == '女' and d['age'] in ['25-34', '35-44', '45-54']:
        score += 3
    # Working people with purchasing power
    if d['occupation'] in ['服務', '醫療', '科技', '金融', '公務', '教育', '自營', '製造']:
        score += 1
    # Domain-specific interest signals
    if any(kw in ' '.join(d.get('hobby', [])) for kw in ['保養', '美妝', '健身', '健康']):
        score += 2
    return score
```

**Diversity constraint**: After scoring top-N candidates, greedily select ensuring:
- No duplicate `residence`
- No duplicate `age` bracket
- Mix of `marriage` and `family_size`
- Each selected persona fills a different decision-making role

**Check for zero-results**: Due to population weighting (~1.9% = ~20 persona per small city), very specific combos (e.g., 新竹市 + 45-54 + 科技 + 4口) may return 0. Always verify counts before selecting; for sparse combos, relax one dimension at a time.

#### Phase 3: Design Survey Questionnaire

Write a **domain-specific questionnaire** tailored to the business decision. Example — store location survey (8 questions):

```
Q1: 你目前最常去哪一類商店購買日常藥品、保健品或美妝保養品？為什麼選這家？
Q2: 你住所或工作地點附近有康是美嗎？步行或騎車大概多久？對目前的便利性滿意嗎？
Q3: 你覺得你居住的區域，還需要再多一家康是美嗎？如果需要，開在哪種地點最適合？（捷運站旁、學區、商圈、住宅區巷口）為什麼？
Q4: 如果家附近開了一家新的康是美，什麼因素會讓你願意走進去消費？（排序：價格、商品齊全、離家近、店員專業、會員活動、品牌信任）
Q5: 你平均一個月花多少錢在藥妝/保健品/個人清潔用品上？價格和方便性哪個更重要？
Q6: 你認為康是美和屈臣氏最大的差別是什麼？你比較偏好哪一家？為什麼？
Q7: 最近一年有沒有因為「附近沒有想要的店」而放棄購買或轉買其他品牌的經驗？
Q8: 自由補充 — 對於康是美未來開店或服務，有什麼建議或期待？
```

General survey templates for other domains: see `references/survey-templates.md`.

#### Phase 4: Two Simulation Modes

There are **two fundamentally different modes** of persona simulation, each testing different things:

##### Mode ①: Self-Simulation (Persona Answers)

The sub-agent **IS the persona**, answering a question or survey as if they were the real person. This tests the persona's voice and perspective.

```python
# Build context with full persona data + questionnaire
tasks = []
for pp in selected_personas:
    d = pp['dimensions']
    context = f'''【Persona Profile】\nID: {pp['id']}\nName: {pp['name']}\nAge: {d['age']} ...\nPersona voice:\n{pp['prompt_prefix']}'''
    tasks.append({
        'goal': '角色扮演以下 persona，完整回答問卷。以第一人稱「我」的口吻，每題回答 2-4 句話，像真人受訪者一樣自然。',
        'context': context,
        'role': 'leaf'
    })
delegate_task(tasks=tasks)
```

**Key rules:**
- Pass the **full persona prompt_prefix** so the sub-agent adopts the correct voice, economic context, and life stage.
- Instruct sub-agent to respond in **first-person** (「我」) with **natural spoken Chinese**.
- Do NOT ask sub-agents to role-play minors or sensitive backgrounds without explicit user direction.
- Results self-report — for critical findings, verify against the original persona data.

##### Mode ②: Encounter Simulation (LLM Responds to Persona)

The sub-agent **encounters a persona asking a question** and responds to them as an expert/friend. The sub-agent is told the persona's background and is asked to tailor their response accordingly. This tests **LLM response quality** to persona-qualified questions — how well does the LLM adapt its advice to the persona's specific situation?

```python
tasks = []
for pp in selected_personas:
    d = pp['dimensions']
    context = f'''【Persona Background】\n{pp['name']}，{d['age']}歲，住{d['residence']}，{d['occupation']}，收入{d['income']}。\n背景：{d['background_story']}\n性格：根據 persona 背景自然推斷。\n\n你用第一人稱「我」直接回答。不要提到任何關於模擬、角色扮演的字眼。'''
    tasks.append({
        'goal': f'你遇到一位名叫{pp["name"]}的女士來問你：「[問題內容]"請以專業友善的態度回答她。回答要針對她的背景來給建議。',
        'context': context,
        'role': 'leaf'
    })
delegate_task(tasks=tasks)
```

**Key rules for mode ②:**
- The sub-agent's role is **"I am an expert/friend who [Persona] came to ask"** — NOT role-playing the persona
- Context must state the persona's background and instruct the sub-agent to tailor the answer
- Do NOT include meta-language like 「角色扮演」or「模擬」 — the sub-agent should answer naturally
- The sub-agent should adjust **level of detail, recommendation criteria, and tone** based on persona context
- Recommended for evaluating whether an LLM's advice to a given persona is appropriate and targeted

##### Mode Comparison: When to Use Which

| Criterion | ① Self-Simulation | ② Encounter-Simulation |
|:----------|:-----------------:|:----------------------:|
| **What it tests** | Persona authenticity — would this persona answer this way? | Response quality — is the LLM answering appropriately for this persona? |
| **Sub-agent role** | IS the persona | ENCOUNTERS the persona asking |
| **Output** | Persona's own answer (survey response) | Advice/response tailored to persona |
| **Use case** | Simulating survey results, market research | Testing customer service, content targeting, ad personalization |
| **Can detect** | Persona consistency, voice quality | Whether LLM adapts to diverse user profiles |

##### Combined 2×2 Experiment Design

For a full methodology comparison, run both modes across the same personas and questions:

| | Q1 (same question) | Q2 (different context) |
|:---:|:-------------------:|:----------------------:|
| **① Self** | ①Q1 — Persona answers Q | ①Q2 — Persona answers Q |
| **② Encounter** | ②Q1 — Expert responds to persona asking Q | ②Q2 — Expert responds to persona asking Q |

This produces 4 results per persona (12 total for 3 personas). The comparison reveals:
- **① vs ① across questions**: Does the persona's voice stay consistent in different contexts?
- **② vs ② across questions**: Does the expert adapt recommendations to question domain?
- **① vs ② per question**: Is the advice actually what the persona would want?

**Batching**: Max 3 parallel sub-agents per call. For 3 personas × 2 modes × N questions = 6+ sub-agents, dispatch in batches of 3 sequentially.

**Empirical results from 2026-07-14 test** (3 personas, 2 questions, 12 total simulations):

| Dimension | ① Self-Simulation | ② Encounter-Simulation |
|:----------|:-----------------:|:----------------------:|
| **Response style** | Like consumer filling survey (focuses on personal needs) | Like expert giving advice (analyzes background, recommends, may challenge preferences) |
| **Localization** | Generic location references | Specific, contextualized (e.g., ②靜怡: 「新竹捷運先不用想😅」 — new urban unfiltered reaction) |
| **Critical thinking** | Tends positive, may not challenge premise | More willing to disagree (②靜怡: 「沒一家兩個都最高」) |
| **Expertise depth** | Answers from lived experience | Combines expertise with personalization — explains *why* a choice fits *this* persona |
| **Hallucination risk** | Lower — answers from persona's limited knowledge | Higher — expert may invent specific rates/terms; need verification |
| **Best for** | Market research, persona voice QA | Customer experience, content targeting tests |

See `references/spawn-agent-methodology.md` for the detailed empirical comparison.

#### Phase 5: Consolidate Results

Each sub-agent returns their full Q&A as a self-contained block. Consolidate by:

1. **Per-question cross-persona comparison table**: For each Q, show all 3-5 answers side-by-side
2. **Key insight extraction**: What patterns repeat across personas? Where do they diverge?
3. **Actionable recommendation**: Tie findings back to the original business decision (store location, campaign targeting, etc.)

#### Contamination Risk: Same-Agent vs Spawn-Agent

**Critical finding from empirical testing (2026-07-13):** Using a single agent to simulate multiple personas in the same conversation creates **contamination bias** — the agent's answers unconsciously converge in structure, brand preference, and tone.

| Dimension | Same Agent | Spawn Agent (delegate_task) |
|:----------|:----------:|:---------------------------:|
| **Brand recommendation** | All personas converge on same brand (e.g., all recommended 將來銀行) | Each independently picks different brands (台銀, 將來, 聯邦NNB) |
| **Localized details** | Generic, template-like phrasing | Specific life-context details (靜怡: 「小孩教育費最大開銷」; 淑貞: 「轉錢給老公」) |
| **Critical thinking** | Tends toward positive recommendations | Willing to say 「沒有一家兩個都最高的啦」 — more authentic |
| **Cost (3 personas)** | ~3 seconds, 1x tokens | ~1-2 min parallel, 3-4x tokens |
| **Role purity** | ⚠️ Contaminated by other personas seen in same context | ✅ Fully independent, no cross-persona awareness |

**When to use each approach:**

| Use Case | Approach | Reason |
|:---------|:---------|:-------|
| Quick exploration / ideation | **Same Agent** | Cheap, instant, good enough for direction |
| Formal survey simulation | **Spawn Agent** | Contamination-free, more authentic responses |
| 10+ persona simulation | **Spawn Agent (batched)** | Same agent context would explode |
| A/B testing methodology | **Spawn Agent** | Need clean A/B separation |
| Client-facing report | **Spawn Agent** | Higher role-play quality justifies cost |

**Pitfalls:**
- Spawn agent results are self-reports — always verify quantitative claims against source data
- Sub-agent model inheritance: children inherit parent's model. Pin via `delegation.provider` + `delegation.model` in config.yaml for consistent quality
- For this user's setup: `delegation.model: deepseek-v4-pro`, `delegation.provider: custom:deepseek-pro`

See `references/spawn-agent-methodology.md` for detailed empirical comparison.

#### User Preference: Presentation Style

When reporting persona analysis or survey results, the user (kstsai) prefers:
- **Tables with clear column headers** over prose descriptions
- **Traditional Chinese** output
- **Side-by-side persona comparison** — show each persona's answer to the same question in parallel rows
- No fluff or filler — direct to the business insight

### K. Bank Visibility Analysis (Mode ② Encounter Simulation Application)

A specialized application of Mode ② encounter simulation — **measuring which brands get mentioned, how prominently, and with what sentiment when the LLM encounters different personas asking about financial products**.

#### Use Case

A bank or fintech company wants to know: "When consumers like Persona A, B, C ask about digital accounts, which banks does the LLM recommend? Does it recommend us? How favorably?" This is **LLM brand visibility / share of voice** analysis.

#### Persona Selection Strategy (6 Dimensions for Banking)

For bank visibility tests, select personas across these 6 dimensions to reveal how LLM recommendation varies by customer profile:

| Dimension | Levels | Why |
|:----------|:-------|:----|
| **Age** | 19-24 / 25-34 / 35-44 / 45-54 / 55-64 / 65+ | Banking needs differ by life stage |
| **Gender** | 男 / 女 | Some products skew by gender |
| **Income** | 無收入 / <3萬 / 3-8萬 / >8萬 | Drives fee vs rate sensitivity |
| **Occupation** | 科技/金融/服務/製造/自營/家管/學生/退休 | Domain expertise changes recommendation depth |
| **Geography** | 北/中/南/東/離島 | Local bank density and branch access affect advice |
| **Marriage/Family** | 未婚/已婚/離婚/鰥寡 × family_size | Family obligations drive spending priorities |

**Target: 11 personas** (as empirical sweet spot — enough for 6-dimension coverage without batch overflow). Each batch of 3 runs in parallel (3×3+2 = 4 batches total, or 3+3+3+2).

See `references/bank-visibility-methodology.md` for a worked 11-persona example.

#### Brand Visibility Scoring System

For each persona's response, score every mentioned bank on 3 axes:

| Axis | Scale | Scoring |
|:-----|:-----:|:--------|
| **Coverage** (was it mentioned?) | 0-1 per persona | Sum across all personas = coverage score (e.g., 3/3 = mentioned in every response) |
| **Position** (where was it?) | 1-5 | 🥇=1st pick, 🥈=2nd pick, 🥉=3rd pick, 📌=listed only, ❌=not mentioned |
| **Sentiment** (how was it framed?) | -2 to +2 | +2=主角級強推, +1=中性推薦, 0=純列舉, -1=有保留建議, -2=不建議/負面 |
| **Persona Fit** (was recommendation tailored?) | 0/1 | Did the response explicitly connect bank features to this persona's life situation? |

**Reporting format** — coverage matrix sorted by total score:

```
| Bank | Coverage | Avg Position | Avg Sentiment | Persona Fit | Total |
|:-----|:--------:|:------------:|:-------------:|:-----------:|:-----:|
| 台銀  | 3/3 ✅    | 🥇 1.0       | +2.0          | 3/3         | 8.0   |
| 將來  | 3/3 ✅    | 🥈 2.0       | +1.3          | 3/3         | 6.3   |
| 聯邦  | 2/3      | 🥉 3.0       | 0.0           | 1/3         | 3.0   |
```

#### Key Findings Pattern (from empirical test, 2026-07-14)

When analyzing results, look for these patterns:

1. **Dominant brand across all personas** — which bank has the best narrative for LLM? In the test, 台銀 won 3/3 because 「免任務、99次」 is a strong story applicable to any busy/savvy persona.
2. **Persona-specific divergences** — which bank only appears for certain profiles? 華南SnY (2.3%) only appeared for 靜怡 (新竹科技女), because the expert framed it as a 「利率冠軍」 for someone who can handle simple tasks.
3. **Zero-visibility banks** — which banks never got mentioned despite being major players? In the test, LINE Bank, Richart, KOKO scored 0/3 — likely because they lack a unique, differentiated story.
4. **Sentiment asymmetry** — which banks are more often mentioned negatively? 聯邦NNB appeared in 2/3 but with reservation language (「任務麻煩」「條件囉嗦」).

#### What Makes a Bank Visible vs Invisible to LLMs

| High Visibility | Low Visibility |
|:----------------|:---------------|
| Simple, memorable feature (99次, 免任務) | Complex conditions (解任務、需匯入資金) |
| Strong persona narrative hook (省心、穩當) | Generic features (line bank, KOKO, Richart) |
| Easy to explain in 1 line | Needs multi-step comparison to sell |
| Solves a relatable pain point | Solves an abstract financial problem |

#### Common Pitfalls

- **Do not interpret coverage as market share** — LLM visibility ≠ real market preference. The LLM may favor certain banks because their features are easier to explain, not because they're actually better.
- **Sentiment scores are LLM-opinion, not customer-opinion** — a bank scoring negatively in LLM responses means the LLM found flaws in their product narrative, not that real customers dislike the bank.
- **Sub-agent model matters** — the test used deepseek-v4-pro. Different models (GPT-4o, Claude) may produce different visibility rankings. Document the model used.
- **The question priming matters** — asking about 「利率最高＋轉帳次數最多」 primes rate-and-fee comparison, which favors simple-structured products. A different question would produce different rankings.
- **Zero visibility does not mean zero awareness** — it means the bank's positioning lacks a narrative hook the LLM can naturally surface in a compare-and-recommend scenario.

---

### J. Update MARRIAGE_PROB from MOI Open Data

When `marriage_prob_real.py` needs updating (new year data, or the estimated `MARRIAGE_PROB` in `_generate_997.py` needs replacement with real data):

1. **Download data** (if not already cached):
   - ODRP014 API: `curl -s "https://www.ris.gov.tw/rs-opendata/api/v1/datastore/ODRP014/11405?page={1..4}"` (4 pages, 7748 records)
   - Divorce ODS: from MOI 婚姻狀況 page → `ps01-24`
   - Divorce rate CSV: from `data.gov.tw/dataset/173964`

2. **Run computation**:
   ```bash
   cd /home/ubuntu && python3 compute_marriage.py
   ```
   This script reads `/tmp/odrp014_all.json`, `/tmp/divorce_by_age.ods`, and `/tmp/divorce_rate.csv`, then outputs to `persona/marriage_prob_real.py`.

3. **Verify output**:
   - Total population should be ~23.4M
   - Sum of all four probabilities per age group should equal 1.0
   - 0-11 and 12-18 should be 100% unmarried
   - Gender-specific tables should show higher widowhood for women (65+: F=30% vs M=5%)

4. **Pitfalls**:
   - **ODS XML parsing**: `odfpy` fails to read county names from merged cells. Parse `content.xml` directly from the ODS zip. The table name attribute is `table:name="113年"` (NOT `table:table-name="113年"`).
   - **16383 repeated columns**: LibreOffice generates thousands of empty columns. Split by `<table:table-row` and search for county names via string match (`if '新北市' in part`).
   - **Age 19 split**: The `<20` group includes ages 0-19. Use population ratio `age19_pop / total_under20_pop` to isolate age 19 data when mapping to 19-24 output group.
   - **Widowed estimation**: No direct source for widowed population. The age/gender ratio table in `references/marriage-data-sources.md` provides the best estimates.

5. **Update `_generate_997.py`**: After computing, replace the estimated `MARRIAGE_PROB` dict imports with:
   ```python
   from marriage_prob_real import MARRIAGE_PROB, MARRIAGE_PROB_MALE, MARRIAGE_PROB_FEMALE
   ```

### Post-hoc Coherence Fixes (generation loop)

After `infer_background()` generates the story and `gen_econ_context()` generates the economic sentence, multiple **post-hoc checks** in `_generate_997.py` fix common contradictions:

| Fix | Condition | Replacement | Counter |
|:----|:-----------|:-------------|:--------|
|| **含飴弄孫 contradictions** | `inc=<3萬` + `price_tier` in (高,中高,中) | 「退休生活，簡單過日子」 | `story_hantai_contra` |
| **沒有生小孩+含飴弄孫** | 「沒有生小孩」+ 「含飴弄孫」 or 「小孩」 | Neutral replacements per phrase | `story_nochild_contra` |
| **BG/PP 語氣不一致** 🆕 | bg含舒適短語(寬裕/不用太省/品質不錯) + econ_ctx含拮据信號(要省/壓力大/不夠用) | bg舒適短語→tight pool | `bg_pp_econ_tone` (~100) |
| **未婚+小孩開銷** 🆕 | `marriage=未婚` + bg含小孩開銷模板 | 小孩開銷→中性(開銷不小/生活開銷) | `unmarried_child_cost` (~33) |
| **1人家庭+小孩敘述** | `fam=1` + 「小孩」 in story, no spouse mention | 「一個人生活，開銷不大」 variants | (inline) |
| **fs=1 vs 家庭描述** 🆕 | `fam=1` + 夫妻/一家X口(無分居/在外地說明) | 「一個人過日子/生活簡單自在」 | `fs1_family_narrative` (~0, HH_SINGLE_MARRIED已正確) |
| **48+未婚說跟爸媽住** | `age in (45-54,55-64,65+)` + `marriage=未婚` + HH_FAM4/5_UNMARRIED parent phrases | HH_FAM4/5_UNMARRIED_SENIOR pools | R20 |

**Pattern**: Always fix at the phrase pool level first (age-gated pools for HH_FAM3/4/5_UNMARRIED, LIFE_SENIOR_WIDOWED_FAMILY), then add a post-hoc safety net. Don't rely on post-hoc alone.

`infer_background()` receives `inc` (personal income level) as a parameter. The helper `econ_by_tier()` was defined inside `infer_background()` with a default parameter `inc_level="3-8萬"` but the callers never passed `inc` explicitly. This meant low-income (<3萬) personas got comfortable economic phrases ("手頭還算寬鬆") because the income bias was never applied. Fix: always pass the actual `inc` to `econ_by_tier()`.

### Sub-agent Finding Verification Pattern

When a sub-agent (Pro review) returns findings, **always verify them programmatically** before reporting or acting on them. The Pro model can produce false positives:

- **Geographic claims**: e.g., "宜蘭縣 belongs to 花東 not 北部" — actually wrong (宜蘭 is geographically in northern Taiwan).
- **Substring false positives**: e.g., flagged 49 cases of "沒有生小孩" + "小孩" as contradictions — but "沒有生小孩" CONTAINS the substring "小孩". Real contradictions require "小孩" appearing OUTSIDE the "沒有生小孩" phrase.
- **Single-char keyword false positives** (discovered chunk 3 validation): The keyword `"女"` in check 2 matched `"女性"` in prompt_prefix intro text — 3 false REALs. Always use regex word boundaries or multi-char patterns (e.g., `r'小孩(?!子)'` instead of `"小孩"`) to avoid matching parts of unrelated words.
- **Negated phrase trap**: "沒有生小孩的打算" literally contains "小孩" but is semantically a negation — it means "no children". A real contradiction requires "小孩" appearing in a SEPARATE positive sentence after the negated one. Check `bg.replace("沒有生小孩的打算", "")` for remaining "小孩" mentions.
- **"剛好夠" vs "寬裕/寬鬆"**: These are tone inconsistencies (MINOR), not logical contradictions (REAL). "剛好夠" (just enough) is not the same as "要省" (must save). Always classify tone mismatches separately from factual contradictions.
- **Economic tone "contradictions"** where family income differs from personal income — a person with <3萬 personal income can still report "有些積蓄" if living with a high-income family.
- **"孩子都成年了" false positive (check 2)**: When `family_size=1` and bg says 「老伴走了，孩子也都成年了」, this is explaining why the person lives alone, not a contradiction. Same pattern as 「孩子在外地」. Both should be classified OK, not REAL.
- **"沒有生小孩的打算" rendered as OK for check 5 (65+)**: When a 65+ persona's bg says 「結婚後沒有生小孩的打算」, the "小孩" is negated — no young-child narrative exists. This is NOT a 65+ contravention.

**Additional false-positive patterns (from chunk 5 analysis):**
- **"不夠用" matching "房間不夠用" (check 1 income check)**: The financial-tightness keyword "不夠用" also matches "房間不夠用" (not enough room space), which is a housing constraint not an economic one. Always exclude `"房間不夠用"` and `"空間不夠"` from financial-keyword matching.
- **"小孩" within "沒有生小孩的打算" (check 8 bg contradiction)**: When checking whether bg says "沒有小孩" and pf mentions "小孩", verify the "小孩" reference appears OUTSIDE the negation phrase. If pf also says "沒有生小孩的打算", the "小孩" is negated — not a contradiction.
- **"一個人住" ≠ "單身/未婚" (check 8 marital contradiction)**: "一個人住" (living alone) is a housing arrangement, not a marital status. The common pattern `"配偶在外地工作，自己一個人住"` is perfectly consistent for a married person. Use `re.search(r'單身|未婚', text)` NOT `r'單身|未婚|一個人'` when checking marital-status contradictions.
- **"孩子都成年了" false positive (check 2, fs=1+children)**: When `family_size=1` and bg says "老伴走了，孩子也都成年了", this explains WHY the person lives alone — not a contradiction. Same pattern as "孩子在外地". Both should be OK, not REAL.

**Verification pattern**: For each claim category, write a quick Python script that checks the actual data, then categorize as CONFIRMED (real bug), FALSE POSITIVE (by design or misunderstanding), or MINOR (borderline case).

#### Age-Aware Household Pools (key pattern)

When a phrase pool contains age-inappropriate language (e.g., 45+ unmarried saying 「跟爸爸媽媽住」, 65+ widow saying 「一個人過日子」 at family_size=3):

**Fix pattern**: Create a SENIOR/age-aware variant of the phrase pool and add an age gate in `infer_background()`:

```python
# Standard pool
HH_FAM4_UNMARRIED = ["跟爸爸媽媽和一個弟弟住", ...]
# Senior variant (added)
HH_FAM4_UNMARRIED_SENIOR = ["跟兄弟姊妹同住，互相照顧", "和家人一起住，互相照應"]

# In infer_background():
elif fam == "4" and marriage == "未婚":
    pool = HH_FAM4_UNMARRIED_SENIOR if age in ("45-54","55-64","65+") else HH_FAM4_UNMARRIED
```

Pools already split this way: HH_FAM3_UNMARRIED, HH_FAM4_UNMARRIED, HH_FAM5_UNMARRIED, HH_SINGLE_MARRIED, HH_DIVORCED_WITH_CHILD, HH_YOUNG_DIVORCED, HH_FAM5_WIDOWED, LIFE_SENIOR_WIDOWED.

Each needs a matching QA rule (R20 pattern) and ideally a post-hoc coherence check.

### Chinese Semantic Tone Mismatches (User-Reported)

Certain Chinese phrases carry strong implicit tones that create felt contradictions even when literal logic is consistent. Always check for these:

| Phrase | Implicit Tone | Conflicts With | Fix |
|--------|---------------|----------------|-----|
| 「含飴弄孫」 | 享福·正面·安穩 | 「生活壓力很大」「收入低」 | Replace with「簡單過日子」when econ_ctx is negative |
| 「手頭還算寬鬆」 | 經濟有餘裕 | 「收入低，要省着點」 | Handle via econ_by_tier income bias |
| 「獨生子，爸媽的寶」 | 未成年·受呵護 | 65+高齡 | Use HH_FAM3_ELDERLY_UNMARRIED pool for 55+ |
| 「退休生活，含飴弄孫」 | 享福 | 低收+高物價 ctx sentence | Coherence check: if inc=low + price_tier=high, replace with「簡單過日子」|

The key lesson: **Chinese tone matters more than literal logic**. Two statements can be literally non-contradictory but feel contradictory in Chinese because one phrase strongly implies a positive/negative state.

<!-- Duplicate removed -- consolidated under Chinese Semantic Tone Mismatches. -->

<!-- Duplicate removed -->