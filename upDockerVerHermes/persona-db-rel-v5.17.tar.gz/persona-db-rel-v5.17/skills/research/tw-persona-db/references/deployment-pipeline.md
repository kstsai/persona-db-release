# Persona DB — 部署管線與版本管理

## 兩個 Repo 架構

| Repo | 角色 | 上層目錄 |
|:-----|:------|:----------|
| `persona-db` | 資料來源 (source of truth) | `~/persona-db/` |
| `persona-db-release` | 甲方拿到的 deploy bundle | `~/persona-db-release/` |

## 版本生命週期 (v2026-07-28+)

```
persona-db/VERSION  (v3.2)  ← source of truth
       │
       ├── build_appliance.py → persona-appliance-v3.2.zip (分身交付)
       └── pack-persona-db-release.sh → persona-db-rel-v3.2.tar.gz
                │
                ├── tarball 內含 VERSION = v3.2 + RELEASE = v3.2
                └── 複製到 persona-db-release/upDockerVerHermes/
                     │
                     deploy-hermes-personadb-containers.sh (auto-detects latest tarball)
                     ※ 舊名 deploy-persona-db-compose.sh / deploy-persona-db-api.sh 已於 2026-09-17 移除
```

## 版本化 Tarball 機制

**`pack-persona-db-release.sh`** 會自動讀取 `VERSION` 檔案，產出 `persona-db-rel-<VERSION>.tar.gz`。

不再使用「固定名稱」—— `persona-db-rel-1.0.tar.gz` 已廢棄。每個 release 有獨立版本號。

產生方式：
```bash
cd ~/persona-db
bash pack-persona-db-release.sh
# → person-db-rel-v3.2.tar.gz (名稱隨 VERSION 自動產生)
```

## Deploy 腳本自動偵測

`deploy-hermes-personadb-containers.sh`（舊名 `deploy-persona-db-compose.sh`，2026-09-17 更名）不再 hardcode tarball 名稱。

行為：
- 掃描 `upDockerVerHermes/` 下所有 `persona-db-rel-*.tar.gz`
- 用 `sort -V` 選最高版本
- 顯示選擇的 tarball 名稱與版本標籤
- 從解壓後的 VERSION 讀取實際版本（不覆寫）

**VERSION 不再被 deploy 腳本覆寫**（過去 bug：`echo "v3.7" > VERSION` 蓋掉真實版的 v3.2）。

## 一鍵發佈

`do-release.sh` 在 `persona-db/` 目錄，一行完成全部：

```bash
cd ~/persona-db
bash do-release.sh        # 正常發佈
bash do-release.sh --dry-run  # 預覽
```

腳本自動：bump → pack → sync → commit → tag → push（兩個 repo）。

## 部署到 dh5 的完整流程

```bash
# 1. 在 a3 本尊更新 VERSION + 重新打包
cd ~/persona-db
# 如果需要 bump:
# echo "v3.3" > VERSION
bash pack-persona-db-release.sh

# 2. 複製到 persona-db-release repo
cp persona-db-rel-v*.tar.gz ~/persona-db-release/upDockerVerHermes/
cp RELEASE-VERSION ~/persona-db-release/upDockerVerHermes/
# 選擇性移除舊版：
# rm ~/persona-db-release/upDockerVerHermes/persona-db-rel-v3.2.tar.gz

# 3. Commit + push
cd ~/persona-db-release
git add -A
git commit -m "release: persona-db v3.3"
git push origin main

# 4. 在 dh5 上 pull + deploy
ssh lzcdh5
cd ~/persona-db-release
git pull origin main
bash upDockerVerHermes/deploy-hermes-personadb-containers.sh
```

## Tarball 內容

由 `pack-persona-db-release.sh` 產生，包含：
- Python source (`api/`, `*.py`)
- Persona 資料 (`tw_persona_1069.json`, CSV files)
- Skills (`skills/`) — 從 `~/.hermes/skills/` 複製
- `VERSION` file (根目錄)
- `RELEASE` file (版本標籤，供 container 讀取)

## 相關 Skill

`productivity/persona-db-release-workflow` 記錄完整的 release + deploy 流程。
