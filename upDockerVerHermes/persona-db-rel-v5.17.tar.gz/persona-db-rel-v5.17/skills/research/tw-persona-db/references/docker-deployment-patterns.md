# Persona DB API — Docker Deployment Patterns

> **Update 2026-07-22**: Git mirror deprecated. Pre-packaged tarball is now the standard method.

## Core Architecture

```
Release Bundle (persona-db-rel-1.0.tar.gz)
  ├── api/ (LLM-powered FastAPI server)
  ├── Dockerfile
  ├── requirements-api.txt
  ├── tw_persona_1069.json
  └── .env (template, no key required)
  │
  ├── docker build -t persona-db-api .
  └── docker run -v /home/ubuntu/.hermes:/hermes-config:ro ...
       │
       └── LLM provider auto-detected from Hermes config
```

## Preferred Method: Tarball Release (No Git/PAT Needed)

```bash
cd ~/persona-db
bash pack-persona-db-release.sh          # generates tarball
bash deploy-hermes-personadb-containers.sh   # deploys (tarball must be next to script)
```

## Deprecated Methods ⛔

- **GitHub with full PAT** (git clone → docker build)
- **Local Gitea mirror** (git clone from local → docker build)

Both superseded by tarball (2026-07-22).

## Constrained-VM Deployment (9.8G Disk, Slow Network)

When deploying on a small VM with limited disk (~9.8G) or slow Docker Hub access:

### Phase 1: Disk Recovery

Before deployment, check and recover space:

```bash
# Check disk
df -h /

# If >90% full — aggressive cleanup:
sudo docker image prune -af          # dangling layers (often 2–3GB)
sudo snap remove lxd                 # not needed on edge VMs
sudo apt-get clean && sudo apt-get autoremove -y
sudo journalctl --vacuum-time=1d
```

Expected recovery: 3–4GB on a 9.8G disk.

### Phase 2: Use Updated Deploy Script (Preferred)

The `deploy-hermes-personadb-containers.sh` script (v2026-07-25+；2026-09-17 前名 `deploy-persona-db-compose.sh`) has built-in pre-flight checks and supports `--skip-hermes`:

```bash
# API-only — skips 3.8GB hermes pull, needs only ~1GB
bash deploy-hermes-personadb-containers.sh --skip-hermes
```

The script automatically:
- Checks disk space before starting
- Detects docker group membership (uses sudo only when needed)
- Falls back gracefully if sudo needs a password (`export SUDO_PASSWORD=...`)
- Builds the API from local Dockerfile (no network needed once python:3.11-slim is cached)
- Auto-injects LLM_API_KEY from `~/.env` into both containers' `.env` files
- Fixes `.hermes/` directory ownership if Docker left it owned by uid 10000
- Copies `references/` from skill directory to shared data volume (for correct skill assessment)

### Phase 3: Standalone API Build (Manual Fallback — Pre-2026-07-24 Scripts)

If using an older version of the deploy script:

```bash
# Build from local Dockerfile (uses python:3.11-slim, small)
sudo docker build -t persona-db-api:latest /srv/persona-db-data/

# Run standalone
sudo docker run -d --name persona-db-api \
  -p 8000:8000 \
  -v /srv/persona-db-data:/app \
  -v /home/ubuntu/.hermes:/hermes-config:ro \
  persona-db-api:latest
```

**What works without Hermes**: `/health`, `/personadb/status`, `/personadb/candidates` (opMode=僅篩選), `/personadb/detail`.

**What needs Hermes** (add later): `opMode=篩選+模擬` if LLM falls back to Hermes config.

### Phase 3: Hermes Pull (Deferred)

On slow networks, defer the hermes image pull:

```bash
nohup timeout 600 docker pull nousresearch/hermes-agent:latest > /tmp/pull.log 2>&1 &
```

The image is ~950MB unique size (3.82GB virtual). Expect 5–10 minutes on constrained connections.

## LLM Config Priority Chain

`_load_llm_config()` in `llm.py` resolves providers with this priority:

```
1. Env vars (LLM_API_KEY, LLM_BASE_URL, LLM_MODEL)  ← highest
2. Hermes config.yaml (fills gaps from env)
3. auth.json  (Nous OAuth token, if no API key found)
4. Defaults   (https://api.deepseek.com + deepseek-v4-flash)

### Critical: LLM_BASE_URL override trap

When `LLM_API_KEY` is set in `.env` (e.g., a DeepSeek key) but `LLM_BASE_URL` is NOT, the priority chain falls through to the **Hermes config**, which may contain a different provider's base URL (e.g., `inference-api.nousresearch.com/v1`). This causes 404 errors because the DeepSeek model is sent to a Nous endpoint.

**Fix**: Always set ALL THREE env vars together:

```bash
echo "LLM_API_KEY=sk-..." >> .env
echo "LLM_MODEL=deepseek-v4-flash" >> .env
echo "LLM_BASE_URL=https://api.deepseek.com" >> .env
```

### auth.json OAuth fallback

If no API key is found in env or config, `_load_llm_config()` tries auth.json's `credential_pool.nous` access token. However, Hermes stores most API keys as encrypted sha256 fingerprints (not plaintext), so this fallback typically fails for DeepSeek keys. Only works if the provider stores a plaintext token.

### Dual-.env Key Mismatch (edge VM trap)

The API container reads **`/srv/persona-db-data/.env`** (mounted at `/app/.env` inside the container). But the host's **`~/.env`** may have a different API key and model. This is a common failure mode after redeployment: the deploy script creates a template `.env` in the shared data directory, but the host's actual key lives in `~/.env`.

**Symptoms**: `llm_analysis: null`, all persona queries return `total_matched:1069` (no LLM-powered filtering), fast response times (<1s), Docker logs show `LLM call failed: Client error '400 Bad Request'`.

**Fix**: After deployment, verify and sync the `.env`:
```bash
diff <(grep -E 'LLM_' /home/ubuntu/.env) <(grep -E 'LLM_' /srv/persona-db-data/.env)
cp /home/ubuntu/.env /srv/persona-db-data/.env   # or edit manually
docker rm -f persona-db-api && docker run -d ...  # restart with new .env
```

**Note**: `docker restart persona-db-api` does NOT reload `.env`. Must remove and recreate the container.

### DeepSeek Model Name: `deepseek-chat` → `deepseek-v4-flash`

The `.env` template in the tarball ships with `LLM_MODEL=deepseek-chat`, which DeepSeek deprecated (returns 400 Bad Request). The current working model is `deepseek-v4-flash`. Always override in the shared data `.env`:

```bash
echo "LLM_MODEL=deepseek-v4-flash" >> /srv/persona-db-data/.env
```

## Critical: `/root/persona-db` Inaccessible to Hermes User

**Hermes container runs as the `hermes` system user, NOT as `root`.** The `/root/` home directory has `drwx------` (700) permissions, so the `hermes` user cannot traverse it. Any mount target under `/root/` (e.g., `-v /srv/persona-db-data:/root/persona-db`) silently fails — the `hermes` user sees `Permission denied` and the skill assessment (`persona-db status`) reports missing scripts/references/tools.

**Fix — always mount shared data under `/opt/data/`** (owned by `hermes:hermes`):

```bash
docker run -d --name hermes ... \
  -v /srv/persona-db-data:/opt/data/persona-db \
  ...
```

Inside the container, the `hermes` user can read `/opt/data/persona-db/` directly.

**Also use `--user 0:0`** to prevent file ownership creep (uid 10000):

```bash
docker run -d --name hermes ... \
  --user 0:0 \
  -v /srv/persona-db-data:/opt/data/persona-db \
  ...
```

Without `--user 0:0`, repeated `docker rm + docker run` cycles leave files owned by uid 10000 (unmapped container UID), blocking the `ubuntu` user from reading `.env` and causing `apikey not found` inside Hermes.

**Post-start symlinks** — after container starts, create symlinks at both locations where `~` might resolve:

```bash
docker exec hermes ln -sf /opt/data/persona-db /root/persona-db
docker exec hermes sh -c "mkdir -p /opt/data/home && ln -sf /opt/data/persona-db /opt/data/home/persona-db"
```

**Verification**:
```bash
docker exec hermes sh -c "su - hermes -c 'ls /opt/data/persona-db/'"
# Should list files, not Permission denied
```

**Impact**: Using `/root/persona-db` causes:
- `hermes chat -q 'persona-db status'` → times out or reports Lite grade
- Skill assessment can't read scripts/, references/, build_appliance.py
- API workaround: deploy script now mounts to `/opt/data/persona-db` (v2026-07-25+)

## Container Volume: Hermes Config Mount

```bash
-v /home/ubuntu/.hermes:/hermes-config:ro
```

Mounted read-only. The container reads `/hermes-config/config.yaml` for auto-discovery.

## Key Commands

### Restart with new env vars

```bash
docker stop persona-db-api && docker rm persona-db-api
docker run -d --name persona-db-api -p 8000:8000 --env-file .env \
  -v /home/ubuntu/.hermes:/hermes-config:ro persona-db-api
```

Note: `docker restart` does NOT reload `.env`. Must recreate.

### Mount path (deprecated: `/root/persona-db` → `/opt/data/persona-db`)

The old deploy script mounted shared data at `/root/persona-db`, which is inaccessible to the `hermes` user (see "Critical" section above). The fix is to mount at `/opt/data/persona-db` instead.

**Old (broken)**: `-v /srv/persona-db-data:/root/persona-db`
**New (fixed)**:  `-v /srv/persona-db-data:/opt/data/persona-db`

For existing deployments that already used the old mount, migrate by recreating the container:

## Configuring Hermes Custom Provider (inside Container)

When the Hermes container (`nousresearch/hermes-agent`) needs to use a custom OpenAI-compatible provider (e.g., DeepSeek with API key from `.env`), use `hermes config set` inside the container:

```bash
# Inside the Hermes container:
docker exec hermes hermes config set custom_providers.deepseek-pro.base_url "https://api.deepseek.com"
docker exec hermes hermes config set custom_providers.deepseek-pro.api_key_env LLM_API_KEY
docker exec hermes hermes config set model.default deepseek-v4-flash
docker exec hermes hermes config set model.provider custom:deepseek-pro

# Also ensure LLM_API_KEY is in the container's .env:
docker exec hermes sh -c "echo LLM_API_KEY=sk-your-key > /opt/data/.env"
```

The resulting `config.yaml` looks like:
```yaml
custom_providers:
  - name: deepseek-pro
    base_url: https://api.deepseek.com
    api_key_env: LLM_API_KEY

model:
  default: deepseek-v4-flash
  provider: custom:deepseek-pro
```

**Important**: After changing provider config, restart the Hermes container for changes to take effect: `docker restart hermes`.

**Why not `hermes model`?** The interactive `hermes model` picker only lists built-in providers (DeepSeek, OpenRouter, Anthropic, etc.) — it has no option for custom endpoints. Custom providers must be set via `hermes config set` or direct config.yaml editing.

**Alternative: Nous Portal OAuth**: If the client has a Nous Research Portal subscription, they can authenticate via:
```bash
docker exec -it hermes hermes auth add nous
# Opens URL → browser → OAuth → done
docker exec -it hermes hermes model --no-browser
```

## Docker Group Setup (Edge VMs)

On a fresh Ubuntu VM, the `ubuntu` user is typically not in the `docker` group:

```bash
# Add user to docker group
sudo usermod -aG docker ubuntu

# ⚠️ Must start a new session for group change to take effect
#   `newgrp docker` works but only for the current shell.
#   A new SSH connection works reliably.
```

If the group is added mid-session, a new SSH connection automatically picks up the group. Without this, all `docker` and `docker compose` commands fail with:
```
permission denied while trying to connect to the Docker daemon socket
```

The updated deploy script detects this in its pre-flight check (Step 0).

## Sudo Password in Automation

For automated deployment scripts that need sudo but the target VM has passwordless sudo disabled:

```bash
# Set environment variable before running deploy
export SUDO_PASSWORD=your_password
bash deploy-hermes-personadb-containers.sh
```

The script uses the password via `echo \$SUDO_PASSWORD | sudo -S ...`. For scripts that cannot set env vars (e.g., remote SSH via `ssh user@host bash script.sh`), pre-create the required directories manually:

```bash
sudo mkdir -p /srv/persona-db-data /home/ubuntu/.hermes/{cron,sessions,memories,skills}
sudo chown -R ubuntu:ubuntu /srv/persona-db-data /home/ubuntu/.hermes
```

## Pitfalls

1. **`LLM_BASE_URL` must match key** — see "LLM_BASE_URL override trap" above.
2. **`docker restart` no env reload** — use `rm + run --env-file`.
3. **Nous OAuth can't be extracted** — persona-db-api needs explicit key in `.env`.
4. **`~/persona-db/` missing** — container runs as `root`, no `/home/`. Symlink above.
5. **Duplicate .env lines** — Docker takes LAST value for duplicate keys.
6. **Permission denied on `[ -d ]` checks** — Docker daemon (root) reads files fine, but the `hermes` SSH user can't `ls /home/ubuntu/.hermes`. Scripts using `[ -d ]` fail.
7. **Tarball ~1.8MB vs git repo ~19MB** — excludes test artifacts, worklogs, refs.
8. **`custom_providers` YAML format**: Must be a YAML **list** (prefixed with `- name:`) not a dict. Dict format silently fails with `custom_providers is a dict — it must be a YAML list` and the provider won't load.
9. **Hermes `--env-file`**: The Hermes container does NOT auto-read `.env`. Without `--env-file` on `docker run`, `api_key_env` resolves to empty. Add `--env-file "${HERMES_HOME}/.env"` to the `docker run` command.
10. **`references/` missing from shared volume**: The skill assessment (`persona-db status`) checks for `references/` in `/root/persona-db/` (mounted data). If absent, the report incorrectly says `Lite` grade (missing scripts, references, tools). Fix: `deploy-hermes-personadb-containers.sh` now auto-copies references from the skill directory to the shared data volume during Step 3.
11. **`.env` model name**: The tarball ships `deepseek-chat` which DeepSeek deprecated (400 Bad Request). Must override to `deepseek-v4-flash` in the shared data `.env`. The host's `~/.env` and the API's `/srv/persona-db-data/.env` often differ — always sync both.
12. **UID 10000 ownership creep**: Repeated `docker rm + docker run` cycles (e.g., restarting containers with new `--env-file`) can leave files in the mounted volume owned by uid 10000 (an unmapped UID from the container runtime). The `.hermes/` directory itself gets `drwx------ 10000 10000`, blocking the `ubuntu` user entirely and causing `apikey not found` inside the Hermes container.
    **Symptoms**: `stat /home/ubuntu/.hermes/` shows UID 10000, `cat /home/ubuntu/.hermes/.env` fails with `Permission denied`, `docker run --env-file /home/ubuntu/.hermes/.env` fails with `permission denied`, Hermes container logs show missing API key.
    **Fix**:
    ```bash
    # Fix directory ownership explicitly with numeric UID
    sudo chown -R 1000:1000 /home/ubuntu/.hermes/
    sudo chmod 755 /home/ubuntu/.hermes/
    # Then recreate the Hermes container
    docker rm -f hermes
    docker run -d --name hermes --network host --restart unless-stopped \
      --env-file /home/ubuntu/.hermes/.env \
      -v /home/ubuntu/.hermes:/opt/data \
      -v /srv/persona-db-data:/opt/data/persona-db \
      nousresearch/hermes-agent:latest \
      /bin/sh -c "sleep infinity"
    ```
    **Important**: `docker restart` does NOT re-read `--env-file`. The environment is captured at container creation time. After changing `.env` contents, you must remove and re-create the container.
    **Prevention** (in deploy script v2026-07-25+): The deploy script now checks `stat -c '%u' "${HERMES_HOME}"` against `id -u` and auto-fixes with `sudo chown` if they differ.
13. **`docker restart` vs `docker rm + run`**: `docker restart` preserves the original environment (env vars, `--env-file` content). After changing `.env` on the host, you MUST do `docker rm -f <name> && docker run ... --env-file ...` to pick up the new values. A common failure mode: fix `.env` on the host, run `docker restart`, and wonder why the container still sees the old key.
14. **Tarball ships stale `.env` — deploy must always overwrite**: The `persona-db-rel-1.0.tar.gz` contains a `.env` with `LLM_API_KEY=sk-b9b...d980` and `LLM_MODEL=deepseek-chat` (deprecated). If the deploy script checks `if [ ! -f ... ]` before writing, the tarball's stale `.env` persists silently. The script (v2026-07-25+) now **always overwrites** the API's `.env` from `~/.env` values, regardless of whether the file already exists. On custom deployments, verify this pattern: the `.env` write should be unconditional, not guarded by existence checks. with `LLM_API_KEY=sk-b9b...d980` and `LLM_MODEL=deepseek-chat` (deprecated). If the deploy script checks `if [ ! -f ... ]` before writing, the tarball's stale `.env` persists silently. The script (v2026-07-25+) now **always overwrites** the API's `.env` from `~/.env` values, regardless of whether the file already exists. On custom deployments, verify this pattern: the `.env` write should be unconditional, not guarded by existence checks.
15. **`docker-compose.yml` env_file not needed**: The deploy script uses `docker run -d` directly (not docker-compose). Adding `env_file:` to the compose file causes intermittent errors when the referenced `.env` doesn't exist yet or has wrong ownership. Keep the compose file simple (no env_file refs) — the deploy script handles env injection via `--env-file` on `docker run`. If running compose manually, set env vars in the shell before `docker-compose up` instead.
16. **API container also needs `--env-file`**: The API's `docker run` command (in deploy script) must include `--env-file "${PERSONA_DB_DATA}/.env"` for `LLM_API_KEY`, `LLM_MODEL`, and `LLM_BASE_URL` to reach the Python process. Without it, `os.getenv()` returns empty and the API returns `llm_analysis: null` with keyword-only fallback.
17. **AI `~` resolution mismatch**: The Hermes agent's terminal tool resolves `~` as `/opt/data/home/` (a directory that doesn't exist by default), NOT the `hermes` user's actual home (`/opt/data/`). Even after fixing the mount to `/opt/data/persona-db`, the AI running `ls ~/persona-db/` looks in the wrong place. Fix: create symlinks at BOTH `/root/persona-db` (for root shell) AND `/opt/data/home/persona-db` (for terminal tool's `~` resolution). The deploy script (v2026-07-25+) does this automatically.
18. **LLM API call takes 10+ seconds**: This is normal. The `/personadb/candidates` endpoint calls DeepSeek LLM for semantic analysis of the query text before filtering. Round-trip to api.deepseek.com takes 6-12 seconds. This is not a bug — it's the expected latency of the remote LLM call. If the test completes in <1 second with `total_matched: 1069` and `llm_analysis: null`, that means the LLM call failed and the API fell back to keyword-only mode (check `.env` and `--env-file`).