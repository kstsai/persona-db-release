"""
Persona DB REST API — FastAPI Server (LLM-powered)

Endpoints:
  GET /personadb/candidates — LLM analyzes questions → filter personas (+ simulate)
  GET /personadb/detail     — Get full persona profile by ID
  GET /health               — Health check

Run:  uvicorn api.server:app --reload
"""

import os, sys, json, logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import PlainTextResponse

from .models import (
    OpMode, CandidatesResponse, PersonaSummary,
    PersonaSimulation, DimensionSummary, LLMAnalysis,
    DetailResponse, PersonaDetail, HealthResponse, ErrorResponse
)
from .persona_matcher import (
    filter_personas, get_important_dimensions,
    format_matched_criteria, load_persona_db, get_persona_by_id,
    llm_filters_to_dimension_filters
)
from .llm import parse_questions_with_llm, simulate_with_llm, call_llm, LLM_CONFIG

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Persona DB API",
    description="台灣人口加權合成人設資料庫 — LLM-powered 查詢與模擬 API",
    version="3.2.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── Startup ────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    try:
        load_persona_db()
        db = load_persona_db()
        logger.info(f"Persona DB loaded: {len(db)} personas")
        app.state.db_loaded = True
        app.state.persona_count = len(db)
    except Exception as e:
        logger.error(f"Failed to load Persona DB: {e}")
        app.state.db_loaded = False
        app.state.persona_count = 0


# ── Health ─────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(
        status="ok",
        version="3.2",
        persona_count=getattr(app.state, "persona_count", 0),
        db_loaded=getattr(app.state, "db_loaded", False),
    )


# ── Candidates (LLM-powered filter + optional simulate) ────────────

@app.get(
    "/personadb/candidates",
    response_model=CandidatesResponse,
    responses={
        400: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
        503: {"model": ErrorResponse},
    }
)
async def personadb_candidates(
    questions: str = Query(..., description="問題列表，用 | 分隔多題"),
    top_k: int = Query(default=12, ge=1, le=20, description="最多回傳筆數"),
    opMode: str = Query(default="僅篩選", description="操作模式: 僅篩選 / 篩選+模擬"),
):
    # Validate
    if opMode not in ("僅篩選", "篩選+模擬"):
        raise HTTPException(400, detail={
            "code": "INVALID_PARAMETER",
            "message": f"不支援的 opMode: {opMode}",
            "details": "有效值: 僅篩選, 篩選+模擬"
        })
    
    if not getattr(app.state, "db_loaded", False):
        raise HTTPException(503, detail={
            "code": "DB_NOT_LOADED",
            "message": "Persona DB 尚未載入",
            "details": ""
        })
    
    # Parse questions (split by |)
    q_list = [q.strip() for q in questions.split("|") if q.strip()]
    if not q_list:
        raise HTTPException(400, detail={
            "code": "MISSING_PARAMETER",
            "message": "請提供至少一個問題",
            "details": "多個問題請用 | 分隔"
        })
    
    try:
        db = load_persona_db()
        
        # Step 1: LLM analyzes questions → dimension filters
        logger.info(f"LLM analyzing {len(q_list)} questions...")
        llm_result = await parse_questions_with_llm(q_list)
        
        llm_analysis = None
        if llm_result:
            llm_analysis = LLMAnalysis(
                domain=llm_result.get("domain", ""),
                reasoning=llm_result.get("reasoning", ""),
                question_analysis=llm_result.get("question_analysis", []),
                usage_suggestion=llm_result.get("usage_suggestion"),
            )
        
        # Step 2: Convert LLM output to filters
        filters = llm_filters_to_dimension_filters(llm_result) if llm_result else {}
        
        # Fallback: if LLM returned no filters, use keyword-based parsing from questions text
        if not filters:
            from .persona_matcher import parse_enduser
            combined_text = " ".join(q_list)
            filters = parse_enduser(combined_text)
            logger.warning("LLM returned no filters, falling back to keyword parsing")
        
        # If still no filters, refuse to match everything (would return all 1069)
        if not filters:
            raise HTTPException(503, detail={
                "code": "FILTER_FAILED",
                "message": "無法從問題中解析出篩選條件（LLM 分析失敗且關鍵字解析無結果）",
                "details": "請確認 LLM API key / model 設定，或換一種問法"
            })
        
        # Step 3: Filter personas
        matched = filter_personas(db, filters)
        
        # Scoring basis metadata (issue #4 — auditability); built once, used
        # in both 0-match and success responses
        scoring_basis = None
        dim_weights = {}
        try:
            from .persona_matcher import load_dim_weights
            dim_weights = load_dim_weights()
        except Exception:
            dim_weights = {}
        if dim_weights:
            scoring_basis = {
                "method": "log-frequency × cross-dim normalized [0.5, 2.0]",
                "weight_source": "DGBAS 113年 家庭收支調查 / 人力資源調查 / 交通部 2024",
                "dims_counted": [d for d in filters.keys() if d in dim_weights],
                "relaxed_dims_scored_at": None,  # Q3-A': relaxed dims not scored
            }
        
        # Step 3b: Filter relaxation — if strict filters yield 0, progressively
        # drop the least-important dimensions until we get a non-empty result.
        # (LLM sometimes returns over-specific combos like 自營+35-44 that
        # intersect to nothing in the DB.)
        relaxed_dims = []
        if not matched and filters:
            dim_order = ["sex", "marriage", "education", "income", "age", "residence", "family_income", "occupation", "commute_mode", "housing_burden", "clothing_spend"]
            # Drop dims one at a time, least-important first
            for dim in dim_order:
                if dim not in filters:
                    continue
                relaxed = {k: v for k, v in filters.items() if k != dim}
                matched = filter_personas(db, relaxed)
                if matched:
                    relaxed_dims.append(dim)
                    filters = relaxed
                    logger.warning(f"Filters too strict (0 matches) — relaxed by dropping '{dim}': {len(matched)} matches")
                    break
            # If still empty after dropping one, drop more (up to keeping 1 dim)
            while not matched and len(filters) > 1:
                # drop the dim with fewest distinct values (most restrictive)
                drop = min(filters.keys(), key=lambda k: len(filters[k]))
                filters = {k: v for k, v in filters.items() if k != drop}
                relaxed_dims.append(drop)
                matched = filter_personas(db, filters)
                logger.warning(f"Still 0 matches — dropped '{drop}', now {len(matched)} matches")
        
        if not matched:
            return CandidatesResponse(
                status="ok",
                total_matched=0,
                persona_ids=[],
                personas=[],
                important_dimensions=[],
                llm_analysis=llm_analysis,
                relaxed_dims=relaxed_dims,
                applied_filters=filters,
                scoring_basis=scoring_basis,
            )
        
        # Step 4: Relevance scoring + take top_k
        from .persona_matcher import sort_by_score, score_persona
        matched = sort_by_score(matched, filters, relaxed_dims)
        top = matched[:top_k]
        
        # Build summary table (replaces full persona details)
        persona_ids = []
        summary = []
        
        for p in top:
            pid_str = p.get("id", "")
            try:
                pid_num = int(pid_str.split("-")[-1]) if "-" in pid_str else int(pid_str)
            except ValueError:
                pid_num = 0
            
            dims = p.get("dimensions", {})
            persona_ids.append(pid_num)
            summary.append(PersonaSummary(
                id=pid_str,
                name=p.get("name", ""),
                age=dims.get("age", ""),
                occupation=dims.get("occupation", ""),
                income=dims.get("income", ""),
                family_income=dims.get("family_income", ""),
                residence=dims.get("residence", ""),
                family_size=dims.get("family_size", ""),
                price_tier=dims.get("price_tier", ""),
                commute_mode=dims.get("commute_mode", ""),
                housing_cost=dims.get("housing_cost", ""),
                housing_burden=dims.get("housing_burden", ""),
                clothing_spend=dims.get("clothing_spend", ""),
                score=score_persona(p, filters, relaxed_dims),
            ))
        
        # Step 5: Optional LLM simulation (populated in full detail)
        # Note: simulation is not included in summary table.
        # Use GET /personadb/detail?id=XXX for full persona detail. 
        if opMode == "篩選+模擬" and q_list:
            logger.info(f"Simulating {len(top)} personas with LLM...")
            for i, p in enumerate(top):
                sim = await simulate_with_llm(p, q_list)
                # Simulation is NOT included in summary table response.
                # Client can use /personadb/detail for full persona info.
                _ = sim  # consumed but not included in summary
        
        # Step 6: Important dimensions
        important_dims = get_important_dimensions(top)
        dim_summaries = [
            DimensionSummary(dim=d["dim"], values=d["values"])
            for d in important_dims
        ]
        
        return CandidatesResponse(
            status="ok",
            total_matched=len(matched),
            persona_ids=persona_ids,
            summary=summary,
            important_dimensions=dim_summaries,
            llm_analysis=llm_analysis,
            relaxed_dims=relaxed_dims,
            applied_filters=filters,
            scoring_basis=scoring_basis,
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Candidates endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Detail ─────────────────────────────────────────────────────────

@app.get(
    "/personadb/detail",
    response_model=DetailResponse,
    responses={
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    }
)
async def personadb_detail(
    persona_id: str = Query(..., description="Persona ID (TW-P-XXXX 或數字)")
):
    try:
        p = get_persona_by_id(persona_id)
        if p is None:
            raise HTTPException(404, detail={
                "code": "PERSONA_NOT_FOUND",
                "message": f"Persona ID '{persona_id}' 不存在",
                "details": "有效範圍: TW-P-0001 ~ TW-P-1069"
            })
        
        return DetailResponse(
            status="ok",
            persona=PersonaDetail(
                id=p.get("id", ""),
                name=p.get("name", ""),
                type=p.get("type", "虛構人設"),
                dimensions=p.get("dimensions", {}),
                prompt_prefix=p.get("prompt_prefix", ""),
                reference_pre_prompt=p.get("reference_pre_prompt", ""),
            )
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Detail endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Status ────────────────────────────────────────────────────────

@app.get("/personadb/status")
async def persona_db_status():
    """
    Return persona-db status as raw text (like `hermes chat 'persona-db status'`).
    No parameters needed.
    """
    try:
        lines = []
        def L(s): lines.append(s)
        
        # Version
        version = "v3.2"
        try:
            vf = Path(__file__).resolve().parent.parent / "VERSION"
            if vf.exists():
                version = vf.read_text().strip()
        except: pass
        
        # Persona count
        db = load_persona_db()
        p_count = len(db)
        json_size = "N/A"
        json_path = Path(__file__).resolve().parent.parent / "tw_persona_1069.json"
        if json_path.exists():
            sz = json_path.stat().st_size
            json_size = f"{sz/1024/1024:.2f} MB" if sz > 1024*1024 else f"{sz/1024:.1f} KB"
        
        # Backup
        backup_path = json_path.parent / "tw_persona_1069_backup.json"
        backup_ok = backup_path.exists()
        
        # Name diversity
        names = set(p.get("name", "") for p in db)
        name_count = len(names)
        name_pct = round(name_count / p_count * 100, 1)
        from collections import Counter
        name_repeats = Counter(p.get("name", "") for p in db)
        max_repeat = max(name_repeats.values()) if name_repeats else 0
        
        # Python
        py_ver = sys.version.split()[0]
        
        # LLM status
        llm_status = "⛔ Not configured"
        if LLM_CONFIG.get("api_key"):
            llm_status = f"✅ {LLM_CONFIG.get('model', '?')} → {LLM_CONFIG.get('base_url', '?')}"
            # Live LLM test
            try:
                resp = await call_llm("回應「ok」就好", max_tokens=50)
                if resp is not None:
                    llm_status += " (responsive)"
                else:
                    llm_status += " (no response)"
            except Exception as e:
                llm_status += f" (error: {str(e)[:100]})"
        else:
            llm_status = "⛔ No API key configured"
        
        # Git
        git_info = "not a repo (filesystem boundary)"
        git_dir = Path(__file__).resolve().parent.parent / ".git"
        if git_dir.exists():
            try:
                import subprocess
                r = subprocess.run(["git", "log", "--oneline", "-1"], capture_output=True, text=True, cwd=str(git_dir.parent))
                if r.returncode == 0:
                    git_info = r.stdout.strip()
            except: pass
        
        # Hermes skills count (from mounted config volume or local)
        hermes_skills = "N/A"
        persona_skills = "N/A"
        for skills_candidate in ["/hermes-config/skills", str(Path.home() / ".hermes/skills")]:
            skills_path = Path(skills_candidate)
            if skills_path.exists() and skills_path.is_dir():
                try:
                    skill_files = list(skills_path.rglob("SKILL.md"))
                    hermes_skills = str(len(skill_files))
                    ps = [s for s in skill_files if "persona" in s.name.lower() or "persona" in str(s.parent).lower()]
                    persona_skills = str(len(ps))
                    break
                except Exception:
                    continue
        
        # QA
        qa_lines = []
        try:
            qa_script = Path(__file__).resolve().parent.parent / "qa_validate.py"
            if qa_script.exists():
                import subprocess
                r = subprocess.run([sys.executable, str(qa_script)], capture_output=True, text=True, cwd=str(qa_script.parent), timeout=30)
                if r.returncode == 0:
                    qa_lines = r.stdout.splitlines()[-6:]
                else:
                    qa_lines = ["❌ QA FAILED"]
        except subprocess.TimeoutExpired:
            qa_lines = ["⏱️ QA timeout"]
        except Exception as e:
            qa_lines = [f"❌ QA error: {e}"]
        
        # File artifacts
        tools_dir = Path(__file__).resolve().parent.parent
        py_files = list(tools_dir.glob("*.py")) + list(tools_dir.glob("api/*.py"))
        
        # ── Build output ──
        L(f"Persona DB Status")
        L(f"{'='*50}")
        L(f"")
        L(f"  Version         {version}")
        L(f"  Main personas   {p_count} (tw_persona_1069.json, {json_size})")
        L(f"  Backup          {'✅' if backup_ok else '❌'} {p_count} (tw_persona_1069_backup.json)")
        L(f"  QA (23 rules)   {'✅ ALL CHECKS PASSED' if qa_lines and 'PASSED' in qa_lines[-1] else '⏳ check below'}")
        L(f"  Name diversity  {name_count} unique names ({name_pct}%), max repeat {max_repeat}×")
        L(f"  Python          {py_ver}")
        L(f"  Git             {git_info}")
        L(f"  LLM             {llm_status}")
        L(f"  Hermes Skills   {hermes_skills} total, {persona_skills} persona-related")
        L(f"")
        L(f"  📁 Supporting Artifices: {len(py_files)} Python files")
        L(f"")
        if qa_lines:
            L(f"  QA Results:")
            for ql in qa_lines:
                if ql.strip():
                    L(f"    {ql.strip()}")
        
        return PlainTextResponse("\n".join(lines))
    
    except Exception as e:
        logger.exception("Status endpoint error")
        return PlainTextResponse(f"Error: {str(e)}", status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.server:app", host="0.0.0.0", port=8000, reload=True)
