# T01 — 稀有維度放寬護欄（#42）

> Spec: `specs/2026-09-12-v5.4-rare-dim-guard-and-score-provenance.md` | Blocked by: —（無）
> Issue: #42 | 檔案: `api/server.py`、`api/llm.py`

## 目標

`_rare_dims_hint()` 不再讓 broadening 過早放寬「核心稀有維度」，同時保留真正需要的救援能力。

## 變更

1. **rescue-only**：`_rare_dims_hint(db, filters, reinforced_dims, matched_count, threshold=0.05)` —— `matched_count > 0` 時回傳空字串
2. **核心性排除**：`reinforced_dims`（step 2b `domain_filters` 實際命中的維度）不列入提示
3. **prompt 強制理由**：提示文案與 `BROADEN_PROMPT` 都要求「若放寬稀有維度，必須在 `change` 寫明為何它不是本問題的核心條件」
4. **overshoot 旗標**：`broadening_attempts[]` 增 `overshoot: bool`（`match_count_after > 2 × TARGET_MIN`）＋ log

## Acceptance criteria

- [ ] `matched > 0` 時 `rare_dims_hint` 為空；`matched == 0` 且存在 <5% 維度時才輸出
- [ ] `reinforced_dims` 中的維度永遠不出現在提示裡
- [ ] `broadening_attempts` 每筆含 `overshoot`；`45 > 40` 的情境標記為 `true`
- [ ] `BROADEN_PROMPT` 含「必須說明為何它不是核心條件」字樣
- [ ] **不改變計分行為**（`dims_counted` / `score` 計算路徑不動）

## 驗收指令

```bash
python3 scripts/test_v5_4_fixes.py            # 單元（含 rescue-only / 排除 / overshoot）
# e2e：案例 07 債務整合 → debt_status 不放寬、符合率 >= 9/10
```
