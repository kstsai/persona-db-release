# T02 — response 可觀測性欄位（#43 + #44）

> Spec: `specs/2026-09-12-v5.4-rare-dim-guard-and-score-provenance.md` | Blocked by: —
> Issue: #43、#44 | 檔案: `api/models.py`、`api/server.py`

## 目標

讓呼叫端能自行偵測「pool 用盡」與「分數尺度版本」，不必靠外部文件猜測。

## 變更

1. `CandidatesResponse` 增：
   - `returned: int`（= `len(summary)`）
   - `pool_exhausted: bool`（= `total_matched < top_k`）
2. `scoring_basis` 增：
   - `weight_version`（= `dim_weights.json._meta.version`，由 `load_dim_weights()` 的 `_meta` 取得）
   - `score_scale: "relative-within-version"`
   - `score_schema: 1`（分數定義版號，與資料版號脫鉤；未來改 ranking 目標時跳版）
3. 兩條回應路徑（0-match early return 與正常回傳）都要帶這些欄位

## Acceptance criteria

- [ ] 正常回應含 `returned` 與 `pool_exhausted`，數值與 `len(summary)` / `total_matched < top_k` 一致
- [ ] `pool_exhausted=true` 出現在案例 06（total 5 < top_k 10）
- [ ] `scoring_basis.weight_version` == `dim_weights.json` 的 `_meta.version`（v5.4 時 == `VERSION`）
- [ ] `score_scale` / `score_schema` 常數正確；0-match 路徑也帶齊
- [ ] 既有 key 不變（向後相容；純新增）

## 驗收指令

```bash
python3 scripts/test_v5_4_fixes.py            # 模型 + 欄位單元測試
# e2e：任一 query 檢查 returned / pool_exhausted / scoring_basis.weight_version
```
