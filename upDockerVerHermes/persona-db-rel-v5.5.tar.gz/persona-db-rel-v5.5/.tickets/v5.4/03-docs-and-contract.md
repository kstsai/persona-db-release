# T03 — 文件與契約措辭（#43 + #44 + Q8-B）

> Spec: `specs/2026-09-12-v5.4-rare-dim-guard-and-score-provenance.md` | Blocked by: T02（欄位名定案）
> Issue: #43、#44 | 檔案: `RELEASE-v5.4.md`、`tw-persona-db-rfc.md`、`concepts/relevance-scoring.md`

## 目標

把「呼叫端與甲方該怎麼正確使用」寫進交付物，不靠口頭說明。

## 變更

1. **RFC**（scoring 與 broadening 章節）：
   - `scoring_basis` 新欄位語意（`weight_version` / `score_scale` / `score_schema`）
   - 稀有維度放寬規則改為「rescue-only + 核心性排除 + 強制理由 + overshoot 旗標」
2. **`RELEASE-v5.4.md`**：
   - API 契約措辭：`回傳數 = min(top_k, total_matched)`；`score` 僅供版本內相對排序
   - **每版 top score 區間**（校準基準）：v4.9.2 ≈ 5.91｜v5.2 ≈ 5.42｜v5.3.1 ≈ 4.36｜v5.4 = 實測值
   - 已知限制宣告（可直接給甲方）
3. **`concepts/relevance-scoring.md`**：補 `score_scale` / `weight_version` 說明與「不可跨版本比較」警語

## Acceptance criteria

- [ ] RFC 的 `scoring_basis` 範例含三個新欄位
- [ ] release notes 含「回傳數可能 < top_k」與「分數不可跨版本比較」兩段對外措辭
- [ ] release notes 含各版 top score 區間表（含本版實測）
- [ ] 措辭不出現「都合理」這類無法防禦的宣稱

## 驗收指令

```bash
grep -n "min(top_k" RELEASE-v5.4.md
grep -n "跨版本" RELEASE-v5.4.md tw-persona-db-rfc.md concepts/relevance-scoring.md
```
