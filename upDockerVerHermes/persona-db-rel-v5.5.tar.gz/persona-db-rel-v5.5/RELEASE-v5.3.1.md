# Persona DB v5.3.1 Release Notes

> 日期: 2026-09-12 | 上一版: v5.3 | 類型: **打包內容變更**（無 code / 無資料變更）

## 重點：設計知識納入交付包（kstsai 2026-09-12 定案）

`pack-persona-db-release.sh` 原本 `--exclude='concepts'`，導致交付 tarball **不含** `concepts/`
—— 但 repo `README.md` 的「交付總覽」把 `concepts/`（14 頁 + README index）列為**設計知識交付項**。
本版移除該 exclude，讓 tarball 與 README 揭露一致：**甲方拿到的包要看得到設計決策、公式、根因與 pitfall**。

- ✅ 新增：`concepts/`（14 頁 + README index，共 16 個 entry）
- ❌ 仍排除：`references/`（**刻意**，已寫進 pack script 註解）—— 內含內部 review session 紀錄、
  方法論、第三方評論與重複檔（業務定價在 repo 根目錄另有正式版 `TRANSFER-MODEL.md` /
  `LITE-MODEL.md` / `UPGRADE-PRICING.md`）。若要開放部分 references，建議先人工篩選成
  一個 curated 子集，而不是整包開放。
- 附帶：pack exclude 清單補 `__pycache__` / `*.pyc`（承 #45 同類 stray 檔——本機跑測試後會生成）

## 為什麼進版號

tarball 內容改變 = 部署方 / 甲方需要重新取包才拿得到，故依 release-workflow「什麼要進版」規則
（改了會進 tarball 的檔案就要 bump）進到 **v5.3.1**。

**無 code / 無資料 / 無權重表變更** —— `api/*.py`、`tw_persona_1069.json`、`dim_weights.json`
與 v5.3 逐位元相同（`dim_weights.json` 僅 `_meta.version` 隨版號更新，值不變）。
因此 **v5.3 的驗證結果完整沿用**（30/30 程式級 + 6/6 端到端）。

## 驗證

```bash
# 1. concepts 確實在包內（16 entries）
tar tzf persona-db-rel-v5.3.1.tar.gz | grep -c 'persona-db-rel-v5.3.1/concepts/'

# 2. repo 根目錄 references/ 仍不在包內（0）
tar tzf persona-db-rel-v5.3.1.tar.gz | grep -c '^persona-db-rel-v5.3.1/references/'

# 3. stray 檔為 0（.pyc / __pycache__ / .bak）
tar tzf persona-db-rel-v5.3.1.tar.gz | grep -cE '\.pyc|__pycache__|\.bak'

# 4. code/data 與驗證過的 working tree 逐位元相同
for f in api/server.py api/persona_matcher.py api/llm.py; do
  diff <(tar xzf persona-db-rel-v5.3.1.tar.gz -O persona-db-rel-v5.3.1/$f) $f && echo "✅ $f"
done
```

## 版本鏈

```
v5.2 (dimension 22) → v5.3 (#33/#34/#35/#36/#37/#41) → v5.3.1 (交付包納入 concepts/ 設計知識)
```
