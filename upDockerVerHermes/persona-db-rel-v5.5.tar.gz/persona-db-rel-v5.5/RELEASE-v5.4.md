# Persona DB v5.4 Release Notes

> 日期: 2026-09-12 | 上一版: v5.3.1 | 類型: bug fix（#42）＋ 可觀測性/契約（#43 / #44）
> 來源: v5.3.1 第三輪跨版本驗證報告（grill-me Q1–Q9 收斂，kstsai 核可）
> Spec: `specs/2026-09-12-v5.4-rare-dim-guard-and-score-provenance.md`

## 修的 issue

| # | 標題 | 修法 |
|---|---|---|
| **#42** | `_rare_dims_hint` 讓 broadening 過早放寬**核心稀有維度** → 案例 07 精度 4/10 | ① **rescue-only**（僅 `matched == 0` 才提示稀有維度）② **核心性排除**（domain reinforcement 補上的維度永不進提示）③ prompt **強制理由**（放寬須寫明「為何它不是核心條件」）④ `broadening_attempts[].overshoot` 旗標（> 2×TARGET_MIN） |
| **#43** | 回傳數可少於 `top_k` 對呼叫端是隱形契約 | response 增 `returned` / `pool_exhausted`；API 契約與對外措辭寫進本文件與 `concepts/relevance-scoring.md` |
| **#44** | `score` 尺度跨版本不可比，下游絕對門檻會靜默失效 | `scoring_basis` 增 `weight_version`（= `dim_weights._meta.version`）、`score_scale: "relative-within-version"`、`score_schema: 1` |

## API 契約（呼叫端/甲方必讀）

- **回傳數 = `min(top_k, total_matched)`**：`len(persona_ids)` 可能小於 `top_k`；系統**不為湊數放寬核心維度**。用 `returned` 與 `pool_exhausted` 判斷。
- **`score` 僅供同版本內相對排序**：以 `scoring_basis.weight_version` 偵測尺度換版；絕對門檻需於版本內重新校準。
- 對外措辭（可直接引用）：
  > 本 API 回傳的候選人數為 `min(top_k, 符合條件人數)`。當篩選條件精準時，符合者可能少於 `top_k`；系統不會為了補足數量而放寬條件。
  > 候選人的 `score` 反映「與本次問題的相對相關性」，數值尺度會隨資料版本更新而調整（v5.3 起整體下移）。請以排序使用，不要跨版本比較絕對數值。

### 各版 top score 區間（校準基準，Q8-B）

| 版本 | top score 平均 | 案例 03（時尚） | 案例 08（小吃攤） |
|---|---|---|---|
| v4.9.2 | ≈ 5.91 | 7.46 | 4.02 |
| v5.2 | ≈ 5.42 | 7.17 | 5.61 |
| v5.3.1 | ≈ 4.36 | 4.83 | 3.26 |
| **v5.4** | ≈ 5.45（本機 5 案例 4.13–6.75） | 5.28 | — |

> ⚠️ **判讀注意**：v5.4 的權重表與 v5.3.1 **完全相同**（僅 `_meta.version` 隨版號更新）→ **v5.4 沒有改變分數尺度**；上表 v5.3.1 與 v5.4 的差異來自**不同案例集**（dsh 8 案例 vs 本機 5 案例）與 LLM 抽樣變異，不是版本效應。同案例對照：案例 03 = 4.83（v5.3.1）→ 5.28（v5.4，單次樣本）。
> 分數尺度由資料分布決定（#41），不可能「修回」舊值 —— 正解是揭露 + 校準。

## 行為變更

1. 稀有維度**不會再於第一輪被放寬** → 核心條件保留（案例 07 符合率 6/10 → **10/10**）；樣本數可能略降（14 vs 45），屬刻意的精度/召回取捨。
2. `matched == 0` 時仍有救援提示（行為不變），但提示文案要求 LLM 明示判斷理由。
3. 新增 4 個 response 欄位（純新增，向後相容）。

## 驗證

**A. 單元（決定性，無 LLM）** — `python3 scripts/test_v5_4_fixes.py` → **27/27 pass**
- rescue-only（matched=0 才提示）、核心性排除（reinforced 維度被排除、混合情境只排除該維度）
- overshoot 邊界（40→False、41→True）、response 欄位序列化與預設值、`load_dim_weights_meta()` == VERSION、`load_dim_weights()` 仍剝掉 `_meta`（回歸護欄）

**B. 端到端（真 LLM，本機 uvicorn + v5.4）** — 5 案例 + 1 補測，**6/6 HTTP 200**

| 案例 | total | returned | 關鍵驗證 |
|---|---|---|---|
| 07 債務整合（role=銀行） | 14 | 10 | ✅ **`debt_status` 保留**、符合率 **10/10**（v5.3.1 = 6/10）、`overshoot=false`、3 輪皆有效（6→6 flagged no_op→12→14） |
| 06 醫美（role=行銷主管） | 10 | 10 | ✅ `sex=女` ＋ `aesthetic_procedure=有` 雙硬篩維持、回傳 **10/10** `有`；放寬的是 family_income/occupation/education（非核心） |
| 03 時尚服裝設計師 | 65 | 10 | ✅ 3 輪漸進（3→6→11→65），**末輪 `overshoot=true` 正確標記**（65 > 40） |
| 01 康是美 | 26 | 3 | ✅ 無 `aesthetic_procedure`（#36 未回歸） |
| 02 TESLA | 40 | 3 | ✅ `no_op` 正確標記（18→18 放寬無效）＋次輪 18→40 |
| 06 醫美（top_k=20 補測） | 13 | 13 | ✅ **`pool_exhausted=true` 實際觸發**（13 < 20）、`aesthetic_procedure=['有']` 保留、放寬 age/income（非核心） |

**不變式（全部案例）**：`returned == len(summary)`、`pool_exhausted == (total_matched < top_k)`、`broadening_attempts[]` 每筆含 `no_op` + `overshoot`、`scoring_basis.weight_version == v5.4` ✅

**C. Release gate** — `check_dim_weights.py` pass（18 維、`_meta.version = v5.4`）

## Out of scope（未做）

- `strict_dims` 硬約束參數（屬 speculative API，待甲方需求）
- `score_norm`（待需求確認；且 #40 若改 ranking 目標會再變）
- 多樣性重排 / 頭部集中（#40）、`usage_suggestion`（#45）、persona 層不穩定（#38）

## 版本鏈

```
v5.3 (6 項修復) → v5.3.1 (交付包納入 concepts/) → v5.4 (#42 稀有維度護欄 + #43/#44 可觀測性)
```
