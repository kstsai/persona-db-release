> 來源: linkEazyCenter wiki `concepts/persona-db/coherence-rules.md`（created 2026-08-10）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Coherence Rules（一致性驗證規則）

`_generate_997.py` 中的 persona 一致性修正。生成後自動檢查並修正矛盾組合。

## 完整規則清單 (v4.5)

| 規則 | 條件 | 修正 | 來源 |
|:----|:-----|:-----|:-----|
| R-A | fam=1 + 無收入 | family_income 壓低 | 人工 (若希 TW-P-0177) |
| R-B | fam=1 + 無收入 + 汽車 | commute 改大眾運輸 | 人工 |
| R-C | fam=1 + 無收入 + 高治裝 | clothing_spend 壓低 | 人工 |
| R-D | housing_burden=高 + clothing_spend≥5000 | clothing_spend 壓低 | autoresearch |
| R-E | 國中以下 + 醫療 | edu 提升 | autoresearch |
| R-F | fi<3萬 + housing_cost≥1.5萬 | housing_cost 壓低 | autoresearch |
| R-G | 離島 + fi>8萬 | family_income 下調 | autoresearch |
