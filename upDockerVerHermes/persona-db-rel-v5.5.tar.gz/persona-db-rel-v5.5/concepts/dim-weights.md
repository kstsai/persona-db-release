> 來源: linkEazyCenter wiki `concepts/persona-db/dim-weights.md`（created 2026-08-05）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Dim Weights（維度權重表）

regen 產物，記錄每個維度每個值的稀有度權重，供 relevance scoring 查表。

## 產生

```bash
python3 scripts/gen_dim_weights.py   # 讀 tw_persona_1069.json → dim_weights.json
```

## 公式

```
raw = log(1069 / count(dim, value))
norm = 0.5 + 1.5 × (raw - min) / (max - min)    # 值數 ≥4 → [0.5, 2.0]
norm = 0.8 + 0.6 × (raw - min) / (max - min)    # 值數 ≤3 → [0.8, 1.4]
```

## 覆蓋 15 維度

age, sex, region, residence, education, occupation, income, family_income, family_size, marriage, commute_mode, housing_cost, housing_burden, clothing_spend, hobby

不計分：political_*, media_diet, background_story, prompt_prefix

## 已知修正

- **sex 正規化失真**（v4.4）：男/女各半，[0.5,2.0] 強制拉極端 → 改 ≤3 值維度用 [0.8, 1.4]
- **hobby list 查權重 bug**：str(list) 查不到 → 改命中任一取最大

## 關聯

- Relevance Scoring — 使用方
- Persona DB — 資料來源
