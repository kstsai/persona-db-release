> 來源: linkEazyCenter wiki `concepts/persona-db/data-verification-loop.md`（created 2026-08-13）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# 資料驗證閉環（Data Verification Loop）

> persona-db 資料品質的標準流程。首次完整跑通於 v4.8（2026-08-13）。

## 流程

```
backup → regen(seed=42) → QA(23 rules) → contradiction hunt(便宜確定性)
  → 合理性分析(pro 只審嫌疑筆) → human review → 修/不改 → known issue
  → test-api → release
```

## 關鍵設計

- **hunt 先跑**（便宜、確定性），只揪組合矛盾；pro 只審 hunt-flagged 嫌疑筆，不全量 1069。
- **措辭精準**：「剩 N 筆**沒被現有規則抓到矛盾**」，不誇大為「都沒問題」。
- **殘留不可修**：開 GitHub issue 列 known issue（承認可能有問題），附修法 + 驗證方式。
- **顧客最挑剔資料正確性**：coherence 是重點（例：若希 fam=1 無收入卻配汽車的矛盾）。

## v4.8 首跑成果

揪出 **10 個系統性 bug**（#15-23，357+134 筆修復），詳見 Persona DB。
