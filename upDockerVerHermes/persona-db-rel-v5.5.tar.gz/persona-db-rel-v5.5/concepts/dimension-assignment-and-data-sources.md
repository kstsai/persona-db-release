> 來源: linkEazyCenter wiki `concepts/persona-db/dimension-assignment-and-data-sources.md`（created 2026-08-05）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# 維度指派邏輯與資料源對照

persona-db 每個新維度都有**可引用的資料源**（kstsai 重視資料可信度）。

## 新維度指派邏輯

| 維度 | 基底 | 微調 | 上限 |
|:----|:-----|:-----|:-----|
| housing_cost | price_tier | family_size shift | ≤50% 家庭可支配所得 |
| commute_mode | residence × age | income/family_size/occ | — |
| clothing_spend | family_income | sex(女↑男↓) × occ × age | — |

## 資料源對照

| 維度 | DGBAS 來源 | 備註 |
|:----|:----------|:-----|
| family_income | 家庭收支調查 | 可支配所得=稅後未扣房貸 |
| 失業 | 人力資源調查 | 年齡層失業率 |
| housing | 家庭收支調查 | cap 對照央行信用管制 |
| commute | 交通部運具分配 | 雙北捷運~45% |
| clothing | 衣著鞋襪消費支出 | 全國每戶月均~2,200 |

## 教訓

- **API 三層都要改**: models.py + persona_matcher.py(valid_dims) + llm.py(prompt) — 漏第三層導致「時尚服裝 query 挑到 <500 服飾消費」bug
- **markdown 用 `-` 不用 `~`**（~ 變刪除線）
- **每次 regen 產 verification report** 並涵蓋 DGBAS 來源

## 關聯

- Persona DB — 主 entity
- Family Income Tiers — 所得 tier 定義
