> 來源: linkEazyCenter wiki `concepts/persona-db/contradiction-hunt.md`（created 2026-08-10）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Contradiction Hunt（自動化矛盾人設偵測）

Autoresearch pattern: LLM 假設 + 程式驗證閉環。對 persona-db 1069 筆自動查找矛盾組合。

## 閉環流程

```
① 程式列舉維度對 (105 對)
② LLM 對每對生成假設 (condition + rationale + severity)
③ dsl.py 掃描 1069 筆 → violations
④ classify.py LLM 三分類 (contradiction / explainable / insufficient)
⑤ 篩出 severity=high + contradiction → 人工審批
⑥ rules.py 產出 rules_draft.json + patch diff
⑦ regen → 再跑 hunt → Recall/Precision 驗證
```

## 首跑結果

- 70 hypotheses → 34 with violations → 5 contradictions → 4 rules (R-D/E/F/G)
- Recall: 4/4 zero residual ✅
