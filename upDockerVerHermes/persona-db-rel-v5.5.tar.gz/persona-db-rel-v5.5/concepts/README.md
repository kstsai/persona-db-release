# Concepts — persona-db 設計知識庫

> 來源：團隊 wiki（linkEazyCenter `concepts/persona-db/`），2026-08-25 批次整合。
> 這些是各版本開發中沉澱的**設計決策、公式、根因、pitfall**，供開發/維護參考。
> **上游是 wiki**：改動本目錄時請同步回 wiki；反之 wiki 有新內容也應整進來。

## 索引

| 檔 | 主題 | 版本時效 |
|:---|:-----|:---------|
| `coherence-rule-design.md` | coherence 規則設計坑（比值≠絕對值、規則順序、未成年語意） | ✅ v4.9.2 現行 |
| `coherence-rules.md` | 一致性規則清單 R-A~R-G | ⚠️ **v4.5 快照**（現行規則見 `_generate_997.py`） |
| `contradiction-hunt.md` | 自動化矛盾偵測閉環（autoresearch pattern） | ✅ |
| `data-verification-loop.md` | 資料驗證閉環流程（hunt→pro 審→human→known issue） | ✅ 現行 |
| `deploy-env-chain.md` | deploy env 鏈根因（~/.env vs pocDemo.env，issue #26） | ✅ 已修 |
| `dim-weights.md` | 維度權重公式 + 已知修正（15 維度） | ✅ |
| `dimension-assignment-and-data-sources.md` | 維度指派邏輯 + DGBAS 資料源對照 | ✅ |
| `family-income-tiers.md` | 家庭可支配所得 6 tiers（DGBAS 定義） | ✅ |
| `interactive-llm-db-loop.md` | LLM-DB 互動 filter loop（broadening） | ✅ |
| `llm-retry-firewall.md` | retry 防火牆 4 層設計（issue #24，v4.9.0） | ✅ 已實作 |
| `persona-db-deployment.md` | 部署模式 + 甲方啟用 + 常見問題 | ✅ |
| `pre-release-sop.md` | pre-release 驗證 SOP（undeploy→deploy→test→LLM verify） | ✅ |
| `relevance-scoring.md` | relevance 分數公式 + response 揭露 | ✅ |

## 維護原則

- **版本時效**：標 ⚠️ 的是歷史快照，以 code（`_generate_997.py` / `api/`）為準
- **資料可信度**：所有資料源引用 DGBAS（主計總處），不憑空捏造
- **改 code 改設計**：本目錄的設計決策若被 code 超越，記得同步更新（或標註）
