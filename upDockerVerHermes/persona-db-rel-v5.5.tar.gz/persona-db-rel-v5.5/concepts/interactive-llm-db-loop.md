> 來源: linkEazyCenter wiki `concepts/persona-db/interactive-llm-db-loop.md`（created 2026-08-12）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Interactive LLM-DB Filter Loop

取代 blind relaxation — LLM 看見資料分布後，自行修正過嚴的 filters。

## 架構

```
Data grounding → LLM → strict filters → DB scan
  ├─ count ≥ TARGET_MIN (20) → scoring → return ✅
  └─ count < TARGET_MIN → broadening loop (max 3):
       LLM: "只 match N 人，請放寬 1-2 個維度"
       → new filters → DB scan
         ├─ count OK → return ✅
         └─ loop again or exhaust → too_strict
```

## Data grounding

Prompt 注入 per-dim 值分布（動態從 tw_persona_1069.json 計算），LLM 知道稀有度 → 不過度使用稀有 dim。

## Broadening loop

LLM 收到 matched count + current filters → 自己決定放寬哪個 dim。
實戰: strict=11 → broaden income → 2 → broaden commute_mode → 22 ✅

## Role parameter

`?role=房仲業者` vs `?role=銀行業者` → 不同 persona 排序結果
