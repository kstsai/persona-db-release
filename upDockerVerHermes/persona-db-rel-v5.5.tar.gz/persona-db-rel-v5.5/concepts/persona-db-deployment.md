> 來源: linkEazyCenter wiki `concepts/persona-db/persona-db-deployment.md`（created 2026-08-04）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Persona-DB 部署與交付

> Persona DB（台灣人口加權合成人設資料庫）的 Docker 容器化部署方案。含 Hermes Agent + Persona DB API 雙容器。

## 部署模式

| 模式 | 指令 | Container | 空間 | 用途 |
|:----|:------|:--------:|:----:|:-----|
| 完整部署 | `deploy-hermes-personadb-containers.sh` | 2 (hermes + api) | ~5GB | 完整交付 |
| API-only | `--skip-hermes` | 1 (api) | ~1GB | edge VM / 空間有限 |

## 甲方啟用流程（Hermes Container）

部署後 Hermes container 已預設 `custom:deepseek-pro` provider。甲方有兩種啟用方式：

| 方式 | 操作 | 適合 |
|:----|:-----|:-----|
| A. DeepSeek API Key | `echo "LLM_API_KEY=sk-xxx" >> ~/.env` → `docker restart hermes` | 最簡單 |
| B. Nous Portal OAuth | `hermes auth add nous` → 瀏覽器授權 → `hermes model` | 已有訂閱 |

## 常見問題

| # | 症狀 | 解法 |
|:--|:-----|:-----|
| 1 | 磁碟不足 | `docker system prune -af`；API-only 只需 ~1GB |
| 2 | Sudo 需密碼 | `export SUDO_PASSWORD=...` 或事先建好目錄 |
| 3 | Docker 權限 | `usermod -aG docker $USER` |
| 4 | Docker Hub 超慢 | API-only 模式跳過 hermes image pull |
| 5 | API 沒回應 | `docker logs persona-db-api`；檢查 ~/.env |

## Release 版本管理

- Tarball 命名：`persona-db-rel-<VERSION>.tar.gz`（版本號來自 source repo 的 `VERSION` 檔）
- Deploy 腳本自動掃描 `upDockerVerHermes/` 下所有 tarball，選版本號最高的
- 發佈流程：`pack-persona-db-release.sh` → 複製到 release repo → git push

## A3 克隆 SOP（從零部署到新 VM）

```bash
# 1. Docker
sudo apt install -y docker.io && sudo usermod -aG docker $USER

# 2. API Key
echo "LLM_API_KEY=sk-xxx" > ~/.env

# 3. Clone + deploy
git clone https://github.com/kstsai/persona-db-release.git
cd persona-db-release/upDockerVerHermes
bash deploy-hermes-personadb-containers.sh

# 4. 驗收
bash test-persona-db-api.sh
docker exec hermes hermes chat -q "persona-db status"
# → 1069 personas, QA 23 rules ALL PASS
```
