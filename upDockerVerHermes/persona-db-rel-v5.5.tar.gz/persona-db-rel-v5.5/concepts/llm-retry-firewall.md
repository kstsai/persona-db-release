> 來源: linkEazyCenter wiki `concepts/persona-db/llm-retry-firewall.md`（created 2026-08-13）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# LLM Retry 防火牆

> 目標：防止 LLM retry 白燒 token（「別讓我們虧本了，我們不搞 token maximize」）。對應 issue #24。**狀態：已實作 + release v4.9.0（2026-08-14）**。

## 成本真相

花錢的是 **reasoning tokens**（pro 每次 85-90s 的思考），不是 output。每次 retry = 重付一次 reasoning + 重送整包 prompt。

## 反模式（現行 bug — v4.9.0 已修）

- **doubling retry**：content 空時 `max_tokens * 2` 重送（2000→4000→8000）— 已砍，改精準 retry
- **無條件 parse retry**：JSON parse 失敗就重試 — 已改為只在截斷才 retry
- **broadening 無預算上限**：實測 no-op loop 白燒 8000 — 已加 per-request 32000 上限
- **BROADEN_PROMPT 缺有效值**：LLM 發明 DB 不存在的值 — 已注入有效值清單

## 4 層設計（全部落地）

| 層 | 做法 | 省錢原理 | 狀態 |
|:--|:-----|:--------|:----:|
| **L1 一次到位** | pro 直接 8000、flash 關 thinking+2000 | 常見 case 不 retry | ✅ |
| **L2 精準 retry** | 只在 `finish_reason=length`（截斷）retry 1 次 +50% | 截斷才是真的 token 不夠 | ✅ |
| **L3 免費提取** | content 空先挖 `reasoning_content`（已付費白拿） | reasoning 不重算 | ✅ |
| **L4 硬預算+熔斷** | 每 request ≤32000 tokens；3 連敗→60s 熔斷 | 不讓單一 request 無限燒錢 | ✅ |

## 實作細節（tickets）

- **#01 precise-retry**（D1+D2+D3）：`call_llm` 重構 — `_resolve_max_tokens`（pro≥8000）、砍 doubling、只在 finish_reason=length retry（+50%）、reasoning 提取前移、garbage/reasoning-only 非截斷回 None。commit `46b38a7`
- **#02 budget+breaker**（D4）：server.py `TOKEN_BUDGET=32000` + `tokens_spent` 累加、broadening loop 條件加預算檢查；llm.py module-level circuit breaker（`_fail_count`/`_cooldown_until`，3 連敗→60s）。commit `0e2172a`
- **#03 broaden-valid-values**（D6）：BROADEN_PROMPT 注入有效值清單 +「不要發明不存在的值」。commit `0e2172a`
- **D5**（broaden 用 flash）可選不預設，留後續 ticket

## 踩過的坑（D6 regression）

有效值清單初版漏 4 維度（region/education/housing_burden/housing_cost），加上「只能使用下列值」指令後，broadening LLM 反而把 housing_burden 誤刪。LLM verify 抓到後補齊兩 prompt 的清單。commit `79da1b0`

## 預期效益

| 場景 | 現行 | 防火牆後 |
|:--|:----|:----|
| 正常 query | 16K | 8K（-50%） |
| 嚴格 query（3 broaden） | 40K | 32K 上限 |

預期省 **40%+**。
