> 來源: linkEazyCenter wiki `concepts/persona-db/pre-release-sop.md`（created 2026-08-13）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Pre-release SOP（部署驗證流程）

> release 前在 lzcdh1 跑的標準驗證流程。kstsai 將寫進 README。

## 步驟

```bash
# 1. 完整清除（undeploy.sh 會刪 /srv/persona-db-data + ~/.hermes）
bash undeploy.sh

# 2. fresh install（tarball 完整解壓）
bash deploy-hermes-personadb-containers.sh --skip-hermes

# 3. 跑 API 測試（5 domains + role QA）
bash test-persona-db-api.sh

# 4. LLM verify API result（★ 核心步驟）
```

## LLM verify 是重點

不是只報 PASS，而是**逐 domain 判讀結果合理性**：
- 5 case（康是美/TESLA/時尚/房貸-房仲/房貸-銀行）top 結果是否符合 domain 邏輯
- Role QA 是否 DIFFERENT（房仲 top ≠ 銀行 top）
- 有無 FILTER_FAILED、broadening 是否正常觸發

## 關鍵 pitfall

- **deploy script 的「資料已存在就跳過 extract」邏輯**：re-deploy 不跑 undeploy 會 stale（VERSION/data/code 都停在舊版）。**正確 SOP 一定要先 undeploy.sh**。
- **LLM_ANALYSIS_MODEL**：fresh deploy 後要確認 `.env` 有 `deepseek-v4-pro`（v4.5.3 曾因漏設導致 FILTER_FAILED）。

## 這輪抓到過的真 bug（都是 SOP 的價值）

1. role 分化失效（房仲/銀行 filters 相同）
2. broadening max_tokens 太小 → 靜默失敗（total 卡 3）
3. BROADEN_PROMPT 發明無效值（clothing_spend 值域外）
