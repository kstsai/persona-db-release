> 來源: linkEazyCenter wiki `concepts/persona-db/coherence-rule-design.md`（created 2026-08-19）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Coherence Rule 設計（比值 vs 絕對值 + 順序）

> 修 #28/#29 時歸納的兩個 coherence rule 設計坑。

## 坑 1：比值 ≠ 絕對值

`housing_burden` 是 `housing_cost / family_income` 的**比值**（≥40% 才算「高」）。

- **高所得 + 高 burden**：`>8萬` 家庭 + 房貸 3萬~5萬 → ratio 0.44 → burden「高」，但每月還剩 5萬+ → `>5000` 服飾**合理**，不是矛盾
- **低所得 + 高 burden**：`1-3萬` 家庭 + 房貸 1.5萬~3萬 → ratio 0.75 → burden「高」，`>5000` 服飾**超過收入** → 真矛盾

所以「housing_burden 高 + clothing >5000」的 coherence rule **只能對低所得開火**（`fam_inc in (<1萬, 1-3萬)`），否則會誤修高所得的合理組合。

## 坑 2：規則順序（重算前 vs 後）

`housing_burden` 和 `family_income` 都會在生成流程中**被後續規則調整**：

1. `housing_burden` 在 R-03（低所得降房貸）等規則後會**重算**
2. `family_income` 在 `adjust_family_income_by_tier` / FI floor / fam=1 cap 後會**再改**

若 coherence rule 在這些調整**之前**執行，就會漏掉「調整後才違反」的 case（殘留）。

**修法**：把 coherence rule 移到 `housing_burden` / `family_income` 的**最終值確定之後**。

## 坑 3：成人語意不套小孩

`clothing_spend` 的 `>5000`（很重視穿搭）是**成人語意**。0-18 歲即使高所得家庭，也不該拿到「治裝/重視穿搭」的消費 tier。修法：0-18 歲 cap 在 `1500~3000`。
