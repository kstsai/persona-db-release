# Persona DB v5.5 Release Notes

> 日期: 2026-09-12 | 上一版: v5.4 | 類型: 錯誤契約修正（#47 / #49）＋ 韌性與可診斷性（#46）＋ schema 型別化（#48）
> 來源: v5.4 第四輪跨版本驗證報告（dsh 驗證）+ 開發期發現

## 修的 issue

| # | 標題 | 修法 |
|---|---|---|
| **47** | 錯誤回應不符自身宣告的 `ErrorResponse` schema（400/500/503 全中） | 新增 app-level `HTTPException` handler + `RequestValidationError` handler → **所有**錯誤碼統一為 `{"status":"error","error":{code,message,details}}`；`_normalize_error_detail()` 兼容 dict 與 string 兩種 detail |
| **46** | analysis 連續解析失敗即硬 503，且失敗原因在生產 log 不可見 | ① parse 失敗時以 **WARNING** 記錄截斷的 raw response（原本只在 DEBUG → 事故無法診斷）② 重試**帶變化**：第二次提高 token 預算（pro 8000→12000、flash 4000→8000）③ 放棄時以 ERROR 記錄 ④ 503 `FILTER_FAILED` 增 `retryable: true` |
| **48** | `broadening_attempts` / `scoring_basis` 缺機器可讀 schema | 新增 Pydantic 子模型 `BroadeningAttempt` / `ScoringBasis`（欄位全有 default）→ OpenAPI 產生 `properties`，codegen 可見 `no_op` / `overshoot` / `score_scale` 等 |
| **49** | `opMode` 預設值 `兩者皆可` 不在自己的合法值清單 → **省略 opMode 一律 400** | Query 預設改為 **`僅篩選`**（對齊 `api/models.py` 宣告的 `OpMode.FILTER_ONLY`）；並把兩個 400 的字串 detail 改為帶錯誤碼（`INVALID_OPMODE` / `TOP_K_TOO_LARGE`） |

## 行為變更（向後相容性）

1. **錯誤回應形狀改變**：`{"detail": ...}` → `{"status":"error","error":{"code","message","details",...}}`。
   - 依 `ErrorResponse`（宣告的 schema）寫的 client 從「取不到 `error`」變成「正確運作」✅
   - 若 client 目前解析 FastAPI 預設的 `detail` 欄位，**需改為讀 `error`**（本次沒有已知下游依賴 `detail`）
2. **422 也統一形狀**（狀態碼不變）：FastAPI 預設的 `detail: [...]` → `error.code = "VALIDATION_ERROR"`
3. **`opMode` 可省略**：過去省略 → 400；現在省略 → 等同 `僅篩選`（不觸發模擬、成本最低）
4. 成功回應（200）**完全不變**（已在單元測試斷言 `model_dump()` key 集合與 v5.4 相同）

## 錯誤契約（對外）

```jsonc
// 修正後（所有錯誤碼一致）
{"status":"error",
 "error":{"code":"INVALID_OPMODE","message":"無效的 opMode: 亂寫","details":"有效值: 僅篩選, 篩選+模擬, 模擬詢問"}}

// 瞬時失敗會帶 retryable（#46）
{"status":"error",
 "error":{"code":"FILTER_FAILED","message":"...","details":"...","retryable":true}}
```

錯誤碼清單：`INVALID_OPMODE` / `TOP_K_TOO_LARGE` / `MISSING_PARAMETER` / `DB_NOT_LOADED` / `FILTER_FAILED` / `VALIDATION_ERROR` / `INTERNAL_ERROR` / `NOT_FOUND`。

## 驗證

**A. 單元（決定性、無 LLM）** — `python3 scripts/test_v5_5_fixes.py` → **26/26 pass**
- #47：400 / 422 / 404 / 500 / 503 五種錯誤碼皆為統一形狀、**不含** `detail`、`code` 正確；正常端點 200（回歸）
- #46：兩次非 JSON → 空 dict；第一次用 8000、**重試用 12000**；WARNING 含 raw response 內容；放棄時 ERROR；空回應路徑同樣帶變化；首次失敗重試成功**不誤放棄**
- #48：OpenAPI 有兩個子模型且 `properties` 完整；`CandidatesResponse` 欄位指向子模型；`model_dump()` key 集合與 v5.4 **相同**；子模型全欄位有 default
- #49：不帶 `opMode` → 不再 400

**B. 端到端（真 LLM）** — 見下方實測（含「不帶 opMode」案例驗證 #49）

**C. Release gate** — `check_dim_weights.py` pass（18 維、`_meta.version = v5.5`）；`py_compile api/*.py scripts/*.py` pass

## Out of scope（未做）

- **第三次重試 / flash salvage**：本次只做「重試帶變化 + 可診斷 log」。累積 log 數據後再決定是否加第三次嘗試或降級路徑（避免未經數據支持的 token 增加）
- **`opMode` 改用 `OpMode` enum 型別**：可讓 FastAPI 自動驗證、文件直接顯示值域（另案，屬 API 現代化）
- 前端／下游若解析 `detail` 的相容層（本次無已知用戶）

## 版本鏈

```
v5.3（6 項修復）→ v5.3.1（交付包納入 concepts/）→ v5.4（#42 稀有維度護欄 + #43/#44 可觀測性）
→ v5.5（#47 錯誤契約 + #46 韌性/可診斷性 + #48 schema 型別化 + #49 預設值修正）
```
