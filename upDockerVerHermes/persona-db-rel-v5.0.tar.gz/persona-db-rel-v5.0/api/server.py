"""
Persona DB REST API — FastAPI Server (LLM-powered)

Endpoints:
  GET /personadb/candidates — LLM analyzes questions → filter personas (+ simulate)
  GET /personadb/detail     — Get full persona profile by ID
  GET /health               — Health check

Run:  uvicorn api.server:app --reload
"""

import os, sys, json, logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import PlainTextResponse

from .models import (
    OpMode, CandidatesResponse, PersonaSummary,
    PersonaSimulation, DimensionSummary, LLMAnalysis,
    DetailResponse, PersonaDetail, HealthResponse, ErrorResponse
)
from .persona_matcher import (
    filter_personas, get_important_dimensions,
    format_matched_criteria, load_persona_db, get_persona_by_id,
    llm_filters_to_dimension_filters
)
from .llm import parse_questions_with_llm, simulate_with_llm, call_llm, LLM_CONFIG

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Persona DB API",
    description="台灣人口加權合成人設資料庫 — LLM-powered 查詢與模擬 API",
    version="3.2.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── Startup ────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    try:
        load_persona_db()
        db = load_persona_db()
        logger.info(f"Persona DB loaded: {len(db)} personas")
        app.state.db_loaded = True
        app.state.persona_count = len(db)
    except Exception as e:
        logger.error(f"Failed to load Persona DB: {e}")
        app.state.db_loaded = False
        app.state.persona_count = 0


# ── Health ─────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(
        status="ok",
        version="3.2",
        persona_count=getattr(app.state, "persona_count", 0),
        db_loaded=getattr(app.state, "db_loaded", False),
    )


# ── Candidates (LLM-powered filter + optional simulate) ────────────

@app.get(
    "/personadb/candidates",
    response_model=CandidatesResponse,
    responses={
        400: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
        503: {"model": ErrorResponse},
    }
)
async def personadb_candidates(
    questions: str = Query(..., description="問題列表，用 | 分隔多題"),
    top_k: int = Query(20, ge=1, le=100, description="要回傳幾個最相關的 persona"),
    opMode: str = Query(default="兩者皆可", description="操作模式: 篩選+模擬 / 僅篩選 / 模擬詢問"),
    role: str = Query(default="", description="詢問者角色（例：房仲業者、銀行業者）。讓 LLM 調整 filter 方向。"),
):
    # Validate
    if opMode not in ("僅篩選", "篩選+模擬", "模擬詢問"):
        raise HTTPException(status_code=400, detail=f"無效的 opMode: {opMode}。有效值: 僅篩選, 篩選+模擬, 模擬詢問")
    if top_k > 100:
        raise HTTPException(status_code=400, detail="top_k 最大為 100")
    if not getattr(app.state, "db_loaded", False):
        raise HTTPException(503, detail={
            "code": "DB_NOT_LOADED",
            "message": "Persona DB 尚未載入",
            "details": ""
        })
    
    # Parse questions (split by |)
    q_list = [q.strip() for q in questions.split("|") if q.strip()]
    if not q_list:
        raise HTTPException(400, detail={
            "code": "MISSING_PARAMETER",
            "message": "請提供至少一個問題",
            "details": "多個問題請用 | 分隔"
        })
    
    try:
        db = load_persona_db()
        
        # Step 1: LLM analyzes questions → dimension filters
        logger.info(f"LLM analyzing {len(q_list)} questions...")
        from .llm import build_distribution_summary
        data_overview = build_distribution_summary(db)
        llm_result = await parse_questions_with_llm(q_list, role=role or None, distribution=data_overview)
        
        llm_analysis = None
        if llm_result:
            llm_analysis = LLMAnalysis(
                domain=llm_result.get("domain", ""),
                reasoning=llm_result.get("reasoning", ""),
                question_analysis=llm_result.get("question_analysis", []),
                usage_suggestion=llm_result.get("usage_suggestion"),
            )
        
        # Step 2: Convert LLM output to filters
        filters = llm_filters_to_dimension_filters(llm_result) if llm_result else {}
        
        # Step 2b: Domain-aware filter reinforcement (issue #4 — LLM 常漏消費維度)
        # 依 LLM 判定的 domain，自動補上關鍵消費維度（確定性兜底，不依賴 LLM 自覺）
        domain = (llm_result or {}).get("domain", "")
        domain_filters = {
            "時尚": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "服飾": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "美妝": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "運動": {"hobby": ["登山", "球類", "游泳", "廣場舞"]},
            "健身": {"hobby": ["登山", "球類", "游泳", "廣場舞"]},
            "跑鞋": {"hobby": ["登山", "球類", "游泳"], "clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "電動車": {"income": [">8萬", "3-8萬"]},
            "汽車": {"income": [">8萬", "3-8萬"]},
            "房產": {"housing_burden": ["中", "高"], "family_income": ["5-7萬", "7萬", ">8萬"]},
            "房貸": {"housing_burden": ["中", "高"], "family_income": ["5-7萬", "7萬", ">8萬"]},
            "旅遊": {"family_income": ["5-7萬", "7萬", ">8萬"]},
            "醫美": {"aesthetic_procedure": ["有"]},
            "美容": {"aesthetic_procedure": ["有"]},
            "整形": {"aesthetic_procedure": ["有"]},
            "皮膚科": {"aesthetic_procedure": ["有"]},
        }
        reinforced = {}
        for kw, add_filters in domain_filters.items():
            if kw in domain:
                reinforced.update(add_filters)
        if reinforced:
            for dim, vals in reinforced.items():
                if dim not in filters or not filters[dim]:
                    filters[dim] = vals
                    logger.info(f"Domain reinforcement ({domain}): added {dim}={vals}")
                # hobby: LLM 常用通用詞（如"運動"），但 DB 只有具體活動。
                # 若 hobby 已在 filters 但 DB 值可能不匹配，用 domain 值覆蓋
                elif dim == "hobby":
                    filters[dim] = vals
                    logger.info(f"Domain reinforcement ({domain}): replaced hobby with {vals}")
        
        # Fallback: if LLM returned no filters, use keyword-based parsing from questions text
        if not filters:
            from .persona_matcher import parse_enduser
            combined_text = " ".join(q_list)
            filters = parse_enduser(combined_text)
            logger.warning("LLM returned no filters, falling back to keyword parsing")
        
        # If still no filters, refuse to match everything (would return all 1069)
        if not filters:
            raise HTTPException(503, detail={
                "code": "FILTER_FAILED",
                "message": "無法從問題中解析出篩選條件（LLM 分析失敗且關鍵字解析無結果）",
                "details": "請確認 LLM API key / model 設定，或換一種問法"
            })
        
        # Step 3: Filter personas
        matched = filter_personas(db, filters)
        
        # Scoring basis metadata (issue #4 — auditability); built once, used
        # in both 0-match and success responses
        scoring_basis = None
        dim_weights = {}
        try:
            from .persona_matcher import load_dim_weights
            dim_weights = load_dim_weights()
        except Exception:
            dim_weights = {}
        if dim_weights:
            scoring_basis = {
                "method": "log-frequency × cross-dim normalized [0.5, 2.0]",
                "weight_source": "DGBAS 113年 家庭收支調查 / 人力資源調查 / 交通部 2024",
                "dims_counted": [d for d in filters.keys() if d in dim_weights],
                "relaxed_dims_scored_at": None,  # Q3-A': relaxed dims not scored
            }
        
        # Step 3b: Filter relaxation — threshold-based (issue #4 v4.4.2)
        # Step 3b: Interactive broadening loop (replaces blind relaxation, issue #12)
        TARGET_MIN = 20
        original_filters = dict(filters)
        relaxed_dims = []
        broadening_attempts = []
        loop = 0
        max_loops = 3
        # D4: per-request token budget（analysis 1 次 + broadening ≤3 次）
        analysis_model = LLM_CONFIG.get("analysis_model") or None
        # pro model is reasoning-heavy: 2000 tokens gets eaten by reasoning
        # and content comes back empty → silent break (issue: 房仲 total=3)
        broaden_max_tokens = 8000 if analysis_model and "pro" in analysis_model.lower() else 2000
        TOKEN_BUDGET = 32000
        tokens_spent = 8000  # analysis call（pro = 8000）

        while (len(matched) < TARGET_MIN and loop < max_loops and filters
               and tokens_spent + broaden_max_tokens <= TOKEN_BUDGET):
            loop += 1
            logger.info(f"Broadening loop {loop}/{max_loops}: {len(matched)} matches < {TARGET_MIN}")
            from .llm import call_llm, BROADEN_PROMPT
            broaden_prompt = BROADEN_PROMPT.format(
                match_count=len(matched),
                target_min=TARGET_MIN,
                current_filters=json.dumps(filters, ensure_ascii=False, indent=2)
            )
            result = await call_llm(broaden_prompt, temperature=0.2, max_tokens=broaden_max_tokens, model_override=analysis_model)
            tokens_spent += broaden_max_tokens
            if not result:
                break
            try:
                result = result.strip()
                if "```json" in result:
                    result = result.split("```json")[1].split("```")[0].strip()
                elif "```" in result:
                    result = result.split("```")[1].split("```")[0].strip()
                new_data = json.loads(result)
                new_filters = new_data.get("filters", {})
                broadening = new_data.get("broadening", "unknown")
            except Exception:
                break
            if not new_filters:
                break
            # #25: 限制每 loop 最多移除 1 個維度（防止 overshoot：一次刪多維度 → total 暴增）
            removed_this_loop = [dim for dim in list(filters.keys()) if dim not in new_filters]
            if len(removed_this_loop) > 1:
                logger.info(f"Broadening loop {loop}: LLM 移除 {len(removed_this_loop)} 維度，cap 到 1（還原 {removed_this_loop[1:]}）")
                for dim in removed_this_loop[1:]:
                    new_filters[dim] = filters[dim]  # 還原多餘移除的維度（保留舊值）
                removed_this_loop = removed_this_loop[:1]
            relaxed_dims.extend(removed_this_loop)
            filters = new_filters
            prev_count = len(matched)
            matched = filter_personas(db, filters)
            broadening_attempts.append({"loop": loop, "change": broadening, "match_count_before": prev_count, "match_count_after": len(matched)})
        
        status = "ok" if len(matched) >= TARGET_MIN else "too_strict" if loop >= max_loops and len(matched) == 0 else "ok"
        
        if not matched:
            return CandidatesResponse(
                status=status,
                total_matched=0,
                persona_ids=[],
                relaxed_dims=relaxed_dims,
                applied_filters=filters,
                broadening_attempts=broadening_attempts,
                llm_analysis=llm_analysis,
                scoring_basis=scoring_basis,
            )
        
        # Step 4: Relevance scoring + take top_k
        from .persona_matcher import sort_by_score, score_persona
        dim_importance = (llm_result or {}).get("dim_importance", {})
        matched = sort_by_score(matched, original_filters, dim_importance, relaxed_dims)
        top = matched[:top_k]
        
        # Build summary table (replaces full persona details)
        persona_ids = []
        summary = []
        
        for p in top:
            pid_str = p.get("id", "")
            try:
                pid_num = int(pid_str.split("-")[-1]) if "-" in pid_str else int(pid_str)
            except ValueError:
                pid_num = 0
            
            dims = p.get("dimensions", {})
            persona_ids.append(pid_num)
            summary.append(PersonaSummary(
                id=pid_str,
                name=p.get("name", ""),
                age=dims.get("age", ""),
                occupation=dims.get("occupation", ""),
                income=dims.get("income", ""),
                family_income=dims.get("family_income", ""),
                residence=dims.get("residence", ""),
                family_size=dims.get("family_size", ""),
                city_price_tier=dims.get("city_price_tier", ""),
                commute_mode=dims.get("commute_mode", ""),
                housing_cost=dims.get("housing_cost", ""),
                housing_burden=dims.get("housing_burden", ""),
                clothing_spend=dims.get("clothing_spend", ""),
                aesthetic_procedure=dims.get("aesthetic_procedure", ""),
                score=score_persona(p, original_filters, dim_importance, relaxed_dims),
            ))
        
        # Step 5: Optional LLM simulation (populated in full detail)
        # Note: simulation is not included in summary table.
        # Use GET /personadb/detail?id=XXX for full persona detail. 
        if opMode == "篩選+模擬" and q_list:
            logger.info(f"Simulating {len(top)} personas with LLM...")
            for i, p in enumerate(top):
                sim = await simulate_with_llm(p, q_list)
                # Simulation is NOT included in summary table response.
                # Client can use /personadb/detail for full persona info.
                _ = sim  # consumed but not included in summary
        
        # Step 6: Important dimensions
        important_dims = get_important_dimensions(top)
        dim_summaries = [
            DimensionSummary(dim=d["dim"], values=d["values"])
            for d in important_dims
        ]
        
        return CandidatesResponse(
            status=status,
            total_matched=len(matched),
            persona_ids=persona_ids,
            summary=summary,
            important_dimensions=dim_summaries,
            llm_analysis=llm_analysis,
            relaxed_dims=relaxed_dims,
            applied_filters=filters,
            broadening_attempts=broadening_attempts,
            scoring_basis=scoring_basis,
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Candidates endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Detail ─────────────────────────────────────────────────────────

@app.get(
    "/personadb/detail",
    response_model=DetailResponse,
    responses={
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    }
)
async def personadb_detail(
    persona_id: str = Query(..., description="Persona ID (TW-P-XXXX 或數字)")
):
    try:
        p = get_persona_by_id(persona_id)
        if p is None:
            raise HTTPException(404, detail={
                "code": "PERSONA_NOT_FOUND",
                "message": f"Persona ID '{persona_id}' 不存在",
                "details": "有效範圍: TW-P-0001 ~ TW-P-1069"
            })
        
        return DetailResponse(
            status="ok",
            persona=PersonaDetail(
                id=p.get("id", ""),
                name=p.get("name", ""),
                type=p.get("type", "虛構人設"),
                dimensions=p.get("dimensions", {}),
                prompt_prefix=p.get("prompt_prefix", ""),
                reference_pre_prompt=p.get("reference_pre_prompt", ""),
            )
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Detail endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Status ────────────────────────────────────────────────────────

@app.get("/personadb/status")
async def persona_db_status():
    """
    Return persona-db status as raw text (like `hermes chat 'persona-db status'`).
    No parameters needed.
    """
    try:
        lines = []
        def L(s): lines.append(s)
        
        # Version
        version = "v3.2"
        try:
            vf = Path(__file__).resolve().parent.parent / "VERSION"
            if vf.exists():
                version = vf.read_text().strip()
        except: pass
        
        # Persona count
        db = load_persona_db()
        p_count = len(db)
        json_size = "N/A"
        json_path = Path(__file__).resolve().parent.parent / "tw_persona_1069.json"
        if json_path.exists():
            sz = json_path.stat().st_size
            json_size = f"{sz/1024/1024:.2f} MB" if sz > 1024*1024 else f"{sz/1024:.1f} KB"
        
        # Backup
        backup_path = json_path.parent / "tw_persona_1069_backup.json"
        backup_ok = backup_path.exists()
        
        # Name diversity
        names = set(p.get("name", "") for p in db)
        name_count = len(names)
        name_pct = round(name_count / p_count * 100, 1)
        from collections import Counter
        name_repeats = Counter(p.get("name", "") for p in db)
        max_repeat = max(name_repeats.values()) if name_repeats else 0
        
        # Python
        py_ver = sys.version.split()[0]
        
        # LLM status
        llm_status = "⛔ Not configured"
        if LLM_CONFIG.get("api_key"):
            llm_status = f"✅ {LLM_CONFIG.get('model', '?')} → {LLM_CONFIG.get('base_url', '?')}"
            # Live LLM test
            try:
                resp = await call_llm("回應「ok」就好", max_tokens=50)
                if resp is not None:
                    llm_status += " (responsive)"
                else:
                    llm_status += " (no response)"
            except Exception as e:
                llm_status += f" (error: {str(e)[:100]})"
        else:
            llm_status = "⛔ No API key configured"
        
        # Git
        git_info = "not a repo (filesystem boundary)"
        git_dir = Path(__file__).resolve().parent.parent / ".git"
        if git_dir.exists():
            try:
                import subprocess
                r = subprocess.run(["git", "log", "--oneline", "-1"], capture_output=True, text=True, cwd=str(git_dir.parent))
                if r.returncode == 0:
                    git_info = r.stdout.strip()
            except: pass
        
        # Hermes skills count (from mounted config volume or local)
        hermes_skills = "N/A"
        persona_skills = "N/A"
        for skills_candidate in ["/hermes-config/skills", str(Path.home() / ".hermes/skills")]:
            skills_path = Path(skills_candidate)
            if skills_path.exists() and skills_path.is_dir():
                try:
                    skill_files = list(skills_path.rglob("SKILL.md"))
                    hermes_skills = str(len(skill_files))
                    ps = [s for s in skill_files if "persona" in s.name.lower() or "persona" in str(s.parent).lower()]
                    persona_skills = str(len(ps))
                    break
                except Exception:
                    continue
        
        # QA
        qa_lines = []
        try:
            qa_script = Path(__file__).resolve().parent.parent / "qa_validate.py"
            if qa_script.exists():
                import subprocess
                r = subprocess.run([sys.executable, str(qa_script)], capture_output=True, text=True, cwd=str(qa_script.parent), timeout=30)
                if r.returncode == 0:
                    qa_lines = r.stdout.splitlines()[-6:]
                else:
                    qa_lines = ["❌ QA FAILED"]
        except subprocess.TimeoutExpired:
            qa_lines = ["⏱️ QA timeout"]
        except Exception as e:
            qa_lines = [f"❌ QA error: {e}"]
        
        # File artifacts
        tools_dir = Path(__file__).resolve().parent.parent
        py_files = list(tools_dir.glob("*.py")) + list(tools_dir.glob("api/*.py"))
        
        # ── Build output ──
        L(f"Persona DB Status")
        L(f"{'='*50}")
        L(f"")
        L(f"  Version         {version}")
        L(f"  Main personas   {p_count} (tw_persona_1069.json, {json_size})")
        L(f"  Backup          {'✅' if backup_ok else '❌'} {p_count} (tw_persona_1069_backup.json)")
        L(f"  QA (23 rules)   {'✅ ALL CHECKS PASSED' if qa_lines and 'PASSED' in qa_lines[-1] else '⏳ check below'}")
        L(f"  Name diversity  {name_count} unique names ({name_pct}%), max repeat {max_repeat}×")
        L(f"  Python          {py_ver}")
        L(f"  Git             {git_info}")
        L(f"  LLM             {llm_status}")
        L(f"  Hermes Skills   {hermes_skills} total, {persona_skills} persona-related")
        L(f"")
        L(f"  📁 Supporting Artifices: {len(py_files)} Python files")
        L(f"")
        if qa_lines:
            L(f"  QA Results:")
            for ql in qa_lines:
                if ql.strip():
                    L(f"    {ql.strip()}")
        
        return PlainTextResponse("\n".join(lines))
    
    except Exception as e:
        logger.exception("Status endpoint error")
        return PlainTextResponse(f"Error: {str(e)}", status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.server:app", host="0.0.0.0", port=8000, reload=True)
