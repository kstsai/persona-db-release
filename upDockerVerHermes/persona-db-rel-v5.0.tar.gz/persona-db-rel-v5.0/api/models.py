"""
models.py — Pydantic models for Persona DB API (LLM-powered).
"""

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class OpMode(str, Enum):
    FILTER_ONLY = "僅篩選"
    FILTER_AND_SIMULATE = "篩選+模擬"


class CandidatesRequest(BaseModel):
    questions: list[str] = Field(..., min_length=1, description="模擬問題列表（至少 1 題）")
    top_k: int = Field(default=12, ge=1, le=20, description="最多回傳 persona 數量")
    opMode: OpMode = Field(default=OpMode.FILTER_ONLY, description="操作模式")


class DimensionSummary(BaseModel):
    dim: str = Field(..., description="維度名稱")
    values: list[str] = Field(..., description="該維度中重要的取值")


class LLMAnalysis(BaseModel):
    domain: str = Field(default="", description="LLM 判斷的領域")
    reasoning: str = Field(default="", description="判斷理由")
    question_analysis: list[dict] = Field(default=[], description="各題分析")
    usage_suggestion: Optional[dict] = Field(default=None, description="LLM 建議的用法")


class SimulationAnswer(BaseModel):
    question: str = Field(..., description="問題")
    answer: str = Field(..., description="模擬回答")


class PersonaSimulation(BaseModel):
    status: str = Field(..., description="模擬狀態: completed/failed/limited")
    answers: list[str] = Field(default=[], description="每個問題的回答（純文字）")


class PersonaBrief(BaseModel):
    id: str = Field(..., description="Persona ID")
    name: str = Field(..., description="姓名")
    dimensions: dict = Field(..., description="維度資料")
    prompt_prefix: str = Field(default="", description="角色扮演 prompt")
    reference_pre_prompt: str = Field(default="", description="結構化摘要")
    simulation: Optional[PersonaSimulation] = Field(default=None, description="LLM 模擬結果")


class PersonaSummary(BaseModel):
    id: str = Field(..., description="Persona ID")
    name: str = Field(..., description="姓名")
    age: str = Field(..., description="年齡層")
    occupation: str = Field(default="", description="職業")
    income: str = Field(default="", description="個人月收入")
    family_income: str = Field(default="", description="家庭可支配所得")
    residence: str = Field(default="", description="居住地")
    family_size: str = Field(default="", description="家庭人數")
    city_price_tier: str = Field(default="", description="城市物價分級（依居住地，非個人）")
    commute_mode: str = Field(default="", description="通勤方式")
    housing_cost: str = Field(default="", description="居住支出")
    housing_burden: str = Field(default="", description="居住負擔率")
    clothing_spend: str = Field(default="", description="服飾消費")
    aesthetic_procedure: str = Field(default="", description="醫美療程經歷（近12個月，ISAPS 2024）")
    score: float = Field(default=0.0, description="相關性分數（log-frequency × cross-dim 正規化，越高越符合）")


class CandidatesResponse(BaseModel):
    status: str = "ok"
    total_matched: int = Field(..., description="符合條件的總筆數")
    persona_ids: list[int] = Field(..., description="符合條件的 persona ID 列表")
    # Full details removed. Use summary table instead.
    summary: list[PersonaSummary] = Field(default=[], description="摘要表格（取代完整 persona 詳細資料）")
    important_dimensions: list[DimensionSummary] = Field(default=[], description="重要維度")
    llm_analysis: Optional[LLMAnalysis] = Field(default=None, description="LLM 對問題的分析（含 reasoning）")
    relaxed_dims: list[str] = Field(default=[], description="因 broadening 被放寬移除的維度（空 = 未放寬）")
    broadening_attempts: list[dict] = Field(default=[], description="broadening loop 過程（loop/change/match_count_before/match_count_after）")
    applied_filters: dict = Field(default={}, description="實際用於篩選的 filters（LLM 產出，含 broadening 後）")
    scoring_basis: Optional[dict] = Field(default=None, description="scoring 演算法說明（method/weight_source/dims_counted/relaxed_dims_scored_at）")


class DetailRequest(BaseModel):
    persona_id: str = Field(..., description="Persona ID (TW-P-XXXX 或數字)")


class PersonaDetail(BaseModel):
    id: str
    name: str
    type: str = "虛構人設"
    dimensions: dict
    prompt_prefix: str
    reference_pre_prompt: str


class DetailResponse(BaseModel):
    status: str = "ok"
    persona: PersonaDetail


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    persona_count: int
    db_loaded: bool


class ErrorResponse(BaseModel):
    status: str = "error"
    error: dict


class ErrorDetail(BaseModel):
    code: str
    message: str
    details: str = ""
