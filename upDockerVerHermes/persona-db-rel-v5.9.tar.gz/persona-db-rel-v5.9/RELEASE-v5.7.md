# Persona DB v5.7 Release Notes

> 日期: 2026-09-14 | 上一版: v5.6 | 類型: **回應維度完備性**（#53）+ **靜默篩選修復**（#54）
> 來源: 第七輪跨版本驗證報告 §4.5（`qa-reports/round7-v5.6-nodeA-upstreamrunner/`）

## 修的 issue

| # | 標題 | 修法 |
|---|------|------|
| **#53** | `summary` 缺 7 個可篩維度（含 `region`）→ 消費端無法驗證 filter 是否生效 | `PersonaSummary` 補 `sex` / `region` / `education` / `marriage` / `hobby`（`list[str]`）/ `politics` / `media_diet`；`hobby` 型別 coerce |
| **#54** | `housing_cost`：prompt 明文指示使用、code 卻靜默丟棄 | `valid_dims` 補上 `housing_cost`（恢復 prompt 與 RFC 已宣告的篩選能力） |
| 配套 | 防止再次漂移 | 新增 `scripts/check_response_schema.py`（三集合一致性守門）+ `do-release.sh` Step 0f |

## ⚠️ 給消費者的兩個變更

### 1. `summary` 新增 7 個欄位（純新增、向後相容）

`model_dump()` key 集合 **17 → 24**（既有欄位名稱與型別完全不變）：

```
sex, region, education, marriage, hobby(list[str]), politics, media_diet
```

**不變式（v5.7 起）**：**`valid_dims ⊆ summary`** —— 凡可被篩選的維度，回應中都看得到。可據此驗證 filter 是否真的生效；`politics` / `media_diet` 為「可篩、可見、**不計分**」。

### 2. `housing_cost` 篩選開始生效（**行為變更，可能使結果變窄**）

先前 prompt 指示 LLM 使用 `housing_cost`（並列出有效值），但 `valid_dims` 漏列 → 該 filter 被**靜默丟棄**。

**實測（本版 e2e 4 案例）**：修好後 `housing_cost` 在 **2/4 案例**進入 `applied_filters`（例：康是美 → `['5千~1.5萬','1.5萬~3萬']`）。
→ 意味**消費類查詢的候選名單會比 v5.6 更窄且更貼題**（過去缺了這道篩選）。

> 這是**恢復原宣告能力**，非新增功能；但因為它確實改變結果，特別標明。若發現結果過窄，請回報——可改為調整 prompt 而非移除能力。

## 驗證

| 層 | 結果 |
|---|---|
| 單元（決定性） | `test_v5_7_fixes.py` **27 項全過**；v5.4 / v5.5 / v5.6 三套件回歸綠 |
| 守門腳本 | `check_response_schema.py` 正/反測試皆如預期（注入缺口 → exit 1 並指名維度） |
| 真 LLM e2e（4 案例） | **4/4 HTTP 200、FAILED 0**；7 個新欄位齊備且非空、`hobby` 皆為 list、applied ↔ returned 一致（`sex` / `marriage` / `education`）、#34 業主回歸通過 |
| Release gate | `check_dim_weights.py` + `check_response_schema.py` 皆 pass；tarball 潔淨；tag → HEAD 一致 |

## 出貨前守門（新增）

```
Step 0e  check_dim_weights.py     — dim_weights.json 新鮮度 + valid_dims ⊆ SCORED_DIMS
Step 0f  check_response_schema.py — valid_dims ⊆ summary 且 SCORED_DIMS ⊆ valid_dims（新）
```

兩道守門檢查**相反方向**的兩個不變式：0e 防「能篩但查不到權重」，0f 防「計分但不可篩」與「可篩但不可見」。#54 之所以潛伏，正是因為 0e 只守單向。

## Out of scope

- `politics` / `media_diet` 是否續留 `valid_dims`（產品決策，另案）
- `/detail` 的 `dimensions` 型別化
- #45（`usage_suggestion`）、#38 / #39 / #40（known-limitation）

## 版本鏈

`v5.3 → v5.3.1 → v5.4 → v5.5 → v5.6 → v5.7`
