#!/usr/bin/env python3
"""v5.8 regression tests — #55（失敗 log 帶例外型別）、②（analysis 預算 8000→12000）、
#56（A: 放寬前提供實際約束維度；B: 連續 2 輪空轉即停 + stop_reason）。

決定性、無外部 LLM 呼叫（httpx / endpoint 的 LLM 皆以 fake 替換）。

Run:  python3 scripts/test_v5_8_fixes.py
"""
import sys, os, json, logging, asyncio, re

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FAIL = []
RECORDS = []


class _Capture(logging.Handler):
    def emit(self, record):
        try:
            RECORDS.append((record.levelname, record.getMessage()))
        except Exception:
            pass


logging.basicConfig(level=logging.INFO)
logging.getLogger().addHandler(_Capture())


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import api.llm as llm_mod
from api.llm import (ANALYSIS_MAX_TOKENS, ANALYSIS_RETRY_MAX_TOKENS, analysis_max_tokens_for,
                     BROADEN_PROMPT, _LAST_LLM_META)

llm_mod.LLM_CONFIG["api_key"] = "test-key"

print("=== ② analysis 預算 8000 → 12000（重試仍帶變化）===")
check("pro 基礎預算 = 12000", analysis_max_tokens_for("deepseek-v4-pro") == 12000,
      analysis_max_tokens_for("deepseek-v4-pro"))
check("pro 重試預算 = 18000（≠ 基礎，保留 #46「帶變化」）",
      analysis_max_tokens_for("deepseek-v4-pro", retry=True) == 18000)
check("flash 基礎 = 4000、重試 = 8000",
      analysis_max_tokens_for("deepseek-v4-flash") == 4000
      and analysis_max_tokens_for("deepseek-v4-flash", retry=True) == 8000)
check("無 model（None）→ flash 值", analysis_max_tokens_for(None) == 4000)
check("預算表常數存在且一致",
      ANALYSIS_MAX_TOKENS == {"pro": 12000, "flash": 4000}
      and ANALYSIS_RETRY_MAX_TOKENS == {"pro": 18000, "flash": 8000})
srv = open(os.path.join(ROOT, "api", "server.py")).read()
check("server TOKEN_BUDGET 已同步為 40000（否則 3 輪放寬會靜默降為 2 輪）",
      "TOKEN_BUDGET = 40000" in srv and "tokens_spent = 12000" in srv)
check("預算算術：12000 + 3×8000 ≤ 40000（可容納 3 輪放寬）", 12000 + 3 * 8000 <= 40000)

print("\n=== #55 失敗 log 帶例外型別（空訊息也要能歸因）===")


class _RaisingClient:
    """模擬 httpx：post 時丟出「訊息為空」的例外（真實世界常見於 ReadTimeout）。"""
    def __init__(self, timeout=None, **kw):
        pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def post(self, *a, **k):
        raise TimeoutError("")   # str(e) == "" → 舊版 log 會是空的


def _call_with_client(client_cls, coro_factory):
    orig = llm_mod.httpx.AsyncClient
    llm_mod.httpx.AsyncClient = client_cls
    try:
        return asyncio.new_event_loop().run_until_complete(coro_factory())
    finally:
        llm_mod.httpx.AsyncClient = orig


RECORDS.clear()
_last = json.dumps(_LAST_LLM_META, ensure_ascii=False)
_coro = lambda: llm_mod.call_llm("test", max_tokens=100, return_meta=True)
res = _call_with_client(_RaisingClient, _coro)
msgs = " | ".join(m for _, m in RECORDS)
check("log 含例外型別（TimeoutError）", "TimeoutError" in msgs, msgs[:200])
check("log 含 model 與 max_tokens（可歸因）", "model=" in msgs and "max_tokens=" in msgs, msgs[:200])
check("_LAST_LLM_META 記錄 error_type", _LAST_LLM_META.get("error_type") == "TimeoutError",
      _LAST_LLM_META)
check("_LAST_LLM_META.error 非空（不再只有冒號）", (_LAST_LLM_META.get("error") or "").startswith("TimeoutError"))
check("重試訊息仍存在（attempt 1/3）", "attempt 1/3" in msgs, msgs[:200])


class _RaisingClientWithMsg(_RaisingClient):
    async def post(self, *a, **k):
        raise ValueError("具體錯誤訊息")


RECORDS.clear()
_coro2 = lambda: llm_mod.call_llm("test", max_tokens=100, return_meta=True)
_call_with_client(_RaisingClientWithMsg, _coro2)
msgs2 = " | ".join(m for _, m in RECORDS)
check("非空訊息完整保留（ValueError: 具體錯誤訊息）",
      "ValueError: 具體錯誤訊息" in msgs2, msgs2[:200])

print("\n=== #56 A 約束維度分析（放寬前提供「移除後樣本數」）===")
from api.persona_matcher import dim_constraint_report
import api.server as server_mod
from api.server import _constraint_hint

db = server_mod.load_persona_db()

f_case4 = {"age": ["25-34", "35-44"], "housing_burden": ["低"], "debt_status": ["無"],
           "marriage": ["已婚"], "family_size": ["3", "4"], "housing_cost": ["<5千", "5千~1.5萬"]}
rep = dim_constraint_report(db, f_case4)
dims_reported = [r["dim"] for r in rep]
check("回傳清單非空且依 lift 降冪", bool(rep) and all(
    rep[i]["lift"] >= rep[i + 1]["lift"] for i in range(len(rep) - 1)), rep)
check("★ 復現第八輪結論：housing_cost 不在約束清單（lift = 1.0）",
      "housing_cost" not in dims_reported, dims_reported)
check("housing_burden 為最高倍率（主要約束）",
      dims_reported and dims_reported[0] == "housing_burden", dims_reported[:2])
check("所有回報項 lift > 1.0", all(r["lift"] > 1.0 for r in rep), rep)
check("最多 top_n 筆（預設 4）", len(rep) <= 4, len(rep))
check("空 filters → []", dim_constraint_report(db, {}) == [])
check("無命中（base=0）→ []",
      dim_constraint_report(db, {"region": ["火星區"]}) == [])

hint = _constraint_hint(db, f_case4, 13)
check("hint 含「當前限制條件分析」與實際人數", "當前限制條件分析" in hint and "目前 13 人" in hint, hint[:120])
check("hint 含最高倍率維度的倍率", "housing_burden" in hint and "×" in hint)
check("hint 明確標示「放寬無效」維度（含 housing_cost）",
      "放寬無效" in hint and "housing_cost" in hint, hint[-200:])
check("hint 要求優先放寬最高倍率", "優先放寬倍率最高的" in hint)
check("無報告時 hint 為空字串", _constraint_hint(db, {}, 0) == "")

# v5.8 核心維度排除（#42 一致性）：核心維度不得出現在「優先放寬」清單
f_med = {"aesthetic_procedure": ["有"], "sex": ["女"]}
rep_core = dim_constraint_report(db, f_med)
hint_core = _constraint_hint(db, f_med, 14, core_dims={"aesthetic_procedure"})
check("核心維度不出現在約束倍率清單",
      "`aesthetic_procedure`：" not in hint_core, hint_core[:200])
check("hint 另有「核心維度（已排除，勿放寬）」段",
      "核心維度（已排除，勿放寬）" in hint_core and "aesthetic_procedure" in hint_core, hint_core[-260:])
check("核心維度被排除後仍有其他維度可放寬（清單非空）",
      any(d in hint_core for d in ("sex",)) or len(rep_core) >= 1, hint_core[:200])
hint_nocore = _constraint_hint(db, f_med, 14)
check("不傳 core_dims 時行為與舊版相同（仍列出該維度）",
      "`aesthetic_procedure`：" in hint_nocore, hint_nocore[:200])

print("\n=== #56 A prompt 層 ===")
check("BROADEN_PROMPT 含 {constraint_hint} 佔位符", "{constraint_hint}" in BROADEN_PROMPT)
check("5 個佔位符皆可 format", bool(BROADEN_PROMPT.format(
    match_count=5, target_min=20, current_filters="{}", rare_dims_hint="", constraint_hint="x")))

print("\n=== #56 B 連續 2 輪空轉即停（endpoint 級，fake LLM）===")
TIGHT = {"aesthetic_procedure": ["有"], "sex": ["女"]}   # 實測 14 人（0 < 14 < 20，會進迴圈）
base_n = len(server_mod.filter_personas(db, TIGHT))
check("測試用 filter 集命中數 < TARGET_MIN(20) 且 > 0（才會進迴圈）", 0 < base_n < 20, base_n)
server_mod.app.state.db_loaded = True   # endpoint 以此旗標判斷 DB 是否載入
check("endpoint 前置條件：db_loaded 已設", getattr(server_mod.app.state, "db_loaded", False) is True)


async def _fake_parse_questions_with_llm(q_list, role=None, distribution=None):
    return {"domain": "測試", "reasoning": "r", "question_analysis": [],
            "usage_suggestion": None, "filters": dict(TIGHT), "dim_importance": {}}


_calls = {"n": 0}


async def _fake_call_llm(prompt, temperature=0.2, max_tokens=2000, model_override=None,
                         return_meta=False):
    """broadening：在**既有維度**加入一個資料庫不存在的值 → filters 有變更、命中數不變
    （= 真 no_op，第八輪空轉的成因類型）。"""
    _calls["n"] += 1
    new_f = {k: list(v) for k, v in TIGHT.items()}
    new_f["aesthetic_procedure"] = ["有", f"月球療程{_calls['n']}"]   # 不存在於資料
    return json.dumps({"broadening": f"加入不存在的療程值（第 {_calls['n']} 輪）", "filters": new_f},
                      ensure_ascii=False)


def _run_endpoint(parse_fake, llm_fake):
    orig_parse = server_mod.parse_questions_with_llm
    orig_llm = llm_mod.call_llm
    server_mod.parse_questions_with_llm = parse_fake
    llm_mod.call_llm = llm_fake
    try:
        loop = asyncio.new_event_loop()
        return loop.run_until_complete(
            server_mod.personadb_candidates(questions="測試用問題", top_k=3,
                                            opMode="僅篩選", role=""))
    finally:
        server_mod.parse_questions_with_llm = orig_parse
        llm_mod.call_llm = orig_llm


res_b = _run_endpoint(_fake_parse_questions_with_llm, _fake_call_llm)
check("stop_reason == 'no_op_limit'（而非跑滿 3 輪）",
      res_b.broadening_stop_reason == "no_op_limit", res_b.broadening_stop_reason)
check("僅 2 輪嘗試（第 3 輪被省下）", len(res_b.broadening_attempts) == 2,
      [b.loop for b in res_b.broadening_attempts])
check("兩輪皆標記 no_op 且 filters 有變更",
      all(b.no_op and b.filters_changed for b in res_b.broadening_attempts),
      [(b.no_op, b.filters_changed) for b in res_b.broadening_attempts])
check("loop 編號為 1,2（未出現 3）", [b.loop for b in res_b.broadening_attempts] == [1, 2])
check("broadening LLM 只被呼叫 2 次（省下一次完整呼叫）", _calls["n"] == 2, _calls["n"])


# 對照組：放寬成功 → target_reached
async def _fake_call_llm_loosen(prompt, temperature=0.2, max_tokens=2000, model_override=None,
                                return_meta=False):
    return json.dumps({"broadening": "放寬為僅 sex=女", "filters": {"sex": ["女"]}}, ensure_ascii=False)


_calls["n"] = 0
res_c = _run_endpoint(_fake_parse_questions_with_llm, _fake_call_llm_loosen)
check("對照組：放寬成功 → stop_reason == 'target_reached'",
      res_c.broadening_stop_reason == "target_reached", res_c.broadening_stop_reason)
check("對照組：total_matched ≥ 20", (res_c.total_matched or 0) >= 20, res_c.total_matched)

print("\n=== 契約（OpenAPI / 向後相容）===")
from api.models import CandidatesResponse
sch = CandidatesResponse.model_json_schema()["properties"]["broadening_stop_reason"]
check("OpenAPI 有 enum（codegen 可見）", "enum" in sch and "no_op_limit" in sch.get("enum", []),
      sch.get("enum"))
check("預設為空字串（未進入迴圈）", sch.get("default") == "", sch.get("default"))
r0 = CandidatesResponse(status="ok", total_matched=1, persona_ids=[1])
check("未帶該欄位仍可建構（向後相容）", r0.broadening_stop_reason == "")
try:
    CandidatesResponse(status="ok", total_matched=1, persona_ids=[1], broadening_stop_reason="bogus")
    check("非法值被擋", False)
except Exception:
    check("非法值被擋（Literal）", True)

print("\n" + "=" * 60)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
