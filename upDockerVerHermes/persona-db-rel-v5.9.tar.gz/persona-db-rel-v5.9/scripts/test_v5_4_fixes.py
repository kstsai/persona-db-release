#!/usr/bin/env python3
"""Regression tests for v5.4 (issues #42 / #43 / #44) — code-level, no LLM calls.

Run:  python3 scripts/test_v5_4_fixes.py
"""
import sys, os, json, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
logging.basicConfig(level=logging.WARNING)

FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


print("=== #42 稀有維度提示：rescue-only ===")
from api.server import _rare_dims_hint, _is_overshoot
from api.persona_matcher import load_persona_db

db = load_persona_db()
# aesthetic_procedure=['有'] 覆蓋 16/1069 = 1.5%
rare_filter = {"aesthetic_procedure": ["有"]}

hint_zero = _rare_dims_hint(db, rare_filter, reinforced_dims=set(), matched_count=0)
check("matched=0 → 提示生效（救援路徑保留）", "aesthetic_procedure" in hint_zero, hint_zero[:80])
check("matched=0 提示含「必須說明理由」的強制句", "必須在 `change` 明確寫出" in hint_zero)
check("matched=6 → 提示為空（rescue-only）", _rare_dims_hint(db, rare_filter, reinforced_dims=set(), matched_count=6) == "")
check("matched=1 → 提示為空", _rare_dims_hint(db, rare_filter, reinforced_dims=set(), matched_count=1) == "")

print("\n=== #42 核心性排除（domain reinforcement 來源）===")
debt_filter = {"debt_status": ["有房貸", "房貸+消費債"]}   # 覆蓋 (38+5)/1069 = 4.0% < 5%
check("debt_status 非 reinforcement → matched=0 時出現", "debt_status" in _rare_dims_hint(db, debt_filter, matched_count=0))
check("debt_status 來自 reinforcement → 排除", "debt_status" not in _rare_dims_hint(db, debt_filter, reinforced_dims={"debt_status"}, matched_count=0))
mixed = {"debt_status": ["有房貸"], "aesthetic_procedure": ["有"]}
h = _rare_dims_hint(db, mixed, reinforced_dims={"debt_status"}, matched_count=0)
bullets = h.split("\n\n**若你決定放寬")[0]   # 只檢查清單段（尾段是引導句，含舉例的維度名）
check("混合情境只排除 reinforced 的那個", ("aesthetic_procedure" in bullets) and ("debt_status" not in bullets), bullets[:160])
check("常見維度永不提示", _rare_dims_hint(db, {"sex": ["女"]}, matched_count=0) == "")

print("\n=== #42 overshoot 判定 ===")
check("45 > 40 → overshoot", _is_overshoot(45, 20) is True)
check("40 → 不是 overshoot（邊界，嚴格大於）", _is_overshoot(40, 20) is False)
check("41 → overshoot", _is_overshoot(41, 20) is True)
check("19 → 不是 overshoot", _is_overshoot(19, 20) is False)
check("source 內 broadening_attempts 帶 overshoot 欄位",
      '"overshoot": overshoot' in open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "api", "server.py")).read())

print("\n=== #43 response 欄位（returned / pool_exhausted）===")
from api.models import CandidatesResponse, PersonaSummary

r_empty = CandidatesResponse(status="too_strict", total_matched=0, persona_ids=[], returned=0, pool_exhausted=True)
check("0-match 回應可帶 returned/pool_exhausted", r_empty.returned == 0 and r_empty.pool_exhausted is True)
r = CandidatesResponse(status="ok", total_matched=5, persona_ids=[1], summary=[
    PersonaSummary(id="TW-P-0001", name="測試", age="35-44", score=1.0)], returned=1, pool_exhausted=True)
d = json.loads(r.model_dump_json())
check("序列化含 returned", d.get("returned") == 1, d.get("returned"))
check("序列化含 pool_exhausted", d.get("pool_exhausted") is True)
check("預設值安全（既有 client 不因缺欄位壞掉）", CandidatesResponse(status="ok", total_matched=0, persona_ids=[]).returned == 0)
src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "api", "server.py")).read()
check("正常回傳路徑填 returned=len(summary)", "returned=len(summary)" in src)
check("正常回傳路徑填 pool_exhausted", "pool_exhausted=(len(matched) < top_k)" in src)

print("\n=== #44 scoring_basis 分數可溯性 ===")
check("source 含 weight_version", '"weight_version"' in src)
check("source 含 score_scale", '"score_scale": "relative-within-version"' in src)
check("source 含 score_schema", '"score_schema"' in src)
from api.persona_matcher import load_dim_weights, load_dim_weights_meta
meta = load_dim_weights_meta()
check("權重表有 _meta.version（weight_version 的來源）", bool(meta.get("version")), meta.get("version"))
check("load_dim_weights_meta() 回傳的版本 == VERSION（#41 的新鮮度保證）",
      meta.get("version") == open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "VERSION")).read().strip(),
      f"{meta.get('version')} vs VERSION")
check("load_dim_weights() 仍剝掉 _meta（計分只看得到維度，回歸護欄）",
      "_meta" not in load_dim_weights())

print("\n=== BROADEN_PROMPT 強制理由（#42 prompt 層）===")
from api.llm import BROADEN_PROMPT
check("prompt 含「為何它不是本問題的核心條件」", "為何它不是本問題的核心條件" in BROADEN_PROMPT)
try:
    BROADEN_PROMPT.format(match_count=5, target_min=20, current_filters="{}", rare_dims_hint="", constraint_hint="")
    check("BROADEN_PROMPT.format 參數仍可用（4 個）", True)
except Exception as e:
    check("BROADEN_PROMPT.format 參數仍可用（4 個）", False, repr(e))

print("\n" + "=" * 60)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
