#!/usr/bin/env python3
"""v5.7 regression tests — #53（summary 維度完備性）+ #54（housing_cost 靜默丟棄）。
決定性、無外部 LLM 呼叫。

Run:  python3 scripts/test_v5_7_fixes.py
"""
import sys, os, json, subprocess

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FAIL = []
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

NEW_DIMS = ["sex", "region", "education", "marriage", "hobby", "politics", "media_diet"]
EXPECTED_KEYS = {
    "id", "name", "age", "occupation", "income", "family_income", "residence", "family_size",
    "city_price_tier", "commute_mode", "housing_cost", "housing_burden", "clothing_spend",
    "aesthetic_procedure", "debt_status", "employment_status", "score",
} | set(NEW_DIMS)


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


print("=== #53 PersonaSummary 補齊 7 個可篩維度 ===")
from api.models import PersonaSummary

d = PersonaSummary(id="TW-P-0001", name="測試", age="35-44").model_dump()
check("model_dump() key 集合 = 原 17 + 7（共 24）", set(d.keys()) == EXPECTED_KEYS,
      f"缺={EXPECTED_KEYS - set(d.keys())} 多={set(d.keys()) - EXPECTED_KEYS}")
for k in NEW_DIMS:
    check(f"欄位存在：{k}", k in d)
check("hobby 為 list（預設 []）", d["hobby"] == [] and isinstance(d["hobby"], list), d.get("hobby"))
check("其餘 6 個新欄位為 str（預設 ''）",
      all(isinstance(d[k], str) and d[k] == "" for k in NEW_DIMS if k != "hobby"),
      {k: d[k] for k in NEW_DIMS if k != "hobby"})
check("既有 17 個 key 與型別不變（純新增）", isinstance(d["age"], str) and isinstance(d["score"], float))

print("\n=== #53 hobby coerce（不假設型別）===")
from api.server import _as_list
check("list 原樣", _as_list(["打電動", "追劇"]) == ["打電動", "追劇"])
check("單一字串 → 包成單元素 list", _as_list("逛街購物") == ["逛街購物"])
check("None → []", _as_list(None) == [])
check("空字串 → []", _as_list("") == [])
check("list 內含空值 → 過濾", _as_list(["爬山", "", None]) == ["爬山"])
check("非預期型別（int）→ 包成字串 list", _as_list(5) == ["5"])

print("\n=== #54 housing_cost 可篩（prompt 已指示使用）===")
import re
matcher = open(os.path.join(ROOT, "api", "persona_matcher.py")).read()
vd = re.search(r"valid_dims\s*=\s*\{(.*?)\}", matcher, re.S).group(1)
valid_dims = set(re.findall(r'"([a-z_]+)"', vd))
check("housing_cost ∈ valid_dims", "housing_cost" in valid_dims, sorted(valid_dims))
check("housing_burden（姊妹維度）仍在", "housing_burden" in valid_dims)
check("valid_dims 共 20 個", len(valid_dims) == 20, len(valid_dims))
from api.persona_matcher import llm_filters_to_dimension_filters
out = llm_filters_to_dimension_filters({"filters": {"housing_cost": ["1.5萬~3萬"], "sex": ["女"]}})
check("LLM 的 housing_cost filter 不再被丟棄", out.get("housing_cost") == ["1.5萬~3萬"], out)
check("同批 sex filter 一併保留", out.get("sex") == ["女"], out)
# 反向：不在 valid_dims 的維度仍應被擋（確認沒有把守門整個打開）
out2 = llm_filters_to_dimension_filters({"filters": {"city_price_tier": ["高"], "sex": ["女"]}})
check("非可篩維度仍被擋（city_price_tier）", "city_price_tier" not in out2 and out2.get("sex") == ["女"], out2)

print("\n=== #53 守門腳本 check_response_schema.py ===")
guard = os.path.join(ROOT, "scripts", "check_response_schema.py")
r = subprocess.run(["python3", guard, ROOT], capture_output=True, text=True)
check("正常狀態 exit 0", r.returncode == 0, r.stdout[-300:])
check("輸出含三集合計數", "valid_dims（可篩）" in r.stdout and "SCORED_DIMS（計分）" in r.stdout)
# 反向測試：移除一個欄位 → 應 exit 1
ms = os.path.join(ROOT, "api", "models.py")
orig = open(ms).read()
try:
    open(ms, "w").write(orig.replace('    sex: str = Field(default="", description="性別")\n', "", 1))
    r2 = subprocess.run(["python3", guard, ROOT], capture_output=True, text=True)
    check("注入缺口（移除 sex）→ exit 1", r2.returncode == 1, r2.stdout[-200:])
    check("訊息指名缺哪個維度", "sex" in r2.stdout and "可篩但不可見" in r2.stdout, r2.stdout[-300:])
finally:
    open(ms, "w").write(orig)
r3 = subprocess.run(["python3", guard, ROOT], capture_output=True, text=True)
check("還原後 exit 0", r3.returncode == 0, r3.stdout[-200:])

print("\n=== v5.7 do-release 守門已接上 ===")
dr = open(os.path.join(ROOT, "do-release.sh")).read()
check("do-release.sh 含 check_response_schema.py", "check_response_schema.py" in dr)
check("Step 0e 的 check_dim_weights.py 仍保留", "check_dim_weights.py" in dr)

print("\n" + "=" * 60)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
