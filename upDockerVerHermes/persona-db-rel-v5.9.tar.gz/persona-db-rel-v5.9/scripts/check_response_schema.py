#!/usr/bin/env python3
"""檢查「可篩 / 可見 / 計分」三個維度集合的一致性（issue #53）。

不變式：
  1. `valid_dims ⊆ PersonaSummary 可見欄位`   ← 消費端才能驗證 filter 是否生效
  2. `SCORED_DIMS ⊆ valid_dims`               ← 計分維度必須可篩

用法:  python3 scripts/check_response_schema.py [repo_dir]
失敗 exit 1，並指名缺哪個維度、該去哪裡補。

背景：`summary` 的欄位是歷史上逐版本人工追加（aesthetic_procedure / debt_status /
employment_status 皆如此），早期的 sex / region / education / marriage / hobby
從未被加入 → 累積性遺漏（issue #53）。本檢查把「可篩 ⊆ 可見」變成機械守門，
避免再次漂移（同 #41 的 check_dim_weights.py 模式）。
"""
import ast
import os
import re
import sys
from pathlib import Path

# 明示例外：若未來決定某個可篩維度**刻意不**在 summary 揭露，把維度名加進來並註明理由。
# 加這裡＝留痕；改腳本邏輯＝隱藏，兩者不可混。
DOCUMENTED_EXCEPTIONS: dict[str, str] = {}


def _parse_list_literal(src: str, name: str) -> list[str]:
    """從原始碼抓 `NAME = [...]` 的 list literal（用 ast，不用 regex）。"""
    tree = ast.parse(src)
    for node in ast.walk(tree):
        targets = []
        if isinstance(node, ast.Assign):
            targets = node.targets
            value = node.value
        elif isinstance(node, ast.AnnAssign):  # NAME: list[str] = [...]
            targets = [node.target]
            value = node.value
        else:
            continue
        for t in targets:
            tid = t.id if isinstance(t, ast.Name) else (t.attr if isinstance(t, ast.Attribute) else None)
            if tid == name and isinstance(value, (ast.List, ast.Set, ast.Tuple)):
                return [str(e.value) for e in value.elts if isinstance(e, ast.Constant)]
    return []


def _parse_valid_dims(src: str) -> list[str]:
    """`valid_dims` 是函式內的 set literal → 抓 `valid_dims = {...}` 區塊。"""
    m = re.search(r"valid_dims\s*=\s*\{(.*?)\}", src, re.S)
    if not m:
        return []
    return [x for x in re.findall(r"\"([a-z_]+)\"", m.group(1))]


def main() -> int:
    repo = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    matcher_src = (repo / "api" / "persona_matcher.py").read_text()
    weights_src = (repo / "scripts" / "gen_dim_weights.py").read_text()
    models_src = (repo / "api" / "models.py").read_text()

    valid_dims = set(_parse_valid_dims(matcher_src))
    scored_dims = set(_parse_list_literal(weights_src, "SCORED_DIMS"))
    unscored_filterable = set(_parse_list_literal(weights_src, "UNSCORED_FILTERABLE_DIMS"))

    # summary 可見欄位（用 ast 解析 PersonaSummary 的 class body）
    tree = ast.parse(models_src)
    summary_fields: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == "PersonaSummary":
            for st in node.body:
                if isinstance(st, ast.AnnAssign) and isinstance(st.target, ast.Name):
                    summary_fields.add(st.target.id)
    non_dim_fields = {"id", "name", "score"}
    summary_dims = summary_fields - non_dim_fields

    print("check_response_schema — 可篩 / 可見 / 計分 一致性（issue #53）")
    print(f"  valid_dims（可篩）      : {len(valid_dims)}")
    print(f"  PersonaSummary（可見）  : {len(summary_dims)} 個維度 + {sorted(non_dim_fields)}")
    print(f"  SCORED_DIMS（計分）     : {len(scored_dims)}")
    print(f"  UNSCORED_FILTERABLE_DIMS: {sorted(unscored_filterable)}")

    problems: list[str] = []

    missing = sorted(valid_dims - summary_dims - set(DOCUMENTED_EXCEPTIONS))
    if missing:
        problems.append(
            f"可篩但不可見的維度（{len(missing)}）: {missing}\n"
            f"    → 補進 api/models.py 的 PersonaSummary + api/server.py 的 summary builder，"
            f"或加入本腳本的 DOCUMENTED_EXCEPTIONS 並註明理由"
        )
    if DOCUMENTED_EXCEPTIONS:
        print(f"  明示例外（刻意不揭露）: {DOCUMENTED_EXCEPTIONS}")

    not_filterable = sorted(scored_dims - valid_dims)
    if not_filterable:
        problems.append(
            f"計分但不可篩的維度（{len(not_filterable)}）: {not_filterable}\n"
            f"    → 計分維度必須同時可篩（見 api/persona_matcher.py 的 valid_dims）"
        )

    listed = sorted(unscored_filterable - valid_dims)
    if listed:
        problems.append(f"UNSCORED_FILTERABLE_DIMS 內含非可篩維度: {listed}（清單應為 valid_dims 的子集）")

    if problems:
        print("\n❌ 檢查失敗:")
        for p in problems:
            print("  - " + p)
        return 1

    print(f"\n✅ check_response_schema OK（可篩 {len(valid_dims)} ⊆ 可見 {len(summary_dims)}；"
          f"計分 {len(scored_dims)} ⊆ 可篩）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
