#!/usr/bin/env python3
"""v5.6 regression tests — #50：`finish_reason` 可診斷性（call_llm return_meta +
截斷警告）。決定性、無外部 LLM 呼叫（httpx 以 fake client 替換）。

Run:  python3 scripts/test_v5_6_fixes.py
"""
import sys, os, json, logging, asyncio

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FAIL = []
RECORDS = []


class _Capture(logging.Handler):
    def emit(self, record):
        RECORDS.append((record.levelname, record.getMessage()))


logging.basicConfig(level=logging.WARNING)
logging.getLogger().addHandler(_Capture())


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


from typing import cast
import api.llm as llm_mod
from api.llm import _llm_result, _LAST_LLM_META, ANALYSIS_MAX_TOKENS
BASE_TOK = ANALYSIS_MAX_TOKENS['pro']   # v5.8: 12000

_ORIG_KEY = llm_mod.LLM_CONFIG.get("api_key")
llm_mod.LLM_CONFIG["api_key"] = "test-key"


class _FakeResp:
    def __init__(self, payload):
        self._payload = payload

    def raise_for_status(self):
        pass

    def json(self):
        return self._payload


def _patch_httpx(payload):
    class _FakeClient:
        def __init__(self, timeout=None, **kw):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            return False

        async def post(self, *a, **k):
            return _FakeResp(payload)

    orig = llm_mod.httpx.AsyncClient
    llm_mod.httpx.AsyncClient = _FakeClient
    return orig


def _payload(content, reasoning="", finish_reason="stop"):
    return {
        "choices": [{"message": {"content": content, "reasoning_content": reasoning},
                     "finish_reason": finish_reason}],
        "usage": {"prompt_tokens": 100, "completion_tokens": 50},
    }


print("=== #50 `_llm_result` 行為 ===")
check("return_meta=False → 純字串（既有呼叫端不受影響）", _llm_result("abc", False) == "abc")
t, m = cast(tuple, _llm_result("abc", True, {"finish_reason": "stop"}))
check("return_meta=True → (text, meta)", t == "abc" and m["finish_reason"] == "stop", (t, m))
t2, m2 = cast(tuple, _llm_result(None, True, {"finish_reason": "length"}))
check("None 也可帶 meta", t2 is None and m2["finish_reason"] == "length", (t2, m2))

print("\n=== #50 call_llm：截斷（content 非空）===")
RECORDS.clear()
orig = _patch_httpx(_payload("我们需要回答用户。需要分析问题列表……但输出 filters ", finish_reason="length"))
try:
    out = asyncio.run(llm_mod.call_llm("測試 prompt", max_tokens=8000, model_override="deepseek-v4-pro"))
finally:
    llm_mod.httpx.AsyncClient = orig
check("content 非空 → 仍回傳內容（維持既有行為）", isinstance(out, str) and out.startswith("我们需要回答"), repr(out)[:60])
warns = [m for lvl, m in RECORDS if lvl == "WARNING"]
check("**新增**：content 非空但被截斷 → WARNING 記錄（過去完全沒有）",
      any("content 非空但被截斷" in m and "finish_reason=length" in m for m in warns), warns)
check("警告含 model 與 max_tokens（可判斷是否為預算不足）",
      any("max_tokens=" in m and "deepseek-v4-pro" in m for m in warns), warns)

print("\n=== #50 call_llm：return_meta=True ===")
orig = _patch_httpx(_payload("推理文字沒有 JSON", finish_reason="length"))
try:
    res = asyncio.run(llm_mod.call_llm("測試 prompt", max_tokens=8000, model_override="deepseek-v4-pro",
                                       return_meta=True))
finally:
    llm_mod.httpx.AsyncClient = orig
check("回傳 tuple (text, meta)", isinstance(res, tuple) and len(res) == 2, type(res))
text, meta = res
check("meta.finish_reason == 'length'", meta.get("finish_reason") == "length", meta)
check("meta.truncated is True", meta.get("truncated") is True, meta)
check("meta 含 model / max_tokens / usage", all(k in meta for k in ("model", "max_tokens", "usage")), meta)
check("_LAST_LLM_META 同步更新（供未用 return_meta 的路徑診斷）",
      _LAST_LLM_META.get("finish_reason") == "length", _LAST_LLM_META)

print("\n=== #50 其他路徑不破壞（空 content / reasoning 挖掘 / 真失敗）===")
# (a) content 空、reasoning 有 JSON → D3 提取，meta 仍帶回
orig = _patch_httpx(_payload("", reasoning='前置說明 {"filters": {"sex": ["女"]}} 後置', finish_reason="stop"))
try:
    r = asyncio.run(llm_mod.call_llm("p", max_tokens=1000, return_meta=True))
finally:
    llm_mod.httpx.AsyncClient = orig
check("D3 reasoning 挖掘仍有效且帶 meta", isinstance(r, tuple) and r[1].get("finish_reason") == "stop"
      and "sex" in (r[0] or ""), str(r)[:80])
# (b) content 空、reasoning 空、finish_reason=stop → None + meta
orig = _patch_httpx(_payload("", reasoning="", finish_reason="stop"))
try:
    r2 = asyncio.run(llm_mod.call_llm("p", max_tokens=1000, return_meta=True))
finally:
    llm_mod.httpx.AsyncClient = orig
check("真失敗（非截斷）→ (None, meta) 且 meta.finish_reason=stop", r2[0] is None and r2[1].get("finish_reason") == "stop", r2)
# (c) 預設不帶 return_meta → 純值（其他呼叫端回歸）
orig = _patch_httpx(_payload("", reasoning="", finish_reason="stop"))
try:
    r3 = asyncio.run(llm_mod.call_llm("p", max_tokens=1000))
finally:
    llm_mod.httpx.AsyncClient = orig
check("預設 return_meta=False 時回傳不是 tuple（既有呼叫端回歸）", not isinstance(r3, tuple), type(r3))

print("\n=== #50 parser WARNING 帶 finish_reason ===")
RECORDS.clear()


async def _stub_truncated(prompt, temperature=0.2, max_tokens=None, model_override=None, return_meta=False):
    payload = ("我們需要分析……但輸出 filters ", {"finish_reason": "length", "truncated": True,
                                                "model": "deepseek-v4-pro", "max_tokens": max_tokens, "usage": {}})
    return payload if return_meta else payload[0]


_orig_call = llm_mod.call_llm
llm_mod.LLM_CONFIG["analysis_model"] = "deepseek-v4-pro"
llm_mod.call_llm = _stub_truncated
try:
    out = asyncio.run(llm_mod.parse_questions_with_llm(["時尚服裝設計師的目標客戶"]))
finally:
    llm_mod.call_llm = _orig_call
warns = [m for lvl, m in RECORDS if lvl == "WARNING"]
errs = [m for lvl, m in RECORDS if lvl == "ERROR"]
check("解析失敗 WARNING 含 finish_reason=length 與 truncated=True",
      any("finish_reason=length" in m and "truncated=True" in m for m in warns), warns)
check("WARNING 含 attempt 與 max_tokens", any("attempt 1/2" in m and f"max_tokens={BASE_TOK}" in m for m in warns), warns)
check("放棄時 ERROR 也帶 finish_reason", any("finish_reason=length" in m for m in errs), errs)
check("仍回空 dict（交給 keyword fallback）", out == {}, out)

print("\n=== #50 兼容舊 stub（非 tuple 回傳）===")
async def _stub_plain(prompt, temperature=0.2, max_tokens=None, model_override=None, return_meta=False):
    return json.dumps({"filters": {"sex": ["女"]}, "question_analysis": {}, "dim_importance": {}})


llm_mod.call_llm = _stub_plain
try:
    out2 = asyncio.run(llm_mod.parse_questions_with_llm(["康是美的目標客戶"]))
finally:
    llm_mod.call_llm = _orig_call
check("非 tuple 回傳不炸且能解析", out2.get("filters") == {"sex": ["女"]}, out2)

if _ORIG_KEY is not None:
    llm_mod.LLM_CONFIG["api_key"] = _ORIG_KEY

print("\n" + "=" * 60)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
