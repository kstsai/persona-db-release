# T03 — 狀態與錯誤語意（#58 / #59）

> Spec: `specs/2026-09-14-v5.9-core-dim-protection.md` | Blocked by: T02（`stop_reason` 值域一起定案）
> 檔案: `api/server.py`、`api/llm.py`、`api/models.py`

## 變更

1. **`status` 修正（#58）**：`matched == 0` 一律不得為 `'ok'`
   ```python
   status = "too_strict" if not matched else ("ok" if len(matched) >= TARGET_MIN else "ok")
   ```
   即移除 `loop >= max_loops` 條件（送出的 0 筆就是 0 筆，不因提早停止而變 `'ok'`）
2. **503 兩型態（#59）**：`api/llm.py` 記錄分析狀態，供 server 判讀
   - `llm.py` 新增 `_LAST_ANALYSIS_STATUS` + `last_analysis_status()`：
     - `{"status": "ok"}`：LLM 回應且有 filters
     - `{"status": "no_filters", "detail": ...}`：LLM 回應但產不出 filter
     - `{"status": "call_failed", "detail": <error_type/message>}`：LLM 呼叫失敗
   - `server.py` 的 503 依狀態給不同 `message` / `details` / `retryable`：
     | status | message | details | retryable |
     |:--|:--|:--|:--|
     | `call_failed` | 「LLM 呼叫失敗，無法分析問題」 | 檢查 API key / model / 連線（附 error_type） | `true` |
     | `no_filters` | 「問題過於籠統，無法產出篩選條件」 | 換更具體的問法（例：加上產業/族群/目的） | `false` |
3. **不可達列舉值（#59）**：`broadening_stop_reason` 的 `Literal` 移除 `""`；`budget_limit` 保留為防護性欄位

## Acceptance criteria

- [ ] `matched=0`（含 `no_op_limit` 提早停止）→ `status != 'ok'`
- [ ] 一般案例（`matched ≥ 1`）→ `status` 行為不變
- [ ] 假 LLM 注入「呼叫失敗」→ 503 message 指向金鑰/連線、`retryable=True`
- [ ] 假 LLM 注入「回應但無 filter」→ 503 message 指向「問題籠統/換問法」、`retryable=False`
- [ ] 兩者皆為統一 `ErrorResponse` 形狀（#47 不回歸）
- [ ] `broadening_stop_reason` 的 Literal 不含 `""`、含 `protected_veto`
- [ ] `py_compile` + `bash -n` pass

## 驗收指令

```bash
python3 scripts/test_v5_9_fixes.py
```
