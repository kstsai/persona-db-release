# T01 — 保護集三來源（#57）

> Spec: `specs/2026-09-14-v5.9-core-dim-protection.md` | Blocked by: —（無）
> 檔案: `api/server.py`、`api/llm.py`（BROADEN_PROMPT）

## 變更

1. `domain_filters` 擴充為「可對 questions 原文比對」的鍵集合：
   - 新增 `QUERY_SAFE_DOMAIN_KEYS = {"債務","貸款整合","債務協商","卡債","醫美","醫美診所","整形","皮膚科"}`
   - 比對邏輯：`if kw in domain or (kw in QUERY_SAFE_DOMAIN_KEYS and kw in query_text)`
   - **`老闆`/`業主`/`企業主`/`創業`/`自營`/`攤商`/`加盟`/`小生意` 維持只認 domain**（顧客語意歧義，見 #34）
2. 新增 `_reasoning_protected_dims(reasoning: str) -> set[str]`：
   - 依句切分（`。！？；\n`），**只取含必要性標記**（`需使用`/`必須使用`/`需以`/`需考量`/`必須`）的句子
   - 句子中出現的維度名（比對 `valid_dims`）→ 納入保護集
3. `BROADEN_PROMPT` 的輸出 JSON 新增 `protected_dims` 欄位 + 指示：
   - 「若你判斷某些維度是本問題**不可放寬**的核心條件，請列在 `protected_dims`（沒有則給空陣列）」
   - 回覆 schema：`{"broadening": …, "protected_dims": [...], "filters": {...}}`
4. 請求層：`protected = domain_reinforced ∪ reasoning_protected ∪ 迴圈中累積的 protected_dims`

## Acceptance criteria

- [ ] `債務整合的目標客戶`（domain=`金融/銀行/貸款`）→ 保護集**含 `debt_status`**（query-safe 比對生效）
- [ ] `小吃攤老闆的目標客群`（顧客語意）→ 保護集**不含** `employment_status`（歧義鍵只認 domain）
- [ ] reasoning 含「需使用 housing_burden、housing_cost、debt_status、family_income」→ 四個維度全數納入
- [ ] reasoning 為一般敍述（無必要性標記）→ 不納入
- [ ] `BROADEN_PROMPT` 可 format（新增欄位不破壞既有佔位符）且含 `protected_dims` 指示
- [ ] `py_compile` pass

## 驗收指令

```bash
python3 scripts/test_v5_9_fixes.py
```
