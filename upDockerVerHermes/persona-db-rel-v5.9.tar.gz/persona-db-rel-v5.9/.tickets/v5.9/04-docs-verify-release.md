# T04 — 文件 / 驗證 / 進版（v5.9）

> Spec: `specs/2026-09-14-v5.9-core-dim-protection.md` | Blocked by: T01、T02、T03

## 文件

1. **RFC**：
   - 新增「核心維度保護（protected dims）」段：三來源、veto 行為、`protected_dims` 欄位、取捨（回傳數可能更少）
   - `broadening_stop_reason` 表加入 `protected_veto`、移除 `""`、註明 `budget_limit` 為防護性
   - `status` 語意更新（`too_strict` = 無符合樣本，不再依賴輪數）
   - 503 兩型態的 message/details/retryable 對照表
2. **`concepts/relevance-scoring.md`**：契約表補 `protected_dims`
3. **`RELEASE-v5.9.md`**：變更摘要 + 給消費者的行為變更（保護變嚴 → 部分題目回傳數更少）＋ `#42` 升為不變式

## 驗證

1. **單元**：`scripts/test_v5_9_fixes.py`（保護集三來源、veto 三情境、status、503 兩型態、Literal）
2. **回歸**：v5.4/5.5/5.6/5.7/5.8 全套件（含引用常數的斷言）
3. **真 LLM e2e**：
   - 案例 07（債務整合）→ `relaxed_dims` **不含** `debt_status`、`applied_filters` 保留、`protected_dims` 含它
   - 案例 05（房貸/銀行）→ 同上
   - 案例 06（醫美）→ `aesthetic_procedure` 保留
   - 案例 09（業主）→ 語意分流不回歸（`employment_status` 仍套用）
4. **Release gate**：`check_dim_weights.py` + `check_response_schema.py`；`do-release.sh`
5. **SOP**：受測主機（kstsai 指定）fresh deploy → 出貨測試腳本（新增 v5.9 斷言：保護維度不得被移除、`protected_dims` 存在、`status` 於 0 筆時非 ok）

## Acceptance criteria

- [ ] 單元全過；既有套件全綠
- [ ] e2e：債務/銀行案例不再移除 `debt_status`（本版的核心驗收）
- [ ] 兩 gate pass；tarball 潔淨；tag → HEAD 三處一致
- [ ] 出貨測試腳本含 v5.9 斷言並在真實資料上驗證
- [ ] RFC / concepts / RELEASE 同步
- [ ] #57 / #58 / #59 以證據關閉（雙 repo）
