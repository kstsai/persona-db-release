# T02 — 硬性 veto + 回應揭露（#57）

> Spec: `specs/2026-09-14-v5.9-core-dim-protection.md` | Blocked by: T01（需要保護集）
> 檔案: `api/server.py`、`api/models.py`

## 變更

1. 放寬迴圈中，套用 `new_filters` **之前**做 veto 檢查：
   - 對每個受保護維度 `d`：若 `d not in new_filters` → **veto**
   - 或 `d in new_filters` 但其值集**不是**前一組值集的超集（縮小／替換）→ **veto**
   - 允許純新增值（合法放寬）
2. veto 動作：**還原**（`filters` 保持前一組）、該筆 attempt 記 `protected_veto: true` + `vetoed_dims: [...]`，並設 `stop_reason = "protected_veto"` 後 `break`
3. `_constraint_hint(..., core_dims=protected)`：**不得**列出受保護維度的倍率（既有參數，傳入完整保護集）
4. 回應新增 `protected_dims: list[str]`（本請求受保護的維度，排序後輸出）
5. `broadening_stop_reason` 的 `Literal` 新增 `"protected_veto"`、**移除不可達的 `""`**
6. `BroadeningAttempt` 新增可選欄位 `protected_veto: bool = False`、`vetoed_dims: list[str] = []`

## Acceptance criteria

- [ ] 移除受保護維度 → 該輪被還原、`applied_filters` 仍含該維度、attempt 標 `protected_veto`
- [ ] 值集縮小（如 `['中','高']` → `['中']`）→ veto
- [ ] **純新增值**（如 `['中']` → `['中','高']`）→ **不 veto**（正常放寬）
- [ ] veto 後 `stop_reason='protected_veto'` 且迴圈立即結束
- [ ] `protected_dims` 出現在回應且與保護集一致
- [ ] `#42` 的產品行為：案例 07 型態（`debt_status` 為保護維度）不得再出現 `保留=False`
- [ ] 向後相容：未帶 `protected_dims` 的舊回應解析不受影響（純新增）

## 驗收指令

```bash
python3 scripts/test_v5_9_fixes.py
python3 scripts/check_response_schema.py .
```
