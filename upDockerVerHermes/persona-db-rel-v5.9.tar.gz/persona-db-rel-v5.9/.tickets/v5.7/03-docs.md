# T03 — 文件：可篩／可見／計分三者關係 + 契約表（#53）

> Spec: `specs/2026-09-14-v5.7-summary-dimension-completeness.md` | Blocked by: T01（欄位定案）
> Issue: #53 | 檔案: `tw-persona-db-rfc.md`、`concepts/relevance-scoring.md`、`RELEASE-v5.7.md`

## 變更

1. **RFC**：
   - Response 範例補新欄位
   - 新增一節說明**三個集合的關係**：可篩（`valid_dims`）／可見（`summary`）／計分（`SCORED_DIMS`）；並載明不變式 **`valid_dims ⊆ summary`**、以及 `politics`/`media_diet` = 「可篩可見但不計分」
   - 明示 **`/detail` 是「完整維度」的唯一出口**（含未公開的 `background_story` / `political_stance` 等），`summary` 只保證「可篩維度皆可見」
2. **`concepts/relevance-scoring.md`**：回應契約表補 7 個欄位；加一句「`summary` 的可見維度集合由 `check_response_schema.py` 守門」
3. **`RELEASE-v5.7.md`**：變更摘要 + `model_dump()` key 集合變更（17 → 24）+ 給消費者的說明（純新增）

## Acceptance criteria

- [ ] RFC 同時出現「可篩 / 可見 / 計分」三詞與 `valid_dims ⊆ summary` 不變式
- [ ] RFC 明示 `/detail` 為完整維度唯一出口
- [ ] release notes 列出 key 集合變更前後（17 → 24）並聲明純新增
- [ ] 交付 tarball 內（`concepts/` 已含於交付包）文件同步更新

## 驗收指令

```bash
grep -n "valid_dims ⊆ summary" tw-persona-db-rfc.md
grep -n "唯一出口" tw-persona-db-rfc.md
grep -n "17 → 24\|17→24" RELEASE-v5.7.md
```
