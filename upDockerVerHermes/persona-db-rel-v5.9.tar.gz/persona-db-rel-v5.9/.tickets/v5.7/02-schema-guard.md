# T02 — 機械守門 `check_response_schema.py` + 出貨前擋（#53）

> Spec: `specs/2026-09-14-v5.7-summary-dimension-completeness.md` | Blocked by: T01（集合需一致才可能通過）
> Issue: #53 | 檔案: `scripts/check_response_schema.py`（new）、`do-release.sh`

## 變更

1. 新增 `scripts/check_response_schema.py`：
   - 讀 `api/persona_matcher.py` 的 `valid_dims`、`scripts/gen_dim_weights.py` 的 `SCORED_DIMS`、`api/models.py` 的 `PersonaSummary` 欄位集
   - 檢查：① `valid_dims − summary_keys` 為空（或落在明示 `DOCUMENTED_EXCEPTIONS`）② `SCORED_DIMS ⊆ valid_dims` ③ 印出三者集合與差集（可稽核）
   - 失敗 `exit 1`，訊息要指出**缺哪個維度**與**該去哪裡補**
2. `do-release.sh` 新增一步（比照 Step 0e 的 `check_dim_weights.py`）：出貨前跑，失敗即中止

## Acceptance criteria

- [ ] 正常狀態 pass 並印出「可篩 19 / 可見 19 / 計分 18」與空差集
- [ ] **注入假缺口測試**（暫時移除一個 summary 欄位）→ `exit 1` 且訊息指名該維度
- [ ] `SCORED_DIMS ⊄ valid_dims` 時也 `exit 1`（守第二條不變式）
- [ ] `do-release.sh` 含該步驟；`bash -n do-release.sh` pass
- [ ] 支援明示例外清單（未來若決定某維度刻意不外露，改為加註而非改腳本邏輯）

## 驗收指令

```bash
python3 scripts/check_response_schema.py .
bash -n do-release.sh
```
