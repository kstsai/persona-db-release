# T04 — 驗證與進版（v5.7）

> Spec: `specs/2026-09-14-v5.7-summary-dimension-completeness.md` | Blocked by: T01、T02、T03
> Issue: #53

## 步驟

1. **單元**：`scripts/test_v5_7_fixes.py`（7 欄位、`hobby` coerce 三態、`model_dump` key 集合、守門腳本正/反測試）
2. **本機 e2e（真 LLM）**
   - 康是美 → 回傳名單**全部** `sex=女` 且與 `applied_filters` 一致
   - 時尚 → `hobby` 為 list 且與 `applied_filters` 一致
   - 業主案例（`employment_status`）→ 回歸
   - `region` 有值（非空）於全部案例
3. **Release gate**：`check_dim_weights.py` + **`check_response_schema.py`**（新）皆 pass
4. **進版**：`VERSION` / `RELEASE-VERSION` → v5.7；regen `dim_weights.json`（`_meta.version` 同步）；`do-release.sh`
5. **tarball 潔淨驗證** + **tag → HEAD 一致性**
6. **SOP**：受測主機（nodeB / nodeA 由 kstsai 指定）fresh deploy → `test-persona-db-api.sh`（含 v5.7 斷言）→ 逐項判讀

## Acceptance criteria

- [ ] 單元全過；守門腳本正/反測試皆如預期
- [ ] e2e：康是美 `sex` 全一致、時尚 `hobby` 一致、業主案例回歸通過
- [ ] 兩個 gate script pass；`check_dim_weights.py` 的 `_meta.version == v5.7`
- [ ] tarball 無 stray 檔、關鍵檔與驗證過的 tree 逐位元相同
- [ ] SOP：9/9 案例 200、0 traceback、新欄位出現於部署環境
- [ ] #53 以驗證證據關閉（雙 repo 鏡像）
