# T01 — `PersonaSummary` 補 7 個可篩維度（#53）

> Spec: `specs/2026-09-14-v5.7-summary-dimension-completeness.md` | Blocked by: —（無）
> Issue: #53 | 檔案: `api/models.py`、`api/server.py`

## 變更

1. `PersonaSummary` 於 `score` 之前新增（接續既有 append 慣例）：
   - `sex: str`、`region: str`、`education: str`、`marriage: str`、`politics: str`、`media_diet: str`
   - `hobby: list[str]`（**多值**）
2. `server.py` 的 summary builder 填入這 7 欄
3. **`hobby` coerce**：資料為 `list`，但需容忍 `str` / `None`：
   ```python
   _hv = dims.get("hobby")
   hobby = _hv if isinstance(_hv, list) else ([_hv] if _hv else [])
   ```

## Acceptance criteria

- [ ] `PersonaSummary` 欄位 = 原 17 + 7（`model_dump()` key 共 24）
- [ ] 既有 17 個 key 與型別**完全不變**（純新增）
- [ ] `hobby` 為 `list[str]`；`str` 輸入被包成單元素 list；`None` → `[]`
- [ ] 每個新欄位都有 `description`（給 OpenAPI 消費者）
- [ ] `py_compile api/*.py` pass

## 驗收指令

```bash
python3 scripts/test_v5_7_fixes.py
```
