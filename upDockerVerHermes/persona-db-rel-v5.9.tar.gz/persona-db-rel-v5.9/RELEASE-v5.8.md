# Persona DB v5.8 Release Notes

> 日期: 2026-09-14 | 上一版: v5.7 | 類型: **放寬策略改善 + 可觀測性 + 成本調整**
> 來源: 第八輪驗證報告（`qa-reports/round8-v5.7-nodeB-upstreamrunner/`）+ 對應 issue #55 / #56

## 修的 issue

| # | 標題 | 修法 |
|---|------|------|
| **#56 A** | broadening 挑錯維度（空轉率 60%、案例 4 三輪全空轉） | 放寬前**逐維度計數**：計算「移除各維度後的樣本數」，把**真正的約束維度**（倍率）與**放寬無效的維度**一併寫進放寬 prompt |
| **#56 B** | 空轉輪次白費一次完整 LLM 呼叫 | **連續 2 輪空轉即停**；新增 `broadening_stop_reason` 欄位揭露停止原因 |
| **#55** | `LLM call failed: ` 訊息為空，無法歸因 | log 一律帶**例外型別**（`[ReadTimeout]`）＋ model / max_tokens / timeout；`_LAST_LLM_META.error_type` |
| **② 預算** | 3 天內 4 次截斷事件，每次救援 = 一整通額外呼叫 | analysis 基礎預算 **8000 → 12000**（重試 12000 → 18000，保留 #46「帶變化」）；`TOKEN_BUDGET` **32000 → 40000** |

## ⚠️ 行為變更（給消費者）

1. **新增回應欄位 `broadening_stop_reason`**（純新增，向後相容）
   `target_reached` / `no_op_limit` / `loop_limit` / `budget_limit` / `llm_empty` / `llm_parse_error` / `llm_no_filters` / `no_filters`；空字串 = 未進入放寬迴圈。
   呼叫端可據此判讀「為何回傳數 < `top_k`」。
2. **放寬策略更精準**：不再盲目挑維度（例：第八輪案例 4 三輪都放寬 `housing_cost`，而它根本不是約束條件）。預期 `no_op` 空轉率下降、樣本數更快達標。
3. **連續 2 輪空轉即停**：最壞情況下少一次 LLM 呼叫（延遲與成本下降）；**代價**是放棄「第 3 輪可能小幅增益」（第八輪案例 5 第 3 輪 +2 筆），此為 2026-09-14 kstsai 定案接受的取捨。
4. **token 預算提高**：不強迫模型多產生 token（**成本影響≈0**），但截斷導致的重試與其延遲應顯著減少。

## 實作細節

- `api/persona_matcher.py`：`dim_constraint_report()` —— 對每個已套用維度計算移除後樣本數（純本地運算，**無 LLM 成本**），回傳依倍率降冪
- `api/server.py`：`_constraint_hint()` 產生提示文字（含「放寬無效」清單）；`TOKEN_BUDGET` 同步提高；連續空轉計數與停止原因
- `api/llm.py`：`ANALYSIS_MAX_TOKENS` / `ANALYSIS_RETRY_MAX_TOKENS` 常數化（可測）、`BROADEN_PROMPT` 新增 `{constraint_hint}`、失敗 log 帶例外型別
- `api/models.py`：`broadening_stop_reason` 以 `Literal` 宣告（OpenAPI 產生 enum，codegen 可見）

## 驗證

| 層 | 結果 |
|---|---|
| 單元（決定性） | `test_v5_8_fixes.py` **35 項全過**；v5.4 / v5.5 / v5.6 / v5.7 回歸全綠（並改為引用預算常數，未來調預算不再誤報） |
| endpoint 級行為測試 | fake LLM 驅動：連續 2 輪空轉 → `stop_reason=no_op_limit`、`attempts=2`（第 3 輪確實被省下）、broadening LLM 只被呼叫 2 次；對照組放寬成功 → `target_reached` |
| 約束分析復現 | 以第八輪案例 4 的 filter 集實測：**`housing_cost` lift = 1.0（不在約束清單）**、`housing_burden` 3.13× 最高 → **與報告結論一致** |
| 契約 | OpenAPI enum 可見、預設空字串、非法值被擋、未帶欄位仍可建構 |
| Release gate | `check_dim_weights.py` + `check_response_schema.py` 皆 pass |
| 真 LLM e2e | 見下方（v5.8 驗收紀錄） |

## Out of scope

- #45（`usage_suggestion`）、#38 / #39 / #40（known-limitation）
- `broadening` 的「多樣性重排」等 ranking 變更（會動 `score_schema`）

## 版本鏈

`v5.3 → v5.3.1 → v5.4 → v5.5 → v5.6 → v5.7 → v5.8`
