# Persona DB v5.9 Release Notes

> 日期: 2026-09-14 | 上一版: v5.8 | 類型: **核心維度保護機制 + 狀態/錯誤語意**
> 來源: 第九輪驗證報告（`qa-reports/round9-v5.8-nodeA-upstreamrunner/`）+ issue #57 / #58 / #59

## 修的 issue

| # | 標題 | 類型 |
|:-:|:---|:---|
| **#57** | 放寬步驟可移除「分析步驟認定必要」的維度，且同一案例內自我矛盾（核心維度保護只靠關鍵字表 → 漏失） | bug（**本版主軸**） |
| **#58** | `matched=0` 時 `status='ok'`（`too_strict` 要求跑滿 3 輪 → 提前停止即誤標） | bug |
| **#59** | 503 指引文字指向錯誤方向 + `broadening_stop_reason` 宣告兩個不可達值 + `no_op` 混用兩種語意 | enhancement |

## 給消費者的行為變更（重要）

| 變更 | 影響 |
|:---|:---|
| **放寬不得移除核心維度**（機制化） | 部分題目回傳數**可能變少**（`pool_exhausted=true`）；**這是刻意的**——寧可少給，不給錯 |
| `status` | `total_matched == 0` 時不再回 `'ok'`（改 `'too_strict'`）→ 只讀 `status` 的消費端行為會變（正確方向） |
| 503 `message` / `details` / `retryable` | 依失敗型態分流；**`retryable` 不再一律 `true`** |
| `broadening_stop_reason` 新增 `protected_veto` | 若有 switch/case，需加分支；`protected_veto` = 放寬被核心維度擋下 |
| 新增 `protected_dims`（純新增） | 可得知系統拒絕放寬哪些維度 |

## #57：核心維度保護機制（由提示升級為機制）

**問題**：第九輪 5/5 進入放寬迴圈的案例都移除了「分析步驟自己說必須用」的維度；案例 07 更在同一案例相鄰兩輪自我矛盾：

```
loop1：「debt_status 為本題核心條件…不可放寬」（正確）
loop2：「移除 debt_status…非本問題的核心判斷（移除後樣本數由 8 增至 58）」
```

**根因**：① 保護集只來自 `domain` 關鍵字表，而本題 `domain='金融/銀行/貸款'` 與表內鍵零命中 → 保護集空
② v5.8 的約束提示因此把 `debt_status` 列進「優先放寬」並附倍率（`8 → 58（7.25×）`）→ 模型逐字引用
③ 核心性每輪由模型重判 → 自我矛盾。**（即 v5.8 以倍率換到空轉率 60%→10% 時引進的迴歸。）**

**修法**：保護集**凍結於請求開始**，四來源聯集 ——
① domain 語意關鍵字（無歧義鍵亦接受 questions 原文比對；`老闆`/`業主`/… 只認 domain）
② 分析步驟必要性宣告（`reasoning` 含「需使用／必須使用／需以／需考量／必須」的句子；詞界比對避免 `income`↔`family_income`）
③ **分析步驟的結構化宣告**（分析回應新增 `core_dims`；免文字解析、凍結於分析時）
④ 模型每輪 `protected_dims` 自我宣告（**單調累積**）

> **③ 是 e2e 實測逼出來的**：銀行房貸題（案例 05）的分析 `reasoning` 用「房貸持有、居住負擔、收入能力」**散文**描述、未點出 dim 名，且 `domain='金融/銀行房貸領域'` 的關鍵字表不含 `debt_status` → ①② 漏接，模型便把 **LLM 自己在 initial filters 套用的 `debt_status`** 放寬掉。→ **「關鍵字表 + 文字解析」必然有縫，因此補上由分析步驟直接宣告的結構化來源**（同時也讓此機制不再只依賴我方維護的詞表）。

**veto**：欲移除／縮小受保護維度 → 還原該輪 + 標 `protected_veto`/`vetoed_dims` + `stop_reason=protected_veto`（純新增值不受影響）。
**提示淨化**：受保護維度不出現在倍率清單，改列「核心維度（已排除，勿放寬）」。
**效果**：`#42` 斷言由「會發 ⚠️ 的告警」→**不會失敗的不變式**。

## #58 / #59

- **#58**：`status = "ok" if matched else "too_strict"`（移除 `loop >= max_loops` 條件）
- **#59**：
  - 503 分流：`call_failed`（查金鑰／連線，`retryable=true`）vs `no_filters`（問題籠統，換問法，`retryable=false`）
  - `protected_veto` 與 `no_op_limit` 分離 → 「刻意拒絕放寬核心維度」不再是「空轉」
  - `budget_limit` 保留為防護性欄位（正常參數下 `loop_limit` 先命中）；`""` 保留為模型預設值並文件化

## 驗證

| 層 | 結果 |
|:---|:---|
| 單元（`scripts/test_v5_9_fixes.py`） | 保護集三來源、veto 三情境（移除／縮小／純新增）、單調累積、`status`、503 兩型態、OpenAPI 列舉 |
| 既有套件回歸 | v5.4/5.5/5.6/5.7/5.8 全綠（斷言依新契約更新：新增欄位以「純新增」方式併入） |
| 真 LLM e2e | 案例 07（債務整合）／05（銀行）→ `relaxed_dims` 不含 `debt_status`；06（醫美）→ `aesthetic_procedure` 保留；09（業主）→ 語意分流不回歸 |
| Gate | `check_dim_weights` + `check_response_schema` pass |
| 部署環境 | Pre-Release SOP（受測主機見下）＋ 出貨測試腳本 v5.9 斷言 |

## 技術債與已知限制

- 殘留：`#38`（端點不可重現）、`#39`（延遲）、`#40`（頭部集中）為 `known-limitation`；`#45` 低優先
- 語意判準 vs 數學判準的殘餘衝突（TESLA `commute_mode`：連續三輪被放寬）未有 domain 關鍵字覆蓋者仍可能發生 → 由 ②/③ 來源與 veto 減緩，但**非零風險**
- 保護變嚴後的池子大小變化需在後續輪次量測（屬 #39/#40 的觀察範圍）

## 相關文件

- RFC：`tw-persona-db-rfc.md`（核心維度保護、停止原因表、status 語意、503 分流表）
- Spec：`specs/2026-09-14-v5.9-core-dim-protection.md`；Tickets：`.tickets/v5.9/01..04`
- 前版：`RELEASE-v5.8.md`
