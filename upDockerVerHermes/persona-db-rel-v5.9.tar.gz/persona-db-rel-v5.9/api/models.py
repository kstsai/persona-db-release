"""
models.py — Pydantic models for Persona DB API (LLM-powered).
"""

from enum import Enum
from typing import Literal, Optional
from pydantic import BaseModel, Field


class OpMode(str, Enum):
    FILTER_ONLY = "僅篩選"
    FILTER_AND_SIMULATE = "篩選+模擬"


class CandidatesRequest(BaseModel):
    questions: list[str] = Field(..., min_length=1, description="模擬問題列表（至少 1 題）")
    top_k: int = Field(default=12, ge=1, le=20, description="最多回傳 persona 數量")
    opMode: OpMode = Field(default=OpMode.FILTER_ONLY, description="操作模式")


class DimensionSummary(BaseModel):
    dim: str = Field(..., description="維度名稱")
    values: list[str] = Field(..., description="該維度中重要的取值")


class LLMAnalysis(BaseModel):
    domain: str = Field(default="", description="LLM 判斷的領域")
    reasoning: str = Field(default="", description="判斷理由")
    question_analysis: list[dict] = Field(default=[], description="各題分析")
    usage_suggestion: Optional[dict] = Field(default=None, description="LLM 建議的用法")


class SimulationAnswer(BaseModel):
    question: str = Field(..., description="問題")
    answer: str = Field(..., description="模擬回答")


class PersonaSimulation(BaseModel):
    status: str = Field(..., description="模擬狀態: completed/failed/limited")
    answers: list[str] = Field(default=[], description="每個問題的回答（純文字）")


class PersonaBrief(BaseModel):
    id: str = Field(..., description="Persona ID")
    name: str = Field(..., description="姓名")
    dimensions: dict = Field(..., description="維度資料")
    prompt_prefix: str = Field(default="", description="角色扮演 prompt")
    reference_pre_prompt: str = Field(default="", description="結構化摘要")
    simulation: Optional[PersonaSimulation] = Field(default=None, description="LLM 模擬結果")


class PersonaSummary(BaseModel):
    id: str = Field(..., description="Persona ID")
    name: str = Field(..., description="姓名")
    age: str = Field(..., description="年齡層")
    occupation: str = Field(default="", description="職業")
    income: str = Field(default="", description="個人月收入")
    family_income: str = Field(default="", description="家庭可支配所得")
    residence: str = Field(default="", description="居住地")
    family_size: str = Field(default="", description="家庭人數")
    city_price_tier: str = Field(default="", description="城市物價分級（依居住地，非個人）")
    commute_mode: str = Field(default="", description="通勤方式")
    housing_cost: str = Field(default="", description="居住支出")
    housing_burden: str = Field(default="", description="居住負擔率")
    clothing_spend: str = Field(default="", description="服飾消費")
    aesthetic_procedure: str = Field(default="", description="醫美療程經歷（近12個月，ISAPS 2024）")
    debt_status: str = Field(default="", description="債務背貸狀態（JCIC 聯徵中心統計）")
    employment_status: str = Field(default="", description="從業身分（DGBAS 113 表48）")
    # #53: 補齊可篩維度（valid_dims ⊆ summary fields）。以下 7 個原本只在 /detail 可見，
    # 導致消費端無法從回應驗證 filter 是否生效；由 scripts/check_response_schema.py 守門。
    sex: str = Field(default="", description="性別")
    region: str = Field(default="", description="區域（都會區/北部/中部…）")
    education: str = Field(default="", description="教育程度")
    marriage: str = Field(default="", description="婚姻狀態")
    hobby: list[str] = Field(default=[], description="興趣（多值）")
    politics: str = Field(default="", description="政治傾向（可篩、不計分）")
    media_diet: str = Field(default="", description="媒體接觸習慣（可篩、不計分）")
    score: float = Field(default=0.0, description="相關性分數（log-frequency × cross-dim 正規化，越高越符合）")


class BroadeningAttempt(BaseModel):
    """broadening loop 的一次嘗試（#48：型別化，讓 OpenAPI 產生 properties 而非
    additionalProperties —— codegen/驗證工具才看得到這些欄位）。"""
    loop: int = Field(default=0, description="第幾輪 broadening（1 起算）")
    change: str = Field(default="", description="LLM 說明的放寬內容（人可讀）")
    match_count_before: int = Field(default=0, description="該輪放寬前的符合數")
    match_count_after: int = Field(default=0, description="該輪放寬後的符合數")
    filters_changed: bool = Field(default=False, description="filters 是否實際變更")
    protected_veto: bool = Field(default=False, description="#57：該輪因觸動受保護的核心維度而被還原（未生效）")
    vetoed_dims: list[str] = Field(default=[], description="#57：被否決的維度（僅 protected_veto=true 時非空）")
    no_op: bool = Field(default=False, description="放寬後樣本數未變（＝空轉）")
    overshoot: bool = Field(default=False, description="放寬後樣本數 > 2×TARGET_MIN（＝放寬過頭）")


class ScoringBasis(BaseModel):
    """scoring 演算法說明（#48：型別化）。`score_scale` 明示 score 僅供版本內相對排序。"""
    method: str = Field(default="", description="計分方法")
    weight_source: str = Field(default="", description="權重來源（資料出處）")
    weight_version: str = Field(default="", description="權重表版本（= 產生時的資料版號）；換版代表分數尺度改變")
    score_scale: str = Field(default="relative-within-version", description="分數尺度語意；不可跨版本比較")
    score_schema: int = Field(default=1, description="分數定義版號（與資料版號脫鉤，改 ranking 目標時跳版）")
    dims_counted: list[str] = Field(default=[], description="實際參與計分的維度")
    relaxed_dims_scored_at: Optional[str] = Field(default=None, description="被放寬維度的計分處理方式（Q3-A': 不計分 → null）")


class CandidatesResponse(BaseModel):
    status: str = "ok"
    total_matched: int = Field(..., description="符合條件的總筆數")
    persona_ids: list[int] = Field(..., description="符合條件的 persona ID 列表")
    # Full details removed. Use summary table instead.
    summary: list[PersonaSummary] = Field(default=[], description="摘要表格（取代完整 persona 詳細資料）")
    returned: int = Field(default=0, description="實際回傳筆數（= len(summary)）；可小於 top_k，見 pool_exhausted（#43）")
    pool_exhausted: bool = Field(default=False, description="符合條件人數 < top_k（系統拒絕為湊數放寬核心維度，故回傳較少；#43）")
    important_dimensions: list[DimensionSummary] = Field(default=[], description="重要維度")
    llm_analysis: Optional[LLMAnalysis] = Field(default=None, description="LLM 對問題的分析（含 reasoning）")
    relaxed_dims: list[str] = Field(default=[], description="因 broadening 被放寬移除的維度（空 = 未放寬）")
    broadening_attempts: list[BroadeningAttempt] = Field(default=[], description="broadening loop 過程（含 no_op / overshoot 旗標；#37/#42）")
    broadening_stop_reason: Literal[
        "", "target_reached", "no_op_limit", "loop_limit", "budget_limit",
        "llm_empty", "llm_parse_error", "llm_no_filters", "no_filters",
        "protected_veto",
    ] = Field(
        default="",
        description="broadening 停止原因（#56；#57 新增 protected_veto）：target_reached / no_op_limit / "
                    "loop_limit / budget_limit / llm_empty / llm_parse_error / llm_no_filters / no_filters / "
                    "protected_veto（該輪欲移除受保護的核心維度 → 已還原）。空字串＝未進入迴圈（呼叫端自行建構時的預設值）",
    )
    protected_dims: list[str] = Field(
        default=[],
        description="#57：本請求受保護的核心維度（domain 語意 ∪ 分析步驟必要性宣告 ∪ 模型自我宣告）。"
                    "放寬步驟不得移除或縮小這些維度 —— 這是 v5.4 #43「拒絕為湊數而放寬核心維度」的機制化",
    )
    applied_filters: dict = Field(default={}, description="實際用於篩選的 filters（LLM 產出，含 broadening 後）")
    scoring_basis: Optional[ScoringBasis] = Field(default=None, description="scoring 演算法說明（含 weight_version / score_scale / score_schema；#44）")


class DetailRequest(BaseModel):
    persona_id: str = Field(..., description="Persona ID (TW-P-XXXX 或數字)")


class PersonaDetail(BaseModel):
    id: str
    name: str
    type: str = "虛構人設"
    dimensions: dict
    prompt_prefix: str
    reference_pre_prompt: str


class DetailResponse(BaseModel):
    status: str = "ok"
    persona: PersonaDetail


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    persona_count: int
    db_loaded: bool


class ErrorResponse(BaseModel):
    status: str = "error"
    error: dict


class ErrorDetail(BaseModel):
    code: str
    message: str
    details: str = ""
