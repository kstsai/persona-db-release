# [RFC] TW Persona Database — 1069 個台灣人設模板 for GEO Operator

> 狀態：實作中 · 建立日期：2026-07-03 · 最後更新：2026-07-11
> 最新 tag：`persona-v3.1`
> 來源：Hermes Slack 對話記錄（thread「persona-db-dev」）

---

## 動機

建立一個包含 **1069 個**分層抽樣人設（persona templates）的資料庫，代表台灣 2,300 萬人口結構。

用途：**GEO（Generative Engine Optimization）Operator** 在回應各領域問題時，能根據問題類型載入對應的人設視角，提問更精準、回答更到位。

### 適用場景

- 用戶問「竹北市長誰勝算高」→ 載入選區選民人設
- 用戶問「高雄開火鍋店推薦地點」→ 載入當地消費者人設
- 用戶問「推年輕族群信用卡」→ 載入目標客群人設

---

## 核心運作流程

```
用戶提問
    ↓
GEO Operator 掃描 reference_pre_prompt 庫
    ↓  找出匹配的 N 個 persona
載入對應的 prompt_prefix
    ↓
組合多 persona 視角思考
    ↓
產出最終回答
```

---

## Coherence Rules（一致性驗證規則）

> 2026-08-10 更新 — 新增「單人家庭 + 無收入」三條規則（v4.4.3）
> 背景：`_generate_997.py` 對 family_size/income/commute_mode/clothing_spend 獨立抽樣，
> 漏了「fam=1 + 無收入」組合，產生矛盾人設（例：TW-P-0177 若希 — 獨居無收入卻有
> 3-5萬家庭所得 + 汽車 + 高服飾消費）。

| # | 規則 | 觸發條件 | 修正 |
|:-:|:-----|:---------|:-----|
| R-A | fam1_noinc_lowfi | fam=1 且 income=無收入 | family_income 重抽為 <1萬(40%) / 1-3萬(60%) |
| R-B | fam1_noinc_nocar | fam=1 且 income=無收入 且 commute=汽車 | commute 改 機車(30%) / 捷運公車(40%) / 步行腳踏車(30%) |
| R-C | fam1_noinc_lowcs | fam=1 且 income=無收入 且 clothing_spend∈{>5000, 3000~5000} | clothing_spend 重抽為 <500(50%) / 500~1500(30%) / 1500~3000(20%) |
| R-D | hb_high_cs_low | housing_burden=高 且 clothing_spend=>5000 | clothing_spend 重抽為 <500(60%) / 500~1500(30%) / 1500~3000(10%) |
| R-E | edu_bump_medical | education=國中以下 且 occupation=醫療 | edu 重抽為 大學(70%) / 高中(30%) |
| R-F | lowfi_high_hc | family_income∈{<1萬, 1-3萬} 且 housing_cost∈{1.5萬~3萬, 3萬~5萬, >5萬} | housing_cost 重抽為 <5千(40%) / 5千~1.5萬(60%) |
| R-G | island_highfi | region=離島 且 family_income=>8萬 | family_income 重抽為 5-7萬(40%) / 7萬(40%) / >8萬(20%) |

**設計原則：**
- 只對 `family_size=1`（單人家庭）生效 — 學生「北漂靠家裡」的合理版本是 fam>1（原生家庭人口），不誤傷
- 19-24 學生 + 汽車 若 fam>1 且 family_income 高 → 合理（車是家裡的），規則不觸發
- 與既有規則（fam_inc_5plus / fam_inc_4 / fam_inc_student_5plus）並存

---

## 維度設計（通用底層 13 維度）

| # | 維度 | 分層 |
|---|------|------|
| 1 | 年齡 | 0-11 / 12-18 / 19-24 / 25-34 / 35-44 / 45-54 / 55-64 / 65+ |
| 2 | 性別 | 男 / 女 |
| 3 | 區域 | 都會區(六都) / 北部 / 中部 / 南部 / 花東 / 離島 |
| 4 | 教育 | 國中以下 / 高中 / 大學 / 研究所以上 |
| 5 | 職業 | 學生 / 科技 / 服務 / 製造 / 教育 / 醫療 / 公務 / 自營 / 家管 / 退休 / 失業 / 其他 |
| 6 | 個人收入 | <3萬 / 3-8萬 / >8萬 / 無收入 |
| 7 | 政治傾向 | 泛綠 / 泛藍 / 白/第三勢力 / 無政治傾向 |  (與年齡相關, 未成年不予貼標)
| 8 | 媒體習慣 | 傳統媒體為主 / 社群為主 / 混合 / 國際來源 |
| 9 | 家庭口數 | 1 / 2 / 3 / 4 / 5+ |
| 10 | 家庭可支配所得（月） | <1萬 / 1-3萬 / 3-5萬 / 5-7萬 / 7萬 / >8萬 |
| 11 | 興趣嗜好 | 打電動 / 追劇 / 閱讀 / 登山 / 遊泳 / 球類 / 逛街購物 / 烹飪 / 園藝 / 泡茶 / 下棋 / 打牌 |
| 12 | 婚姻狀況 | 未婚 / 已婚 / 離婚 / 鰥寡 |
| 13 | 戶籍地 | 台北市 / 新北市 / 桃園市 / 台中市 / 台南市 / 高雄市 / 基隆市 / 新竹縣 / 新竹市 / 苗栗縣 / 宜蘭縣 / 彰化縣 / 南投縣 / 雲林縣 / 嘉義市 / 嘉義縣 / 屏東縣 / 花蓮縣 / 台東縣 / 澎湖縣 / 金門縣 / 連江縣 |
| 14 | 物價分級 | 高 / 中高 / 中 / 低 / 極低 |（基於主計總處113年平均每人月消費支出，影響經濟短語選取權重）|
| 15 | 家戶所得分級 | 極高 / 高 / 中 / 中低 / 低 |（基於主計總處113年家庭收支調查，調整家庭收入分配）|
| 16 | 居住支出（月） | <5千 / 5千~1.5萬 / 1.5萬~3萬 | 房貸或房租，依 price_tier × family_size 指派，上限 ≤ 家庭可支配所得 50%。**v5.7 起可篩**（#54：原 `valid_dims` 漏列，prompt 已指示使用卻被靜默丟棄） |
| 17 | 居住負擔率 | 低 / 中 / 高 | 自動計算：housing_cost / family_income。低<20%, 中20-40%, 高>40%。影響背景故事中的經濟短語選取 |
| 18 | 通勤方式 | 步行/腳踏車 / 機車 / 捷運/公車 / 汽車 / 在家工作 | 依 residence × age 為基底，income / family_size / occ 微調 |
| 19 | 服飾消費（月） | <500 / 500-1500 / 1500-3000 / 3000-5000 / >5000 | 家庭月衣著支出（DGBAS 113年家庭收支調查），依 family_income × sex × occ × age 指派 |
| 20 | 醫美療程經歷（近 12 個月） | 無 / 有 | ISAPS Global Survey 2024 p24 Chinese Taipei — 過去 12 個月有進行至少一次醫美療程（注射或手術型）。2026-09-02 新增（甲方提供資料）；in-place annotation 於 v4.9.3，非重抽 |
| 21 | 債務背貸狀態 | 無 / 有房貸 / 有信貸或卡債 / 房貸+消費債 | JCIC 聯徵中心個人授信統計（uid=213）— 目前背負的債務類型（存量）。2026-09-03 新增；房貸 derive 自 housing_cost，消費債 annotate 自 JCIC 信貸 by 年齡×性別 |
| 22 | 從業身分 | 受僱者 / 雇主 / 自營作業者 / 無酬家屬 / 不適用 | DGBAS 113 年報表48 就業者之從業身分 by 性別×年齡。2026-09-04 新增（issue #32）；**occupation 自營值退役**（身分剝離），就業 occupation 依身分表指派 |

> **⚠️ 注意 — 家庭可支配所得的定義（對甲方重要）**  
> 本欄位採用 **DGBAS 主計總處「家庭可支配所得」** 定義：  
> `家庭可支配所得 = 所得總額 − 稅金 − 社會保險（勞健保/勞退）`  
>  
> **已扣除：** 所得稅、勞健保、勞退  
> **尚未扣除（要從這裡面付）：** 房貸/房租、伙食費、水電瓦斯、教育費、交通費…全部消費支出  
>  
> 換句話說，**`<1萬` ~ `>8萬` 是稅後、但要拿去付所有開銷（含房貸房租）的錢**，不是淨儲蓄。  
>  
> **舉例：** 丹尼爾（TW-P-0233）個人月收 >8萬，家庭可支配所得 5-7萬  
> → 稅後全家有 5-7萬可花用，要付房租+養媽媽+生活費，  
>    「經濟壓力非常大」在 v3.8 以前是 BG 模板遺漏造成的 bug，已修復。

### 醫美療程經歷（dimension 20，2026-09-02 新增）

> 來源: ISAPS Global Survey 2024 p24 Chinese Taipei（甲方提供）。台灣年療程總數 658,320（手術型 39% / 非手術型 61%），對 ~2,340 萬人口 → **全年齡年盛行率 ~2.8%**。

- **語意**: 過去 12 個月有進行至少一次醫美療程（注射如肉毒/玻尿酸，或手術如眼皮/隆乳皆算）。二元：無 / 有。
- **實作**: in-place annotation（`_annotate_aesthetic.py`）於 v4.9.3 資料上，**非重抽** — 原 19 維完全不動，只對選定 persona 加註 `aesthetic_procedure: 有`。
- **Segment 條件化**（依 sex × age × income，rate 為假設值 — 甲方確認過）：

  | Segment | 年盛行率 | 依據 |
  |:----|:----:|:----|
  | 女 19-24 | 2% | 年輕注射族 |
  | 女 25-44 | 6% | 主力客群 |
  | 女 45-64 | 3% | 抗老 |
  | 女 65+ | 0.5% | 邊緣 |
  | 男（全齡） | 0.5% | 低但存在（gynecomastia） |
  | 0-18（男女） | 0% | QA rule |

- **Coherence**: ① 0-18 → 無（硬性）② income=無收入 → 無（無可支配所得，甲方確認）③ 不與 clothing_spend 連動（避免過度設計）。
- **API**: Level 2（filterable）— 進 valid_dims + PersonaSummary + llm.py 有效值清單 + domain reinforcement（醫美/整形/皮膚科/醫美診所 → 此維度；**「美容」已於 2026-09-12 移除**，#36）。**SCORED_DIMS 已納入**（v5.3, #35）。
- **語意適用性（#36, 2026-09-12）**: 本維度**只適用於醫美療程/整形/皮膚科語意**的 query；零售/藥妝/美妝/通路/時尚等非療程語意**不得套用** —— DB 僅 1.5%（16/1069）為「有」，誤套會把候選池限縮到個位數（實測「康是美的目標客戶」matched 62 → 1，且無任何錯誤訊號）。prompt 已加負面約束。
- **稀有維度放寬規則（#42, v5.4 定案）**: broadening 對稀有維度（覆蓋率 <5%）的提示改為 **rescue-only**（僅 `matched == 0` 才提示）＋ **核心性排除**（由 domain reinforcement 補上的維度永不出現在提示中）＋ **強制理由**（若 LLM 仍決定放寬，必須在 `change` 寫明「為何它不是本問題的核心條件」）。放寬後樣本數 > 2×`TARGET_MIN` 時 `broadening_attempts[].overshoot = true`（只標記，因為此時迴圈本就會退出）。**教訓（v5.3.1 實測）**：原本只要 <5% 就提示「優先放寬」，導致「債務整合」在第一輪（matched=6）就被移除，matched 6 → 45、回傳 10 筆中 4 筆無債務。
- **版號**: v5.0（新增 filterable 維度 = feature）。

### 債務背貸狀態（dimension 21，2026-09-03 新增）

> 來源: JCIC 聯徵中心「個人授信統計資訊」download_page uid=213 pid=190（2026-03/04 最新）。借款人「人數」by 年齡×性別 → 可算盛行率（優於 ISAPS 只有療程數）。

- **語意**: 目前背負的債務類型（存量快照）。4 tiers：無 / 有房貸 / 有信貸或卡債 / 房貸+消費債（多重）。
- **實作**: 混合（A3 決策）—
  - **房貸 tier = derive**（不另抽）：housing_cost ∈ {1.5萬~3萬, 3萬~5萬} 且非租客/非住家裡語意者 = 有房貸（與 #27 homeowner 邏輯一致）
  - **消費債 tier = annotate**：JCIC 信貸 by 年齡×性別 rate（fid=1300）+ 車貸併入（fid=898，36萬小眾）；卡債 11.27% 持卡人（fid=920）
  - **多重 tier**: 房貸族中 18.7% 也有信貸（fid=1008 交叉，2026-04: 422,592/2,259,959）— 有房貸者以 18.7% 條件率加註消費債
- **Eligible**: 19+ 且 income ≠ 無收入（無還款能力不背債；與 dimension 20 同規則）
- **盛行率基準**（2026-04）: 信貸借款人 188 萬（<30: 男17.1萬/女10.7萬、30-40: 38.3/25.2萬、40-50: 33.6/25.1萬、50-60: 16.5/13.1萬、60+: 4.6/3.5萬）；房貸 226 萬；車貸 36 萬；卡債 11.3% 持卡人
- **Coherence**: ① 0-18、無收入 → 無 ② 有房貸 → housing_cost 高值 + BG 房貸短語（derive 保證）③ 無負債 + housing_cost 高 = 高房租（BG 房租短語）④ 消費債不與 income 衝突（低所得卡債 = 債奴人設，可接受）
- **API**: L2 filterable（debt_status 進 valid_dims + PersonaSummary + 兩處 prompt + domain reinforcement 債務/貸款整合/協商 → 有信貸或卡債/多重）
- **版號**: v5.1（新增 filterable 維度 = feature，接續 v5.0）

### 從業身分（dimension 22，2026-09-04 新增 — issue #32）

> 來源: DGBAS 113年人力資源調查統計年報 表48「就業者之教育程度與年齡—按從業身分分」（2024）。完整 rates 見 `references/employment-status-dgbas-2024.md`。

- **背景**: kstsai 逐筆審查發現 occupation=自營 只有 4/1069（0.37%）不合理 — 但查證後發現根因是**概念混淆**：現行 occupation 的「自營」（映射 DGBAS 職業大分類「民意代表/主管/經理人員」1-3%）是**職業**概念；甲方期望的 13%（雇主 4.5% + 自營作業者 8.5%）是**從業身分**概念（B2B 決策者=真雇主、B2C 決策者可能是無酬家屬）
- **語意**: 就業者的從業身分。5 值：受僱者 / 雇主（有雇人）/ 自營作業者（無雇人、自己接案/擺攤）/ 無酬家屬（在自家事業幫忙、無薪但就業）/ 不適用（非就業）
- **實作**: **occupation=自營 值退役**（Y1）— 身分從 occupation 剝離成獨立維度；OCC_PROB 移除自營（1-3% mass 分給 製造/服務/其他）；就業 occupation 依 `EMP_STATUS[(sex,age)]`（DGBAS 表48，5 年帶細分）指派
- **指派規則**: ① 公務 → 受僱者 100%（公務員不可能當雇主）② 無酬家屬 僅允許 服務/其他（家庭店面）③ 教育/醫療 雇主/自營 = 開業/補習班（可接受）④ 學生/退休/家管/失業/0-18 → 不適用 ⑤ OCC_CITY_BOOST 排除對象加 自營（退役後自然消失）
- **收入連動**: 雇主偏高收、自營作業者兩極化（現行 INC_PROB[自營] >8萬 40% 過高 — 退役後由身分調整取代）；FAMILY_INCOME_PROB (>8萬,自營) key 移除
- **故事短語**: occupation 自營短語「自己做生意」→ employment_status 短語（雇主=開店/開公司當老闆、自營作業者=自己做小生意/接案、無酬家屬=在自家店裡幫忙）
- **API / 語意適用性（#34, 2026-09-12）**: Level 2 filterable。**只有當問題主體是「業主本人」**（雇主／自營作業者／攤商／創業者／企業主）時才用本維度；問「某店／某攤的目標客群」（即其顧客）**不要用** —— 這是 2026-09-12 跨版本驗證抓出的語意歧義：案例「小吃攤老闆的目標客群」的 `domain` 是「餐飲/夜市商圈/市場研究」，LLM 正確地把它理解成**顧客**而不套 `=雇主`。prompt 已加 must-use 指引（analysis + broaden 兩處），domain_filters 補「業主」「自營」關鍵字。
- **版本**: v5.2（full regen — issue #32 建議 + R1 決策；regen 後重跑 dim 20/21 annotation 補回）

### 城市職業加權

Occupation probabilities are adjusted by city to reflect real-world industry clustering:

| 城市 | 職業加權 | 說明 |
|:-----|:---------|:-----|
| 新竹縣、新竹市 | 科技↑30% | 竹科效應 |
| 台北市 | 金融↑20% | 金融中心 |
| 桃園市 | 製造↑20% | 工業大城 |
| 台中市、台南市、高雄市 | 製造↑15% | 製造業重鎮 |

Implementation: post-selection redirect (if base occ ≠ target, X% chance to switch).

可依領域疊加 domain-specific 維度：
- 選舉 → 疊加「投票記錄」、「在地連結感」
- 金融 → 疊加「風險偏好」、「理財知識」
- 餐飲 → 疊加「外食頻率」、「口味偏好」

---

## 每個人設的輸出格式

### JSON 欄位結構

```json
{
  "id": "TW-P-0001",
  "name": "叩莓",
  "type": "虛構人設 (fictional persona)",
  "note": "姓名與地點/校名皆虛構，無對應真實人物",
  "input_dimensions": { "...9 維度值..." },
  "generated": {
    "location": "泉台（桃竹苗都會區）",
    "school": "星辰綜合高中",
    "age": "15 歲"
  },
  "interests": ["貓咪", "拍照", "K-pop"],
  "persona_profile": {
    "summary": "叩莓，泉台的高中生，15歲。每天上課滑手機跟朋友打屁。",
    "values": ["同儕認同", "當下快樂", "視覺美感", "不踩雷"],
    "pain_points": ["零用錢不夠", "補習好累", "父母碎念"],
    "decision_logic": "朋友推薦 → 查 Threads/Dcard → 確認安全 → 買",
    "trust_signals": ["網紅推薦", "同學用過", "按讚數高"],
    "distrust_signals": ["太像業配", "政治內容", "字太多", "長輩文"]
  },
  "prompt_prefix": "（沉浸式角色代入，供 LLM 直接使用）",
  "reference_pre_prompt": "（結構化摘要，供 GEO operator 篩選用）"
}
```

---

## 雙 Prompt 格式

### ① prompt_prefix — 沉浸式角色代入

**用途：** GEO operator 已選定此人設後，直接作為 system prompt 前綴餵給 LLM。

範例 — 高中生：

> 你是叩莓，一位 15 歲的高中生，住在桃竹苗都會區。
> 你的世界以學校和社群網路為中心。每天滑 IG、Threads、TikTok。
> 你對政治完全無感。決策模式：朋友推薦 → 查評價 → 確認安全 → 決定。
> 請用這個人設的語氣和視角來回應。

範例 — 工程師：

> 你是阿睿，31 歲，竹科資深韌體工程師，碩士畢業，年薪約 200 萬。
> 你單身，在竹北租屋。對政治冷感——覺得藍綠都一樣爛。
> 消費決策：爬 PTT/Dcard 看災情 → Mobile01 比 spec → 等折扣 → 才買。
> 你相信數據和實測，不信廣告和名人代言。
> 請用這個人設的視角和語氣來回應。理性、務實、帶一點工程師的冷幽默。

### ② reference_pre_prompt — 結構化查閱

**用途：** GEO operator 篩選比對時快速掃描用。

範例 — 高中生：

```
【參考人設 #叩莓】
年齡區間：12-18（15 歲）
教育程度：高中
居住區域：桃竹苗 / 都會核心
職業狀態：學生（無收入）
政治傾向：無 / 冷感
決策風格：同儕驗證型
興趣信號：貓咪, 拍照, K-pop
觸發因子：網紅推薦、同儕使用、限時限量
排斥因子：業配感、政治內容、長文
【適用場景】Z 世代高中生消費決策、社群傳播、政治冷感
```

範例 — 工程師：

```
【參考人設 #阿睿】
年齡區間：25-34（31 歲）
教育程度：碩士
居住區域：桃竹苗 / 都會核心
職業：資深工程師（年薪 200 萬）
政治傾向：無 / 厭惡藍綠
決策風格：理性比價型
興趣信號：科技產品、健身、PC Game
觸發因子：客觀評測、數據對比、CP 值分析
排斥因子：業配文、政治語言、太廉價感
【適用場景】高收入科技族群消費決策、竹科生活圈、房市/租屋
```

---

## 命名原則：名字對應人設屬性

名字不是隨機產生的，而是根據人設的年齡、性別、職業屬性自動匹配適當的命名風格：

| 人設類型 | 命名風格 | 範例 |
|---------|---------|------|
| 🧑 學生/青少年 | 可愛、疊字、醬系 | 叩莓、星醬、小雲、芽泉 |
| 👨‍💻 工程師/科技業 | 科技感、克/斯/睿/達 | 阿睿、科克、達森、老雲斯 |
| 👔 金融/商務 | 穩重、爾/瑞/邦/貿 | 益安、金爾、艾貿 |
| 👨‍💼 中年管理/自營 | 江湖感、哥/董/老大 | 強哥、老大、威爾、麥斯 |
| 🏭 中年傳產/勞工 | 本土味、昇/坤/雄 | 阿昇、志強、秀蘭、淑貞 |
| 👴 銀髮族 | 伯/嬸/媽系 | 春伯、天伯、金花嬸、阿好嬸 |

### 命名規則對照

```
年齡層 12-18     → 可愛系（小型、疊字、醬）
年齡層 19-34     → 年輕系（英文感、阿/小/艾）
年齡層 35-54     → 穩重系（哥/姐/中文雙字）
年齡層 55+       → 傳統系（伯/嬸/媽/叔）

職業 科技/工程 → 科技感字根（芯、科、達、睿）
職業 金融/商務 → 商務感字根（金、信、誠、貿）
職業 製造/傳產 → 本土感字根（宏、信、雄、坤）
```

---

## 隱私原則

| 原則 | 說明 | 範例 |
|------|------|------|
| 全虛構名稱 | 命名風格貼合人設，但不似真人姓名 | 叩莓、阿睿、春伯 |
| 無真實地名 | 合成地名，非真實行政區 | 泉台、光華庄、星崎 |
| 無真實校名 | 未成年使用虛構校名 | 星辰綜合高中、彩虹藝術中學 |
| 免責標註 | 每個人設 JSON 內標明虛構身份 | `"type": "虛構人設"` |

---

## 與 Hermes Agent 的整合

| 層級 | 用途 | 範例 |
|------|------|------|
| 🎭 Personality | 改變語氣/風格 | kawaii, noir, pirate |
| 🗂️ Profile | 改變工具/技能/記憶 | default vs work |
| 🧬 Persona DB | 扮演特定人口視角 | 叩莓（15歲高中生）、阿睿（31歲工程師） |

建議做法：將 Persona DB 包成 Hermes **skill**，agent 需要時載入查詢，不影響現有系統。

---

## 相關檔案

| 檔案 | 說明 |
|------|------|
| `hermesa3/persona/tw-persona-db-rfc.md` | 本文件 |
| `hermesa3/persona/tw_persona_1069.json` | **最新輸出** — 1069 人設, 16 維度, ~1.4MB |
| `hermesa3/persona/_generate_997.py` | 產生器（seed=42, target=1069） |
| `hermesa3/persona/qa_validate.py` | 18 條自動化驗證規則 |
| `hermesa3/persona/query_persona.py` | 查詢 CLI 工具 |
| `hermesa3/persona/sample_stratified.py` | 分層抽樣（96 combos, seed=42） |
| `hermesa3/persona/population_by_region_age_sex_2025.csv` | 6區×8年齡×2性別人口資料 |
| `hermesa3/persona/tw_persona_prototype_001_v3.json` | Prototype v3 — 高中生「叩莓」 |
| `hermesa3/persona/tw_persona_prototype_002_engineer.json` | Prototype v2 — 工程師「阿睿」 |
| `hermesa3/persona/MILESTONE-v3.0.md` | v3.0 milestone 文件 |

## Scoring 演算法（Relevance Ranking）

> 2026-08-10 新增（issue #4）— `/personadb/candidates` 的 `persona_ids` 依相關性分數排序，不再只是 DB 檔案順序。

### 動機

LLM 產出 filters 後，`matched` 可能遠多於 `top_k`。舊行為直接取檔案前 N 筆 — 可能挑到「剛好符合 filter 但其實最不像目標客戶」的人。Scoring 讓「命中稀有維度值」的人排前面。

### 權重表（dim_weights.json）

- **產出：** `scripts/gen_dim_weights.py`（regen 時或獨立執行）
- **公式：** `raw = log(total / count(dim, value))` → 跨維度正規化到 `[0.5, 2.0]`
- **覆蓋 18 個維度**（對齊 LLM filter 能力；= `persona_matcher.valid_dims` 的可計分集合）：
  `age, sex, region, residence, education, occupation, income, family_income, family_size, marriage, commute_mode, housing_cost, housing_burden, clothing_spend, hobby, aesthetic_procedure, debt_status, employment_status`
  - ⚠️ **新增 filterable 維度時必須同步擴充 `SCORED_DIMS`（`scripts/gen_dim_weights.py`）並重跑權重表**（2026-09-12, issue #35 —— dim 20/21/22 上線時漏了這一步：維度「能篩選但權重查不到」，舊版 fallback 0.0 → 排序靜默無感）
  - 驗收：`bash scripts/regenerate-dim-weights.sh`（含 `valid_dims − SCORED_DIMS` 必須為空的檢查）
- **不計分：** `political_stance, political_issues, politics, media_diet, background_story, prompt_prefix`（LLM 幾乎不用它們 filter；文字欄位無法計分）
- **資料源對照**（寫入 `_meta.data_sources`）：
  - 年齡/性別/區域/居住地/婚姻/家戶人數 — 內政部戶政司 113年人口統計
  - 教育/職業/收入/家庭所得/居住/服飾消費 — DGBAS 113年 家庭收支調查 / 人力資源調查
  - 通勤方式 — 交通部 2024 運具分配調查

### 分數計算

```
score(persona) = Σ [ weight(dim, persona.value)  for dim in filters ]
```

- **只算 LLM filter 有出現的維度**（Q2b-B）
- `hobby`（list 型）：命中任一 filter 值即加分，取命中值中最大權重
- **被 relaxation 丟掉的維度不計分**（Q3-A'）— 因為丟維度的原因就是「matched 無人命中該維度」，計分恆為 0
- 同分 → DB 檔案順序（Q7-A，確定性、可重現）
- 權重表缺失時 graceful degradation：所有 score=0，回歸無排序（不 crash）

**現行實作公式（含 issue #29 dim_importance + #35 修正）：**

```
score = Σ_(dim ∈ filters)        imp[dim] × tier_match(value, filter_values) × rarity
      + Σ_(dim ∈ dim_importance)  imp[dim] × 0.5 × rarity      # 不在 filters 者（無 target）
```

- `dims_counted`（response `scoring_basis`）= **實際進入上式加總的維度集合**，由
  `persona_matcher.scored_dims()` 產生（單一真相來源）= `filters`（含 relaxed，以
  `original_filters` 計 tier_match）∪ `dim_importance` 中不在 `filters` 者。
  舊版用 `filters ∩ dim_weights` 推測 → 漏列 `dim_importance`-only 與新維度（#35）。
- **rarity 查不到時 fallback 1.0（中性），不是 0.0**：合法權重值域是 `[0.5,2.0]` /
  `[0.8,1.4]`，0.0 從不是刻意值；舊版 fallback 0.0 讓「權重表沒涵蓋的維度」靜默不計分（#35）。

### Response 揭露（可稽核性）

```json
{
  "summary": [{ "id": "TW-P-0195", "score": 2.77, ... }],
  "returned": 1,
  "pool_exhausted": true,
  "applied_filters": { "occupation": ["自營"], "age": ["25-34"] },
  "scoring_basis": {
    "method": "log-frequency × cross-dim normalized [0.5, 2.0]",
    "weight_source": "DGBAS 113年 家庭收支調查 / 人力資源調查 / 交通部 2024",
    "weight_version": "v5.4",
    "score_scale": "relative-within-version",
    "score_schema": 1,
    "dims_counted": ["occupation", "age"],
    "relaxed_dims_scored_at": null
  }
}
```

**分數可溯性欄位（#44, v5.4 新增）**

| 欄位 | 意義 |
|:----|:----|
| `weight_version` | 產生權重表時的資料版號（= `dim_weights.json._meta.version`，由 `check_dim_weights.py` 保證 == `VERSION`）→ 下游可偵測「尺度換版」 |
| `score_scale` | 固定為 `"relative-within-version"`：**`score` 僅供同版本內相對排序** |
| `score_schema` | 分數**定義**版號（與資料版號脫鉤）；若改 ranking 目標（如 #40 多樣性重排）需跳版 |

> ⚠️ **`score` 不可跨版本比較**：v4.9.2 ≈ 5.91 → v5.2 ≈ 5.42 → v5.3.1 ≈ 4.36（top score 平均）。權重源自資料分布，資料更新必然改變尺度（#41）。以下游絕對門檻（例 `score > 5`）實作的邏輯，升級時必須重新校準。

### 錯誤契約（v5.5 #47 / #49 統一）

**所有**錯誤碼（400 / 404 / 422 / 500 / 503）一律回 `ErrorResponse` 形狀：

```json
{"status": "error",
 "error": {"code": "INVALID_OPMODE", "message": "無效的 opMode: 亂寫",
           "details": "有效值: 僅篩選, 篩選+模擬, 模擬詢問"}}
```

- `code` 值域：`INVALID_OPMODE` / `TOP_K_TOO_LARGE` / `MISSING_PARAMETER` / `DB_NOT_LOADED` / `FILTER_FAILED` / `VALIDATION_ERROR` / `INTERNAL_ERROR` / `NOT_FOUND`
- **`FILTER_FAILED`（503）依型態給不同指引（v5.9 #59）** —— `retryable` 對應「重試是否有意義」：

| 型態 | `message` / `details` | `retryable` |
|:---|:---|:---|
| **LLM 呼叫失敗**（逾時／網路／http 錯誤／回應不可解析） | 「LLM 呼叫失敗，無法分析問題」+ 檢查 API key / model / 連線（附 `finish_reason` 等細節） | **`true`**（重試可能成功） |
| **LLM 回應成功但產不出 filter**（問題過於籠統） | 「問題過於籠統，LLM 無法產出篩選條件」+ 建議換更具體的問法 | **`false`**（同一問題重試仍會失敗） |

  （v5.5 前一律 `true` 且 `details` 指向金鑰 → 維運會被帶往錯誤方向；第九輪以伺服器 log 證實真因屬第二型態。）
- **不再使用** FastAPI 預設的 `{"detail": ...}` 包裝（v5.4 前錯誤碼與宣告不一致）
- `opMode` 可省略，預設 `僅篩選`（v5.5 #49 修正：先前預設值 `兩者皆可` 不在合法值內，省略即 400）

### 核心維度保護（protected dims）（v5.9 #57）

**不變式**：放寬步驟**不得移除或縮小核心維度** —— 這是 v5.4 #43「系統拒絕為湊數而放寬核心維度」的**機制化**（v5.9 之前僅為提示，v5.8 更曾因提供倍率資訊而導致模型移除核心維度）。

**保護集於請求開始凍結**，四個來源取聯集：

| 來源 | 說明 |
|:---|:---|
| ① domain 語意關鍵字 | 既有 `domain_filters`；**無語意歧義的鍵**（`債務`/`貸款整合`/`債務協商`/`卡債`/`醫美`/`醫美診所`/`整形`/`皮膚科`）亦接受 **questions 原文**比對。`老闆`/`業主`/`企業主`/`創業`/`自營`/`攤商`/`加盟`/`小生意` **只認 domain**（問「某攤的目標客群」是人家的顧客，不該套 `employment_status`，#34） |
| ② 分析步驟的必要性宣告 | 分析結果 `reasoning` 中含必要性標記（需使用／必須使用／需以／需考量／必須）的句子所列維度（詞界比對，避免 `income` 命中 `family_income`） |
| ③ 分析步驟的結構化宣告 | 分析回應的 `core_dims` 欄位（「本題不可放寬的核心維度」）—— 免文字解析（v5.9 e2e 實測：銀行房貸題的 reasoning 為散文、未點出 dim 名 → ② 漏接，故補此來源） |
| ④ 模型每輪自我宣告 | 放寬回應的 `protected_dims` 欄位；**單調累積**（一旦宣告，本請求後續輪次皆受保護）→ 消除「loop1 說不可放寬、loop2 說非核心」的自我矛盾 |

**執行（veto）**：任一輪若欲**移除**受保護維度，或其值集**不再是原值集的超集**（縮小／替換）→ **還原該輪變更**（保留前一組 filters）、該筆 `broadening_attempts` 記 `protected_veto: true` + `vetoed_dims`、並以 `stop_reason = protected_veto` 結束迴圈。**純新增值＝合法放寬，不受影響。**

**揭露**：回應新增 `protected_dims: list[str]`（本請求受保護的維度）。

> **取捨**：保護變嚴 → 部分題目回傳數**更少**（`pool_exhausted=true`）。此為契約預期行為（寧可少給，不給錯）。
> 呼叫端判讀：`protected_veto` 表示「該輪放寬被否決、結果維持在保護維度之下」；若同時 `total_matched < top_k`，代表**池子真的小且不該再放寬**。

### broadening（放寬）行為與停止原因（v5.8 #56；v5.9 更新）

當初始 filter 命中數 < `TARGET_MIN`（20）時，系統會進入放寬迴圈（最多 3 輪），並在每輪：

1. **提供實際約束分析**：對每個已套用維度計算「移除它之後的樣本數」，把**倍率最高**的維度與**放寬無效**（移除後樣本數不變）的維度一併寫進放寬 prompt
   - **核心維度（由 domain 語意補上的維度，如醫美之於 `aesthetic_procedure`、債務之於 `debt_status`）排除在「優先放寬」清單外**，並明確標示「勿放寬」（#42 一致性）
2. **連續 2 輪空轉即停**（`no_op`：filters 有變更但樣本數不變）→ 省下一次完整 LLM 呼叫

回應的 `broadening_stop_reason` 揭露停止原因（純新增欄位，v5.8）：

| 值 | 意義 |
|:---|:---|
| `target_reached` | 已達 `TARGET_MIN`（正常結束） |
| `no_op_limit` | **連續 2 輪空轉** → 主動停止（最多放寬 2 輪有效） |
| `loop_limit` | 跑滿 3 輪仍未達 `TARGET_MIN`（可能 `total_matched` 仍小於 20） |
| `budget_limit` | per-request token 預算用盡（analysis 1 次 + 放寬 ≤3 次 = 12000 + 3×8000 ≤ 40000） |
| `llm_empty` / `llm_parse_error` / `llm_no_filters` | 放寬呼叫失敗（回應無法解析／空／無 filters） |
| `no_filters` | 無 filters 可放寬 |
| **`protected_veto`**（v5.9 #57） | **該輪欲移除／縮小受保護的核心維度 → 已還原並停止**（不再硬湊；亦用於模型「刻意拒絕放寬」的情形，#59） |
| `budget_limit` | per-request token 預算用盡（**防護性**：正常參數下 `loop_limit` 會先命中） |
| `""`（空字串） | 未進入放寬迴圈（呼叫端自行建構模型時的預設值；服務端一律給出明確原因） |

> 呼叫端判讀建議：`loop_limit` 且 `total_matched < top_k` 代表**池子真的小**（配合 `pool_exhausted`）；`no_op_limit` 代表**放寬已無效**（連續 2 輪空轉）；**`protected_veto` 代表放寬被核心維度擋下**（配合 `protected_dims`，語意為「不該再放寬」而非「放寬失敗」，v5.9 起與 `no_op_limit` 區分開來）。

### 維度可見性：可篩 / 可見 / 計分（v5.7 #53）

三個集合的關係（**v5.7 起為契約不變式**，由 `scripts/check_response_schema.py` 於出貨前守門）：

| 集合 | 定義 | 現值 |
|:---|:---|:---|
| **可篩** | `api/persona_matcher.py` 的 `valid_dims` | **20** |
| **可見** | `PersonaSummary`（`summary[]` 的欄位） | **21 個維度**（+ `id`/`name`/`score`） |
| **計分** | `SCORED_DIMS`（`scripts/gen_dim_weights.py`） | **18** |

- **不變式 ①：`valid_dims ⊆ summary`** —— 凡可被篩選的維度，回應中都必須看得到，否則消費端無法驗證 filter 是否生效（#53 的成因）
- **不變式 ②：`SCORED_DIMS ⊆ valid_dims`** —— 計分維度必須同時可篩（#54：`housing_cost` 曾停在「有權重、不可篩」的縫隙 → filter 被靜默丟棄）
- `valid_dims = SCORED_DIMS ∪ {politics, media_diet}` —— 後兩者**可篩、可見，但刻意不計分**（RFC「不計分」清單）
- **`summary` 另有兩個非可篩的資訊欄位**：`city_price_tier`（城市物價分級）、`housing_cost`（v5.7 起同時可篩）
- **`/personadb/detail` 是「完整維度」的唯一出口**：回傳 `dimensions` 含全部 25 維（含未公開的 `political_stance` / `political_issues` / `background_story` 等）。`summary` 只保證「可篩維度皆可見」，不保證窮盡
- **新增維度時**：`valid_dims` / `SCORED_DIMS` / `PersonaSummary` **三者要同步**，`do-release.sh` 的 0e / 0f 兩道守門會擋

### 限制

- 權重反映**靜態稀有度**，不反映**語意相關性** — 「花蓮高消費」與「台北時尚圈」可能同分
- 真正的語意理解需要 LLM 打分（未來工作，spec 見 `specs/2026-08-10-relevance-scoring.md`）
- 新增維度時必須同步更新 `SCORED_DIMS`（`scripts/gen_dim_weights.py`）與權重表，
  並用 `bash scripts/regenerate-dim-weights.sh` 驗收（含 `valid_dims − SCORED_DIMS` 必須為空的檢查，2026-09-12 issue #35）

---

## 自動化矛盾偵測（Autoresearch Contradiction Hunt）

> 2026-08-10 新增（issue #5，參考 karpathy/autoresearch）

### 動機

Coherence Rules 只能抓「已知要檢查什麼」的矛盾。若希 TW-P-0177 是被肉眼發現的 —
證明靠人力漏掉很多。旨在把「假設發現」從人工變自動：LLM 提出矛盾假設 → 程式掃描
→ 三分類 → 精審 → 落地。

### 流程

```
程式列舉維度對（15 取 2 = 105 對）
  → LLM 對每對生成 1-3 個假設（condition + rationale + severity）
  → dsl.py 掃描 1069 筆 → violations
  → classify.py LLM 三分類（真矛盾/可解釋/資訊不足）
  → 篩出 severity=high + 判「真矛盾」→ 人工精審
  → rules.py 產出 rules_draft.json + patch diff
  → 人審批 → 套用至 _generate_997.py
  → regen 後再跑一次 hunt → 對比三指標（Recall/Precision/新發現）
```

### 工具

- `scripts/contradiction_hunt/dsl.py` — 受限 condition DSL
- `scripts/contradiction_hunt/hunt.py` — 假設生成 + 掃描
- `scripts/contradiction_hunt/classify.py` — LLM 逐筆三分類 + 15% spot-check
- `scripts/contradiction_hunt/rules.py` — 規則草案 JSON + patch diff 產生器
- `reports/contradiction-hunt-*.md` — 歷史報告（對比基準）

### 驗證指標

| 指標 | 定義 | 目標 |
|:----|:-----|:-----|
| **Recall** | 上次矛盾在新版是否消失 | 0 殘留 |
| **Precision** | 新清單「真矛盾」比例 | 上升（規則 filter 假陽性） |
| **新發現** | 新浮現的組合 | 存在（證明自動化 > 肉眼） |

---

## API 設計

### Candidates endpoint（`GET /personadb/candidates`）

| 參數 | 說明 |
|:----|:-----|
| `questions` | 問題文字 |
| `top_k` | 回傳筆數（1-100，預設 20） |
| `opMode` | 僅篩選 / 篩選+模擬 / 模擬詢問 |
| `role` | 詢問者角色（v4.7，B2B 用）：房仲業者、銀行業者…。讓 LLM 調整 filter 方向 |

### Pipeline（interactive broadening，v4.7）

```
Data grounding: LLM prompt 注入 per-dim 分布（金融只有 70 人 → 不過度使用稀有 dim）
  → LLM → strict filters → DB scan
    → count ≥ TARGET_MIN (20) → scoring → return ✅
    → count < TARGET_MIN → broadening loop (max 3)
        LLM: "只 match N 人，請放寬 1-2 個維度"
        → new filters → DB scan
          → count ≥ TARGET_MIN → return ✅
          → exhaust → status=too_strict + partial results
```
（`status` 語意（v5.9 #58）：**有符合樣本 → `ok`；`total_matched == 0` → `too_strict`** —— 不再依賴「是否跑滿 3 輪」，因提早停止（如 `no_op_limit`）時回傳 0 筆卻報 `ok` 會誤導只讀 `status` 的消費端。）

- 取代 blind relaxation（hardcoded dim_order 丟維度）
- `broadening_attempts` 記錄每次 loop 的決策（loop/change/match_counts）
- Data grounding 從 `tw_persona_1069.json` 動態計算（不 hardcode）

### Scoring（query-based，v4.6）

```
score = Σ importance[dim] × tier_match(value, target) × rarity_weight
```

- **importance**：LLM 產 per-dim 權重（dim_importance）
- **tier_match**：有序 dim 用 tier 距離計分（age=25-34 vs target=35-44 → 0.7）
- **rarity_weight**：log-frequency 權重（dim_weights.json）

## 下一步討論方向

- [ ] 確認最終維度表（9 維度是否完備？需增減？）
- [ ] Domain 疊加設計 — 選舉 / 金融 / 餐飲
- [ ] 人口比例加權抽樣邏輯（各維度組合佔真實人口比例）
- [ ] 批次生成 1,000 個 persona 的 script
- [ ] Hermes skill 包裝 + 查詢 CLI 工具
- [ ] 第一版試用場景 — 建議從選舉分析開始
