#!/usr/bin/env python3
"""Regression tests for issues #33 / #34 / #35 / #36 / #37 (code-level, no LLM calls).

Run:  python3 scripts/test_fixes_2026_09_12.py
"""
import sys, os, json, logging
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
logging.basicConfig(level=logging.WARNING)

FAIL = []
def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)

print("=== #33 filter 值型別 coerce ===")
from api.persona_matcher import llm_filters_to_dimension_filters as F
check("family_size [3,4] → ['3','4']", F({"filters": {"family_size": [3, 4]}}) == {"family_size": ["3", "4"]}, F({"filters": {"family_size": [3, 4]}}))
check("age [35] → ['35']", F({"filters": {"age": [35]}}) == {"age": ["35"]})
check("float 3.5 → ['3.5']", F({"filters": {"family_size": [3.5]}}) == {"family_size": ["3.5"]})
check("None 丟棄", F({"filters": {"age": [None]}}) == {})
check("bool 丟棄", F({"filters": {"age": [True]}}) == {})
check("dict 丟棄", F({"filters": {"hobby": [{"a": 1}]}}) == {})
check("混型 [3,'4',None] → ['3','4']", F({"filters": {"family_size": [3, "4", None]}}) == {"family_size": ["3", "4"]})
check("str 正常", F({"filters": {"family_size": ["3", "4"]}}) == {"family_size": ["3", "4"]})
check("未知維度仍被忽略", F({"filters": {"nope": [1]}}) == {})

print("\n=== #35 權重表覆蓋 + rarity fallback + dims_counted ===")
from api.persona_matcher import load_dim_weights, scored_dims, score_persona, _rarity_weight
w = load_dim_weights()
check("dim_weights 載入 18 維", len([k for k in w if not k.startswith("_")]) == 18, len([k for k in w if not k.startswith("_")]))
for d in ("aesthetic_procedure", "debt_status", "employment_status"):
    check(f"{d} 在權重表", d in w)
check("缺維度 fallback = 1.0（不是 0.0）", _rarity_weight({}, "brand_new_dim", "x") == 1.0)
check("已知維度取實際權重", _rarity_weight(w, "debt_status", "無") == w["debt_status"]["無"])
sd = scored_dims({"debt_status": ["有房貸"], "age": ["35-44"]}, {"debt_status": 0.9, "occupation": 0.7}, [], weights=w)
check("scored_dims 含新維度", "debt_status" in sd and "aesthetic_procedure" not in sd, sd)
check("scored_dims 含 dim_importance-only 維度（舊版漏）", "occupation" in sd, sd)
# 新維度現在真的影響分數（舊版 rarity=0 → 貢獻 0）
p = {"dimensions": {"age": "35-44", "debt_status": "有房貸"}}
col = {"age": ["35-44"], "debt_status": ["有房貸"]}
with_new = score_persona(p, col, {"age": 1.0, "debt_status": 1.0}, [])
without_new = score_persona(p, {"age": ["35-44"]}, {"age": 1.0}, [])
check("新維度計分有貢獻（score 變大）", with_new > without_new, f"{with_new} vs {without_new}")

print("\n=== #36 稀有維度提示 ===")
from api.server import _rare_dims_hint
from api.persona_matcher import load_persona_db
db = load_persona_db()
hint = _rare_dims_hint(db, {"aesthetic_procedure": ["有"]})
check("aesthetic_procedure=['有'] 被標為稀有", "aesthetic_procedure" in hint, hint[:80])
check("提示含實際覆蓋率", "1.5%" in hint, hint[:160])
check("常見維度不提示", _rare_dims_hint(db, {"sex": ["女"]}) == "")
check("debt_status=['無'] 90% 不提示", _rare_dims_hint(db, {"debt_status": ["無"]}) == "", _rare_dims_hint(db, {"debt_status": ["無"]}))
check("debt_status=['有房貸'] 3.6% 應提示（真稀有值）", "debt_status" in _rare_dims_hint(db, {"debt_status": ["有房貸"]}))
check("threshold 可調（2% 時 aesthetic 稀有、有房貸 不稀有）",
      "aesthetic_procedure" in _rare_dims_hint(db, {"aesthetic_procedure": ["有"]}, threshold=0.02)
      and "debt_status" not in _rare_dims_hint(db, {"debt_status": ["有房貸"]}, threshold=0.02))

print("\n=== #37 no-op 結構（broadening_attempts schema） ===")
import inspect
src = inspect.getsource(sys.modules["api.server"])
check("有 no_op 欄位", '"no_op": no_op' in src)
check("有 filters_changed 欄位", '"filters_changed": filters_changed' in src)
check("no-op 會 break", "no-op（filters 未變更、樣本數不變）→ 提前中止" in src)

print("\n=== #34 domain_filters ===")
check("employment_status 關鍵字含 業主/自營", '"業主"' in src and '"自營"' in src)
check("美容 不再對應 aesthetic_procedure", '"美容": {"aesthetic_procedure"' not in src)

print("\n=== BROADEN_PROMPT 佔位符 ===")
from api.llm import BROADEN_PROMPT
try:
    BROADEN_PROMPT.format(match_count=5, target_min=20, current_filters="{}", rare_dims_hint="")
    check("BROADEN_PROMPT.format 四個參數可用", True)
except Exception as e:
    check("BROADEN_PROMPT.format 四個參數可用", False, repr(e))
check("BROADEN_PROMPT 有 rare_dims_hint 佔位符", "{rare_dims_hint}" in BROADEN_PROMPT)
check("BROADEN_PROMPT 禁數量預測", "不要預測或承諾樣本數" in BROADEN_PROMPT)

print("\n" + ("=" * 60))
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
