#!/usr/bin/env python3
"""check_dim_weights.py — 權重表完整性/新鮮度檢查（issue #35 / #41）

用法:
    python3 scripts/check_dim_weights.py [repo_path] [expected_version]

檢查項目:
  1. `_meta.version` 必須等於預期版本（預設讀 repo 的 VERSION）——
     `dim_weights.json` 是**資料衍生產物**：資料 regen 後不重跑就會拿舊分布計分
     （issue #41：v4.4→v5.2 一路帶著 v4.3.2 的權重表出貨）
  2. 每個 filterable 維度（`api/persona_matcher.py` 的 `valid_dims`）都必須在權重表內
     —— 漏了不是報錯，而是「能篩選但權重查不到」（issue #35）
  3. 權重值域檢查（≤3 值 → [0.8,1.4]；≥4 值 → [0.5,2.0]）

退出碼 0 = 全部通過；1 = 有問題（訊息印在 stdout）。
"""
import json
import os
import re
import sys


def _unscored_filterable_dims(repo: str) -> list:
    """Import UNSCORED_FILTERABLE_DIMS from the repo's scripts/gen_dim_weights.py."""
    gw = os.path.join(repo, "scripts", "gen_dim_weights.py")
    if not os.path.exists(gw):
        return ["politics", "media_diet"]  # 保守預設（與 RFC「限制」章節一致）
    src = open(gw).read()
    m = re.search(r"UNSCORED_FILTERABLE_DIMS\s*=\s*\[(.*?)\]", src, re.S)
    if not m:
        return ["politics", "media_diet"]
    return re.findall(r'"([a-z_]+)"', m.group(1))


def main() -> int:
    repo = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    dw_path = os.path.join(repo, "dim_weights.json")

    if not os.path.exists(dw_path):
        print("❌ dim_weights.json 不存在 → bash scripts/regenerate-dim-weights.sh")
        return 1

    w = json.load(open(dw_path))
    dims = [k for k in w if not k.startswith("_")]
    problems = []

    # 1. 新鮮度
    expected = sys.argv[2] if len(sys.argv) > 2 else None
    if expected is None:
        ver_path = os.path.join(repo, "VERSION")
        expected = open(ver_path).read().strip() if os.path.exists(ver_path) else None
    meta_version = (w.get("_meta") or {}).get("version")
    if expected and meta_version != expected:
        problems.append(
            f"dim_weights.json 由 {meta_version} 的資料產生，但目前 VERSION={expected} "
            "→ 資料已 regen 但權重表沒重建（排序會用舊分布）；執行 bash scripts/regenerate-dim-weights.sh"
        )

    # 2. valid_dims 覆蓋（排除 RFC 載明「刻意不計分」的 filterable 維度）
    pm_path = os.path.join(repo, "api", "persona_matcher.py")
    if os.path.exists(pm_path):
        src = open(pm_path).read()
        m = re.search(r"valid_dims = \{(.*?)\}", src, re.S)
        if m:
            valid = set(re.findall(r'"([a-z_]+)"', m.group(1)))
            unscored = set(_unscored_filterable_dims(repo))
            missing = sorted(valid - set(dims) - unscored)
            if missing:
                problems.append(
                    f"filterable 維度不在權重表、也不在刻意的排除清單（{sorted(unscored)}）"
                    f"—— 新維度忘了加 scripts/gen_dim_weights.py 的 SCORED_DIMS？: {missing}"
                )

    # 3. 值域
    for d in dims:
        vals = list(w[d].values())
        lo, hi, n = min(vals), max(vals), len(vals)
        band = (0.8, 1.4) if n <= 3 else (0.5, 2.0)
        if lo < band[0] - 1e-9 or hi > band[1] + 1e-9:
            problems.append(f"{d}: {lo:.2f}-{hi:.2f} 超出 [{band[0]},{band[1]}]（{n} 值）")

    if problems:
        print("❌ dim_weights.json 檢查失敗：")
        for p in problems:
            print("   - " + p)
        return 1
    print(f"✅ dim_weights.json OK（{len(dims)} 維、_meta.version={meta_version}、valid_dims 全涵蓋、值域正常）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
