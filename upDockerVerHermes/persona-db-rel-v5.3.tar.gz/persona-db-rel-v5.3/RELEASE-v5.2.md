# Persona DB v5.2 Release Notes

> 日期: 2026-09-09 | 上一版: v5.1 | 類型: feature（dimension 22 從業身分 + occupation 模型修正，issue #32）

## 重點：Dimension 22 — 從業身分（employment_status）

issue #32（kstsai 逐筆審查：occupation=自營 只有 4/1069 不合理）→ 查證根因是**概念混淆**：
- 現行 occupation「自營」= DGBAS 職業大分類「主管/經理人員」（1-3%）— **職業**概念
- 甲方期望 13% = **從業身分**概念（雇主 4% + 自營作業者 11%，DGBAS 113 表35/表48）
- 決策（X3+Y1+R1）：新增維度 + occupation 自營退役 + full regen

**新維度**：受僱者 / 雇主 / 自營作業者 / 無酬家屬 / 不適用
- 來源: DGBAS 113 年報表48（性別×5年帶，references/employment-status-dgbas-2024.md）
- 指派: 非就業=不適用、公務=受僱100%、無酬家屬限 服務/其他/製造（家庭店面/工廠）
- 收入: 無酬家屬=無薪；雇主偏高收；自營作業者兩極化（修掉舊 INC_PROB[自營] >8萬 40% 病灶）
- 故事: 身分短語（自己開店當老闆/自己做小生意/在自家店裡/工廠幫忙）
- POL: (泛X,自營) → (泛X,雇主型)，occ_group 身分感知

**occupation 自營退役**：OCC_PROB 7 cells 移除（mass 分給 製造/服務/其他）、INC_PROB/FAMILY_INCOME_PROB/OCC_GROUP_MAP/OCC_KEYWORDS/prompt 值清單同步清掉

## 結果（regen seed 42 + dim 20/21 補回）

- occupation=自營: **0**
- employment_status: 不適用 518 / 受僱者 467 / 自營作業者 53 / 雇主 20 / 無酬家屬 11
- **雇主+自營作業者 = 13.2% 就業者（DGBAS ~15%）**；受僱 84.8%（81%）；無酬家屬 2.0%（4%，職業結構限制）
- 收入: 雇主 >8萬 65%、自營作業者 <3萬 32%+3-8萬 51%（兩極化成形）
- dim 20 醫美 16 有、dim 21 債務 43 房貸/5 多重/60 消費債（regen 後重跑補回）
- QA 23 rules + dim22 專屬規則 ALL PASS
- 確定性: regen 兩次 0 diff

## 已知限制

- 無酬家屬 2.0% < DGBAS 4%（persona 職業 mix：55-64 女多為 家管 非 就業服務 — 職業模型限制，記錄）
- 就業者佔比 52% vs 前版（55% 級）— 抽樣波動
- L2 API 整合完成（case 8 老闆 query 驗收）
