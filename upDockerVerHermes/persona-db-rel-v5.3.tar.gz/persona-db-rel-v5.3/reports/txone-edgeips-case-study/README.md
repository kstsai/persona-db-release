# TXOne EdgeIPS persona 評論案例包

> 2026-09-09 建立。persona-db API demo：role=「有自動化工廠的傳統產業廠長」+ q=「OT網路安全」→ top N 人設以第一人稱評論 TXOne EdgeIPS 產品頁。

## 流程

1. **API 查詢**（lzcdh1, v5.1, LLM_ANALYSIS_MODEL=deepseek-v4-pro）：`GET /personadb/candidates?questions=OT網路安全&role=有自動化工廠的傳統產業廠長&opMode=僅篩選`
2. 取 top N persona 完整檔案（repo `tw_persona_1069.json`）
3. **sub-agent (pro) 第一人稱評論**：完整 persona 檔案 + 產品頁實際內容 → 六面向評論（第一印象/痛點共鳴/質疑擔憂/評估邏輯/想問賣方/結論）
4. 原稿 + 整理版存檔（本目錄）

## 查詢紀錄

| 次 | top_k | total_matched | top1 | top2 | top3 | 評論對象 |
|:--|:--|:--|:--|:--|:--|:--|
| 1 | 1 | 200 | 雅芳 TW-P-0912（35-44 自營 苗栗）| — | — | 雅芳 ✅ |
| 2 | 3 | 178 | 秀英 TW-P-0609（55-64 科技 台南）| 清輝 TW-P-0825 | 秀美 TW-P-0620 | 清輝+秀美 ✅ |

⚠️ **抽樣 variance**：同 role+q 兩次 query top1 不同（雅芳→秀英），filters 漂移（含自營→科技限定）— 已知特性（見 persona-roleplay-review reference）。評論代表「目標客群樣本視角」而非特定個人。

## 檔案

| 檔 | 內容 |
|:--|:--|
| `api-query-top1-2026-09-09.json` | 第 1 次 API 原始回應 |
| `api-query-top3-2026-09-09.json` | 第 2 次 API 原始回應（top3） |
| `txone-network-security-page-text.txt` | 產品頁抓取文字（2026-09-09） |
| `persona-review-yaofang-raw.md` / `.md` | 雅芳評論 原稿 + 整理版 |
| `persona-review-qinghui-raw.md` | 清輝評論原稿 |
| `persona-review-xiu-mei-raw.md` | 秀美評論原稿 |
| `persona-review-top2-top3.md` | 清輝+秀美整理版 + 三視角交叉比對 |

## 可帶走的甲方洞察（三視角共識）

1. **零價格資訊 = 最大銷售阻力**：三個 persona 都主動質疑價格/長期成本（老闆要十萬內含維護、員工警戒「幾百萬等級」、專業人士要三年 TCO）
2. **「100% 不中斷」需要 SLA 化**：三人都不信行銷話術，要合約承諾/驗證方法（故障切換毫秒數、實際切換測試）
3. **缺在地客戶證明**：雅芳要苗栗/台中 reference、清輝要半導體廠案例 — 「給我電話我去問」是傳產決策鏈的關鍵動作
4. **維運責任是隱形門檻**：傳產無 MIS/OT 人力 → 「誰來顧」決定買不買；代管選項是潛在賣點
5. **PoV 是共同下一步**：三人（老闆/員工/專業人士）都要先試再買 — 60 分鐘 PoV 訴求有效，但要證明「不動產線、不誤擋」
