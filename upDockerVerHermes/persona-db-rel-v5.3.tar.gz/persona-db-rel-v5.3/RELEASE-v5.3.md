# Persona DB v5.3 Release Notes

> 日期: 2026-09-12 | 上一版: v5.2 | 類型: bug fix（5 項）+ 1 項 latent bug（權重表 stale）
> 來源: lzcdh5(v4.9.2) / lzc-dh1-1(v5.2) API 跨版本驗證報告（2026-09-12, a945 `personadb-dh1-api-verify/`）

## 修的 issue

| # | 標題 | 修法 |
|---|---|---|
| **#33** | `candidates` 500 — LLM filter 值回數字型別（`AttributeError: 'int' object has no attribute 'strip'`） | `persona_matcher._coerce_filter_value()`：純量 coerce 成字串（`str(3)=="3"` 對得到 DB）、非純量（None/bool/dict/list）丟棄 |
| **#34** | `employment_status`（dim 22）從未被套用為 filter | ① `QUESTION_ANALYSIS_PROMPT` 加 must-use 指引（業主本人 vs 顧客語意）② 有效值清單註解同步 ③ `domain_filters` 補「業主」「自營」④ 測試案例語意校正（新增案例 9；案例 8 標為顧客語意） |
| **#35** | 新維度不在 `dim_weights.json` → rarity 權重 0（**靜默不計分**） | ① `gen_dim_weights.SCORED_DIMS` 15→18 ② 重跑權重表 ③ `score_persona` rarity fallback `0.0`→`1.0`（+ warning）④ `dims_counted` 改由 `scored_dims()`（實際計分集合）產生 ⑤ `check_dim_weights.py` 守門 |
| **#36** | `aesthetic_procedure` 誤套非醫美語境（藥妝零售）→ matched 崩到 1 | ① prompt 移除 `aesthetic_procedure` 的「一般消費維度必須」清單 + 加負面約束 ② `domain_filters` 移除「美容」 ③ broadening 對覆蓋率 <5% 的維度下「優先放寬」提示（**不硬刪**，語意留給 LLM） |
| **#37** | broadening 空轉率 17%→41%（no-op 白燒 8000-token pro call） | ① no-op 偵測（`filters` 未變更 → 提前中止）② `broadening_attempts` 新增 `no_op` / `filters_changed` 欄位 ③ `BROADEN_PROMPT` 禁止數量預測 + 允許「原樣回傳」（無法再放寬時） |
| **#41** | `dim_weights.json` 自 v4.3.2 後未隨資料 regen 重建（**latent**：v4.4~v5.2 排序一直用舊分布） | ① 重跑權重表（`_meta.version` v4.3.2 → v5.2/v5.3）② `do-release.sh` Step 0e 出貨前擋 stale ③ `scripts/check_dim_weights.py` ④ 明示 `UNSCORED_FILTERABLE_DIMS = [politics, media_diet]` |

## 行為變更（部署方需知）

1. **排序會變**（#41 + #35）：權重表由 v4.3.2 的資料分布更新為 v5.2 現行分布（12/15 既有維度值改變，例 `family_size=1` 0.7259→2.0），且新維度正式進入計分 → **同一 query 的 top-k 與 score 會與 v5.2 不同**。既有案例的 longitudinal 比較請以本版為新基準。
2. `scoring_basis.dims_counted` 現在會列出**所有實際計分維度**（含 `dim_importance`-only 與新維度）→ 欄位值變多，屬修正而非破壞。
3. `broadening_attempts[]` 新增 `no_op` / `filters_changed` 兩個欄位（既有欄位不變）。
4. `aesthetic_procedure=["有"]` 不再出現於非醫美語意 query → 「康是美的目標客戶」類查詢的 matched 不再崩到 1。

## 驗證

**A. 程式級（決定性，無 LLM）** — `python3 scripts/test_fixes_2026_09_12.py` → **30/30 pass**
- #33：`family_size=[3,4]`→`['3','4']`；`[3.5]`/`[None]`/`[True]`/`[{"a":1}]` 全部安全
- #35：權重表 18 維；缺維度 fallback=1.0；`scored_dims()` 涵蓋新維度與 dim_importance-only；新維度計分有貢獻
- #36：`_rare_dims_hint` 正確標出 1.5% 的 `aesthetic_procedure=['有']`
- #37：`no_op` / `filters_changed` 欄位存在、no-op 會 break
- #41：`check_dim_weights.py` 通過；模擬 stale（`v9.9`）正確 exit 1

**B. 端到端（真 LLM，本機 uvicorn + v5.2 資料）** — 6/6 HTTP 200、**0 次 500**

| 案例 | 耗時 | total_matched | 關鍵驗證 |
|---|---|---|---|
| 業主本人（B2B 問卷受訪者） | 46s | 61 | ✅ `employment_status=['雇主','自營作業者']`（#34） |
| 康是美的目標客戶 ×3 | 69s / 139s / 199s | 28 / 21 / 107 | ✅ **3/3 無 `aesthetic_procedure`**（#36；v5.2 baseline 為 62/1/1+逾時） |
| 醫美診所的目標客戶 | 198s | 8 | ✅ 仍套用 `aesthetic_procedure=['有']`（未修過頭），`dims_counted` 含該維度 |
| 想買電動車的目標客戶 | 24s | 26 | ✅ 無回歸 |

- **#37**：康是美 #2 兩輪 broadening 皆 `no_op=false, filters_changed=true`（11→19→21 有效放寬）；醫美案例第 3 輪 `no_op=true, filters_changed=true`（新旗標正確區分「改了但樣本數沒動」）；`change` 文字**無**數量預測
- **#35**：所有案例的 `dims_counted` 皆涵蓋 `applied_filters` 全部維度（舊版會漏 `family_size` 等 dim_importance-only 維度）

**C. Release gate** — `do-release.sh` Step 0e（`check_dim_weights.py`）通過；`dim_weights.json` 同資料兩次產出 0 差異

## 版本鏈

```
v5.2 (dimension 22 從業身分) → v5.3 (#33/#34/#35/#36/#37/#41)
```
