# Contradiction Hunt Report — v4.5 (Baseline + v4.5.2 Fix)

> 日期: 2026-08-11 | 工具: scripts/contradiction_hunt/
> 資料: tw_persona_1069.json (v4.5, 1069 筆, seed=42)

## Hunt 結果

- **LLM 假設**: 65 個
- **有 violations 的假設**: 29 / 總 violations: 996
- **Recall check**: R-D/E/F/G/R-H 全部 zero residual

## Top 10 Findings（人工分析）

| # | Violations | 組合 | 判定 | 處理 |
|:-:|:---------:|:-----|:----:|:----:|
| 1 | 291 | 都會區 + hb=低 | 可解釋 | — |
| 2 | 226 | 都會區 + cs<500 | 可解釋 | — |
| **3** | **124** | **fs=1 + 已婚** | **真矛盾** | ✅ **R-H**（118 fixes） |
| 4 | 48 | fs=4 + hc<5千 | 可疑 | → 待追蹤 |
| 5 | 42 | inc<3萬 + cs>5000 | 可疑 | → 待追蹤 |
| 6 | 42 | fs=5+ + hc<5千 | 可疑 | → 待追蹤 |
| 7 | 36 | fi=1-3萬 + 汽車 | 可疑 | → 待追蹤 |
| 8 | 35 | 家管 + 未婚 | 可解釋 | — |
| 9 | 16 | 男 + 家管 | 不修 | — |
| 10 | 16 | 無收入 + cs=3000-5000 | R-C 已 cover | — |

## 修復記錄

### issue #6（v4.5.2）
- Bug 1: housing_burden 計算順序錯誤 → recalculation 放在 rules 之後
- Bug 2: fs=1+已婚（124 violations）→ R-H 規則

### 既有規則 Recall（v4.5 對比 v4.4.3）
- R-D/E/F/G: all zero residual ✅
- R-H: new in v4.5.2

## Classify 備註

Deepseek-v4-pro 在 batch classify（full-dimension prompt）中持續 reasoning-only retry。
下次 hunt 需要：
- 用 flash model 做 classify（更輕量）
- 或只用 violate count 排序 + 人工分析 top N

## 追蹤（open → resolved）

| Issue | Finding | 規則 | 狀態 |
|:----:|:-----|:----|:----:|
| #7 | fs=4+hc<5千 → TW-P-0475 cs過高 | R-I | ✅ v4.5.3 |
| #8 | inc<3萬+cs>5000 → 小胖/菲菲 cs過高 | R-J | ✅ v4.5.3 |
| #9 | fs=5++hc<5千 | — | ✅ 全部可解釋 |
| #10 | fi=1-3萬+汽車 → 獨居養車不合理 | R-K | ✅ v4.5.3 (3 fixes, 1 residual) |
