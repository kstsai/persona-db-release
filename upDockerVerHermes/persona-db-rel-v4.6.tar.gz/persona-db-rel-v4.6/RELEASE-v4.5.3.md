# Persona DB v4.5.3 Release Notes

> 日期: 2026-08-11 | 上一版: v4.5.2 | 類型: 資料 coherence 修正

## 變更摘要

v4.5 矛盾 hunt (#7-10) 追蹤處理：新增 3 條 coherence rules。

## 新增規則

| 規則 | 條件 | 修正 | 觸發 |
|:----|:-----|:-----|:----:|
| **R-I** lowfi_bigfam_lowcs | fi=1-3萬 + fs≥4 + cs∈{>5000,3000~5000} | cs 壓低 | 6 fixes |
| **R-J** lowfi_smallfam_lowcs | fi=1-3萬 + fs≤2 + cs∈{>5000,3000~5000} | cs 壓低 | 12 fixes |
| **R-K** lowfi_single_nocar | fi=1-3萬 + fs=1 + commute=汽車 | 改機車/捷運/步行 | 3 fixes |

## Bug fixes

- classify.py: hardcode flash model + llm.py skip reasoning retry
- housing_burden recalculation (issue #6, v4.5.2)

## Coherence 規則總計

A/B/C (v4.4.3) + D/E/F/G (v4.5) + H (v4.5.2) + **I/J/K (v4.5.3) = 11 條**

## 驗證

- QA 23 rules ALL PASS
- Contradiction hunt Recall: R-I/J/K 全部 zero residual

## Hunt 追蹤（#7-10）

| # | Finding | 判定 | 規則 |
|:-:|:-----|:----|:----:|
| 7 | fs=4+hc<5千 → 雅芳 cs 過高 | 修 | R-I |
| 8 | inc<3萬+cs>5000 → 小胖/菲菲 | 修 | R-J |
| 9 | fs=5++hc<5千 | 全部可解釋 | — |
| 10 | fi=1-3萬+汽車獨居 | 修 | R-K |

## 部署

- lzcdh5: pending deploy
- lzcdh1: pending deploy
