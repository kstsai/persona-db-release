# Persona DB v5.12 Release Notes

> 日期: 2026-09-15 | 上一版: v5.11.1 | 類型: **語意護欄機械化（顧客 vs 業主）＋ 保護優先序 ＋ 揭露與留痕**
> 來源: round 11 §3.1/§4.1/§4.1.1/§6.2/§6.3；issue **#65**（我方複驗：機制＋反轉率 2/10）

## 修的 issue

| # | 標題 |
|:-:|:---|
| **#65** | 顧客語意被誤判為業主：`domain` 關鍵字兜底被 LLM 產生的 domain 字串觸發＋保護集把錯誤鎖死 |

## 問題（一句話）

「小吃攤老闆的**目標客群**」（顧客語意）被機械式套上 `employment_status`：該次分析吐出
`domain=餐飲／夜市攤商經營` → 命中 `domain_filters` 的「攤商」條目 → 補上 `employment_status`
→ **同時進入保護集**（錯誤被鎖死）→ 回傳 10 筆全是高收入僱主，與案例 09（B2B 業主名單）**重疊 9/10**。

## 變更

### 1. 主體判準機械化（`_subject_from_questions`）

只看**題目原文**，判「題目的標的」而非「題目提到誰」：

| 主體 | 樣式（節錄） | 例 |
|:--|:--|:--|
| `customer` | 業者詞 + （的）+ 消費端名詞 | 「小吃攤老闆的目標客群」 |
| `owner` | 明確業主受訪者樣式／B2B | 「業主本人（B2B 受訪者）」 |
| `""` | 無法判定 → **不設限**（維持原行為） | 「房貸優惠 — 房仲業者」 |

### 2. forbidden set + 優先序

- `FORBIDDEN_BY_SUBJECT = {"customer": {"employment_status"}}`
- filters 套用前剝除禁用維度（**含 LLM 自己套的**）；`domain` 兜底表在該主體下跳過只補禁用維度的條目
- **`forbidden > protected`**：保護集計算最後扣掉 forbidden 維度

### 3. 揭露與留痕

| 欄位／訊息 | 內容 |
|:--|:--|
| `subject: str` | `customer`／`owner`／`""` —— 消費端可辨識本次詮釋方向（round 11 §6.3-1） |
| `warnings: list[str]` | 剝除時記錄（例：`employment_status 已依「customer」語意剝除`） |
| log INFO | `Subject gate (#65): subject=… forbidden=[…]` |
| log WARNING | 剝除事件（可被 log 監控攔截） |
| log INFO | `Normalize filters (#62)`：最終套用前與**放寬路徑**（補 round 11 §6.2-3 的靜默缺陷） |

### 4. 出貨斷言新增

- 契約：`subject`／`warnings` 存在
- **顧客案例（08）**：無 `employment_status`、`subject='customer'`；**業主案例（09）**：仍套用、`subject='owner'`
- **S/T 不變式**（來源 round 11 §3.2，dsh1 提出）：`widened_dims ⊆ applied_filters`、`widened_dims ∩ relaxed_dims = ∅`
- **同質化矩陣**：跨案例回傳名單兩兩重疊，語意不同卻 ≥8/10 → ⚠️（**語意反轉的指紋**）

## 行為影響（消費者需知）

| 項目 | 影響 |
|:---|:---|
| **顧客語意題**（「X 老闆／店家的目標客群」） | `employment_status` **保證不出現**在 `applied_filters`／`protected_dims`（即使 LLM 或兜底表想套） |
| 業主語意題 | 不受影響（must-use 不變；`#34` 護欄保留） |
| 無法判定主體 | 不設限 → 行為與 v5.11.1 相同 |
| 新增欄位 | `subject`、`warnings`（皆為純新增、有 default，向後相容） |

## 測試

- **單元**：`scripts/test_v5_12_fixes.py`（主體判定 11 案例含 3 反例、endpoint 級 5 情境、留痕 log capture、契約）＋ v5.4–v5.11 全套件回歸
- **真 LLM e2e**：同題（小吃攤 + role 夜市商圈協會）**k≥6 → 反轉 0 次**；「業主本人」題仍正確；債務／銀行／醫美／TESLA 回歸
- **SOP（nodeB）**：fresh deploy → 出貨斷言（含新 4 項）
- **反向測試**：endpoint 測試以「LLM 自己套禁用維度」與「domain 兜底命中」兩種路徑分別驗證剝除
