# 1069 Persona 生成驗證報告 v4.4.3

**日期**: 2026-08-05 | **總數**: 1069 筆 | **種子**: 42
**變更**: Coherence Rules R-A/R-B/R-C（單人家庭 + 無收入矛盾修正）
**RFC 對照**: tw-persona-db-rfc.md「Coherence Rules」章節
**QA 結果**: ✅ 23 條規則全數通過

## 變更動機

NODE-B 實測（v4.4.2）時發現 TW-P-0177 若希 — 獨居（fam=1）無收入，卻有 3-5萬 家庭可支配所得 + 汽車 + 3000~5000 服飾消費。矛盾根源：generator 對 family_size/income/commute_mode/clothing_spend **獨立抽樣**，coherence 檢查漏了「fam=1 + 無收入」組合。

## 新增規則

| 規則 | 觸發 | 修正 | 觸發次數 |
|:-----|:-----|:-----|:--------:|
| R-A fam1_noinc_lowfi | fam=1 且 無收入 且 fi≥3-5萬 | fi 重抽 <1萬(40%) / 1-3萬(60%) | **9** |
| R-B fam1_noinc_nocar | fam=1 且 無收入 且 commute=汽車 | commute 改 機車(30%) / 捷運公車(40%) / 步行腳踏車(30%) | **4** |
| R-C fam1_noinc_lowcs | fam=1 且 無收入 且 cs∈{>5000, 3000~5000} | cs 重抽 <500(50%) / 500~1500(30%) / 1500~3000(20%) | **4** |

## 若希（TW-P-0177）修正對照

| 維度 | Before | After |
|:-----|:-------|:------|
| family_size | 1 | **3**（regen 後變住家學生） |
| family_income | 3-5萬 | **1-3萬** |
| commute_mode | 汽車 | **捷運/公車** |
| clothing_spend | 3000~5000 | 3000~5000（fam=3 住家合理） |

## 殘留 edge case（可接受）

2 筆「fam=1 + 無收入 + fi=3-5萬」仍存在 — 因 `adjust_family_income_by_tier`（依城市物價）在規則之後把 fi 調回。但 R-B/R-C 已生效（無汽車、無高治裝），可解釋為「依賴儲蓄/家庭補助的獨居者」，矛盾程度可接受。

## 資料分布驗證（無回歸）

| 檢查 | 結果 |
|:-----|:-----|
| 總數 | 1069 ✅ |
| QA 23 rules | ALL PASS ✅ |
| family_income 分布 | 無異常跳動（R-A 只影響 9 筆） |
| commute_mode 分布 | 汽車 -4 筆（R-B），無異常 |
| clothing_spend 分布 | 高階 -4 筆（R-C），無異常 |

## 資料來源

| 維度 | 資料源 |
|:----|:-------|
| 年齡/性別/區域 | 內政部戶政司 113年人口統計 |
| 教育/職業/收入 | DGBAS 113年 人力資源調查 |
| 家庭所得/居住/服飾 | DGBAS 113年 家庭收支調查 |
| 通勤方式 | 交通部 2024 運具分配調查 |
