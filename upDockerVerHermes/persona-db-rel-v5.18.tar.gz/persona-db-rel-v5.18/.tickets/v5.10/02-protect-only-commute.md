# T02 — protect-only 語意對應（#61）

> Spec: `specs/2026-09-15-v5.10-diagnostics-and-protect-only.md` | 檔案: `api/server.py`

## 變更

1. 新增 `PROTECT_ONLY_DOMAIN_DIMS = {"電動車": {"commute_mode"}, "汽車": {"commute_mode"}}`
   - 命中時**只加入 PROTECTED**（#57），**不修改 `filters`**（與 `domain_filters` 的補值語意分離）
   - 比對範圍限 **domain**（不做 query 原文比對）
2. 保護集計算改為五來源聯集：domain 關鍵字 ∪ reasoning 必要性 ∪ 分析 `core_dims` ∪ 模型每輪 `protected_dims` ∪ **protect-only 語意對應**
3. `Protected dims (#57)` 診斷行新增 `protect_only=` 欄位

## Acceptance criteria

- [x] 單元：domain 含「電動車」/「汽車」→ 保護集含 `commute_mode`
- [x] 單元：對照組（domain 不含）→ 不含
- [x] 單元：protect-only **不改變 filters**（未憑空新增篩選維度）
- [x] 單元：移除 `commute_mode` → veto（`protected_veto`）且 `applied_filters` 保留
- [x] 單元：`domain_filters` 未新增 `commute_mode` 補值
- [ ] 真 LLM e2e：TESLA query `relaxed_dims` 不含 `commute_mode`
- [ ] 其他案例回歸

## 取捨

TESLA 類 query 可放寬的維度變少 → 樣本數可能下降（契約預期：寧可少給，不給錯）。
