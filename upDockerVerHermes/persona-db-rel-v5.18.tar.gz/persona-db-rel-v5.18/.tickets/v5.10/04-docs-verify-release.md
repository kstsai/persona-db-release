# T04 — 文件 / 驗證 / 進版（v5.10）

> Spec: `specs/2026-09-15-v5.10-diagnostics-and-protect-only.md` | Blocked by: T01、T02、T03

## 文件

1. **RFC**：核心維度保護改為**五來源**（新增 ⑤ protect-only 語意對應）；新增運維段（`LOG_LEVEL`、log rotation）
2. **`RELEASE-v5.10.md`**：三項變更 + 給消費者的行為變更表
3. **`.tickets/v5.10/01..04`**：本批票

## 驗證

1. **單元**：`scripts/test_v5_10_fixes.py`（#60 三情境、#61 四情境）＋ v5.4–v5.9 全套件回歸
2. **真 LLM e2e**：TESLA（`commute_mode` 不得被放寬）＋ 債務/銀行/醫美/業主回歸
3. **#45 驗收**：5 案例 `mode` ≥2 種值 + filters 品質不回歸
4. **Gate**：`check_dim_weights` + `check_response_schema`
5. **SOP**（受測主機由 kstsai 指定）：fresh deploy → 出貨測試腳本 → **新增 v5.10 斷言**：
   - `docker logs | grep -c "Protected dims"` > 0（#60 生效）
   - 電動車類查詢 `protected_dims` 含 `commute_mode`（#61）

## Acceptance criteria

- [ ] 單元全過；既有套件全綠
- [ ] e2e：TESLA `relaxed_dims` 不含 `commute_mode`
- [ ] #45 五案例 ≥2 種 `mode`
- [ ] 兩 gate pass；tarball 潔淨；tag → HEAD 一致
- [ ] 出貨斷言含 v5.10 兩條並於部署環境驗證
- [ ] RFC / RELEASE 同步；#60/#61/#45 以證據關閉（雙 repo）
