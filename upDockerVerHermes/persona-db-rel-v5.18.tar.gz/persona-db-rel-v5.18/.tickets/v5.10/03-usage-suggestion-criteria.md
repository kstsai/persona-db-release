# T03 — `usage_suggestion` 判斷準則（#45）

> Spec: `specs/2026-09-15-v5.10-diagnostics-and-protect-only.md` | 檔案: `api/llm.py`（`QUESTION_ANALYSIS_PROMPT`）

## 前置量測（k=5 變異檢定，2026-09-15）

同 query（「康是美的目標客戶」）連打 5 次 → **`mode` 5/5 = `問卷答題者`**（值分布單一）⇒ 依 issue 流程判定為**系統性**（非抽樣雜訊）→ 走修 prompt 路徑。

## 變更

在 `QUESTION_ANALYSIS_PROMPT` 的 `usage_suggestion` 說明補**選擇準則**（原本只有值域與定義、沒有判準）：

1. 特定角色／決策者的立場（B2B、業主或雇主本人、專業人士、主管、採購決策者）→ 偏向「模擬詢問」
2. 某一族群的態度／偏好／推薦（一般消費者、家長、某地區居民、某興趣族群）→ 偏向「問卷答題者」
3. 兩者兼具或題意不明 → 「兩者皆可」

並補一句判準：「以**題目的主體是「誰的觀點」**為準」。

## Acceptance criteria

- [ ] 5 案例的 `mode` **至少出現 2 種值**
- [ ] `recommended_opMode` 與 `mode` 一致（模擬詢問↔篩選+模擬；問卷答題者↔僅篩選）
- [ ] **不得影響 filters 品質**：案例 01/06/07 既有斷言回歸全綠
- [ ] prompt 可 format、JSON 範例合法（pitfall #41）

## 備註

判斷準則與 issue 建議方向一致，但措辭改以「題目主體是誰的觀點」為軸 —— 因為「B2B 一律模擬詢問」會與既有合理案例衝突（案例 09「找業主本人填答」的 `問卷答題者` 其實正確）。
