# T01 — root logger 設定（#60）

> Spec: `specs/2026-09-15-v5.10-diagnostics-and-protect-only.md` | 檔案: `api/server.py`、`upDockerVerHermes/pocDemo.env`、`upDockerVerHermes/deploy-hermes-personadb-containers.sh`

## 變更

1. `api/server.py` 模組載入時設定 root logger：
   - `LOG_LEVEL` 環境變數（預設 `INFO`）；**值非法時回退 `INFO`**（不讓 `basicConfig` 拋 `ValueError` 導致服務起不來）
   - root 已有 handler 時**只調整層級**，不重複掛 handler
2. `pocDemo.env` 新增 `LOG_LEVEL=INFO`
3. 部署腳本對 `persona-db-api` 的 `docker run` 新增 `--log-opt max-size=10m --log-opt max-file=3`（log rotation）

## Acceptance criteria

- [x] 單元：`LOG_LEVEL=WARNING` → root 層級 WARNING 且 INFO 不輸出；`LOG_LEVEL=INFO` → INFO 正常輸出
- [x] 單元：`LOG_LEVEL` 值非法 → 回退、不炸（子行程匯入測試）
- [x] 部署環境：`docker logs persona-db-api | grep -c "Protected dims"` > 0（`LOG_LEVEL=INFO`）
- [x] 部署環境：`LOG_LEVEL=WARNING` 重啟 → 該行為 0
- [ ] 既有 WARNING 行不受影響

## 備註

`docker run` 缺 `--restart`（僅 hermes 容器有）→ 本票**不動**（避免擴大 diff），另記為觀察。
