# T03 — 主體覆蓋擴充與依據揭露（#67 A/B）

> Spec 同 T01 | 檔案: `api/server.py`、`api/models.py`

## 變更
1. 樣式擴充：業者詞加 `業者`／`診所`／`補習班`；消費端名詞加 `目標客戶`／`客層`；允許省略「目標」
2. 新增 `_subject_detail()` → `(subject, basis)`；回應新增 `subject_basis`

## Acceptance criteria
- [ ] 單元：新樣式正例；**既有 9 案例判定不變**（09 必須仍為 `owner`；04／05 仍為 `""`）
- [ ] 單元：`subject_basis` 於 `subject != ""` 時非空且對應題目原文
- [ ] 真 LLM：新樣式題 k≥3 → `customer` 且未套 `employment_status`
