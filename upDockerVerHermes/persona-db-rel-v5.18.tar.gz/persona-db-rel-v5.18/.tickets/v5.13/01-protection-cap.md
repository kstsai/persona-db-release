# T01 — 來源④上限與揭露（#66 A）

> Spec: `specs/2026-09-15-v5.13-protection-cap-and-subject-coverage.md` | 檔案: `api/server.py`、`api/models.py`

## 變更
1. `DECLARED_PROTECTED_MAX = 3`；實際上限 = `max(1, min(3, len(filters_at_start)//2))`（以請求開始的已套用維度數為基準）
2. 超過上限的模型宣告 → 丟棄 + `logger.info` + `warnings` 追加一則
3. 回應新增 `protected_dims_sources`（五來源拆解）
4. 保護集覆蓋 ≥1/2 已套用維度 → `warnings` 追加一則

## Acceptance criteria
- [ ] 單元：宣告 5 個時只接受上限數；①②③⑤ 不受影響
- [ ] 單元：`protected_dims_sources` 各鍵正確、且不含 forbidden
- [ ] 單元：覆蓋警示在門檻上觸發
- [ ] 既有 9 案例回歸（保護集大小與 `matched` 不得退化）
