# T04 — 驗證 / 斷言 / 進版（v5.13）

> Spec 同 T01 | Blocked by: T01、T02、T03

## 出貨斷言新增
1. `protected_dims_sources`／`subject_basis` 欄位存在（契約）
2. enum 含 `protection_saturated`（既有動態白名單自動涵蓋）
3. 保護集上限：`len(protected_dims) - 本回合新增` ≤ 上限（以回應資料驗證）
4. 新樣式題的 `subject`／`applied_filters`（若納入套件案例）

## 驗證
- [ ] 單元 11 套件全綠（新增 `test_v5_13_fixes.py`）
- [ ] 真 LLM e2e：新樣式 k≥3、既有回歸（08/09/TESLA/債務/銀行/醫美）
- [ ] SOP（nodeB）：fresh deploy → 出貨斷言全跑
- [ ] RFC／RELEASE 同步；#66／#67 以證據關閉（雙 repo）
