# T02 — `protection_saturated` 停止原因（#66 C）

> Spec 同 T01 | 檔案: `api/server.py`、`api/models.py`

## 變更
迴圈開始時若 `set(filters) - (protected_dims | declared_protected)` 為空 → 不呼叫 LLM，`stop_reason = "protection_saturated"` 並停止；加入 enum／RFC／斷言白名單（白名單已動態取自 OpenAPI）。

## Acceptance criteria
- [ ] 單元：全維度受保護 → `protection_saturated`，且**未呼叫** LLM
- [ ] 單元：仍可移除至少一維時 → 行為不變
- [ ] 契約：enum 與 RFC 更新；出貨斷言自動涵蓋（動態白名單）
