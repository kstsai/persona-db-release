# T01 — 主體判準機械化 + forbidden set（#65）

> Spec: `specs/2026-09-15-v5.12-subject-gate-and-forbidden-dims.md` | 檔案: `api/server.py`、`api/models.py`

## 變更

1. `_subject_from_questions(q_list)`：正則判定 `customer`／`owner`／`""`（只看題目原文）
   - `customer`：`(老闆|業主|企業主|攤商|店家|商家|店主|店長|自營)[^。；;]{0,8}(的)?(目標客群|客群|顧客|消費者|客戶群|來客)`
   - `owner`：`(業主|老闆|企業主|雇主)[^。；;]{0,6}(本人|名單|受訪者|訪談)|B2B`
   - 先判 customer（有消費端標的才是顧客語意）
2. `FORBIDDEN_BY_SUBJECT = {"customer": {"employment_status"}}`
3. filters 套用前剝除禁用維度；**domain 兜底表**在該主體下跳過只補禁用維度的條目
4. `protected_dims -= forbidden`
5. 回應新增 `subject: str`、`warnings: list[str]`

## Acceptance criteria

- [x] 單元：11 個主體判定案例（含 3 個反例）全對
- [x] 單元/endpoint：顧客語意 → 剝除、不進保護集、`subject='customer'`、`warnings` 有值
- [x] endpoint：業主語意 → **仍套用** `employment_status` 且受保護（#34 must-use 不回歸）
- [x] endpoint：主體未判定 → 不設限（既有行為不變）
- [x] endpoint：domain 含「攤商經營」但題目為顧客語意 → 兜底被抑制
- [ ] 真 LLM：同題 k≥6 反轉 0 次；「業主本人」題仍正確
