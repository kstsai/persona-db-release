# T03 — 剝除與正規化的留痕（#62 / #65）

> Spec 同 T01 | 檔案: `api/server.py`

## 變更

1. `Subject gate (#65): subject=… forbidden=[…]`（INFO，每請求）
2. 剝除時 `Subject gate (#65): … 剝除禁用維度 […]`（**WARNING**，可被 log 監控抓到）
3. `Normalize filters (#62)`: 最終套用前與**放寬路徑**各寫一行 INFO（含被丟棄維度）
   —— 補 round 11 §6.2-3 指出的「#62 修復原本靜默、無法稽核」

## Acceptance criteria

- [x] 單元：以 log capture 驗證 subject 與 normalize 訊息確實輸出
- [x] 部署環境：`docker logs` 可見上述 INFO/WARNING（SOP 斷言）
