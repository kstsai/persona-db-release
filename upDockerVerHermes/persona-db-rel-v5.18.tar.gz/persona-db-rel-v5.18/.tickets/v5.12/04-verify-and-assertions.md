# T04 — 驗證 / 斷言 / 進版（v5.12）

> Spec 同 T01 | Blocked by: T01、T02、T03

## 出貨斷言新增（release repo `test-persona-db-api.sh`）

1. `subject` / `warnings` 欄位存在（契約）
2. **顧客語意案例（08）**：`applied_filters` 不含 `employment_status`、`subject == 'customer'`
3. **業主案例（09）**：`employment_status` 仍套用、`subject == 'owner'`（#34 must-use）
4. **S/T 不變式**（來源 round 11 §3.2，註記 dsh1）：`widened_dims ⊆ applied_filters`、`widened_dims ∩ relaxed_dims = ∅`
5. **同質化矩陣**：各案例回傳名單兩兩重疊；`08∩09`（或任何語意不同配對）≥ 8/10 → ⚠️（語意反轉指紋）

## 驗證

- [x] 單元 10 套件全綠（含新增 `test_v5_12_fixes.py`）
- [ ] 真 LLM e2e：k≥6 反轉 0 次；業主 must-use；債務/銀行/醫美/TESLA 回歸
- [ ] SOP（nodeB）：fresh deploy → 出貨斷言全跑（含新 4/5 項）
- [ ] RFC / RELEASE 同步；#65 以證據關閉（雙 repo）
