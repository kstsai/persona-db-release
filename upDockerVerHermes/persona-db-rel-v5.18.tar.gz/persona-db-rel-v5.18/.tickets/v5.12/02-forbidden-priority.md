# T02 — 優先序 `forbidden > protected`（#65）

> Spec 同 T01 | 檔案: `api/server.py`

## 變更

保護集計算最後扣掉 forbidden 維度（`protected_dims = (reinforced ∪ reasoning ∪ core_declared ∪ protect_only) - forbidden`）。
動機：round 11 §6.2-2/§6.3-3 —— 保護機制把「被誤套的維度」一起保護起來，使錯誤更難被自動修正。

## Acceptance criteria

- [x] 單元：`employment_status` 被 forbidden 時不得出現在 `protected_dims`
- [x] 不變式 `protected_dims ∩ relaxed_dims = ∅` 仍成立
- [x] 非禁用維度的保護行為不變（既有 #57 測試全過）
