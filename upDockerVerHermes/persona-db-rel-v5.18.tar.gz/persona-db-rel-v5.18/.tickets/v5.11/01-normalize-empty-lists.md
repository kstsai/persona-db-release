# T01 — 空值清單正規化（#62）

> Spec: `specs/2026-09-15-v5.11-empty-list-and-widened-dims.md` | 檔案: `api/server.py`

## 變更

1. 新增 `_normalize_filters(filters: dict) -> dict`：**丟棄值清單為空的維度**（保留原 dict 的其他鍵；純量值不動）
2. 放寬迴圈：解析出 `new_filters` 後**先正規化、再做 veto 判定**（受保護維度被清空 → 正規化後消失 → 落入既有「移除」判定 → veto）
3. 最終 `applied_filters` 亦走正規化（保證回應不含空值清單）

## Acceptance criteria

- [ ] 單元：`{"age": [], "income": [">8萬"]}` → `{"income": [">8萬"]}`
- [ ] 單元：純量值（非 list）不受影響；空 dict 回空 dict
- [ ] endpoint：放寬回應把**非受保護**維度設為 `[]` → `applied_filters` 不含該維度、且不排除所有人
- [ ] endpoint：放寬回應把**受保護**維度設為 `[]` → `protected_veto` + `vetoed_dims` 含該維度
- [ ] 出貨斷言（repo 既有）：`applied_filters` 不得有空值清單
