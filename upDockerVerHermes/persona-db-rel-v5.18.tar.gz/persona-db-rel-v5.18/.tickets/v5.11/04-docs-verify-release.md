# T04 — 文件 / 驗證 / 進版（v5.11）＋ infra `--restart`

> Spec: `specs/2026-09-15-v5.11-empty-list-and-widened-dims.md` | Blocked by: T01、T02、T03

## 文件

1. **RFC**：veto 條件（受保護維度＝任何變更）、`widened_dims` 欄位、空值清單語意說明（「上游一律正規化；底層 `filter_personas` 的『空清單＝排除全部』不變但不再被觸發」）
2. **`concepts/relevance-scoring.md`**：契約表補 `widened_dims`
3. **`RELEASE-v5.11.md`**：變更 + 行為影響（受保護維度雙向凍結 → 回傳數可能再降；`applied_filters` 不再有空清單）
4. **`.tickets/v5.11/01..04`**

## infra（不涉版號，release repo）

5. `deploy-hermes-personadb-containers.sh`：`persona-db-api` 的 `docker run` 加 **`--restart unless-stopped`**（對齊 hermes 容器；主機重啟後 API 自動恢復）
6. `test-persona-db-api.sh`：新增「受保護維度未被放寬值集」斷言（配合 T02）

## 驗證

1. 單元 `scripts/test_v5_11_fixes.py` + v5.4–v5.10 全套件回歸
2. 真 LLM e2e：TESLA／醫美（值集）＋ 債務／銀行／業主回歸 ＋ 顧客語意題（#64）
3. Gate：`check_dim_weights` + `check_response_schema`
4. SOP（nodeB）：fresh deploy（含 `--restart` 驗證 `docker inspect`）→ 出貨斷言全跑 → 空清單守門與 K/L/M

## Acceptance criteria

- [ ] 單元全過；既有套件全綠（含更新後的 veto 語意測試）
- [ ] e2e：受保護維度不被放寬值集；`widened_dims` 有值
- [ ] `docker inspect` 顯示 `RestartPolicy=unless-stopped`
- [ ] SOP 出貨斷言：42+ 條全過（含既有的 `protected_dims ∩ relaxed_dims = ∅` 與空清單守門）
- [ ] 兩 gate pass；tag → HEAD 一致；tarball 潔淨
- [ ] RFC / RELEASE 同步；#62/#63/#64 以證據關閉（雙 repo）
