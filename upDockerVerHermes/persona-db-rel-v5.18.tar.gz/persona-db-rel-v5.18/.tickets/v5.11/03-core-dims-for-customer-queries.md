# T03 — 顧客語意題的 `core_dims`（#64）

> Spec: `specs/2026-09-15-v5.11-empty-list-and-widened-dims.md` | 檔案: `api/llm.py`（`QUESTION_ANALYSIS_PROMPT`）

## 變更

在 `core_dims` 的指示補一句：

> **即使是「找某店／某攤的目標客群」這類顧客語意題，也要指出 1–2 個定義目標族群的維度**（例：`clothing_spend`／`income`／`occupation`／`family_size`）；沒有明確語意主體時才給空陣列。

理由：案例 08（小吃攤）目前 `protected_dims` 為空 → #57 機制對該類題目不生效；而 ①domain 詞表不觸發是**刻意**的（#34 歧義鍵只認 domain）。

## Acceptance criteria

- [ ] prompt 可 format、JSON 範例仍合法（pitfall #41）
- [ ] 真 LLM：同型態題（顧客語意的店/攤類查詢）**3 次執行至少 2 次**給出非空 `protected_dims`
- [ ] **must-not-use 不回歸**：案例 08 仍不得套 `employment_status`
- [ ] 既有 9 案例回歸（保護集不得因此暴增到無可放寬）
- [ ] 若驗收未達 → 回報並改走 A 案（明示為 known limitation），不硬改

## ⚠️ v5.11.1 處置（2026-09-15）

**prompt 改動已回退（走 A 案）**：v1 措辭使醫美多宣告 `clothing_spend`/`income`；v2 措辭使小吃攤 run1 套用 `employment_status`（must-not-use 回歸）。兩版皆無法同時滿足驗收 → 記為 known-limitation。
