# T01 — `widened_deltas`（#69）

> Spec: `specs/2026-09-16-v5.14-...md` | 檔案: `api/server.py`、`api/models.py`

## 變更
`_widened_deltas(prev, new)` 回傳 `[{"dim","before","after","added"}]`（嚴格超集口徑，與 `widened_dims` 一致）；
寫入 `broadening_attempts[]`（新欄位，default `[]`）。

## Acceptance criteria
- [ ] `{d["dim"] for d in widened_deltas} == set(widened_dims)`（同輪一致）
- [ ] `added` 非空、`before ⊆ after`
- [ ] 未放寬的輪次為 `[]`
- [ ] 契約向後相容（既有 key 集合不變）
