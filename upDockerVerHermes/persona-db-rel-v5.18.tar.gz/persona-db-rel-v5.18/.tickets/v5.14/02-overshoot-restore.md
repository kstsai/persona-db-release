# T02 — 過衝回饋 + 自選維度優先序（#70）

> Spec 同 T01 | 檔案: `api/server.py`、`api/models.py`

## 變更
- **A**：移除維度後 `after / max(before,1) ≥ 3` → 還原被移除維度、加入保護集（新來源 `overshoot_restore`）、
  `warnings` 揭露倍率、attempt 標記 `overshoot_restore=True`
- **B**：`_constraint_hint(..., self_selected_dims=[...])` → 提示「優先放寬其他維度」（**不進保護集**）

## Acceptance criteria
- [ ] 單元：造 3× 過衝 → 還原且維度進保護集；< 3× 不還原
- [ ] 單元：還原後 `protected_dims_sources.overshoot_restore` 非空、`warnings` 含倍率
- [ ] 真 LLM：案例 03（時尚）過衝消失或被還原
- [ ] 回歸：既有 9 案例不得因此讓 `matched` 顯著下降（正常放寬不受影響）
