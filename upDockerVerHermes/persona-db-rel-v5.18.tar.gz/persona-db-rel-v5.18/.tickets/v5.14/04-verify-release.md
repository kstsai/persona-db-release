# T04 — 驗證/斷言/進版（v5.14）

> Spec 同 T01 | Blocked by: T01、T02、T03

## 出貨斷言更新
1. `protected_dims_sources` **六鍵**（新增 `overshoot_restore`）
2. 來源④數量改以 **`declared_protected_cap`** 驗證（取代硬編碼 3）
3. `widened_deltas` 契約（存在、口徑與 `widened_dims` 一致）
4. `overshoot_restore`：若有過衝還原事件 → 該維度必在保護集內

## 驗證
- [ ] 單元 12 套件全綠（新增 `test_v5_14_fixes.py`）
- [ ] 真 LLM e2e：案例 03 過衝、六鍵來源、既有回歸
- [ ] SOP（nodeB）全跑、0 紅旗
- [ ] RFC／RELEASE 同步；#69/#70/#71 以證據關閉（雙 repo）
