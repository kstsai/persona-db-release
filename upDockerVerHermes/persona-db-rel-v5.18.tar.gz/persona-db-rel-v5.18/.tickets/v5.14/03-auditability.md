# T03 — 留痕位置 + 上限基準（#71）

> Spec 同 T01 | 檔案: `api/server.py`、`api/models.py`

## 變更
- **A**：`_normalize_filters()` 本體記 log；呼叫點移除重複訊息
- **B**：回應新增 `declared_protected_cap: int`

## Acceptance criteria
- [ ] 單元：直接呼叫 `_normalize_filters()` 即有 log（不需經端點）
- [ ] 單元：呼叫點不再輸出重複訊息
- [ ] 單元／SOP：`len(model_declared) ≤ declared_protected_cap` 可於部署層驗證
