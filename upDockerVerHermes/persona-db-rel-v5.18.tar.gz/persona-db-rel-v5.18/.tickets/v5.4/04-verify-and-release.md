# T04 — 驗證與進版（v5.4）

> Spec: `specs/2026-09-12-v5.4-rare-dim-guard-and-score-provenance.md` | Blocked by: T01、T02、T03
> Issue: #42、#43、#44 | 檔案: `scripts/test_v5_4_fixes.py`、`VERSION`

## 目標

三層驗證（單元 / 本機 e2e / SOP QA），通過才發 v5.4。

## 步驟

1. **單元（決定性）**：`scripts/test_v5_4_fixes.py`
   - rescue-only、reinforced 排除、overshoot 判定、新欄位、模型序列化
2. **本機 e2e（真 LLM）**
   - 案例 07 債務整合：`debt_status` 保留、符合率 ≥ 9/10、`overshoot=false`
   - 案例 06 醫美：雙硬篩選、`pool_exhausted=true`、`returned=5`
   - 案例 03 時尚（起點 0）→ **rescue 生效**（證明救援沒被關掉）
   - 空轉率 ≤ 20%
3. **`scripts/regenerate-dim-weights.sh`**（版號變更 → `_meta.version` 同步）+ `check_dim_weights.py`
4. **進版**：`VERSION` → v5.4、`do-release.sh`（留意已知 pitfall：Step 3 後中斷需手動完成 commit/tag/push）
5. **tarball 潔淨驗證**：`.bak`/`.pyc` = 0、`api/*.py` 與 working tree 逐位元相同
6. **SOP QA**：NODE-A（`undeploy` → `deploy --skip-hermes`）→ `test-persona-db-api.sh` → 逐項判讀（非只看 exit code）

## Acceptance criteria

- [ ] 單元全數 pass
- [ ] e2e 4 項全綠（含案例 03 救援路徑）
- [ ] `check_dim_weights.py` pass；`_meta.version == v5.4`
- [ ] tarball 無 stray 檔、code 與 working tree 一致
- [ ] SOP QA：9/9 案例 200、0 traceback、Role QA DIFFERENT、新欄位出現在部署環境
- [ ] 三個 issue 以驗證證據關閉（雙 repo 鏡像）
