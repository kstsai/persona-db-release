# Tickets — Dimension 22 從業身分（issue #32, v5.2）

> 2026-09-04 | RFC: tw-persona-db-rfc.md §「從業身分（dimension 22）」commit e895f95
> 決策: X3（新增維度）+ Y1（occupation 自營退役）+ R1（full regen）
> 狀態: 01-04 全部 TODO

## Ticket 01: Generator refactor（occupation 自營退役 + EMP_STATUS 原生）

- [ ] OCC_PROB: 7 個 cell 移除「自營」，mass 依比例分給 製造/服務/其他
- [ ] INC_PROB: 移除「自營」key（>8萬 40% 過高問題隨退役消失）
- [ ] FAMILY_INCOME_PROB: 移除 (>8萬, 自營) key
- [ ] POL_PROB: (泛綠/泛藍/白/第三勢力, 自營) rows → 移除或改 key（自營 mass 併入 製造/服務 的政治分布）
- [ ] pick_hobbies: 檢查 occ=自營 key（有則移除/併入）
- [ ] 新增 EMP_STATUS[(sex, age)] 表（DGBAS 表48 5年帶 rates）
- [ ] 指派邏輯: occupation 選完後 → 公務=受僱者 100%；其餘就業 occ 依 EMP_STATUS 抽身分；無酬家屬僅 服務/其他；學生/退休/家管/失業/0-18=不適用
- [ ] 故事短語: occupation 自營短語 → employment_status 短語（3 種身分）
- [ ] 收入連動: 雇主 income 偏高、自營作業者兩極化（若 INC 仍 per-occupation，加身分微調或 per-(occ,status) 處理）
- [ ] OCC_CITY_BOOST: 排除條件加註（自營退役後無需特判，確認無殘留）
- [ ] 驗證: dryrun + determinism gate（兩次 0 diff）

## Ticket 02: Regen + dim 20/21 補回

- [ ] regen（seed 42，先 .bak）— 新人口含 employment_status、無 occupation=自營
- [ ] 重跑 `_annotate_aesthetic.py`（dim 20）+ `_annotate_debt.py`（dim 21）於新資料
- [ ] 確定性驗證: 兩次跑 0 diff（regen 後 annotation 重跑同 seed 同結果）

## Ticket 03: QA + 佔比合理性

- [ ] qa_validate.py 23 rules 全過
- [ ] 新規則: ① 公務/教育(公立?) 非雇主 ② 無酬家屬僅 服務/其他 ③ 不適用 族群正確（學生/退休/家管/失業/0-18）④ employment_status 存在性（全員）
- [ ] 佔比合理性報告: 雇主+自營作業者 ~15% 就業者（對 DGBAS）、無酬家屬 女45+ 明顯、occupation=自營 0 殘留、收入分布（自營作業者 <3萬 比例 vs 雇主 >8萬）
- [ ] 驗證 #32 原個案: 雅芳類「高中+自營作業者/雇主+>8萬」佔比合理性

## Ticket 04: L2 API + Release v5.2

- [ ] valid_dims/models/server/llm.py 加 employment_status（有效值 5 值）；occupation 值清單**移除自營**（llm.py prompt、QA、docs）
- [ ] domain reinforcement: 老闆/攤商/創業/加盟 → employment_status:[雇主, 自營作業者]
- [ ] test-persona-db-api.sh case 8（老闆客群 query → employment_status filter）
- [ ] RELEASE-v5.2.md + VERSION + do-release + tag 雙 repo
- [ ] NODE-B pre-release SOP + LLM verify
- [ ] issue #32 close（雙 repo）+ digest

## 驗收指標（issue #32）

- regen 後: 就業者中雇主+自營作業者合計落在 DGBAS 期望區間（男 25-44 ~12-14%、男 45-64 ~25-30% 等 per 表48）
- occupation=自營 = 0
- 甲方 query「小吃攤老闆/小生意人」能撈到（服務/其他 + 自營作業者）
