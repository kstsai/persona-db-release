#!/usr/bin/env python3
"""v5.17 regression tests — API 文件內建操作重點（甲方在 /docs 第一眼看到）。

驗的是「送進 OpenAPI 的內容」＝ Swagger UI 實際渲染的來源（不是原始碼註解）。

Run:  python3 scripts/test_v5_17_fixes.py
"""
import sys, os, importlib

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


sm = importlib.import_module("api.server")
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"
oa = sm.app.openapi()
_desc = oa["info"]["description"]
_cand = oa["paths"]["/personadb/candidates"]["get"]
_det = oa["paths"]["/personadb/detail"]["get"]

print("=== 頁首說明（Swagger 最上方）===")
for key, label in [("1–5 分鐘", "⏱ 執行時間警告"), ("不要關頁", "不要關頁"), ("不要重複按", "不要重複按"),
                   ("重新計費", "重按＝重新計費"), ("Try it out", "操作指引"), ("too_strict", "常見狀況"),
                   ("pool_exhausted", "回應欄位說明"), ("llm_analysis.reasoning", "建議先讀 reasoning"),
                   ("/personadb/detail", "第二步（取完整人設）")]:
    check(f"頁首含「{label}」", key in _desc)
check("頁首警告排在前面（前 1/3）", _desc.find("1–5 分鐘") < len(_desc) / 3, _desc.find("1–5 分鐘"))

print("\n=== candidates 端點 ===")
check("summary 帶 ⏱ 與時間", "⏱" in (_cand.get("summary") or "") and "1–5" in (_cand.get("summary") or ""), _cand.get("summary"))
check("description 有內容（>200 字）", len(_cand.get("description") or "") > 200, len(_cand.get("description") or ""))
check("description 含「不要重複按」警告", "不要重複按" in (_cand.get("description") or ""))
check("description 列出回應重點（summary/persona_ids）",
      "summary[]" in (_cand.get("description") or "") and "persona_ids[]" in (_cand.get("description") or ""))
_p = {x["name"]: x for x in _cand.get("parameters", [])}
check("參數 top_k 說明含執行時間提醒", "1–5 分鐘" in _p["top_k"]["description"], _p["top_k"]["description"])
check("參數 opMode 說明含三值限制", "只接受這三個值" in _p["opMode"]["description"], _p["opMode"]["description"])
check("參數 questions 說明含多題分隔", "|" in _p["questions"]["description"], _p["questions"]["description"])
check("參數 role 說明含留空指引", "留空" in _p["role"]["description"], _p["role"]["description"])

print("\n=== detail 端點 ===")
check("summary 標明毫秒級／不呼叫 LLM",
      "毫秒" in (_det.get("summary") or "") and "不呼叫 LLM" in (_det.get("summary") or ""), _det.get("summary"))
check("description 說明 prompt_prefix 可直接餵 LLM",
      "prompt_prefix" in (_det.get("description") or ""), (_det.get("description") or "")[:80])

print("\n=== tags（頁面分組）===")
check("candidates/detail 歸「人設查詢」",
      _cand.get("tags") == ["人設查詢"] and _det.get("tags") == ["人設查詢"], (_cand.get("tags"), _det.get("tags")))
check("health/status 歸「系統」",
      oa["paths"]["/health"]["get"].get("tags") == ["系統"] and oa["paths"]["/personadb/status"]["get"].get("tags") == ["系統"])
check("openapi_tags 已宣告（含說明）", len(oa.get("tags") or []) == 2, oa.get("tags"))

print("\n=== 既有行為不變 ===")
check("版本仍為單一來源（#77）", oa["info"]["version"] == open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "VERSION")).read().strip())
check("四個端點仍在", all(p in oa["paths"] for p in ("/health", "/personadb/candidates", "/personadb/detail", "/personadb/status")))

print("\n" + "=" * 60)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
