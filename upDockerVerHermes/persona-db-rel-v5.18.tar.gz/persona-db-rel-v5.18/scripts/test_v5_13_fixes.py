#!/usr/bin/env python3
"""v5.13 regression tests — #66（保護集來源④上限、來源揭露、覆蓋警示、protection_saturated）
與 #67（主體覆蓋擴充、判定依據揭露）。

決定性、無外部 LLM 呼叫。

Run:  python3 scripts/test_v5_13_fixes.py
"""
import sys, os, json, asyncio, logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


print("=== #67 A 主體判定覆蓋擴充（新樣式 + 既有不得改變）===")
from api.server import _subject_detail, _subject_from_questions, _declared_cap, DECLARED_PROTECTED_MAX
CASES = [
    # 既有（回歸）
    (["小吃攤老闆的目標客群"], "customer"),
    (["業主本人（B2B 受訪者）"], "owner"),
    (["企業主本人名單"], "owner"),
    (["房貸優惠 — 房仲業者"], ""),          # 有業者詞但無消費端名詞
    (["債務整合的目標客戶"], "customer"),   # v5.13 #67 A：消費端名詞即可（語意正確）
    (["房貸優惠 — 銀行業者"], ""),          # 無消費端名詞 → 不設限
    (["時尚服裝設計師的目標客戶"], "customer"),
    ([""], ""),
    # #67 A 新增樣式
    (["咖啡廳的客群"], "customer"),          # 省略「目標」
    (["想找健身房的顧客"], "customer"),
    (["某診所的目標客戶"], "customer"),      # 業者詞新增「診所」
    (["補習班的客層"], "customer"),
    (["銀行業者的目標客戶"], "customer"),    # 業者詞新增「業者」
    # ★ 優先序：明確業主標記優先（同時含顧客詞也不得誤判）
    (["找業主本人回答關於其顧客的問題"], "owner"),
    (["B2B 受訪者名單（他們服務的顧客）"], "owner"),
]
for q, exp in CASES:
    got = _subject_from_questions(q)
    check(f"subject({q!r}) = {exp!r}", got == exp, got)
check("_subject_from_questions 仍回傳 str（相容）", isinstance(_subject_from_questions(["咖啡廳的客群"]), str))
subj, basis = _subject_detail(["小吃攤老闆的目標客群"])
check("#67 B subject_basis 非空且含命中片段", subj == "customer" and "目標客群" in basis, (subj, basis))
check("#67 B 未判定時 basis 為空", _subject_detail(["房貸優惠 — 房仲業者"]) == ("", ""), _subject_detail(["房貸優惠 — 房仲業者"]))

print("\n=== #66 A 來源④上限 ===")
check("上限公式：1 維→1、2 維→1、4 維→2、6 維→3、10 維→3",
      [_declared_cap(n) for n in (1, 2, 4, 6, 10)] == [1, 1, 2, 3, 3],
      [_declared_cap(n) for n in (1, 2, 4, 6, 10)])
check("常數存在且為 3", DECLARED_PROTECTED_MAX == 3)

print("\n=== endpoint 級（fake LLM）===")
server_mod = sys.modules["api.server"]
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"
server_mod.app.state.db_loaded = True
os.chdir(ROOT)


def _run(query, domain, filters, broadens, core=None, role=""):
    """broadens: list of (filters_dict, declared_protected_list) —— 逐輪依序回傳。"""
    calls = {"n": 0}

    async def _parse(q_list, role=None, distribution=None):
        return {"domain": domain, "reasoning": "一般敍述。", "question_analysis": [],
                "usage_suggestion": None, "filters": filters, "dim_importance": {}, "core_dims": core or []}

    async def _llm(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
        i = min(calls["n"], len(broadens) - 1)
        calls["n"] += 1
        f, decl = broadens[i]
        return json.dumps({"broadening": f"loop{i+1}", "protected_dims": decl, "filters": f},
                          ensure_ascii=False)
    op, ol = server_mod.parse_questions_with_llm, llm_mod.call_llm
    server_mod.parse_questions_with_llm, llm_mod.call_llm = _parse, _llm
    try:
        loop = asyncio.new_event_loop()
        return loop.run_until_complete(server_mod.personadb_candidates(
            questions=query, top_k=10, opMode="僅篩選", role=role)), calls["n"]
    finally:
        server_mod.parse_questions_with_llm, llm_mod.call_llm = op, ol


# 1) 來源④ 超過上限：一輪宣告 5 個 → 只接受上限（filters 4 維 → 上限 2）
F4 = {"aesthetic_procedure": ["有"], "sex": ["女"], "age": ["25-34"], "income": [">8萬"]}
r, _ = _run("醫美診所的目標客戶", "醫美／醫美診所", F4,
            [(F4, ["sex", "age", "income", "occupation", "education"])], core=["aesthetic_procedure"])
md = (r.protected_dims_sources or {}).get("model_declared") or []
check("★ 來源④ 上限：宣告 5 個只接受 2 個", len(md) == 2, (md, r.protected_dims_sources))
check("上限觸發時 warnings 有記錄", any("上限" in w for w in (r.warnings or [])), r.warnings)
check("#66 A/#70 A 來源拆解存在六鍵",
      set(r.protected_dims_sources or {}) == {"domain", "reasoning", "analysis_declared",
                                              "model_declared", "protect_only", "overshoot_restore"},
      r.protected_dims_sources)
check("#66 A analysis_declared 正確", (r.protected_dims_sources or {}).get("analysis_declared") == ["aesthetic_procedure"],
      r.protected_dims_sources)

# 2) 覆蓋警示：保護集覆蓋 ≥1/2 已套用維度
F2 = {"aesthetic_procedure": ["有"], "sex": ["女"]}
r2, _ = _run("醫美診所的目標客戶", "醫美／醫美診所", F2, [(F2, [])], core=["aesthetic_procedure", "sex"])
check("#66 A 覆蓋警示（2/2 已套用維度受保護）",
      any("覆蓋" in w for w in (r2.warnings or [])), r2.warnings)

# 3) #66 C：全維度受保護 → protection_saturated 且**未呼叫 LLM**
F1 = {"aesthetic_procedure": ["有"]}
r3, calls3 = _run("醫美診所的目標客戶", "醫美／醫美診所", F1, [(F1, [])], core=["aesthetic_procedure"])
check("★ #66 C protection_saturated（全維度受保護）", r3.broadening_stop_reason == "protection_saturated",
      r3.broadening_stop_reason)
check("#66 C 未浪費 LLM 呼叫（calls==0）", calls3 == 0, calls3)

# 4) 仍有可移除維度 → 行為不變（不會誤觸 C）
F3 = {"aesthetic_procedure": ["有"], "sex": ["女"]}
r4, calls4 = _run("醫美診所的目標客戶", "醫美／醫美診所", F3, [(F3, [])], core=["aesthetic_procedure"])
check("#66 C 僅部分受保護 → 未觸發 saturated", r4.broadening_stop_reason != "protection_saturated",
      r4.broadening_stop_reason)
check("僅部分受保護 → 仍會呼叫 LLM", calls4 >= 1, calls4)

# 5) 新樣式 + 禁用維度：顧客語意（新樣式）→ 剝除 employment_status
F5 = {"employment_status": ["雇主"], "age": ["25-34"]}
r5, _ = _run("咖啡廳的客群", "餐飲／咖啡廳", F5, [(F5, [])])
check("#67 新樣式：subject='customer' + basis 非空", r5.subject == "customer" and r5.subject_basis, (r5.subject, r5.subject_basis))
check("#67 新樣式：employment_status 被剝除", "employment_status" not in (r5.applied_filters or {}), r5.applied_filters)

# 6) 業主語意不受影響（must-use 不回歸）
r6, _ = _run("業主本人（B2B 受訪者）", "市場研究／B2B問卷招募",
             {"employment_status": ["雇主", "自營作業者"]}, [({"employment_status": ["雇主", "自營作業者"]}, [])])
check("#67 業主語意仍為 owner 且套用 employment_status",
      r6.subject == "owner" and (r6.applied_filters or {}).get("employment_status"), (r6.subject, r6.applied_filters))

print("\n=== 契約 ===")
from api.models import CandidatesResponse
props = CandidatesResponse.model_json_schema()["properties"]
check("有 subject_basis（string）", props["subject_basis"]["type"] == "string")
check("有 protected_dims_sources（object）", props["protected_dims_sources"]["type"] == "object")
check("enum 含 protection_saturated", "protection_saturated" in props["broadening_stop_reason"]["enum"])
d0 = CandidatesResponse(total_matched=0, persona_ids=[])
check("向後相容（預設值）", d0.subject_basis == "" and d0.protected_dims_sources == {} and d0.warnings == [])

print("\n" + "=" * 62)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
