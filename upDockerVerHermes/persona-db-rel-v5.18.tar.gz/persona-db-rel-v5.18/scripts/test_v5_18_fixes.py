#!/usr/bin/env python3
"""v5.18 regression tests — #70 B：過衝還原的**觸發倍率**必須在還原前量測（訊息不再誤報 1.0×）。

Run:  python3 scripts/test_v5_18_fixes.py
"""
import sys, os, json, asyncio, logging, importlib

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAIL = []
os.chdir(ROOT)


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


class _Cap(logging.Handler):
    def __init__(self):
        super().__init__(); self.msgs = []

    def emit(self, r):
        self.msgs.append(r.getMessage())


server_mod = importlib.import_module("api.server")
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"
server_mod.app.state.db_loaded = True
_cap = _Cap(); logging.getLogger("api.server").addHandler(_cap); logging.getLogger("api.server").setLevel(logging.INFO)

_orig_parse, _orig_llm, _orig_filter = server_mod.parse_questions_with_llm, llm_mod.call_llm, server_mod.filter_personas
_db = server_mod.load_persona_db()


async def _parse(q, role=None, distribution=None):
    return {"domain": "市場研究", "reasoning": "一般敍述。", "question_analysis": [],
            "usage_suggestion": None, "filters": {"politics": ["關心政治"], "hobby": ["逛街購物"]},
            "dim_importance": {}, "core_dims": []}


def _fake_filter(db, filters):
    """確定性：含 politics → 12 人；移除後 → 1069 人（89.1× 過衝）。"""
    return list(db)[:12] if "politics" in filters else list(db)


_orig_filter_fn = None
for i, m in enumerate(dir(server_mod)):
    pass
server_mod.filter_personas = _fake_filter


async def _llm_remove_politics(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    return json.dumps({"broadening": "移除 politics 以擴大名單", "protected_dims": [],
                       "filters": {"hobby": ["逛街物"]}}, ensure_ascii=False)


server_mod.parse_questions_with_llm = _parse
llm_mod.call_llm = _llm_remove_politics
try:
    r = asyncio.new_event_loop().run_until_complete(
        server_mod.personadb_candidates(questions="夜市消費者的輪廓", top_k=10, opMode="僅篩選", role=""))
finally:
    server_mod.parse_questions_with_llm, llm_mod.call_llm = _orig_parse, _orig_llm
    server_mod.filter_personas = _orig_filter

_att = [b for b in (r.broadening_attempts or []) if getattr(b, "overshoot_restore", False)]
print(f"  過衝還原輪: {[(b.match_count_before, b.match_count_after, b.overshoot_ratio) for b in _att]}")
check("★ 觸發了一次過衝還原（12 → 1069）", len(_att) == 1, _att)
if _att:
    _b = _att[0]
    check("★ overshoot_ratio 為**觸發倍率**（≥3，實測 ≈89）", float(_b.overshoot_ratio or 0) >= 3, _b.overshoot_ratio)
    check("★ match_count_after 為**還原後**樣本數（12）", _b.match_count_after == 12, _b.match_count_after)
    check("★ 不再誤報 1.0×", abs(float(_b.overshoot_ratio or 0) - 1.0) > 0.5, _b.overshoot_ratio)
_w = [m for m in _cap.msgs if "已還原" in m]
print(f"  warnings: {[w[:110] for w in (r.warnings or [])]}")
check("★ 訊息含觸發倍率（非 1.0×）", any("（1.0×" not in w and "×" in w for w in (r.warnings or [])), r.warnings)
check("#70 A 訊息格式含門檻說明", any("≥ 3×" in w for w in (r.warnings or [])), r.warnings)

print("\n=== 契約 ===")
from api.models import BroadeningAttempt
_ap = BroadeningAttempt.model_json_schema()["properties"]
check("BroadeningAttempt 有 overshoot_ratio（number）", _ap["overshoot_ratio"]["type"] == "number")
check("向後相容（預設 0.0）", BroadeningAttempt(loop=1).overshoot_ratio == 0.0)

print("\n" + "=" * 60)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
