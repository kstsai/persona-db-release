#!/usr/bin/env python3
"""v5.15 regression tests — #72（llm_parse_error 可稽核 + 失敗輪記錄 + llm_calls）、
#73（`_normalize_filters` 留痕單一化：本體唯一輸出點）。

決定性、無外部 LLM 呼叫。

Run:  python3 scripts/test_v5_15_fixes.py
"""
import sys, os, json, asyncio, logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


class _Cap(logging.Handler):
    def __init__(self):
        super().__init__(); self.msgs = []

    def emit(self, record):
        self.msgs.append(record.getMessage())


def _attach():
    c = _Cap()
    lg = logging.getLogger("api.server")
    lg.addHandler(c)
    lg.setLevel(logging.INFO)
    return c, lg


print("=== #73 留痕單一化（本體唯一輸出點）===")
from api.server import _normalize_filters, _failed_attempt
_cap, _lg = _attach()
_normalize_filters({"age": [], "income": ["3-8萬"]})
_normalize_filters({"age": [], "sex": ["女"]}, context="loop 2")
_lg.removeHandler(_cap)
_nf = [m for m in _cap.msgs if "Normalize filters" in m]
check("★ 呼叫兩次 → 只輸出 2 行（每次 1 行）", len(_nf) == 2, _nf)
check("#73 context 有值時附在訊息內", any("loop 2" in m for m in _nf), _nf)
check("#73 無 context 時不附空括號", any(m.endswith("['age']") for m in _nf), _nf)
check("#73 只丟棄空值維度（結果正確）", _normalize_filters({"age": [], "sex": ["女"]}) == {"sex": ["女"]})

print("\n=== #72 失敗輪記錄（_failed_attempt 形狀）===")
_fa = _failed_attempt(2, {"a": ["x"]}, 7, "JSONDecodeError")
check("#72 失敗輪標記 parse_error + error_type", _fa["parse_error"] is True and _fa["error_type"] == "JSONDecodeError", _fa)
check("#72 失敗輪計數不變（不是放寬）", _fa["match_count_before"] == _fa["match_count_after"] == 7, _fa)
check("#72 失敗輪形狀與正常輪一致（可被同一套斷言檢查）",
      set(_fa) >= {"loop", "change", "filters_changed", "no_op", "overshoot", "widened_dims",
                   "widened_deltas", "overshoot_restore", "restored_dims"}, sorted(_fa))

print("\n=== endpoint 級：解析失敗 / 空回應（fake LLM）===")
import importlib
server_mod = importlib.import_module("api.server")
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"
server_mod.app.state.db_loaded = True
os.chdir(ROOT)
_orig_parse, _orig_llm = server_mod.parse_questions_with_llm, llm_mod.call_llm
_orig_filter = server_mod.filter_personas
TIGHT = {"aesthetic_procedure": ["有"], "sex": ["女"]}


async def _parse(q_list, role=None, distribution=None):
    return {"domain": "市場研究", "reasoning": "一般敍述。", "question_analysis": [],
            "usage_suggestion": None, "filters": dict(TIGHT), "dim_importance": {}, "core_dims": []}


def _run(llm_fn):
    calls = {"n": 0}

    async def _llm(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
        calls["n"] += 1
        return await llm_fn(calls["n"])
    server_mod.parse_questions_with_llm = _parse
    llm_mod.call_llm = _llm
    try:
        loop = asyncio.new_event_loop()
        r = loop.run_until_complete(server_mod.personadb_candidates(
            questions="夜市消費者的輪廓", top_k=10, opMode="僅篩選", role=""))
        return r, calls["n"]
    finally:
        server_mod.parse_questions_with_llm, llm_mod.call_llm = _orig_parse, _orig_llm


# ① 非法 JSON → llm_parse_error
async def _bad_json(n):
    return "{ this is not json"


_cap, _lg = _attach()
r1, c1 = _run(_bad_json)
_lg.removeHandler(_cap)
_att1 = r1.broadening_attempts or []
print(f"     解析失敗：stop={r1.broadening_stop_reason!r} attempts={len(_att1)} llm_calls={r1.llm_calls} 實際呼叫={c1}")
check("★ stop_reason 仍為 llm_parse_error", r1.broadening_stop_reason == "llm_parse_error", r1.broadening_stop_reason)
check("★ 失敗輪已記入 attempts（parse_error=True）", any(b.parse_error for b in _att1),
      [(b.loop, b.parse_error, b.error_type) for b in _att1])
check("★ attempts 數 == 實際 LLM 呼叫次數", len(_att1) == c1, (len(_att1), c1))
check("★ llm_calls == 1(分析) + 呼叫次數", r1.llm_calls == 1 + c1, (r1.llm_calls, c1))
_warn = [m for m in _cap.msgs if "無法解析" in m]
check("★ 有 WARNING log（含例外型別）", any("JSONDecodeError" in m or "Exception" in m for m in _warn), _warn)
check("#72 log 含 llm.py 診斷 meta", any("meta=" in m for m in _warn), _warn)

# ② 空回應 → llm_empty，同樣要留痕＋記一輪
async def _empty(n):
    return ""


_cap, _lg = _attach()
r2, c2 = _run(_empty)
_lg.removeHandler(_cap)
_att2 = r2.broadening_attempts or []
check("★ 空回應：stop=llm_empty 且失敗輪已記入（error_type=empty_response）",
      r2.broadening_stop_reason == "llm_empty"
      and any(b.parse_error and b.error_type == "empty_response" for b in _att2),
      (r2.broadening_stop_reason, [(b.parse_error, b.error_type) for b in _att2]))
check("★ 空回應：attempts == 呼叫次數", len(_att2) == c2, (len(_att2), c2))
check("#72 空回應有 WARNING log", any("回應為空" in m for m in _cap.msgs), _cap.msgs)

# ③ 正常路徑：llm_calls 與 attempts 一致、無 parse_error
async def _ok(n):
    return json.dumps({"broadening": "加入不存在的值", "protected_dims": [],
                       "filters": {**TIGHT, "sex": ["女"]}}, ensure_ascii=False)


r3, c3 = _run(_ok)
check("正常輪：attempts == 呼叫次數且無 parse_error",
      len(r3.broadening_attempts or []) == c3 and not any(b.parse_error for b in (r3.broadening_attempts or [])),
      (len(r3.broadening_attempts or []), c3))
check("正常輪：llm_calls 揭露正確", r3.llm_calls == 1 + c3, (r3.llm_calls, c3))

print("\n=== 契約 ===")
from api.models import CandidatesResponse, BroadeningAttempt
_ap = BroadeningAttempt.model_json_schema()["properties"]
_cp = CandidatesResponse.model_json_schema()["properties"]
check("BroadeningAttempt 有 parse_error（boolean）", _ap["parse_error"]["type"] == "boolean")
check("BroadeningAttempt 有 error_type（string）", _ap["error_type"]["type"] == "string")
check("CandidatesResponse 有 llm_calls（integer）", _cp["llm_calls"]["type"] == "integer")
_a = BroadeningAttempt(loop=1)
check("向後相容（預設值）", _a.parse_error is False and _a.error_type == "" and
      CandidatesResponse(total_matched=0, persona_ids=[]).llm_calls == 0)

print("\n" + "=" * 62)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
