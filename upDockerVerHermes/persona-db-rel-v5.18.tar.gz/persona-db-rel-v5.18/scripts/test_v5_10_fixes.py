#!/usr/bin/env python3
"""v5.10 regression tests — #60（root logger 設定 / LOG_LEVEL）、#61（protect-only 語意對應）。

決定性、無外部 LLM 呼叫。

Run:  python3 scripts/test_v5_10_fixes.py
"""
import sys, os, json, asyncio, logging, subprocess, inspect

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


print("=== #60 root logger 設定（LOG_LEVEL）===")
src = open(os.path.join(ROOT, "api", "server.py")).read()
check("server.py 有 logging.basicConfig", "logging.basicConfig(" in src)
check("讀取 LOG_LEVEL 環境變數（預設 INFO）", 'os.environ.get("LOG_LEVEL", "INFO")' in src)
check("有 handler 時只調整層級（不重複掛 handler）", "logging.getLogger().setLevel(_LOG_LEVEL)" in src)


def _probe(level):
    """在子行程以指定 LOG_LEVEL 匯入 api.server，回傳 root logger 層級與是否輸出 INFO。"""
    code = (
        "import logging, sys\n"
        "import api.server\n"
        "root = logging.getLogger()\n"
        "api_log = logging.getLogger('api.server')\n"
        "api_log.info('PROBE_INFO_LINE')\n"
        "logging.shutdown()\n"
        "sys.stderr.write('LEVEL=' + logging.getLevelName(root.level) + '\\n')\n"
    )
    env = dict(os.environ, LOG_LEVEL=level)
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env=env, cwd=ROOT)
    return r.stderr


out_warn = _probe("WARNING")
check("LOG_LEVEL=WARNING → root 層級為 WARNING", "LEVEL=WARNING" in out_warn, out_warn[-200:])
check("LOG_LEVEL=WARNING → INFO 不輸出", "PROBE_INFO_LINE" not in out_warn, out_warn[-300:])
out_info = _probe("INFO")
check("LOG_LEVEL=INFO → root 層級為 INFO", "LEVEL=INFO" in out_info, out_info[-200:])
check("LOG_LEVEL=INFO → INFO 正常輸出（修正前為靜默丟棄）", "PROBE_INFO_LINE" in out_info, out_info[-300:])
out_bad = _probe("not-a-level")
check("LOG_LEVEL 值非法 → 不炸（回退）", "LEVEL=" in out_bad, out_bad[-200:])

print("\n=== #61 protect-only 語意對應 ===")
from api import server as server_mod
from api.server import PROTECT_ONLY_DOMAIN_DIMS, _vetoed_dims
check("PROTECT_ONLY_DOMAIN_DIMS 為獨立表（與 domain_filters 分離）",
      isinstance(PROTECT_ONLY_DOMAIN_DIMS, dict) and "電動車" in PROTECT_ONLY_DOMAIN_DIMS
      and "domain_filters" not in PROTECT_ONLY_DOMAIN_DIMS)
check("電動車/汽車 → commute_mode", PROTECT_ONLY_DOMAIN_DIMS.get("電動車") == {"commute_mode"}
      and PROTECT_ONLY_DOMAIN_DIMS.get("汽車") == {"commute_mode"})
# domain_filters 不含 commute_mode 的補值（確認 protect-only 未偷改畫面）
_dom_filters_src = src[src.index("domain_filters = {"):src.index("}", src.index("domain_filters = {"))]
check("domain_filters 未新增 commute_mode 補值（不改變篩選行為）", "commute_mode" not in _dom_filters_src)

db = server_mod.load_persona_db()
server_mod.app.state.db_loaded = True
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"


def _run(query, domain, filters, broaden_fn):
    async def _parse(q_list, role=None, distribution=None):
        return {"domain": domain, "reasoning": "一般敍述。", "question_analysis": [],
                "usage_suggestion": None, "filters": filters, "dim_importance": {}, "core_dims": []}
    orig_p, orig_l = server_mod.parse_questions_with_llm, llm_mod.call_llm
    server_mod.parse_questions_with_llm = _parse
    llm_mod.call_llm = broaden_fn
    try:
        loop = asyncio.new_event_loop()
        return loop.run_until_complete(server_mod.personadb_candidates(
            questions=query, top_k=3, opMode="僅篩選", role=""))
    finally:
        server_mod.parse_questions_with_llm, llm_mod.call_llm = orig_p, orig_l


EV_FILTERS = {"age": ["35-44", "45-54"], "income": [">8萬"], "commute_mode": ["汽車"],
              "family_size": ["3", "4"], "marriage": ["已婚"]}


async def _b_remove_commute(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    """模擬反覆出現的行為：移除 commute_mode。"""
    return json.dumps({"broadening": "刪除非核心維度 commute_mode",
                       "protected_dims": [],
                       "filters": {"age": ["35-44", "45-54"], "income": [">8萬"],
                                   "family_size": ["3", "4"]}}, ensure_ascii=False)


res_ev = _run("電動車的目標客戶", "電動車／新能源車", EV_FILTERS, _b_remove_commute)
check("★ 電動車 domain → 保護集含 commute_mode", "commute_mode" in (res_ev.protected_dims or []),
      res_ev.protected_dims)
check("★ 移除 commute_mode 被 veto（protected_veto）",
      res_ev.broadening_stop_reason == "protected_veto" and "commute_mode" in (res_ev.applied_filters or {}),
      (res_ev.broadening_stop_reason, res_ev.applied_filters))
check("protect-only 不改變 filters（未憑空加入 commute_mode 之外的維度）",
      set(res_ev.applied_filters or {}) <= set(EV_FILTERS), res_ev.applied_filters)

res_ctrl = _run("美妝產品的目標客戶", "美妝／零售", {"age": ["25-34"], "clothing_spend": ["3000~5000"]},
                _b_remove_commute)
check("對照組：domain 不含電動車/汽車 → 不含 commute_mode 保護",
      "commute_mode" not in (res_ctrl.protected_dims or []), res_ctrl.protected_dims)

res_car = _run("汽車買家的目標客群", "汽車／交通", EV_FILTERS, _b_remove_commute)
check("「汽車」domain 亦保護 commute_mode", "commute_mode" in (res_car.protected_dims or []),
      res_car.protected_dims)

print("\n" + "=" * 62)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
