#!/usr/bin/env python3
"""v5.16 regression tests — #77（產品版號單一來源：openapi／health／status 三者一致）。

Run:  python3 scripts/test_v5_16_fixes.py
"""
import sys, os, json, pathlib, unittest.mock as mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


import importlib
server_mod = importlib.import_module("api.server")
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"

VERSION_FILE = os.path.join(ROOT, "VERSION")
file_version = open(VERSION_FILE).read().strip()

print("=== #77 版本單一來源 ===")
check("helper 讀到的版本 == VERSION 檔內容", server_mod._product_version() == file_version,
      (server_mod._product_version(), file_version))
check("VERSION 檔存在且非空", bool(file_version), file_version)

_oa = server_mod.app.openapi()
check("★ openapi info.version == VERSION（Swagger 頁首）", _oa["info"]["version"] == file_version,
      (_oa["info"]["version"], file_version))

import asyncio
_h = asyncio.new_event_loop().run_until_complete(server_mod.health())
check("★ /health version == VERSION", _h.version == file_version, (_h.version, file_version))

# /personadb/status 為 raw text：抓版本行比對
try:
    _st = asyncio.new_event_loop().run_until_complete(server_mod.persona_db_status())
    _txt = _st if isinstance(_st, str) else getattr(_st, "body", b"").decode()
    check("★ /personadb/status 回報同一版本", file_version in _txt, _txt[:120])
except Exception as e:  # status 需要 DB，允許在缺 DB 時略過（不影響 #77 主斷言）
    print(f"  ℹ️ /personadb/status 在此環境無法執行（{type(e).__name__}）→ 主斷言已由 openapi／health 覆蓋")

print("\n=== #77 讀不到 VERSION 時的行為 ===")
with mock.patch.object(pathlib.Path, "read_text", side_effect=OSError("no such file")):
    _fb = server_mod._product_version()
check("讀檔失敗 → 'unknown'（不假裝是某個版本）", _fb == "unknown", _fb)

print("\n=== 契約 ===")
from api.models import HealthResponse
check("HealthResponse 的 version 為字串", HealthResponse.model_json_schema()["properties"]["version"]["type"] == "string")
check("openapi 仍提供 /docs 與兩個主端點",
      all(p in _oa["paths"] for p in ("/personadb/candidates", "/personadb/detail", "/personadb/status", "/health")))

print("\n" + "=" * 60)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
