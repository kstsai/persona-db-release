#!/usr/bin/env python3
"""v5.12 regression tests — #65（主體判準機械化、forbidden > protected、主體揭露、留痕）。

決定性、無外部 LLM 呼叫。

Run:  python3 scripts/test_v5_12_fixes.py
"""
import sys, os, json, asyncio, logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


print("=== #65 主體判準（機械化，只看題目原文）===")
from api.server import _subject_from_questions, FORBIDDEN_BY_SUBJECT
CASES = [
    (["小吃攤老闆的目標客群"], "customer"),
    (["小吃攤老闆的目標客群", "夜市商圈"], "customer"),
    (["某商家的目標客群"], "customer"),
    (["老闆的顧客在哪"], "customer"),
    (["業主本人（B2B 受訪者）"], "owner"),
    (["企業主本人名單"], "owner"),
    (["我想找小吃攤老闆本人"], "owner"),
    (["房貸優惠 — 房仲業者"], ""),          # 反例：「業者」後面沒有消費端標的
    (["債務整合的目標客戶"], "customer"),   # v5.13 #67 A：消費端名詞即可判（「目標客戶」）
    (["醫美診所的目標客戶"], "customer"),   # v5.13 #67 A：同上（診所的客戶＝顧客語意）
    ([""], ""),
]
for q, exp in CASES:
    got = _subject_from_questions(q)
    check(f"subject({q!r}) = {exp!r}", got == exp, got)
check("customer 的禁用維度＝employment_status",
      FORBIDDEN_BY_SUBJECT.get("customer") == {"employment_status"}, FORBIDDEN_BY_SUBJECT)
check("owner 無禁用維度（must-use 不受影響）", FORBIDDEN_BY_SUBJECT.get("owner", set()) == set())

print("\n=== #65 endpoint 級（fake LLM）===")
server_mod = sys.modules["api.server"]
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"
server_mod.app.state.db_loaded = True
os.chdir(ROOT)

CAP = []


class _Cap(logging.Handler):
    def emit(self, record):
        CAP.append(record.getMessage())


logging.getLogger("api.server").addHandler(_Cap())
logging.getLogger("api.server").setLevel(logging.INFO)


def _mk_run(domain, filters, core=None):
    async def _parse(q_list, role=None, distribution=None):
        return {"domain": domain, "reasoning": "一般敍述。", "question_analysis": [],
                "usage_suggestion": None, "filters": filters, "dim_importance": {},
                "core_dims": core or []}

    def _run(query, role=""):
        async def _broad(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
            # 回傳原樣 filters（no-op）→ 迴圈自然以 no_op_limit 結束，不真的放寬
            return json.dumps({"broadening": "no-op（測試）", "protected_dims": [],
                               "filters": filters}, ensure_ascii=False)
        op, ol = server_mod.parse_questions_with_llm, llm_mod.call_llm
        server_mod.parse_questions_with_llm = _parse
        llm_mod.call_llm = _broad
        try:
            loop = asyncio.new_event_loop()
            return loop.run_until_complete(server_mod.personadb_candidates(
                questions=query, top_k=10, opMode="僅篩選", role=role))
        finally:
            server_mod.parse_questions_with_llm, llm_mod.call_llm = op, ol
    return _run


# 1) 顧客語意 + domain 兜底會命中「攤商」+ LLM 自己也套了 employment_status
#    → 剝除、不進保護集、warnings 有記錄、subject=customer
_r = _mk_run("餐飲／夜市攤商經營",
             {"employment_status": ["自營作業者", "雇主"], "age": ["25-34", "35-44"]},
             core=["employment_status"])
r1 = _r("小吃攤老闆的目標客群", role="夜市商圈協會")
check("顧客語意：employment_status 被剝除", "employment_status" not in (r1.applied_filters or {}), r1.applied_filters)
check("顧客語意：employment_status 不在保護集", "employment_status" not in (r1.protected_dims or []), r1.protected_dims)
check("顧客語意：subject='customer'", r1.subject == "customer", r1.subject)
check("顧客語意：warnings 有記錄剝除", any("剝除" in w for w in (r1.warnings or [])), r1.warnings)
check("顧客語意：其他維度保留（age）", (r1.applied_filters or {}).get("age") == ["25-34", "35-44"], r1.applied_filters)
check("留痕：log 有 Subject gate / 剝除訊息",
      any("Subject gate" in m for m in CAP), [m for m in CAP if "gate" in m][:2])

# 2) 業主語意：must-use 不得回歸（employment_status 必須仍被套用且受保護）
_r2 = _mk_run("市場研究／B2B問卷招募",
              {"employment_status": ["雇主", "自營作業者"], "age": ["35-44"]},
              core=["employment_status"])
r2 = _r2("業主本人（B2B 受訪者）")
check("業主語意：subject='owner'", r2.subject == "owner", r2.subject)
check("業主語意：employment_status 仍被套用（#34 must-use 不回歸）",
      (r2.applied_filters or {}).get("employment_status") == ["雇主", "自營作業者"], r2.applied_filters)
check("業主語意：employment_status 在保護集", "employment_status" in (r2.protected_dims or []), r2.protected_dims)
check("業主語意：無剝除告警（#66 A 的覆蓋警示可存在）",
      not any("剝除" in w for w in (r2.warnings or [])), r2.warnings)

# 3) 無法判定主體（一般題）：不設限（既有行為不變）
_r3 = _mk_run("金融／銀行貸款", {"debt_status": ["有房貸"], "income": [">8萬"]}, core=["debt_status"])
r3 = _r3("房貸優惠 — 房仲業者")   # v5.13 #67 A 後，含消費端名詞的題會被判 customer → 改用不判定題
check("主體未判定：subject 為空字串", r3.subject == "", r3.subject)
check("主體未判定：filters 不被剝除", set(r3.applied_filters or {}) == {"debt_status", "income"}, r3.applied_filters)

# 4) 只看題目原文：domain 說「攤商經營」但題目是顧客語意 → 兜底必須被抑制
_r4 = _mk_run("餐飲／夜市攤商經營", {"age": ["25-34"]})   # LLM 自己沒套 employment_status
r4 = _r4("小吃攤老闆的目標客群", role="夜市商圈協會")
check("★ domain 兜底被抑制（題目為顧客語意 → 不補 employment_status）",
      "employment_status" not in (r4.applied_filters or {}), r4.applied_filters)

# 5) #62 留痕（原本靜默）—— 走**放寬路徑**（analysis 路徑本來就會丟棄空清單，不會觸發）
CAP.clear()


def _run5b(query, role=""):
    async def _broad(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
        return json.dumps({"broadening": "把 age 設為空清單", "protected_dims": [],
                           "filters": {"aesthetic_procedure": ["有"], "sex": ["女"], "age": []}},
                          ensure_ascii=False)
    async def _parse(q_list, role=None, distribution=None):
        # 兩個維度：一個受保護（aesthetic_procedure）→ 仍有可放寬維度，避免觸發 #66 C
        return {"domain": "醫療美容／醫美診所", "reasoning": "一般敍述。", "question_analysis": [],
                "usage_suggestion": None, "filters": {"aesthetic_procedure": ["有"], "sex": ["女"]},
                "dim_importance": {}, "core_dims": []}
    op, ol = server_mod.parse_questions_with_llm, llm_mod.call_llm
    server_mod.parse_questions_with_llm, llm_mod.call_llm = _parse, _broad
    try:
        loop = asyncio.new_event_loop()
        return loop.run_until_complete(server_mod.personadb_candidates(
            questions=query, top_k=10, opMode="僅篩選", role=role))
    finally:
        server_mod.parse_questions_with_llm, llm_mod.call_llm = op, ol


r5 = _run5b("醫美診所的目標客戶")
check("#62：放寬路徑的空值清單被丟棄（applied_filters 不含空清單）",
      all(v for v in (r5.applied_filters or {}).values()), r5.applied_filters)
check("#62 留痕：log 有 Normalize filters 訊息（放寬路徑）",
      any("Normalize filters" in m for m in CAP), [m for m in CAP if "Normalize" in m][:2])

print("\n=== 契約 ===")
from api.models import CandidatesResponse
props = CandidatesResponse.model_json_schema()["properties"]
check("CandidatesResponse 有 subject（string）", props["subject"]["type"] == "string")
check("CandidatesResponse 有 warnings（array）", props["warnings"]["type"] == "array")
check("預設值向後相容（subject='' / warnings=[]）",
      CandidatesResponse(total_matched=0, persona_ids=[]).subject == ""
      and CandidatesResponse(total_matched=0, persona_ids=[]).warnings == [])

print("\n" + "=" * 62)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
