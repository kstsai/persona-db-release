#!/usr/bin/env python3
"""v5.14 regression tests — #69（放寬幅度）、#70（過衝回饋 + 自選維度優先序）、#71（留痕位置 + 上限基準）。

決定性、無外部 LLM 呼叫（`filter_personas` 亦以真實 DB 為基礎做確定性替換）。

Run:  python3 scripts/test_v5_14_fixes.py
"""
import sys, os, json, asyncio, logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAIL = []


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


print("=== #69 _widened_deltas（放寬幅度）===")
from api.server import _widened_deltas, _widened_dims, _normalize_filters, OVERSHOOT_RESTORE_RATIO
_prev = {"sex": ["女"], "age": ["25-34", "35-44"], "income": ["3-8萬"]}
_new = {"sex": ["女", "男"], "age": ["25-34", "35-44", "45-54"], "income": ["3-8萬"]}
_dl = _widened_deltas(_prev, _new)
_dims = _widened_dims(_prev, _new)
check("#69 dim 集合 == widened_dims（口徑一致）", {d["dim"] for d in _dl} == set(_dims), (_dl, _dims))
check("#69 before/after/added 正確",
      _dl == [{"dim": "age", "before": ["25-34", "35-44"], "after": ["25-34", "35-44", "45-54"], "added": ["45-54"]},
              {"dim": "sex", "before": ["女"], "after": ["女", "男"], "added": ["男"]}], _dl)
check("#69 未放寬 → 空列表", _widened_deltas(_prev, {"sex": ["女"]}) == [], _widened_deltas(_prev, {"sex": ["女"]}))
check("#69 縮小不算放寬", _widened_deltas({"sex": ["女", "男"]}, {"sex": ["女"]}) == [])
check("#69 常數存在（OVERSHOOT_RESTORE_RATIO=3）", OVERSHOOT_RESTORE_RATIO == 3)

print("\n=== #71 A 留痕在函式本體（不經端點也可見）===")
class _Cap(logging.Handler):
    def __init__(self):
        super().__init__(); self.msgs = []
    def emit(self, r):
        self.msgs.append(r.getMessage())

_cap = _Cap()
logging.getLogger("api.server").addHandler(_cap)
logging.getLogger("api.server").setLevel(logging.INFO)
_normalize_filters({"age": [], "aesthetic_procedure": ["有"]})
logging.getLogger("api.server").removeHandler(_cap)
check("#71 A 直接呼叫 _normalize_filters() 就有留痕", any("Normalize filters (#62)" in m for m in _cap.msgs), _cap.msgs)
check("#71 A 留痕含被丟棄的維度", any("['age']" in m for m in _cap.msgs), _cap.msgs)

print("\n=== #70 A 過衝回饋（過衝 ≥3× → 還原 + 保護 + 揭露）===")
import importlib
server_mod = importlib.import_module("api.server")
import api.llm as llm_mod
llm_mod.LLM_CONFIG["api_key"] = "test-key"
server_mod.app.state.db_loaded = True
os.chdir(ROOT)
from api.persona_matcher import load_persona_db
_db = load_persona_db()
_orig_filter = server_mod.filter_personas
_orig_parse, _orig_llm = server_mod.parse_questions_with_llm, llm_mod.call_llm

# 移除 aesthetic_procedure（稀有：14 人）→ 樣本暴增 → 觸發 #70 A；還原後回到 14
# 以「確定性替換」控制樣本數（不依賴真實值的分布）：
# 含 politics（當稀有維度）→ 12 人；移除它 → 全池（暴增 ≥3×）→ 應觸發 #70 A 還原
FILTERS_IN = {"politics": ["關心政治"], "hobby": ["逛街購物"]}


def _fake_filter(db, filters):
    return list(db)[:12] if "politics" in filters else list(db)


async def _parse(q_list, role=None, distribution=None):
    return {"domain": "市場研究", "reasoning": "一般敍述。", "question_analysis": [],
            "usage_suggestion": None, "filters": FILTERS_IN, "dim_importance": {}, "core_dims": []}


async def _llm(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    # 模型試圖移除唯一的維度（＝挑錯維度）→ 樣本暴增
    return json.dumps({"broadening": "移除 politics 以增加樣本", "protected_dims": [],
                       "filters": {"hobby": ["逛街購物"]}}, ensure_ascii=False)


server_mod.filter_personas = _fake_filter
server_mod.parse_questions_with_llm = _parse
llm_mod.call_llm = _llm
try:
    loop = asyncio.new_event_loop()
    r = loop.run_until_complete(server_mod.personadb_candidates(
        questions="夜市消費者的輪廓", top_k=10, opMode="僅篩選", role=""))
finally:
    server_mod.filter_personas = _orig_filter
    server_mod.parse_questions_with_llm, llm_mod.call_llm = _orig_parse, _orig_llm

_ba = r.broadening_attempts or []
_rest = [b for b in _ba if b.overshoot_restore]
print(f"     嘗試: {[(b.loop, b.match_count_before, b.match_count_after, b.overshoot_restore, b.restored_dims) for b in _ba]}")
check("★ #70 A 過衝輪被標記 overshoot_restore", bool(_rest), [(b.overshoot_restore, b.restored_dims) for b in _ba])
check("★ #70 A 被移除的維度已還原（applied_filters 仍有）",
      "politics" in (r.applied_filters or {}), r.applied_filters)
check("★ #70 A 維度進入保護集（來源⑥ overshoot_restore）",
      "politics" in ((r.protected_dims_sources or {}).get("overshoot_restore") or []),
      r.protected_dims_sources)
# v5.18：訊息改為「已還原至 N 筆（X× ≥ 3×）」（倍率為還原前量測）
check("#70 A/#70 B warnings 揭露**觸發**倍率（v5.18 起為還原前量測）",
      any("已還原至" in w and "×" in w for w in (r.warnings or [])), r.warnings)
check("#70 A 還原後樣本數回到原值（不再暴增）", (r.total_matched or 0) > 0 and
      all(b.match_count_after < 100 for b in _ba), [(b.match_count_before, b.match_count_after) for b in _ba])

print("\n=== #70 A 反向測試：中度放寬（<3×）不得還原 ===")
# 12 → 30（2.5× <3）→ 不得還原，且應達成 target_reached（#70 A 不得讓正常放寬變難）
def _ff_mod(db, filters):
    return list(db)[:12] if "politics" in filters else list(db)[:30]


server_mod.filter_personas = _ff_mod
server_mod.parse_questions_with_llm = _parse
llm_mod.call_llm = _llm
try:
    loop = asyncio.new_event_loop()
    r_mod = loop.run_until_complete(server_mod.personadb_candidates(
        questions="夜市消費者的輪廓", top_k=10, opMode="僅篩選", role=""))
finally:
    server_mod.filter_personas = _orig_filter
    server_mod.parse_questions_with_llm, llm_mod.call_llm = _orig_parse, _orig_llm
_ba_mod = r_mod.broadening_attempts or []
check("★ 反向：2.5× 未達門檻 → 不還原",
      bool(_ba_mod) and not any(b.overshoot_restore for b in _ba_mod),
      [(b.match_count_before, b.match_count_after, b.overshoot_restore) for b in _ba_mod])
check("反向：樣本數達標 → target_reached",
      r_mod.broadening_stop_reason == "target_reached" and (r_mod.total_matched or 0) >= 20,
      (r_mod.broadening_stop_reason, r_mod.total_matched))
check("反向：來源⑥ 為空（沒有還原事件）",
      not ((r_mod.protected_dims_sources or {}).get("overshoot_restore") or []),
      (r_mod.protected_dims_sources or {}).get("overshoot_restore"))

print("\n=== #71 B declared_protected_cap ===")
check("#71 B 回應含 declared_protected_cap（int）", isinstance(r.declared_protected_cap, int), r.declared_protected_cap)
check("#71 B 來源④數量 ≤ cap",
      len((r.protected_dims_sources or {}).get("model_declared") or []) <= (r.declared_protected_cap or 0),
      ((r.protected_dims_sources or {}).get("model_declared"), r.declared_protected_cap))

print("\n=== 契約 ===")
from api.models import CandidatesResponse, BroadeningAttempt
_props = CandidatesResponse.model_json_schema()["properties"]
check("declared_protected_cap（integer）", _props["declared_protected_cap"]["type"] == "integer")
_aprops = BroadeningAttempt.model_json_schema()["properties"]
for f, t in (("widened_deltas", "array"), ("overshoot_restore", "boolean"), ("restored_dims", "array")):
    check(f"BroadeningAttempt 有 {f}（{t}）", _aprops[f]["type"] == t, _aprops.get(f, {}).get("type"))
_a = BroadeningAttempt(loop=1)
check("嘗試物件向後相容（預設值）",
      _a.widened_deltas == [] and _a.overshoot_restore is False and _a.restored_dims == [])
_d0 = CandidatesResponse(total_matched=0, persona_ids=[])
check("回應向後相容（預設值）", _d0.declared_protected_cap == 0)

print("\n" + "=" * 62)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
