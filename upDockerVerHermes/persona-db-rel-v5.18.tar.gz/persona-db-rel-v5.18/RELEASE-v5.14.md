# Persona DB v5.14 Release Notes

> 日期: 2026-09-16 | 上一版: v5.13 | 類型: **放寬幅度揭露（#69）＋ 過衝回饋與自選維度優先序（#70）＋ 可稽核性（#71）**
> 來源: round 13 §6.2(2)(3)(6)、§6.3(2)(3)(4)；issues **#69 #70 #71**

## 修的 issue

| # | 類型 | 內容 |
|:-:|:--|:--|
| **#69** | enhancement | 值集放寬只留「哪個維度」、不留「鬆了多少」→ 新增 `widened_deltas` |
| **#70** | enhancement | 移除**高相關維度**造成嚴重過衝（案例 03：18→105 = 5.8×）只有 WARNING、沒有回饋 → 新增**過衝還原**（A）＋ 自選維度優先序提示（B） |
| **#71** | chore | `#62` 留痕在**呼叫點**（讀函式本體者誤以為沒留痕，同一誤判被重複提出三次）＋ 來源④上限基準不在回應 → 留痕移入函式本體、新增 `declared_protected_cap` |

## 變更

### #69 `widened_deltas`

`broadening_attempts[]` 新增 `widened_deltas: [{"dim","before","after","added"}]`（口徑與 `widened_dims` 一致：嚴格超集）。

### #70 A 過衝回饋（機械）

某輪**移除維度**後樣本數 `after / before ≥ OVERSHOOT_RESTORE_RATIO (=3)` →
**還原該輪被移除的維度**（保留同輪合法的值集放寬）、加入保護集（**新來源⑥ `overshoot_restore`**）、
`warnings` 揭露倍率、attempt 標記 `overshoot_restore=True` + `restored_dims`。
理由：移除後樣本暴增代表**挑錯維度**（移除的往往正是語意相關的那一維）；此時「少而正確」優於「多而失焦」。

### #70 B 自選維度優先序（提示層）

`_constraint_hint()` 新增 `self_selected_dims`（模型自己在 analysis 階段選定、非兜底表補的維度）→
提示「這些是你自己判定的語意核心，請優先放寬其他維度」。**不進保護集**（避免與 #66 A 的上限設計衝突）。

### #71 A 留痕移進函式本體

`_normalize_filters()` 自己記 log（訊息文字不變）；呼叫點移除重複訊息。

### #71 B `declared_protected_cap`

回應新增 `declared_protected_cap: int`（本請求實際套用的來源④上限）→ 出貨斷言可驗
`len(protected_dims_sources.model_declared) ≤ declared_protected_cap`（「半數規則」也納入部署層稽核）。

## 相容性

- 全部為**純新增**欄位（皆有 default）：`widened_deltas`、`overshoot_restore`、`restored_dims`、`declared_protected_cap`
- `protected_dims_sources` 由五鍵 → **六鍵**（新增 `overshoot_restore`）→ **消費端若有硬編碼五鍵需更新**
- **行為變更**：移除維度造成 ≥3× 過衝的輪次會被**還原**（該維度進保護集）→ 這類請求的 `returned` 可能變少但語意更貼題；未達門檻的正常放寬不受影響（已有反向測試）

## 驗證

- **單元**：12 套件全綠（新增 `test_v5_14_fixes.py`：`widened_deltas` 口徑、`_normalize_filters` 本體留痕、過衝還原正/反向、`declared_protected_cap`、契約）
- **出貨斷言新增**：`widened_deltas` 口徑一致（含嚴格超集 + `added` 非空）、`declared_protected_cap` 契約、六鍵來源、`restored_dims ⊆ protected_dims`
- **真 LLM e2e**：案例 03（時尚）過衝是否消失／被還原；六鍵來源；既有回歸
- **SOP（nodeB）**：fresh deploy → 出貨斷言全跑、0 紅旗
