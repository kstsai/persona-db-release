# Persona DB v5.13 Release Notes

> 日期: 2026-09-15 | 上一版: v5.12 | 類型: **保護集上限與揭露（#66）＋ 主體判準覆蓋擴充與依據揭露（#67）**
> 來源: **#66**（我方 v5.11 實測：保護集 1→5 個時 `matched` 14→3）、**#67**（round 12 §6.2(2)／§6.3(3)：`subject` 僅 2/9 案例判定）

## 修的 issue

| # | 類型 | 內容 |
|:-:|:--|:--|
| **#66** | enhancement | 保護集來源④（模型每輪宣告）**單調累積無上限** → 過度保護時樣本數崩落且無警示（A 上限＋揭露、C 專屬停止原因） |
| **#67** | enhancement | `subject` 判定**覆蓋窄**（2/9）且**無判定依據**（A 覆蓋擴充、B `subject_basis`） |

## 變更

### #66 A：來源④上限 + 來源揭露 + 覆蓋警示

- `DECLARED_PROTECTED_MAX = 3`；實際上限 = `max(1, min(3, 已套用維度數 // 2))`（以**請求開始**的維度數為基準 → 凍結語意）
- 超過上限的模型宣告 → 丟棄 ＋ `warnings` 記錄 ＋ INFO log；**①②③⑤ 來源不受限**
- 回應新增 **`protected_dims_sources`**（`domain`／`reasoning`／`analysis_declared`／`model_declared`／`protect_only`）—— 先前來源拆解只存在於 log
- 保護集覆蓋 ≥ 1/2 已套用維度 → `warnings` 追加一則（＋INFO log）

### #66 C：`protection_saturated`

放寬迴圈開始時，若**全部已套用維度都受保護**（可移除者為 0）→ **不再呼叫 LLM**，`broadening_stop_reason = "protection_saturated"`。
理由：此狀態下唯一合法的放寬是「稀釋受保護維度的值集」→ 選擇**停手並標示**，而非靜默稀釋（與 #59「區分刻意拒絕與嘗試失敗」同精神）。附帶效益：省下至少一次 LLM 呼叫。

### #67 A：`subject` 覆蓋擴充

- 判準改為：**① 明確業主標記優先**（`業主／老闆本人`、`名單／受訪者／訪談`、`B2B` → `owner`）→ **② 出現消費端名詞**（`目標客群／目標客戶／客群／客層／顧客／消費者／客戶群／來客`，可帶 `X的` 前綴 → `customer`）→ ③ 否則 `""`
- 效果：round 12 的 9 案例中，除 04／09 外其餘皆可判定（原僅 2/9）
- **優先序設計動機**：避免「找業主本人回答其顧客問題」這類**同時含顧客詞**的題被誤判為 `customer` → 會誤擋 must-use

### #67 B：`subject_basis`

回應新增 **`subject_basis`**（命中的原文片段，例：`命中「老闆的目標客群」（顧客語意樣式）`）→ 「為什麼這題沒判定」變成可稽核。

## 相容性

- 三個新欄位（`subject_basis`、`protected_dims_sources`）＋ 一個 enum 值（`protection_saturated`）皆為**純新增**，向後相容
- `subject` 的**值域可能變化**：過去判 `""` 的題目（例：`醫美診所的目標客戶`、`債務整合的目標客戶`）現在判為 `customer` → 這些題的 `applied_filters` 將**保證不含** `employment_status`（語意正確；既有案例未使用該維度，實測無影響）
- 來源④ 上限可能讓保護集**變小** → 放寬空間變大 → 部分題的 `matched` 可能上升（預期改善，非退化）

## 驗證

- **單元**：11 套件全綠（新增 `scripts/test_v5_13_fixes.py`：主體判定 15 案例含 2 個「業主標記優先」反例、上限公式、endpoint 級 6 情境含反向測試、契約）
- **出貨斷言新增**：`subject_basis`／`protected_dims_sources` 契約、來源⑤鍵齊全、**來源④ 數量 ≤ 上限**、enum 含 `protection_saturated`
- **真 LLM e2e**：新樣式題（`咖啡廳的客群`）＋ 既有回歸（08 customer／09 owner／TESLA／債務／銀行／醫美）
- **SOP（nodeB）**：fresh deploy → 出貨斷言全跑
