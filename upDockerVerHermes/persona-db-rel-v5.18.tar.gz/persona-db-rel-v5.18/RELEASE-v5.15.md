# Persona DB v5.15 Release Notes

> 日期: 2026-09-16 | 上一版: v5.14 | 類型: **失敗路徑可稽核（#72）＋ 留痕單一化（#73）**
> 來源: round 14 §4.6(1)、§6.2(2)、§6.3(1)(2)；round 14 review 時我方自查（#73）

## 修的 issue

| # | 類型 | 內容 |
|:-:|:--|:--|
| **#72** | bug | `llm_parse_error` **完全不留 log**（該路徑 logger 呼叫 0 次）＋失敗輪未記入 `broadening_attempts`（回應 `loops` 低估實際呼叫次數） |
| **#73** | chore | v5.14 `#71 A` 未竟：呼叫點仍重複輸出 log（同一次丟棄最多 3 行）→ 以 `context` 參數單一化 |

## 變更

### #72 失敗路徑可稽核

1. **失敗輪記入**：`llm_parse_error`（解析失敗）與 `llm_empty`（空回應）兩條路徑在 `break` **前** append 一筆 attempt
   （`parse_error=true`、`error_type` = 例外型別或 `empty_response`；計數不變、`no_op=true`）→ `len(broadening_attempts)` 等於實際放寬呼叫次數
2. **WARNING log**：含**例外型別與訊息** ＋ `llm.py` 的 `_LAST_LLM_META` 診斷（`finish_reason`／`truncated`／`max_tokens`）
   → 「解析失敗率」與「截斷 vs garbage」變成可監控指標
3. **回應新增 `llm_calls`**：分析 1 次 + 放寬嘗試 N 次（含失敗／空回應）

### #73 留痕單一化

`_normalize_filters(filters, context: str = "")`：留痕在**函式本體**輸出**唯一一行**，
`context`（`final`／`loop N`）併入訊息；兩個呼叫點刪除各自的 logger 呼叫。

## 相容性

- 純新增欄位（皆有 default）：`broadening_attempts[].parse_error`／`error_type`、`llm_calls`
- 行為變更：失敗輪現在**會出現在** `broadening_attempts`（先前不存在）→ 若消費端以 `len(attempts)` 推估「成功輪數」，需改看 `parse_error=false` 的筆數
- log 訊息文字變更（`Normalize filters (#62)（loop 2）:` 形式）；**同一事件只輸出 1 行**

## 驗證

- **單元**：13 套件全綠（新增 `test_v5_15_fixes.py`：留痕單一化、失敗輪形狀、解析失敗／空回應兩條路徑的端點級驗證、`llm_calls` 一致性、契約）
- **出貨斷言新增**：`llm_calls` 揭露且 `≥ 1 + attempts`（掃描 9/9）、attempt 皆有 `parse_error`／`error_type`
- **真 LLM e2e**：既有回歸；若自然出現解析失敗，可從 log 與 attempts 交叉確認
- **SOP（nodeB）**：fresh deploy → 出貨斷言全跑、0 紅旗
