# Persona DB v5.10 Release Notes

> 日期: 2026-09-15 | 上一版: v5.9 | 類型: **可診斷性 + 語意保護補強 + 分析欄位品質**
> 來源: v5.9 Pre-Release SOP 發現（#60）、跨 4 輪重複觀測（#61）、既有量測需求（#45）

## 修的 issue

| # | 標題 | 類型 |
|:-:|:---|:---|
| **#60** | app `logger.info` 在生產環境被靜默丟棄（無 `basicConfig`）→ 主機端鑑識少一整層 | enhancement（可診斷性） |
| **#61** | TESLA 案例連續 4 輪放寬 `commute_mode`（電動車客群的語意核心）→ 補 protect-only 保護 | bug |
| **#45** | `llm_analysis.usage_suggestion` 失去區辨力（k=5 判定為系統性後補判斷準則） | bug（低） |

## 給消費者的行為變更

| 變更 | 影響 |
|:---|:---|
| `protected_dims` 可能新增 `commute_mode`（電動車/汽車 query） | 該類 query 的放寬維度變少 → **樣本數可能較小**（`pool_exhausted` 為契約預期行為） |
| `llm_analysis.usage_suggestion.mode` 開始依題意變化 | 先前（v5.3.1 起）8/8 常數；仰賴「恆為某值」的下游邏輯需檢視（正確方向：恢復區辨力） |
| 容器 `LOG_LEVEL`（新，預設 `INFO`） | `docker logs` 開始出現 app 的 INFO 行（可診斷性↑；可用 `LOG_LEVEL=WARNING` 關閉） |
| 容器 log rotation（`max-size=10m, max-file=3`） | 長跑不再無上限成長 |

## #60：可診斷性

**問題**：容器以 `python3 -m api.server` 啟動，但 `api/server.py` 全檔無 `logging.basicConfig` → root logger 無 handler，只剩 Python `lastResort`（**只輸出 WARNING 以上**）→ 所有 `logger.info` 靜默丟棄。

**影響**：① `Broadening loop N`、`Protected dims (#57)`、`Domain reinforcement`、`no_op` 等逐輪軌跡在生產環境看不到（#57 的保護集判定無法從 log 複驗，只能靠回應的 `protected_dims`）② **對 INFO 行的 grep 檢查會產生偽陰性**（v5.8 SOP 期間曾據此誤判「未觸發」）。

**修法**：`log_level = os.environ.get("LOG_LEVEL", "INFO")`（**非法值回退 INFO**，避免打錯字讓服務起不來）＋ `pocDemo.env` 加 `LOG_LEVEL=INFO` ＋ 部署腳本加 `--log-opt max-size=10m --log-opt max-file=3`。

## #61：protect-only（#57 模式的第五個來源）

`PROTECT_ONLY_DOMAIN_DIMS = {"電動車": {"commute_mode"}, "汽車": {"commute_mode"}}` —— 命中時**只加入保護集、不修改 `filters`**（與 `domain_filters` 的補值語意分離）。

由來：`commute_mode`（以汽車通勤）是電動車的購買動機維度，第 6/7/8/9 輪與 v5.9 SOP **連續 4 輪**被放寬移除（第 8 輪更因此首度觸發 `overshoot` 19→60），而 #57 的四來源全數漏接（關鍵字表無此鍵、分析與模型皆未宣告）→ 以**語意對應表**補上。

## #45：`usage_suggestion` 判斷準則

**k=5 變異檢定**（同 query 連打 5 次）：`mode` **5/5 = `問卷答題者`** → 判定為系統性（非抽樣雜訊）→ 於 prompt 補**選擇準則**（依「題目的主體是誰的觀點」判斷：決策者立場→模擬詢問；族群態度→問卷答題者；兼具→兩者皆可）。

## 驗證

| 層 | 結果 |
|:---|:---|
| 單元（`scripts/test_v5_10_fixes.py`） | `LOG_LEVEL` 三情境（WARNING/INFO/非法值）＋ protect-only 四情境（電動車、汽車、對照組、filters 不變） |
| 既有套件 | v5.4–v5.9 全綠 |
| 真 LLM e2e | TESLA query → `relaxed_dims` 不含 `commute_mode`；康是美/債務/醫美/業主回歸；#45 五案例 `mode` ≥2 種值 |
| 部署環境 | SOP（nodeB）：`docker logs \| grep -c "Protected dims"` > 0；`LOG_LEVEL=WARNING` → 0 |
| Gate | `check_dim_weights` + `check_response_schema` |

## 已知限制（續留）

- `#38`（端點不可重現）、`#39`（延遲）、`#40`（頭部集中）為 `known-limitation`
- 語意判準 vs 數學判準的衝突仍有殘留可能：**未列為保護維度的語意核心仍可能被放寬**（本版以第五來源補上 `commute_mode` 這一例；其餘需後續輪次證據再開票）
- `persona-db-api` 容器無 `--restart`（僅 hermes 容器有）—— 本版未動，另記觀察
