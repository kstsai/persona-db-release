# Container Hermes Configuration

When deploying persona-db via Docker, the Hermes container needs explicit configuration for custom providers and OAuth. This reference covers the patterns discovered during NODE-A edge-VM deployment.

## Config Structure

### `custom_providers` MUST be a YAML list (❗)

```yaml
# ✅ CORRECT — list with `-` prefix
custom_providers:
  - name: deepseek-pro
    base_url: https://api.deepseek.com
    api_key_env: LLM_API_KEY

model:
  default: deepseek-v4-flash
  provider: custom:deepseek-pro
```

```yaml
# ❌ WRONG — dict format; Hermes rejects with:
# "custom_providers is a dict — it must be a YAML list"
custom_providers:
  deepseek-pro:
    base_url: ...
```

The `hermes config set custom_providers.N.key value` nested key syntax also produces the wrong format (creates a dict, not a list). Always write the config directly via YAML.

### `model` must be a section, not a string

```yaml
# ✅ CORRECT
model:
  default: deepseek-v4-flash
  provider: custom:deepseek-pro

# ❌ WRONG — top-level string; provider won't be recognized
model: deepseek-v4-flash
```

### Required keys per custom provider entry

| Key | Value | Example |
|:----|:------|:--------|
| `name` | Provider identifier | `deepseek-pro` |
| `base_url` | API endpoint | `https://api.deepseek.com` |
| `api_key_env` | Env var name (not the key itself) | `LLM_API_KEY` |

## Hermes `.env` and `--env-file`

The Hermes container needs the API key as a runtime environment variable because `api_key_env: LLM_API_KEY` tells Hermes to look for `$LLM_API_KEY` in its environment.

### Container startup

```bash
docker run -d \
  --name hermes \
  --network host \
  --restart unless-stopped \
  --env-file /path/to/.env \          # ← REQUIRED for api_key_env to work
  -v "${HERMES_HOME}:/opt/data" \
  -v "${PERSONA_DB_DATA}:/root/persona-db" \
  nousresearch/hermes-agent:latest \
  /bin/sh -c "sleep infinity"
```

Without `--env-file`, the `.env` file in `/opt/data/.env` is present on disk but NOT loaded as shell env vars — Hermes only reads env vars, not the `.env` file directly, for the custom provider key.

### Docker-compose equivalent

```yaml
services:
  hermes:
    image: nousresearch/hermes-agent:latest
    container_name: hermes
    network_mode: host
    volumes:
      - ${HERMES_HOME}:/opt/data
      - ${PERSONA_DB_DATA}:/root/persona-db
    env_file:                           # ← REQUIRED
      - ${HERMES_HOME}/.env
    entrypoint: ["/bin/sh", "-c", "sleep infinity"]
```

## Hermes CLI inside Container: Interactive vs Non-interactive

### `hermes model` — Interactive provider picker

Requires a PTY (interactive terminal):

```bash
# Works (interactive SSH session)
ssh user@host
docker exec -it hermes hermes model --no-browser

# Fails (pipe / non-interactive)
docker exec hermes hermes model --no-browser
# Error: 'hermes model' requires an interactive terminal.
```

The `--no-browser` flag prints an OAuth URL that the user opens in their own browser (the container has no browser). Once authorized, the CLI detects it and shows available models.

`hermes model` output shows custom providers as selectable options:
```
→ (●) deepseek-pro (api.deepseek.com)  ← currently active
```

### `hermes auth add nous` — Nous Portal OAuth

For clients who have their own Nous Portal subscription:

```bash
docker exec -it hermes hermes auth add nous
```

Prints a URL like:
```
Open: https://portal.nousresearch.com/manage-subscription?user_code=RMKP-GSNX
```

The user opens the URL in their browser, logs in, authorizes. After that, `hermes model` shows Nous Portal as a selectable provider.

### `hermes chat` — Requires no PTY for one-shot

```bash
# One-shot query (works non-interactively)
docker exec hermes hermes chat -q "Show status"

# Interactive chat (needs PTY)
docker exec -it hermes hermes chat
```

## Verification

After setting up config + .env, verify:

```bash
docker exec hermes hermes config get model
# Should show: default: deepseek-v4-flash, provider: custom:deepseek-pro

docker exec hermes hermes --version
# Should show no config warnings
```

## Pitfalls

1. **`custom_providers` dict vs list**: Hermes v0.19.0+ validates this strictly. Dict format produces a hard error on startup.
2. **`--env-file` missing**: Without it, `api_key_env: LLM_API_KEY` silently fails — the env var is never set in the process.
3. **`hermes model` inside container**: Requires `-it` flag (interactive + TTY). Without it, errors with "requires an interactive terminal".
4. **Dual `.env` trap**: The persona-db API reads from `PERSONA_DB_DATA/.env`, but Hermes reads from `HERMES_HOME/.env`. They are DIFFERENT files. Both need the correct `LLM_API_KEY` and `LLM_MODEL`.
5. **Model name deprecation**: `deepseek-chat` returns 400 Bad Request. Current working name: `deepseek-v4-flash`. The tarball's `.env` template historically shipped with `deepseek-chat` — always verify.
