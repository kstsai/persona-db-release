# Session 管理實戰流程

> 給 kstsai 的跨 session 專注力輔助系統
> 需知：靜態表格一定會過期，真正的進度追蹤靠即時查詢。
> 2026-07-15 (v2 — 改為動態查詢模式)

## 核心原則：動態查詢 > 靜態表格

**不要依賴 markdown 裡寫死的 active goals 表格** — 那一定跟不上使用者發散的速度。

當使用者問「我剛在忙什麼」時，Hermes 做的事：

```
1. session_search(limit=5)       → 最近活躍的 5 個 session
2. memory scan (active goals)    → 記憶中記錄的 pending 事項
3. 即時交叉比對                    → 哪些 session 完成了什麼、哪些還在 pending
4. 動態合成回答                    → 不是讀一個過期的檔案
```

### 為什麼不用靜態表格？

| 問題 | 靜態表格 | 動態查詢 |
|:-----|:---------|:---------|
| Issue #22 狀態更新了 | ❌ 表格還寫「等 mini-PC」 | ✅ 即時查 GitHub API 或 session 記錄 |
| 使用者開了新 thread 討論新主題 | ❌ 表格還是「待探索」 | ✅ session_search 馬上抓到新活動 |
| 使用者在另個 channel @ 你 | ❌ 表格不知道 | ✅ 跨 channel session 搜得到 |

## 核心機制

### 1️⃣ 每當使用者開新 thread / 新 session 時

Hermes 應**即時查詢**最近的活動，在回覆開頭提示：

```
╔════════════════════════════════════════╗
║  📋 從 session 記錄看到你最近在忙：   ║
║  🎯 [persona-db] Transfer 交付驗證    ║
║  🎯 [lab-riscv] Issue #22 qcow2 build ║
║  (⏱ 動態查詢，非靜態表格)             ║
║                                       ║
║  要繼續追這些？還是先處理新的？         ║
╚════════════════════════════════════════╝
```

### 2️⃣ 當使用者跳主題時

用關鍵字觸發 recall — 即時查，不是讀檔案：

| 你說 | 我做的事 | 資料源 |
|:-----|:---------|:-------|
| `我剛在忙什麼` | session_search(limit=5) + memory scan | session DB + memory |
| `我之前跟進度到哪` | 針對關鍵字搜尋相關 session 內容 | session_search(query=...) |
| `切回去討論[主題]` | 找到對應 session，建議 resume | session_search |
| `幫我記錄目前進度` | 寫入 memory（跨 session 持久） | memory tool |
| `Issue #22 現在怎樣` | 即時查 GitHub issue API | gh CLI / curl |

### 3️⃣ Session 命名慣例

每次結束一個主題時，建議 rename：

```
Before: —                            (不知道是什麼)
After:  [persona-db] Lite方案定價確認 — 7/15
```

命名格式：`[專案] 主題 — 日期`

## 跨 Channel @mention 感知

使用者在 Slack 上常在 channel A 開 thread 討論，然後在 channel B 發新 thread。當使用者說「我在另個 channel @你」或提及跨 channel 活動時：

1. 用 `session_search` 帶關鍵字搜尋提及的 channel 或主題
2. 不要假設當前 session 有那些 context
3. 引用結果到當前對話中

## 與本尊的 sync 策略

| Instance | 什麼同步 | 什麼不同步 |
|:---------|:---------|:-----------|
| 本尊 (原 VM) | Git repos (persona-db, lab-riscv) | Session 對話記錄 |
| 分身 (新 VM) | Git repos (via push/pull) | Session DB 為空 (可重建) |
| Slack | Session 列表共享 (透過 gateway) | 實際訊息內容各自儲存 |

### 工作流程建議

```bash
# 1. 在任何 instance 工作前
git pull origin main    # 確保拿到最新 code

# 2. 工作後
git push origin main    # 同步回 GitHub
git push internal main     # 同步回內部

# 3. 換 instance 繼續
git pull origin main    # 拿到另一台 push 的進度
```

這樣不管在哪台機器上工作，code 和資料永遠是最新版。
