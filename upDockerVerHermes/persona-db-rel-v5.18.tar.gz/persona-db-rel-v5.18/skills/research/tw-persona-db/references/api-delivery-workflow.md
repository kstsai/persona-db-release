# Persona DB API + Container Delivery Workflow

> Generated 2026-07-20 from Transfer delivery iteration

## Overview

Per client meeting (2026-07-17), the delivery format shifted from qcow2 KVM image to:

1. **RESTful API** (FastAPI, LLM-powered) instead of Issue-based queries
2. **Docker container** instead of KVM/qcow2

This reference documents the API design, LLM integration patterns, and deployment scripts.

## Architecture

```
questions="問題一|問題二"
  ↓
LLM analyzes (DeepSeek Flash / any OpenAI-compatible):
  1. Domain detection
  2. Dimension filter inference
  3. Usage suggestion (模擬詢問 vs 問卷答題者)
  ↓
Filter Persona DB (1069 entries)
  ↓
(Optional) LLM simulation (遭遇模擬②)
  ↓
JSON Response
  ├─ persona_ids, personas (with prompt_prefix)
  ├─ important_dimensions
  ├─ llm_analysis (domain, reasoning, usage_suggestion)
  └─ simulation (answers per persona, if opMode=篩選+模擬)
```

## Key Files

| File | Purpose |
|:-----|:--------|
| `api/server.py` | FastAPI app — `/personadb/candidates`, `/personadb/detail`, `/health` |
| `api/llm.py` | LLM client — reads Hermes config OR env vars for provider |
| `api/persona_matcher.py` | Keyword fallback + LLM filter bridge |
| `api/models.py` | Pydantic schemas |
| `api/API-SPEC.md` | Full API specification, v0.2 |
| `Dockerfile` | Python 3.11-slim, HEALTHCHECK, env config |
| `docker-compose.yml` | .env-driven deployment |
| `deploy-hermes-personadb-containers.sh` | One-command deploy（2026-09-17 起唯一支援；舊名 `deploy-persona-db-api.sh` 已移除） |
| `setup-internal-mirror.sh` | Mirror kstsai/persona-db to local internal git server |

## LLM Integration Pattern

The API calls LLM in two places:

### 1. Question Analysis (`api/llm.py:parse_questions_with_llm`)
- Prompt includes the exact valid dimension values (age brackets, occupations, etc.)
- LLM outputs structured JSON with `filters` and `usage_suggestion`
- Falls back to keyword parsing if LLM unavailable

### 2. Persona Simulation (`api/llm.py:simulate_with_llm`)
- Each persona's `prompt_prefix` + dimensions → LLM
- LLM answers in first-person as the persona (遭遇模擬②)
- Runs async, max 3 parallel

### LLM Provider Discovery

Priority order:
1. `LLM_API_KEY` env var (highest — explicit override)
2. `/hermes-config/config.yaml` (mounted Hermes config, auto-detect)
3. Falls back to keyword parsing if no key

## Deployment Options

### Option A: GitHub token (traditional)
```bash
bash deploy-hermes-personadb-containers.sh   # 舊版含 mirror 參數的用法已隨腳本移除
```

### Option B: Local internal git server mirror (no full-privilege PAT)
```bash
# Setup mirror once
bash setup-internal-mirror.sh

# Deploy from mirror
# （mirror 參數用法已隨舊腳本移除；現行部署以 tarball 為準）
```

### Option C: Bare git mirror (simplest on single VM)
```bash
# Setup on target VM
git clone --mirror https://...@github.com/kstsai/persona-db.git ~/git-mirror/
crontab: */30 * * * * cd ~/git-mirror && git fetch --all

# Deploy
bash deploy-from-mirror.sh  # clones from local mirror
```

## Pitfalls

- **API key truncation**: Config shows `sk-b9b...d980` with literal `...`. The real key must be obtained from `.env` or runtime env, NOT from the config file display.
- **LLM model name**: When calling DeepSeek directly, use `deepseek-chat` (not `deepseek-v4-flash` which is a Hermes custom name). For Nous API, use whatever model the provider supports (e.g., `tencent/hy3:free`).
- **Hobby filter bug**: `hobby` is stored as a list in persona DB (`["登山","游泳"]`). The `filter_personas()` function must check `any(v in val for v in accepted)` for list-type dimensions, not `val not in accepted`.
- **Docker restart doesn't reload .env**: Changing `.env` requires `docker rm` + `docker run`, not just `docker restart`. Use the deploy script to do this automatically.
- **Permission for Hermes config mount**: The `hermes` user may not have `read` permission on `/home/ubuntu/.hermes/`. Docker daemon runs as root and can mount it anyway — the bash `[ -d ]` check may fail falsely. Always mount, don't check.

## Related Issues

- GitHub `kstsai/persona-db` Issue #1 — API design & implementation tracker
