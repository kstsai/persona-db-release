# Persona DB v5.16 Release Notes

> 日期: 2026-09-17 | 上一版: v5.15 | 類型: **版本顯示修正（#77）＋ 打包順序缺陷首驗（#74）**
> 來源: 甲方訊息「可以透過 swagger 操作，產生出第一批的人設」→ 實測其可見性問題；#74 為 round15 發現

## 修的 issue

| # | 類型 | 內容 |
|:-:|:--|:--|
| **#77** | bug | `/openapi.json` 的 `info.version` **寫死 `3.2.0`**、`/health` 寫死 `3.2` → **Swagger 頁首與產品版號（v5.15）不一致**（甲方可見的顯示層缺陷） |
| **#74** | bug | 出貨 tarball 內 `RELEASE-VERSION` 落後一版（打包順序）→ 修法已於 `f262bda` 進，**本版首次由守門斷言驗證** |

## 變更

### #77 版本單一來源

新增 `_product_version()`：讀容器內 `/app/VERSION`（讀不到回 `"unknown"`，不假裝是某個版本），
三處共用同一來源：**FastAPI `version`（＝Swagger 頁首）／`/health`／`/personadb/status`**。

修前 → 修後：

| 端點 | 修前 | 修後 |
|:--|:--|:--|
| `/openapi.json` `info.version` | `3.2.0`（寫死） | **`v5.16`** |
| `/health` `version` | `3.2`（寫死） | **`v5.16`** |
| `/personadb/status` | 讀 VERSION（fallback `v3.2`） | 同 helper（fallback `unknown`） |

### #74 驗證方式

出貨斷言新增「tarball 內 `VERSION` == `RELEASE-VERSION` == tag」（v5.15 會 ❌、v5.16 起應 ✅）。

## 相容性

- 純欄位值修正（`info.version`／`health.version` 由寫死改為真實版號）→ 對既有消費端為**改善**；
  若有工具硬比對舊值（`3.2.0`），需更新
- 無 API 參數／回應結構變更

## 驗證

- **單元**：14 套件全綠（新增 `test_v5_16_fixes.py`：三處版本一致、openapi == VERSION、缺少 VERSION 時回 `unknown`）
- **出貨斷言新增**：#77（openapi 版本 == 部署版本）、#74（tarball 三處版本一致）
- **真 LLM e2e**：既有回歸
- **SOP（nodeB）**：fresh deploy → 全部斷言；0 紅旗
