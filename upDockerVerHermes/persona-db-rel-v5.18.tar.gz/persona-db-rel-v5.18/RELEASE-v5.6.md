# Persona DB v5.6 Release Notes

> 日期: 2026-09-12 | 上一版: v5.5 | 類型: **可診斷性強化**（#50）— **無 API 契約／行為變更**
> 來源: #46 的部署環境證據（NODE-B v5.5 QA）+ `api/llm.py` code review

## 修的 issue

| # | 標題 | 修法 |
|---|---|---|
| **50** | analysis 解析失敗的 WARNING 應帶 `finish_reason`（區分截斷 vs 其他失敗原因） | ① `call_llm(..., return_meta=True)` → `(text, meta)`，meta 含 `finish_reason` / `truncated` / `model` / `max_tokens` / `usage`（**預設 `False`，既有呼叫端零影響**，已用 `@overload` 標註型別）② `parse_questions_with_llm` 的 WARNING / ERROR 一律帶 `finish_reason` 與 `truncated` ③ **新增**：`content` 非空但被截斷（`finish_reason=length`）時在來源就警告 —— 這是先前完全沒有記錄、導致 503 只能靠猜的情況 |

## 為什麼要做（#46 的部署證據）

NODE-B v5.5 QA 中發生 1 次真實解析失敗，log 顯示 raw response 是**推理文字且被中途截斷**：

```
Failed to parse LLM response as JSON (attempt 1/2): Expecting value: line 1 column 1 (char 0)
Raw LLM response (first 300 chars): '我们需要回答用户。…必须使用 clothing_spend 等消费维度。但输出 filters '
JSON parse failed, retrying with max_tokens=12000...   → 第二次成功、該案例最終 200
```

原 code 的問題：`call_llm` **只在 `content` 為空**時才使用 `finish_reason`；`content` 非空**即使被截斷也直接回傳**，而且 `finish_reason` 完全不傳給 caller。→ 只能靠「字串在句中結束」人工推測是截斷。本版把這個診斷缺口補上。

## 修好之後的 log 長相

```
LLM content 非空但被截斷（finish_reason=length, max_tokens=8000, model=deepseek-v4-pro）—— 若要求結構化輸出，可能無法解析
Failed to parse LLM response as JSON (attempt 1/2, finish_reason=length, truncated=True, max_tokens=8000): Expecting value: line 1 column 1 (char 0)
Raw LLM response (first 300 chars): '…'
JSON parse failed, retrying with max_tokens=12000...
```

→ **一句話就能分辨**「截斷型（token 不足）」與「其他格式問題」，也可直接統計兩者比例。

## API 相容性

- **完全不變**：成功回應、錯誤契約（v5.5 的 `ErrorResponse` 形狀）與 `opMode` 預設值皆未動
- `call_llm` 是**內部** Python 函式；`return_meta` 預設 `False` → `broadening` / `simulate` / `reasonableness` 等既有呼叫端行為不變（單元測試已驗）

## 驗證

**A. 單元（決定性、無外部 LLM；httpx 以 fake client 替換）** — `python3 scripts/test_v5_6_fixes.py` → **19/19 pass**
- `_llm_result`：`return_meta=False` → 純字串；`True` → `(text, meta)`；`None` 也帶 meta
- 截斷路徑：content 非空 + `finish_reason=length` → 回傳內容不變 **且新增 WARNING**（含 model / max_tokens）
- meta 正確性：`finish_reason` / `truncated` / `model` / `max_tokens` / `usage`；`_LAST_LLM_META` 同步
- **未破壞既有路徑**：D3 reasoning 挖掘仍有效、非截斷真失敗回 `(None, meta)`、預設呼叫回非 tuple
- parser：WARNING 含 `finish_reason=length` + `truncated=True` + attempt + max_tokens；放棄時 ERROR 同樣帶；**兼容非 tuple 的舊 stub**

**B. 既有套件回歸** — `test_v5_4_fixes.py`（27）與 `test_v5_5_fixes.py`（26）**皆 FAILED: 0 / exit 0**

**C. Release gate** — `check_dim_weights.py` pass（`_meta.version=v5.6`）、`py_compile api/*.py scripts/*.py` pass
**D. 出貨測試腳本** — 新增兩項零成本斷言：① 部署版本 == `RELEASE-VERSION`（防 stale 映像）② 映像內含 `finish_reason` 診斷碼

## Out of scope（kstsai 定案）

- **不**提高 pro 的 analysis 基礎預算（先累積 log 數據再決定）
- **不**改寫 retry 策略（不以 `finish_reason` 觸發更多重試）
- 第三次重試 / flash salvage 仍維持不做

## 版本鏈

```
v5.3 → v5.3.1 → v5.4（#42 稀有維度護欄 + #43/#44 可觀測性）
→ v5.5（#47 錯誤契約 + #46 韌性 + #48 schema 型別化 + #49 預設值修正）
→ v5.6（#50 finish_reason 可診斷性；無 API 行為變更）
```
