# Persona-DB 文件評論 SOP（可重現流程）

> 版本: 0.1 | 日期: 2026-09-02 | 用途: 用 persona-db API 找目標客群 persona，以 sub-agent 角色扮演評論一份文件
> 首跑實例: lzc-cp-overview v0.3 → 丹尼爾評論 → v0.4（見 `reports/lzc-cp-case-study/`）

## 目的

對一份文件（提案/產品說明/市場資料）做「目標客群壓力測試」：API 找出該客群的代表 persona → sub-agent（pro model）以 persona 第一人稱閱讀並評論 → 回饋供修訂參考。

## 前置條件

- persona-db-api 部署在 NODE-B（NODE-B）或任一 fresh 實例
- 評論標的文件存在（本 SOP 用 lzc-cp-overview 為例）
- sub-agent 走 deepseek-v4-pro（delegation model）

## 流程（3 步）

### Step 1: API 查 persona

```bash
sshpass -p ubuntu ssh ubuntu@NODE-B \
  "curl -s --get 'http://localhost:8000/personadb/candidates' \
     --data-urlencode 'questions=<主題 query>' \
     --data-urlencode 'top_k=1' \
     --data-urlencode 'opMode=僅篩選' \
     --data-urlencode 'role=<角色>'"
```

實例（lzc-cp 首跑）：
- `role=中小企業IT主管` + `q=邊緣計算相關的產品與服務` → top 1 = 丹尼爾（25-34 科技 >8萬 台南市，score 2.67）

### Step 2: 準備評論標的文件

評論對象要是 persona 看得懂的版本（v0.3 原稿 → `reports/lzc-cp-case-study/lzc-cp-overview-v0.3.md`）。

### Step 3: sub-agent 角色扮演評論

delegate_task 給 sub-agent（pro model）：
- Context: persona 完整檔案（19 維度 + 背景故事）+ 任務文件路徑
- Goal: 以 persona 第一人稱讀完整份文件 → 給出買方/客群視角評論
- 評論框架：解決了什麼痛點 / 質疑什麼 / 怎麼評估 / 想問賣方的問題 / 會不會買

### Step 4: 結果保存

- 原稿（sub-agent 完整輸出）→ `reports/lzc-cp-case-study/persona-review-<name>-raw.md`
- 整理版 → 同一目錄 `persona-review-<name>.md`
- 兩檔並列保存（提案方與評論方對照）

## ⚠️ 可重現性聲明（實測 2026-09-02）

| 項目 | 實測結果 |
|:----|:----|
| **同 role+q 連打 3 次 top 1** | **不穩定**：8/29 top1=丹尼爾；9/2 三次 top1=小艾（金融），丹尼爾 #2-#3 或不在 top 3 |
| total_matched | 浮動 207-254（LLM analysis 每次 filter 不同） |
| **可重現的是流程** | 同 role+q → 同「客群輪廓」（25-34/35-44 高收入科技金融服務…），但**具體哪個 persona 是抽樣結果** |

**意義**：persona-db 的 role+q 是「抽目標客群樣本」— 每次抽到誰有 variance。評論流程本身可重現，但：
- 要「同一 persona 重跑」→ 不保證（LLM analysis 非確定）
- 要「同一客群輪廓」→ 穩定（filters 大致落在同輪廓）
- SOP 定位：**流程可重現、樣本會變** — 評論品質看的是客群視角，不是特定 persona

## ⚠️ 人設-任務匹配檢查（Daniel-inverse 實驗教訓）

**實驗**：把 Daniel（中小企業 IT 主管）換成 inverse persona（0-11 歲小學生豆豆）跑同一評論流程。

**發現**：
1. **API 自然流程產不出錯配 persona**：role=中小企業IT主管 + q=邊緣計算 → matched 全是工作年齡成年人（filters 自動排除 0-18）。連「q=12歲以下兒童 + role=兒童發展研究員」都回 494 筆全成年人 — LLM filter 系統性偏成年人。→ role 參數 = 人設-任務匹配的第一道保險
2. **強制錯配的結果**（豆豆 TW-P-0001, 0-11 小學生評論 lzc-cp v0.3，實測 2026-09-02）：
   - 技術內容**完全看不懂**（異質/邊緣/節點/k3s/KubeEdge —「三個字分開都認識，放在一起就不知道在幹嘛」）
   - 只對**表層字面聯想**有反應：AI agent=電動裡的機器人、Ollama=駱馬🦙、Tailscale=尾巴、Jetson=超人名字、black box=魔術箱
   - 唯一接上的概念：「人走了知識就沒了」→ 對照「媽媽的同事阿姨辭職」（靠生活經驗，非專業理解）
   - 結論「好難好無聊，不想打分數，想去打電動了」— **零可用商業回饋**

**對照（同文件、同流程、不同 persona）**：
| | 丹尼爾（匹配） | 豆豆（錯配） |
|:----|:----|:----|
| 產出 | 5 個具體買方質疑（黑盒子/lock-in/定價…）→ 直接驅動 v0.4 | 字面聯想 + 無聊想走 |
| 可用性 | 高（v0.4 改了 3 處回應質疑） | 零 |
| 角色一致性 | 全程 IT 主管決策框架 | 誠實小學生反應（一致性 OK 但無用） |

**教訓**：這流程的價值建立在「persona 與評論任務匹配」上 — 用對客群（IT 主管評 B2B 提案）得到可用的買方回饋；錯配時（小孩評 B2B 提案）產出無實質參考價值。**跑 SOP 前先問：這個 persona 是這份文件的目標讀者嗎？**

## 附錄：完整命令（可複製）

```bash
# Step 1 — API
sshpass -p ubuntu ssh ubuntu@NODE-B "curl -s --get 'http://localhost:8000/personadb/candidates' --data-urlencode 'questions=邊緣計算相關的產品與服務' --data-urlencode 'top_k=1' --data-urlencode 'opMode=僅篩選' --data-urlencode 'role=中小企業IT主管' | python3 -m json.tool"

# Step 3 — 取 persona 檔案後 delegate_task（見對話流程）
# Step 4 — 存 raw + 整理版到 reports/lzc-cp-case-study/
```
