> 來源: linkEazyCenter wiki `concepts/persona-db/deploy-env-chain.md`（created 2026-08-14）
> 整合進 persona-db repo 供開發參考。Wiki 為上游，改動時同步。


# Deploy Env 鏈（~/.env vs pocDemo.env）

> deploy 時 LLM config 從哪裡讀的坑。issue #26。

## 問題

`pocDemo.env` 是 canonical source（有正確的 `LLM_ANALYSIS_MODEL=deepseek-v4-pro`），但 deploy script 有「`~/.env` 存在就覆蓋 pocDemo.env」的邏輯。若 `~/.env` 是舊的（缺 LLM_ANALYSIS_MODEL），就會把空值寫進容器 `.env`。

**後果**：`LLM_ANALYSIS_MODEL` 空白 → analysis fallback 到 flash（關 thinking）→ 漏消費維度（TESLA dims_counted 只 3 維度 vs pro 的 8-10 維度）。

## 根因

v4.5.3 的「pocDemo.env canonical」修法**只修了一半**：
- ✅ 修了「~/.env 不存在時從 pocDemo.env 建立」
- ❌ 留著「~/.env 存在就覆蓋 pocDemo.env」

加上 `undeploy.sh` 不刪 `~/.env`，所以 stale 檔一直贏。

## 修法（根治）

1. `undeploy.sh` 加 `rm -f ~/.env`（完整清除應包含 ~/.env）
2. deploy script：LLM config（MODEL/ANALYSIS_MODEL/BASE_URL）**只從 pocDemo.env 讀**，`~/.env` 只供 LLM_API_KEY（user secret 才允許覆蓋）

## 為什麼 NODE-B 正常、NODE-A 掛

NODE-B 的 `~/.env` 在 v4.5.3 除錯時手動補過（有 LLM_ANALYSIS_MODEL）；NODE-A 的 `~/.env` 是 Jul 24 舊檔（缺 key），從沒被動過。
