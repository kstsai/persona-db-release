"""
Persona DB REST API — FastAPI Server (LLM-powered)

Endpoints:
  GET /personadb/candidates — LLM analyzes questions → filter personas (+ simulate)
  GET /personadb/detail     — Get full persona profile by ID
  GET /health               — Health check

Run:  uvicorn api.server:app --reload
"""

import os, sys, json, logging, re
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import FastAPI, Query, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import PlainTextResponse, JSONResponse

from .models import (
    OpMode, CandidatesResponse, PersonaSummary,
    PersonaSimulation, DimensionSummary, LLMAnalysis,
    DetailResponse, PersonaDetail, HealthResponse, ErrorResponse
)
from .persona_matcher import (
    filter_personas, get_important_dimensions,
    format_matched_criteria, load_persona_db, get_persona_by_id,
    llm_filters_to_dimension_filters
)
from .llm import parse_questions_with_llm, simulate_with_llm, call_llm, LLM_CONFIG

logger = logging.getLogger(__name__)

# #60: 補 root logger 設定 —— 容器以 `python3 -m api.server` 啟動，但先前**全檔無 basicConfig**
# → root logger 無 handler（只剩 lastResort）→ **app 的 logger.info 在生產環境被靜默丟棄**，
# 只有 WARNING 以上會進 `docker logs`。後果：主機端鑑識少一整層（#57 的保護集判定無法從
# log 複驗），且對 INFO 行的 grep 檢查會產生偽陰性（v5.8 SOP 期間曾據此誤判）。
# uvicorn 只設定自己的 logger，root 不受影響；`api.*` 的 logger 逐級 propagate 到 root。
# LOG_LEVEL=WARNING 可回到安靜模式（預設 INFO）。
_LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()
if _LOG_LEVEL not in ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"):
    # 值非法（打錯字）→ 回退 INFO；不讓 `logging.basicConfig` 拋 ValueError（那會讓
    # 整個模組載入失敗、服務起不來 —— 環境變數打錯字不該是致命錯誤）
    _LOG_LEVEL = "INFO"
if not logging.getLogger().handlers:
    logging.basicConfig(
        level=_LOG_LEVEL,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
else:
    # 已被其他程式庫（或呼叫端）設定過 handler → 只調整層級，不重複掛 handler
    logging.getLogger().setLevel(_LOG_LEVEL)


def _rare_dims_hint(db: list, filters: dict, reinforced_dims: set = None,
                    matched_count: int = 0, threshold: float = 0.05) -> str:
    """稀有維度的放寬提示（#36 引入；#42 收斂為 rescue-only + 核心性排除）。

    #42 的教訓：原本只要覆蓋率 <5% 就提示「優先放寬」，導致 broadening 在
    **第一輪（matched 非 0）** 就把核心維度當「非核心且極稀有」移除
    （案例 07 債務整合：`debt_status` 覆蓋 4.0% → matched 6 → 45，回傳 10 筆中
    4 筆無債務）。三道護欄：

    1. **rescue-only**：只有 `matched == 0` 才提示（救援用，不是首選手段）
    2. **核心性排除**：由 `domain_filters` reinforcement 補上的維度（`reinforced_dims`）
       是本問題語意的主體 → 永不出現在提示中（確定性判定，不依賴 LLM 自評）
    3. **提示文案強制理由**：若 LLM 仍決定放寬，必須在 `change` 寫明為何它不是核心條件

    只「提示」不「硬刪」—— 該維度是否為核心語意最終仍由 LLM 判（確定性硬刪會把
    正確的稀有維度也殺掉，例如醫美 query 的 `aesthetic_procedure`）。
    """
    if matched_count > 0:
        return ""  # #42: rescue-only —— 非 0 不放寬稀有維度
    reinforced_dims = reinforced_dims or set()
    total = len(db) or 1
    rare = []
    for dim, vals in filters.items():
        if not isinstance(vals, list) or not vals:
            continue
        if dim in reinforced_dims:
            continue  # #42: 由 domain reinforcement 補上的維度視為核心，不提示放寬
        hits = len(filter_personas(db, {dim: vals}))
        cov = hits / total
        if cov < threshold:
            rare.append(f"{dim}={vals}（DB 只有 {hits}/{total} = {cov*100:.1f}% 符合）")
    if not rare:
        return ""
    return (
        f"**注意：目前無任何 persona 符合篩選（matched=0），且下列維度在資料庫中極稀有"
        f"（覆蓋率 < {threshold*100:.0f}%）。若要放寬，可優先考慮它們，但必須先判斷語意：**\n- "
        + "\n- ".join(rare)
        + "\n\n**若你決定放寬上述任一維度，必須在 `change` 明確寫出「為何它不是本問題的核心條件」；"
          "若它是本問題的核心條件（例如債務整合之於 debt_status、醫美之於 aesthetic_procedure），"
          "請**保留不要放寬**，並說明必須保留的理由。**"
    )


def _constraint_hint(db, filters: dict, matched_count: int, top_n: int = 4,
                     core_dims: set | None = None,
                     self_selected_dims: set | None = None) -> str:
    """#56 A: 提供「移除各維度後的樣本數」給放寬 prompt，讓模型挑**真正的約束維度**。

    第八輪（v5.7）實測：空轉率 60%（9/15），案例 4 三輪全空轉 —— 模型挑了非約束維度
    （housing_cost）放寬，真正的限制在 housing_burden / debt_status / marriage / family_size。
    純本地計數（無 LLM 成本），故每輪都附。

    `core_dims`（= #42 的 reinforced_dims）：即使倍率最高也**排除在「優先放寬」清單外**。
    否則提示會把模型推向放寬語意核心維度（v5.8 首次 e2e 實測：醫美案例依「倍率最高」
    把 `aesthetic_procedure` 放寬掉 → overshoot 154），正是 #42 要防的行為。
    """
    core_dims = core_dims or set()
    # #70 B：模型**自己在 analysis 階段選定**的維度（非兜底表補的）—— 提示優先保留，避免
    # 「為衝樣本數而移除自己判定的高相關維度」（round13 案例 03：移除 hobby → matched 18→105）。
    # 刻意**不進保護集**（純提示），以免與 #66 A 的上限設計衝突。
    self_selected_dims = (self_selected_dims or set()) - core_dims
    try:
        from .persona_matcher import dim_constraint_report
        rep = [r for r in dim_constraint_report(db, filters, top_n=top_n + len(core_dims))
               if r["dim"] not in core_dims][:top_n]
    except Exception as e:  # 不影響放寬流程
        logger.warning(f"維度約束分析失敗（不影響放寬）: {e}")
        return ""
    if not rep:
        return ""
    lines = [
        f"**當前限制條件分析**（目前 {matched_count} 人；移除各維度後的樣本數，"
        f"倍率越高＝該維度限制越強）："
    ]
    for r in rep:
        lines.append(f"- `{r['dim']}`：{matched_count} → {r['without']}（{r['lift']}×）")
    binding = {r["dim"] for r in rep}
    ineffective = [d for d in filters if d not in binding and d not in core_dims]
    if ineffective:
        lines.append(
            "- **放寬無效**（移除後樣本數不變）："
            + ", ".join(f"`{d}`" for d in ineffective)
            + " ← 不要放寬這些（放了也不會增加樣本數）"
        )
    if core_dims & set(filters):
        lines.append(
            "- **核心維度（已排除，勿放寬）**："
            + ", ".join(f"`{d}`" for d in sorted(core_dims & set(filters)))
            + " ← 即使移除後樣本數最多，也**不可**放寬（它們是本問題的語意主體）"
        )
    if self_selected_dims & set(filters):
        lines.append(
            "- **你先前自己選定的維度（請優先保留，先放寬其他維度）**："
            + ", ".join(f"`{d}`" for d in sorted(self_selected_dims & set(filters)))
            + " ← 這些是你在分析階段判斷與題意相關而加入的；移除它們等於放棄你自己的語意判斷"
        )
    lines.append("**請優先放寬倍率最高的非核心維度；若你放寬的不是倍率最高的維度，必須說明理由。**")
    return "\n".join(lines)


# #57: 必要性標記 —— 分析步驟 reasoning 以此宣告維度為必要時，該維度進入保護集
_NECESSITY_MARKERS = ("需使用", "必須使用", "需以", "需考量", "必須")

# #57: 可安全對「questions 原文」比對的 domain 關鍵字（無語意歧義者）。
# 其餘鍵（老闆/業主/企業主/創業/自營/攤商/加盟/小生意）**只認 LLM 判定的 domain**：
# 問「某店/某攤的目標客群」（顧客語意）也含「老闆」，誤比對會把 employment_status
# 保護/套用到不該套的題目（#34 的教訓）。
_QUERY_SAFE_DOMAIN_KEYS = {
    "債務", "貸款整合", "債務協商", "卡債",
    "醫美", "醫美診所", "整形", "皮膚科",
}


# #61: protect-only 語意對應 —— 命中時**只加入保護集**（#57 的 PROTECTED），
# **不修改 filters**（與 domain_filters 的「補 filter」語意分離 → 不改變既有篩選結果）。
# 由來：電動車/汽車 query 的 `commute_mode`（以汽車通勤）是購買動機維度，卻連續四輪
# （r6/r7/r8/r9 + v5.9 SOP）被放寬移除，而 #57 的四來源全數漏接（關鍵字表無此鍵、
# 分析與模型皆未宣告）。比對範圍限 domain（不做 query 原文比對：誤保護成本高於收益）。
PROTECT_ONLY_DOMAIN_DIMS = {
    "電動車": {"commute_mode"},
    "汽車": {"commute_mode"},
}


def _reasoning_protected_dims(reasoning: str, candidate_dims) -> set:
    """#57 ②: 從分析步驟的 reasoning 抽出「必要性宣告」所涵蓋的維度名。

    第九輪實測：5/5 進入放寬迴圈的案例，其 reasoning 都寫了必要性（例：「需使用 housing_burden、
    housing_cost、debt_status、family_income」），而後續放寬步驟把其中一個移除。

    保守原則：只認**含必要性標記的句子**，且只認**當前已在 filters 中的維度**（避免「提到即保護」造成過度限縮）。
    """
    if not reasoning:
        return set()
    cands = {str(d) for d in candidate_dims}
    out = set()
    for sentence in re.split(r"[。！？；\n]", reasoning):
        if not any(m in sentence for m in _NECESSITY_MARKERS):
            continue
        for d in cands:
            # 詞界比對：避免子字串碰撞（`income` 會命中 `family_income`、`region` 會命中 `city_income_region` 之類）
            if re.search(rf"(?<![a-z_]){re.escape(d)}(?![a-z_])", sentence):
                out.add(d)
    return out


def _normalize_filters(filters: dict, context: str = "") -> dict:
    """#62: 空值清單視為「未指定」→ 丟棄該維度。

    底層 `filter_personas` 對 `accepted == []` 的行為是**排除所有人**
    （`val not in []` 恆為真）—— 與字面直覺完全相反（實測：`age=[]`+income → 0 人；
    「不指定 age」→ 129 人）。因此**所有來自 LLM 的 filters 在套用前一律正規化**。
    """
    if not isinstance(filters, dict):
        return {}
    _dropped = sorted(k for k, v in filters.items() if isinstance(v, list) and len(v) == 0)
    _out = {k: v for k, v in filters.items()
            if not (isinstance(v, list) and len(v) == 0)}
    if _dropped:
        # #71 A：留痕刻意寫在**函式本體**（先前在呼叫點 → 只讀本體者誤以為「不留痕」，
        # 同一誤判在 round12/round13 被重複提出三次）。
        # #73：**唯一**輸出點 —— context（final／loop N）由呼叫端傳入，避免呼叫點各自重複 log。
        _ctx = f"（{context}）" if context else ""
        logger.info(f"Normalize filters (#62){_ctx}: 丟棄空值清單維度 {_dropped}")
    return _out


def _as_value_set(v) -> set:
    return set(v) if isinstance(v, list) else {v}


# #65: 主體判準（機械化）—— **只看題目原文**，不依賴 LLM 產生的字串。
# 動機：round 11 案例 08「小吃攤老闆的目標客群」（顧客語意）被誤判為攤商本人，
# 因為 domain 兜底表比對的是 LLM 產生的 `domain` 字串（該次吐「餐飲／夜市攤商經營」
# → 命中「攤商」→ 機械式套上 employment_status）。程式註解原本假設該題不會觸發 —— 假設被打破。
# 判準改為判「題目的標的」而不是「題目提到誰」。
_CUSTOMER_SUBJECT_RE = re.compile(
    # `X的<消費端名詞>` 或 直接出現<消費端名詞>（#67 A：不再要求業者詞，讓「咖啡廳的客群」等通用題也涵蓋）
    r"(?:[^\s，。；、]{2,10}的)?(目標客群|目標客戶|客群|客層|顧客|消費者|客戶群|來客)"
)
_OWNER_SUBJECT_RE = re.compile(
    r"(業主|老闆|企業主|雇主)[^。；;]{0,6}(本人|名單|受訪者|訪談)|B2B|b2b"
)

# #65: 該主體下**禁用**的維度（不得套用，也不得進保護集）
FORBIDDEN_BY_SUBJECT = {"customer": {"employment_status"}}

# #66 A: 來源④（模型每輪自我宣告）的累積上限
DECLARED_PROTECTED_MAX = 3


def _declared_cap(n_filter_dims: int) -> int:
    """#66 A: 模型宣告的保護維度上限 = max(1, min(3, 已套用維度數 // 2))。

    動機：來源④ 是單調累積且無上限 → 護欄會自己長大（醫美實測：保護集 1→5 個時
    `matched` 由 14 掉到 3、`returned < top_k`）。上限只約束 ④，①②③⑤ 不受影響。
    """
    return max(1, min(DECLARED_PROTECTED_MAX, max(1, int(n_filter_dims)) // 2))


def _subject_from_questions(q_list) -> str:
    """#65: 從題目原文機械判定主體 → 'customer' / 'owner' / ''（無法判定，不設限）。

    先判 customer（有消費端標的才是顧客語意），再判 owner。判的是**題目的標的**。
    """
    return _subject_detail(q_list)[0]


def _subject_detail(q_list) -> tuple:
    """#65 + #67 B: 回傳 `(subject, basis)`；`basis` 為命中的原文片段（供稽核／除錯）。

    **優先序（v5.13 #67 A 定案）**：
    ① **業主明確標記優先** —— 題目出現「業主／老闆本人」「名單／受訪者／訪談」「B2B」→ `owner`
       （避免「找業主本人回答其顧客問題」這類**同時含顧客詞**的題被誤判為 customer → 會誤擋 must-use）
    ② 否則出現消費端名詞（目標客群／顧客／消費者…，可帶 `X的` 前綴）→ `customer`
    ③ 否則 `""`（無法判定、不設限）
    """
    text = " ".join(str(x) for x in q_list) if isinstance(q_list, (list, tuple)) else str(q_list or "")
    if not text.strip():
        return ("", "")
    _m = _OWNER_SUBJECT_RE.search(text)          # ① 明確業主標記優先
    if _m:
        return ("owner", f"命中「{_m.group(0)}」（業主語意樣式）")
    _m = _CUSTOMER_SUBJECT_RE.search(text)       # ② 消費端名詞
    if _m:
        return ("customer", f"命中「{_m.group(0)}」（顧客語意樣式）")
    return ("", "")


def _widened_dims(prev_filters: dict, new_filters: dict) -> list:
    """#63(a): 值集被『放寬』（新值集為舊值集的**嚴格超集**）的維度。

    供稽核用（**不**併入 `relaxed_dims` —— 那會與 `protected_dims ∩ relaxed_dims = ∅` 不變式衝突）。
    """
    out = []
    for d in sorted(prev_filters):
        if d not in new_filters:
            continue
        if _as_value_set(prev_filters[d]) < _as_value_set(new_filters[d]):
            out.append(d)
    return out


def _vetoed_dims(protected: set, prev_filters: dict, new_filters: dict) -> list:
    """#57 ③: 受保護維度不得被**移除**，或其值集**不再是原值集的超集**（縮小／替換）→ 違規。

    **值集放寬（嚴格超集）＝合法**（v5.11.1 定案）：
    - v5.11 曾收緊為「雙向凍結」（放寬亦 veto），但實測顯示代價過高：
      醫美題保護集被模型的每輪宣告撐到 5 個維度後，放寬全被擋 → `matched` 由 14 掉到 3。
    - 因此回到 v5.9 的規則（移除／縮小才 veto），**值集放寬改由 `_widened_dims` 留痕**供稽核
      （此即 round 10 §6.3(1) 的原始建議：可觀測性，而非禁止）。
    """
    violated = []
    for d in sorted(protected):
        if d not in prev_filters:
            continue
        if d not in new_filters:
            violated.append(d)
            continue
        if not _as_value_set(prev_filters[d]) <= _as_value_set(new_filters[d]):
            violated.append(d)
    return violated


def _widened_deltas(prev_filters: dict, new_filters: dict) -> list:
    """#69: 值集放寬的**幅度**（舊值集 → 新值集）—— 供稽核「這一輪鬆了多少」。

    口徑與 `_widened_dims` 一致（嚴格超集）；未放寬的維度不列。
    例：`sex: ['女'] → ['女','男']` ⇒ `{"dim":"sex","before":["女"],"after":["女","男"],"added":["男"]}`
    """
    out = []
    for dim, nv in (new_filters or {}).items():
        pv = (prev_filters or {}).get(dim)
        if not isinstance(nv, list) or not isinstance(pv, list):
            continue
        ns, ps = set(nv), set(pv)
        if ps < ns:                      # 嚴格超集 = 放寬
            out.append({"dim": dim, "before": sorted(ps), "after": sorted(ns),
                        "added": sorted(ns - ps)})
    return sorted(out, key=lambda d: d["dim"])


# #70 A: 過衝回饋門檻 —— 移除維度後樣本數 ≥3× 代表「挑錯維度」（round13 案例 03：18→105 = 5.8×）
OVERSHOOT_RESTORE_RATIO = 3


def _llm_meta_brief() -> dict:
    """#72: 取 `llm.py` 的診斷摘要（`finish_reason`／截斷／`max_tokens`／錯誤）供失敗路徑記錄。

    round 14 §4.6(1)：`llm_parse_error` 路徑原本**完全不寫 log** → 維運無法得知型態
    （截斷 vs garbage），而這些診斷其實早已存在於 `_LAST_LLM_META`。
    """
    try:
        from .llm import _LAST_LLM_META as _m
    except Exception:
        return {}
    return {k: _m.get(k) for k in ("finish_reason", "truncated", "max_tokens", "model",
                                   "error", "error_type")
            if _m.get(k) is not None}


def _failed_attempt(loop: int, prev_filters: dict, matched_count: int, error_type: str) -> dict:
    """#72: 失敗輪的 attempt 記錄（與正常輪同形狀 ＋ `parse_error`／`error_type`）。

    目的：讓 `len(broadening_attempts)` == **實際 LLM 呼叫次數**（原本 break 在 append 之前
    → 回應的 loops 低估了呼叫次數與成本）。
    """
    return {
        "loop": loop, "change": f"LLM 回應無法使用（{error_type}）",
        "match_count_before": matched_count, "match_count_after": matched_count,
        "filters_changed": False, "no_op": True, "overshoot": False,
        "widened_dims": [], "widened_deltas": [],
        "overshoot_restore": False, "restored_dims": [],
        "parse_error": True, "error_type": error_type,
    }


def _is_overshoot(match_count: int, target_min: int = 20) -> bool:
    """#42: 放寬後樣本數遠超目標（> 2×TARGET_MIN）＝ 放寬過頭（例：債務整合 6 → 45）。"""
    return match_count > 2 * target_min


def _as_list(v) -> list:
    """#53: 多值維度（`hobby`）coerce —— 不假設型別（資料為 list，但容忍 str/None）。

    同族教訓見 issue #33 / #14：LLM 或資料衍生產物的型別不可信，一律 coerce。
    """
    if isinstance(v, list):
        return [str(x) for x in v if x not in (None, "")]
    if v in (None, ""):
        return []
    return [str(v)]


def _product_version() -> str:
    """#77: 產品版號的**單一來源**（容器內 `/app/VERSION`）。

    原本 `FastAPI(version="3.2.0")` 與 `/health` 的 `version="3.2"` 都是**寫死**值
    → Swagger 頁首顯示 3.2.0、與實際交付版號（v5.15）不一致（甲方可見的顯示層缺陷）。
    讀不到檔案時回 `"unknown"`（不假裝是某個版本）。
    """
    try:
        vf = Path(__file__).resolve().parent.parent / "VERSION"
        return vf.read_text().strip() or "unknown"
    except Exception:
        return "unknown"


_API_DESCRIPTION = """
台灣人口加權合成人設資料庫（**1069 位**）— 用自然語言描述目標族群，系統以 LLM 分析後篩選出對應的人設。

---

## ⏱ 最重要的一件事（第一次使用請先讀）

> **`GET /personadb/candidates` 這個呼叫要 1–5 分鐘才會回應** —— 系統要先做 LLM 分析，必要時最多再放寬 3 輪。
>
> 在 Swagger 上按 **「Execute」** 之後畫面會顯示 `Loading…`：**請不要關頁、不要重複按**。
> （**重按 = 重新計費一次分析**，而且結果可能不同。）
>
> 先想確認能不能動 → 用**單一題目 ＋ `top_k=5`** 試一次即可。

---

## 使用步驟（兩步）

**① 產出第一批人設** → `GET /personadb/candidates`

- `Try it out` → 填參數 → **Execute**（等 1–5 分鐘）
- 回應重點：
  - `summary[]` — **人設摘要表**（id／姓名／年齡／職業／所得／居住地…）
  - `persona_ids[]` — 符合條件的 ID 清單
  - `total_matched` — 符合條件的**總人數**；`returned` — 本次實際回傳數
  - `llm_analysis.reasoning` — **系統怎麼理解你的問題（建議先讀這段再往下用）**
  - `pool_exhausted` — 符合人數不足 `top_k`（**設計行為**，系統不硬湊）

**② 取完整人設** → `GET /personadb/detail?persona_id=TW-P-0234`

- 回傳 `dimensions`（全部維度）、`prompt_prefix`（**可直接餵 LLM 的人設敘述**）、`reference_pre_prompt`
- 此端點**不呼叫 LLM、毫秒級**，可放心逐一取用

---

## 參數速查（candidates）

| 參數 | 說明 |
|:--|:--|
| `questions` | 要找什麼族群；**多題用 `\|` 分隔**（例：`都會區上班族\|重視價格`） |
| `top_k` | 要回傳幾位人設，**1–100**（預設 20） |
| `opMode` | `僅篩選`（預設）／`篩選+模擬`／`模擬詢問` —— **只接受這三個值**，其他值回 400 |
| `role` | 詢問者角色（例：`房仲業者`），讓系統調整篩選方向；不需要就留空 |

---

## 常見狀況

- **`status=too_strict` 且 `total_matched=0`**：題目與系統推導出的條件**衝突或太窄**。
  系統**不會**為了湊數而放寬題目的核心條件 → 請**拆題或減少限定**（先讀 `llm_analysis.reasoning` 看系統套了哪些條件）
- **`returned < top_k`**：符合條件者不足（`pool_exhausted=true`）→ **正常設計**，非錯誤
- **`warnings` 出現「保護維度覆蓋 …」**：系統保護了題目的核心維度（例：醫美題保護「有醫美經驗」）→ 正常行為
- **想確認服務版本**：`GET /personadb/status`（本頁標題顯示的版本即現行版號）

> 免認證。完整操作說明另見交付文件 `docs/swagger-quickstart.md`。
"""


app = FastAPI(
    title="Persona DB API",
    description=_API_DESCRIPTION,        # v5.17：把操作重點寫進 /docs 頁面（甲方第一眼就看到）
    version=_product_version(),          # #77：讀 VERSION，不寫死
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {"name": "人設查詢", "description": "產出人設名單與取用完整人設內容"},
        {"name": "系統", "description": "健康檢查與服務狀態"},
    ],
)


# ── 統一錯誤回應（#47）─────────────────────────────────────────────
# 端點宣告 `responses={400/404/500/503: {"model": ErrorResponse}}`，但實作一律
# `raise HTTPException(code, detail=...)` → FastAPI 會包成 `{"detail": ...}`，
# 與宣告的 `ErrorResponse`（required `error`）不符 → 依 schema 寫的 client 取不到
# `error`。此 handler 一次把**所有**錯誤碼正規化成 `{"status":"error","error":{...}}`。

def _normalize_error_detail(detail, status_code: int) -> dict:
    """把 HTTPException.detail（dict 或 string）轉成 ErrorResponse.error 的形狀。"""
    if isinstance(detail, dict):
        err = {
            "code": str(detail.get("code", f"HTTP_{status_code}")),
            "message": str(detail.get("message", "")),
            "details": str(detail.get("details", "")),
        }
        # 保留額外欄位（例：retryable）
        for k, v in detail.items():
            if k not in ("code", "message", "details"):
                err[k] = v
        return err
    return {"code": f"HTTP_{status_code}", "message": str(detail), "details": ""}


@app.exception_handler(HTTPException)
async def _http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content=ErrorResponse(
            status="error", error=_normalize_error_detail(exc.detail, exc.status_code)
        ).model_dump(),
        headers=getattr(exc, "headers", None),
    )


@app.exception_handler(RequestValidationError)
async def _validation_exception_handler(request: Request, exc: RequestValidationError):
    """422 也統一形狀（狀態碼不變，維持 FastAPI 語意）。"""
    return JSONResponse(
        status_code=422,
        content=ErrorResponse(status="error", error={
            "code": "VALIDATION_ERROR",
            "message": "請求參數驗證失敗",
            "details": str(exc.errors())[:500],
        }).model_dump(),
    )

# ── Startup ────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    try:
        load_persona_db()
        db = load_persona_db()
        logger.info(f"Persona DB loaded: {len(db)} personas")
        app.state.db_loaded = True
        app.state.persona_count = len(db)
    except Exception as e:
        logger.error(f"Failed to load Persona DB: {e}")
        app.state.db_loaded = False
        app.state.persona_count = 0


# ── Health ─────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["系統"], summary="健康檢查（毫秒級）")
async def health():
    return HealthResponse(
        status="ok",
        version=_product_version(),      # #77：與 openapi／VERSION 同源
        persona_count=getattr(app.state, "persona_count", 0),
        db_loaded=getattr(app.state, "db_loaded", False),
    )


# ── Candidates (LLM-powered filter + optional simulate) ────────────

@app.get(
    "/personadb/candidates",
    response_model=CandidatesResponse,
    tags=["人設查詢"],
    summary="產出第一批人設（⏱ 需 1–5 分鐘，請耐心等待、不要重按）",
    responses={
        400: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
        503: {"model": ErrorResponse},
    }
)
async def personadb_candidates(
    questions: str = Query(..., description="要找什麼族群。多題用 | 分隔（例：都會區上班族|重視價格）"),
    top_k: int = Query(20, ge=1, le=100,
                       description="要回傳幾位人設（1–100）。注意：本呼叫需 1–5 分鐘才回應"),
    opMode: str = Query(default="僅篩選",
                        description="僅篩選（預設）／篩選+模擬／模擬詢問 —— 只接受這三個值，其他回 400"),
    role: str = Query(default="",
                      description="詢問者角色（例：房仲業者、銀行業者），讓系統調整篩選方向；不需要就留空"),
):
    """
    **產出第一批人設** —— 用自然語言描述目標族群，系統以 LLM 分析後篩選。

    > ## ⏱ 請先讀：這個呼叫要 **1–5 分鐘**
    > 系統要先做 LLM 分析，必要時最多再放寬 3 輪。
    > 按 **Execute** 後畫面顯示 `Loading…` 是正常的 —— **不要關頁、不要重複按**
    > （**重按 = 重新計費一次分析**，結果也可能不同）。

    **回應重點**

    - `summary[]`：人設摘要表（第一批人設）
    - `persona_ids[]`：符合條件的 ID 清單（可接著呼叫 `/personadb/detail`）
    - `total_matched`：符合條件的總人數｜`returned`：本次實際回傳數
    - `llm_analysis.reasoning`：**系統怎麼理解你的問題 —— 建議先讀這段**
    - `pool_exhausted=true`：符合人數不足 `top_k`（設計行為，系統不為湊數放寬核心條件）
    - `status=too_strict` 且 0 筆：題目與條件衝突／太窄 → 拆題或減少限定
    """
    # Validate
    if opMode not in ("僅篩選", "篩選+模擬", "模擬詢問"):
        raise HTTPException(status_code=400, detail={
            "code": "INVALID_OPMODE",
            "message": f"無效的 opMode: {opMode}",
            "details": "有效值: 僅篩選, 篩選+模擬, 模擬詢問",
        })
    if top_k > 100:
        raise HTTPException(status_code=400, detail={
            "code": "TOP_K_TOO_LARGE",
            "message": "top_k 最大為 100",
            "details": f"收到 top_k={top_k}",
        })
    if not getattr(app.state, "db_loaded", False):
        raise HTTPException(503, detail={
            "code": "DB_NOT_LOADED",
            "message": "Persona DB 尚未載入",
            "details": ""
        })
    
    # Parse questions (split by |)
    q_list = [q.strip() for q in questions.split("|") if q.strip()]
    if not q_list:
        raise HTTPException(400, detail={
            "code": "MISSING_PARAMETER",
            "message": "請提供至少一個問題",
            "details": "多個問題請用 | 分隔"
        })
    
    try:
        db = load_persona_db()
        
        # Step 1: LLM analyzes questions → dimension filters
        logger.info(f"LLM analyzing {len(q_list)} questions...")
        from .llm import build_distribution_summary
        data_overview = build_distribution_summary(db)
        llm_result = await parse_questions_with_llm(q_list, role=role or None, distribution=data_overview)
        
        llm_analysis = None
        if llm_result:
            llm_analysis = LLMAnalysis(
                domain=llm_result.get("domain", ""),
                reasoning=llm_result.get("reasoning", ""),
                question_analysis=llm_result.get("question_analysis", []),
                usage_suggestion=llm_result.get("usage_suggestion"),
            )
        
        # Step 2: Convert LLM output to filters
        filters = llm_filters_to_dimension_filters(llm_result) if llm_result else {}
        
        # Step 2b: Domain-aware filter reinforcement (issue #4 — LLM 常漏消費維度)
        # 依 LLM 判定的 domain，自動補上關鍵消費維度（確定性兜底，不依賴 LLM 自覺）
        domain = (llm_result or {}).get("domain", "")
        # #65: 主體判準 + 禁用維度（機械化，只看題目原文）；#67 B: 併記判定依據
        subject, subject_basis = _subject_detail(q_list)
        forbidden = set(FORBIDDEN_BY_SUBJECT.get(subject, set()))
        warnings_out: list = []
        if subject:
            logger.info(
                f"Subject gate (#65): subject={subject!r} forbidden={sorted(forbidden)} basis={subject_basis!r}"
            )
        domain_filters = {
            "時尚": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "服飾": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "美妝": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "運動": {"hobby": ["登山", "球類", "游泳", "廣場舞"]},
            "健身": {"hobby": ["登山", "球類", "游泳", "廣場舞"]},
            "跑鞋": {"hobby": ["登山", "球類", "游泳"], "clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "電動車": {"income": [">8萬", "3-8萬"]},
            "汽車": {"income": [">8萬", "3-8萬"]},
            "房產": {"housing_burden": ["中", "高"], "family_income": ["5-7萬", "7萬", ">8萬"]},
            "房貸": {"housing_burden": ["中", "高"], "family_income": ["5-7萬", "7萬", ">8萬"]},
            "旅遊": {"family_income": ["5-7萬", "7萬", ">8萬"]},
            "醫美": {"aesthetic_procedure": ["有"]},
            "醫美診所": {"aesthetic_procedure": ["有"]},
            "整形": {"aesthetic_procedure": ["有"]},
            "皮膚科": {"aesthetic_procedure": ["有"]},
            # ⚠️ #36: 「美容」不再對應 aesthetic_procedure —— 美容不等於醫美療程，
            #    且該維度 DB 覆蓋率僅 1.5%，誤套會把候選池限縮到 1 人（藥妝零售案例）。
            #    泛指美容/藥妝/零售的美妝消費請走 clothing_spend（見上方「美妝」）。
            "債務": {"debt_status": ["有信貸或卡債", "房貸+消費債"]},
            "貸款整合": {"debt_status": ["有信貸或卡債", "房貸+消費債"]},
            "債務協商": {"debt_status": ["有信貸或卡債", "房貸+消費債"]},
            "卡債": {"debt_status": ["有信貸或卡債", "房貸+消費債"]},
            "老闆": {"employment_status": ["雇主", "自營作業者"]},
            "業主": {"employment_status": ["雇主", "自營作業者"]},
            "企業主": {"employment_status": ["雇主"]},
            "創業": {"employment_status": ["雇主", "自營作業者"]},
            "自營": {"employment_status": ["自營作業者"]},
            "攤商": {"employment_status": ["自營作業者"]},
            "加盟": {"employment_status": ["雇主", "自營作業者"]},
            "小生意": {"employment_status": ["自營作業者"]},
            # 註（#34）：本表是 domain 標籤的關鍵字兜底，只在 LLM 判定的 domain 字串含
            # 該關鍵字時觸發（例：案例 08 domain=「餐飲/夜市商圈/市場研究」→ 全部不觸發）。
            # 主要機制是 QUESTION_ANALYSIS_PROMPT 的 must-use 指引；且問「某店/某攤的
            # 目標客群」（顧客）時不該套 employment_status（語意歧義，見 issue #34）。
        }
        reinforced = {}
        query_text = " ".join(q_list)
        for kw, add_filters in domain_filters.items():
            # #65: 顧客語意下，只會補上「禁用維度」的條目直接跳過
            _add = {d: v for d, v in add_filters.items() if d not in forbidden}
            if not _add:
                continue
            if kw in domain:
                reinforced.update(_add)
            elif kw in _QUERY_SAFE_DOMAIN_KEYS and kw in query_text:
                # #57 ①: 無歧義鍵也接受 questions 原文比對
                # （第九輪：query「債務整合的目標客戶」+ domain「金融/銀行/貸款」→ 原本零命中
                #  → 保護集空 → 放寬步驟把 debt_status 移除）
                reinforced.update(_add)
                logger.info(f"Domain reinforcement (query-text #{57}): 「{kw}」→ {_add}")
        if reinforced:
            for dim, vals in reinforced.items():
                if dim not in filters or not filters[dim]:
                    filters[dim] = vals
                    logger.info(f"Domain reinforcement ({domain}): added {dim}={vals}")
                # hobby: LLM 常用通用詞（如"運動"），但 DB 只有具體活動。
                # 若 hobby 已在 filters 但 DB 值可能不匹配，用 domain 值覆蓋
                elif dim == "hobby":
                    filters[dim] = vals
                    logger.info(f"Domain reinforcement ({domain}): replaced hobby with {vals}")
        
        # Fallback: if LLM returned no filters, use keyword-based parsing from questions text
        if not filters:
            from .persona_matcher import parse_enduser
            combined_text = " ".join(q_list)
            filters = parse_enduser(combined_text)
            logger.warning("LLM returned no filters, falling back to keyword parsing")

        
        # If still no filters, refuse to match everything (would return all 1069)
        # #59: 區分兩種型態 —— 「LLM 呼叫失敗」（查金鑰/連線）與「LLM 回應但產不出 filter」
        # （問題過於籠統 → 換問法；重試同一問題仍會失敗，故 retryable=False）
        if not filters:
            from .llm import last_analysis_status
            _st = (last_analysis_status() or {}).get("status") or ""
            _dt = (last_analysis_status() or {}).get("detail") or ""
            if _st == "call_failed":
                _msg = "LLM 呼叫失敗，無法分析問題"
                _det = f"請確認 LLM API key / model / 連線設定（{_dt or '詳見伺服器 log'}）"
                _retry = True
            else:  # no_filters（或未取得狀態）
                _msg = "問題過於籠統，LLM 無法產出篩選條件"
                _det = "請換更具體的問法（例：加上產業、目標族群或使用情境）；同一問題重試仍會失敗"
                _retry = False
            raise HTTPException(503, detail={
                "code": "FILTER_FAILED",
                "message": _msg,
                "details": _det,
                "retryable": _retry,
            })
        
        # #62: 套用前正規化（空值清單＝「未指定」，不得被當成「排除全部」的篩選條件）
        # #62/#73：正規化與留痕都在 `_normalize_filters()` 本體（呼叫點不再重複 log）
        filters = _normalize_filters(filters, context="final")

        # #65: 顧客語意 → 剝除禁用維度（**含 LLM 自己套的**）；forbidden > protected
        _stripped = sorted(set(filters) & forbidden)
        if _stripped:
            for _d in _stripped:
                filters.pop(_d, None)
            warnings_out.append(
                f"{', '.join(_stripped)} 已依「{subject}」語意剝除（禁用維度，issue #65）"
            )
            logger.warning(
                f"Subject gate (#65): subject={subject} → 剝除禁用維度 {_stripped}"
                f"（原套用來源可能是 LLM 自行判定或 domain 兜底）"
            )

        # #57: 核心維度保護集 —— **凍結於請求開始**（domain 強化 ∪ 分析必要性宣告）。
        # 第九輪的迴歸：保護集只靠 domain 關鍵字表 → 本題零命中 → 放寬步驟用 v5.8 提供的
        # 倍率資訊把 `debt_status`（分析步驟自己說必須用的維度）移除，且相鄰兩輪自我矛盾。
        _reason_text = getattr(llm_analysis, "reasoning", "") or ""
        reasoning_protected = _reasoning_protected_dims(
            _reason_text, set(filters.keys()) | set(reinforced.keys())
        )
        # #57 ④: 分析步驟的結構化宣告（`core_dims`）—— 不需文字解析、凍結於分析時，
        # 補上 ①② 的縫隙（第九輪 v5.9 e2e 實測：銀行房貸題的 reasoning 用「房貸持有/
        # 居住負擔」散文描述、未點出 dim 名，且 domain 關鍵字表不含 debt_status
        # → 模型便把 LLM 自己在 initial filters 套用的 debt_status 放寬掉）
        core_declared = set()
        if isinstance(llm_result, dict):
            _cd = llm_result.get("core_dims") or []
            if isinstance(_cd, list):
                core_declared = {str(d) for d in _cd if isinstance(d, str) and d}
        # #61: protect-only 語意對應（只保護、不補 filter）
        protect_only = set()
        for _kw, _dims in PROTECT_ONLY_DOMAIN_DIMS.items():
            if _kw in domain:
                protect_only |= set(_dims)
        protected_dims = (set(reinforced.keys()) | reasoning_protected | core_declared | protect_only) - forbidden
        if protected_dims:
            logger.info(
                f"Protected dims (#57): {sorted(protected_dims)} "
                f"(domain={sorted(reinforced.keys())}, reasoning={sorted(reasoning_protected)}, "
                f"analysis_declared={sorted(core_declared)}, protect_only={sorted(protect_only)})"
            )

        # Step 3: Filter personas
        matched = filter_personas(db, filters)
        
        # NOTE: scoring_basis 的建構移到 broadening loop 之後（見下方）—— #35：
        # dims_counted 必須反映 score_persona 的實際計分集合（含 relaxed dims；
        # relaxed dims 由 original_filters 計分），舊版在 loop 前用「當下 filters」
        # 推測會少列維度。
        
        # Step 3b: Filter relaxation — threshold-based (issue #4 v4.4.2)
        # Step 3b: Interactive broadening loop (replaces blind relaxation, issue #12)
        TARGET_MIN = 20
        original_filters = dict(filters)
        relaxed_dims = []
        broadening_attempts = []
        loop = 0
        max_loops = 3
        # D4: per-request token budget（analysis 1 次 + broadening ≤3 次）
        analysis_model = LLM_CONFIG.get("analysis_model") or None
        # pro model is reasoning-heavy: 2000 tokens gets eaten by reasoning
        # and content comes back empty → silent break (issue: 房仲 total=3)
        broaden_max_tokens = 8000 if analysis_model and "pro" in analysis_model.lower() else 2000
        TOKEN_BUDGET = 40000
        tokens_spent = 12000  # analysis call（pro = 12000，v5.8 起）
        # v5.8: TOKEN_BUDGET 由 32000 → 40000 —— 基礎預算提高後（8000 → 12000）若不同步
        # 提高上限，per-request 預算會讓「最多 3 輪放寬」**靜默降為 2 輪**
        # （12000 + 2×8000 = 28000 < 32000，第三輪需 36000 > 32000）。維持設計意圖
        # （analysis 1 次 + broadening ≤ 3 次 = 12000 + 3×8000 = 36000 ≤ 40000）。
        # #56 B: 連續 no_op 上限 —— 第八輪實測空轉率 60%（9/15），每次空轉都是完整 LLM
        # 呼叫。連續 2 輪無效即停（省下一次呼叫；代價是放棄「第 3 輪可能 +2」的小幅增益，
        # 已由 kstsai 2026-09-14 定案接受）。停止原因記於 `broadening_stop_reason`。
        consecutive_no_op = 0
        stop_reason = ""
        # #72: 實際 LLM 呼叫次數（分析 1 次 + 放寬嘗試 N 次；含失敗/空回應）→ 揭露用
        llm_calls = 1
        # #57 ③: 模型在放寬回應中自我宣告的保護維度（單調累積）
        declared_protected: set = set()
        # #66 A: 來源④ 的累積上限（以**請求開始**的已套用維度數為基準 → 凍結語意）
        _decl_cap = _declared_cap(len(filters))
        # #70 A: 來源⑥ —— 過衝還原的維度（移除後樣本數暴增 → 還原並保護，避免語意被沖淡）
        overshoot_restore_dims: set = set()

        def _all_protected() -> set:
            """保護集聯集（①②③⑤ ＋ ④模型宣告 ＋ ⑥過衝還原）—— 集中一處，避免漏加來源。"""
            return protected_dims | declared_protected | overshoot_restore_dims

        while (len(matched) < TARGET_MIN and loop < max_loops and filters
               and tokens_spent + broaden_max_tokens <= TOKEN_BUDGET):
            loop += 1
            # #66 C: 保護集覆蓋**全部**已套用維度 → 唯一合法的放寬是稀釋受保護維度的值集
            #         → 停手並以專屬原因標示（不靜默稀釋；與 #59「區分刻意拒絕與嘗試失敗」同精神）
            if not (set(filters) - _all_protected()):
                logger.info(
                    f"Broadening loop {loop}: 保護集覆蓋全部已套用維度 {sorted(set(filters))} "
                    f"→ stop=protection_saturated（#66 C）"
                )
                stop_reason = "protection_saturated"
                break
            logger.info(f"Broadening loop {loop}/{max_loops}: {len(matched)} matches < {TARGET_MIN}")
            from .llm import call_llm, BROADEN_PROMPT
            # #36 → #42: 稀有維度提示改為 rescue-only + 核心性排除（reinforced_dims）
            broaden_prompt = BROADEN_PROMPT.format(
                match_count=len(matched),
                target_min=TARGET_MIN,
                current_filters=json.dumps(filters, ensure_ascii=False, indent=2),
                rare_dims_hint=_rare_dims_hint(
                    db, filters,
                    reinforced_dims=set(reinforced.keys()),
                    matched_count=len(matched),
                ),
                constraint_hint=_constraint_hint(db, filters, len(matched),
                                                 core_dims=_all_protected(),
                                                 self_selected_dims=set(filters) - set(reinforced)),
            )
            prev_filters = dict(filters)
            result = await call_llm(broaden_prompt, temperature=0.2, max_tokens=broaden_max_tokens, model_override=analysis_model)
            tokens_spent += broaden_max_tokens
            llm_calls += 1
            if not result:
                # #72: 靜默失敗 → 可稽核事件（含 llm.py 的診斷 meta）＋ 記一筆失敗輪
                _meta = _llm_meta_brief()
                logger.warning(
                    f"Broadening loop {loop}: LLM 回應為空 → stop=llm_empty｜meta={_meta}"
                )
                broadening_attempts.append(_failed_attempt(loop, prev_filters, len(matched),
                                                            "empty_response"))
                stop_reason = "llm_empty"
                break
            try:
                result = result.strip()
                if "```json" in result:
                    result = result.split("```json")[1].split("```")[0].strip()
                elif "```" in result:
                    result = result.split("```")[1].split("```")[0].strip()
                new_data = json.loads(result)
                _nf_raw = new_data.get("filters", {}) or {}
                new_filters = _normalize_filters(_nf_raw, context=f"loop {loop}")   # #62/#73
                broadening = new_data.get("broadening", "unknown")
                # #57 ④ + #66 A: 模型自我宣告的保護維度（單調累積）—— **加上限**，
                #   避免護欄自己長大把整題的放寬空間鎖死（醫美實測：保護集 1→5 個時 matched 14→3）
                _declared = new_data.get("protected_dims") or []
                if isinstance(_declared, list):
                    _add = {str(d) for d in _declared if isinstance(d, str) and d}
                    _new = (_add - declared_protected) - forbidden
                    _used = len(declared_protected)          # 目前 ④ 已累積的數量
                    _room = _decl_cap - _used
                    if _new and _room > 0:
                        _accept = set(sorted(_new)[:_room])
                        declared_protected |= _accept
                        logger.info(
                            f"Broadening loop {loop}: 模型宣告保護維度 {sorted(_accept)}"
                            f"（④ 累積 {len(declared_protected)}/{_decl_cap}，上限 #66 A）"
                        )
                        if len(_accept) < len(_new):
                            warnings_out.append(
                                f"模型宣告的保護維度超過上限 {_decl_cap} → 僅接受 {sorted(_accept)}（#66 A）"
                            )
                    elif _new:
                        logger.info(
                            f"Broadening loop {loop}: 模型宣告 {sorted(_new)} 已達上限 "
                            f"{_decl_cap} → 忽略（#66 A）"
                        )
                        warnings_out.append(
                            f"模型宣告的保護維度已達上限 {_decl_cap} → 忽略 {sorted(_new)}（#66 A）"
                        )
            except Exception as _e:
                # #72（round14 §4.6(1)）：此路徑原本**完全不留痕**，且失敗輪未記入 attempts
                # （回應的 loops 因此低估實際呼叫次數）→ 兩者一併補上。
                _meta = _llm_meta_brief()
                logger.warning(
                    f"Broadening loop {loop}: LLM 回應無法解析（{type(_e).__name__}: {str(_e)[:120]}）"
                    f" → stop=llm_parse_error｜meta={_meta}"
                )
                broadening_attempts.append(_failed_attempt(loop, prev_filters, len(matched),
                                                            type(_e).__name__))
                stop_reason = "llm_parse_error"
                break
            if not new_filters:
                stop_reason = "llm_no_filters"
                break
            # #57 ③ + #63(b): 受保護維度雙向凍結（移除／縮小／放寬值集）→ 還原該輪並停止
            _violated = _vetoed_dims(_all_protected(), prev_filters, new_filters)
            if _violated:
                logger.warning(
                    f"Broadening loop {loop}: 受保護維度被變更 {_violated} → 還原該輪並停止（#57/#63）"
                )
                broadening_attempts.append({
                    "loop": loop, "change": broadening,
                    "match_count_before": len(matched), "match_count_after": len(matched),
                    "filters_changed": False, "no_op": True, "overshoot": False,
                    "protected_veto": True, "vetoed_dims": _violated,
                })
                stop_reason = "protected_veto"
                break
            # #25: 限制每 loop 最多移除 1 個維度（防止 overshoot：一次刪多維度 → total 暴增）
            removed_this_loop = [dim for dim in list(filters.keys()) if dim not in new_filters]
            if len(removed_this_loop) > 1:
                logger.info(f"Broadening loop {loop}: LLM 移除 {len(removed_this_loop)} 維度，cap 到 1（還原 {removed_this_loop[1:]}）")
                for dim in removed_this_loop[1:]:
                    new_filters[dim] = filters[dim]  # 還原多餘移除的維度（保留舊值）
                removed_this_loop = removed_this_loop[:1]
            relaxed_dims.extend(removed_this_loop)
            filters = new_filters
            prev_count = len(matched)
            matched = filter_personas(db, filters)
            # #37: no-op 偵測 —— filters 未變更（或變了但樣本數沒動）時再放寬只是白燒
            # 一次 pro call（8000 token），提前中止而不是耗掉剩餘迴圈額度
            filters_changed = (filters != prev_filters)
            no_op = (len(matched) == prev_count)
            # #42: overshoot 旗標 —— 放寬後樣本數遠超目標（> 2×TARGET_MIN）代表放寬過頭
            # （案例：債務整合第一次放寬 6 → 45）。只標記與記錄，不強制中斷（overshoot 時
            # `while len(matched) < TARGET_MIN` 本就會讓迴圈退出）。
            overshoot = _is_overshoot(len(matched), TARGET_MIN)
            # #63(a): 值集被「放寬」（嚴格超集）的維度 —— 稽核用（不併入 relaxed_dims）
            _widened = _widened_dims(prev_filters, filters)
            if _widened:
                logger.info(f"Broadening loop {loop}: 值集放寬 dims={_widened}（#63 留痕）")
            broadening_attempts.append({
                "loop": loop, "change": broadening,
                "match_count_before": prev_count, "match_count_after": len(matched),
                "filters_changed": filters_changed, "no_op": no_op, "overshoot": overshoot,
                "widened_dims": _widened,
                "widened_deltas": _widened_deltas(prev_filters, filters),   # #69 放寬幅度
                "overshoot_restore": False, "restored_dims": [],            # #70 A（若有還原會被更新）
            })
            if overshoot:
                logger.warning(
                    f"Broadening loop {loop}: overshoot —— {prev_count} → {len(matched)} "
                    f"（> 2×TARGET_MIN={2 * TARGET_MIN}），放寬可能過頭"
                )
            # #70 A: 過衝回饋 —— 移除維度後樣本數暴增（≥ ratio）代表**挑錯維度** →
            #   還原該輪被移除的維度、加入保護集（來源⑥）、揭露倍率。
            #   案例：round13 案例 03（時尚）移除模型自己選的 hobby → 18→105（5.8×），
            #   而 hobby=['逛街購物'] 對該題是高度相關維度 → 還原比給出 105 筆更正確。
            _restored = []
            # #70 B（2026-09-17，v5.18）：**觸發倍率必須在還原前量測** —— v5.14–v5.17 的 `_ratio`
            # 在還原**之後**才算 → 訊息把「還原後的 1.0×」寫成過衝倍率（實測真正觸發 10 → 51，
            # 卻顯示「10 → 10（過衝 1.0×）」）→ 數字無意義且誤導判讀。
            _overshoot_n = len(matched)
            _ratio = round(_overshoot_n / prev_count, 1) if prev_count else 0.0
            if (overshoot and removed_this_loop and prev_count > 0
                    and (len(matched) / prev_count) >= OVERSHOOT_RESTORE_RATIO):
                for _dim in removed_this_loop:
                    if _dim not in filters:
                        filters[_dim] = prev_filters.get(_dim)
                        _restored.append(_dim)
                if _restored:
                    relaxed_dims[:] = [d for d in relaxed_dims if d not in _restored]
                    matched = filter_personas(db, filters)
                    overshoot_restore_dims |= set(_restored)
                    # 還原後重新判定本輪是否等於沒動（供下方 no-op 分支使用）
                    filters_changed = (filters != prev_filters)
                    no_op = (len(matched) == prev_count)
                    broadening_attempts[-1].update({
                        "overshoot_restore": True,
                        "restored_dims": sorted(_restored),
                        "match_count_after": len(matched),
                        "overshoot_ratio": _ratio,          # v5.18：觸發倍率（還原前量測）
            })
                    _w70 = (f"移除 {sorted(_restored)} 導致樣本數 {prev_count} → {_overshoot_n}"
                            f"（{_ratio}× ≥ {OVERSHOOT_RESTORE_RATIO}×）→ "
                            f"已還原至 {len(matched)} 筆並將這些維度加入保護集（#70 A）")
                    warnings_out.append(_w70)
                    logger.warning(f"Broadening loop {loop}: {_w70}")
            if no_op and not filters_changed:
                # #59: 區分「刻意拒絕放寬核心維度」與「空轉」—— 模型若已宣告保護維度，
                # 這次不再變更屬它的判斷（守住核心），而非無效嘗試
                stop_reason = "protected_veto" if declared_protected else "no_op_limit"
                logger.info(
                    f"Broadening loop {loop}: filters 未變更 → 提前中止"
                    f"（{'模型宣告核心維度、拒絕放寬（#59）' if declared_protected else '空轉'}）"
                )
                break
            if no_op:
                consecutive_no_op += 1
                logger.info(
                    f"Broadening loop {loop}: filters 有變更但樣本數不變"
                    f"（{prev_count}→{len(matched)}，連續空轉 {consecutive_no_op}）"
                )
                if consecutive_no_op >= 2:
                    logger.info(
                        f"Broadening loop {loop}: 連續 {consecutive_no_op} 輪空轉 → 停止放寬"
                        f"（#56 B；節省後續 LLM 呼叫）"
                    )
                    stop_reason = "no_op_limit"
                    break
            else:
                consecutive_no_op = 0

        # #56 B: 停止原因（供呼叫端判讀「為何沒達到 TARGET_MIN」）
        if not stop_reason:
            if len(matched) >= TARGET_MIN:
                stop_reason = "target_reached"
            elif loop >= max_loops:
                stop_reason = "loop_limit"
            elif not filters:
                stop_reason = "no_filters"
            else:
                stop_reason = "budget_limit"

        # #66 A: 保護集來源拆解 + 覆蓋警示（回應層揭露；先前只存在於 log）
        _forbidden_now = forbidden
        protected_sources = {
            "domain": sorted(set(reinforced) - _forbidden_now),
            "reasoning": sorted(reasoning_protected - _forbidden_now),
            "analysis_declared": sorted(core_declared - _forbidden_now),
            "model_declared": sorted(declared_protected - _forbidden_now),
            "protect_only": sorted(protect_only - _forbidden_now),
            # #70 A: 來源⑥ —— 過衝還原而受保護的維度
            "overshoot_restore": sorted(overshoot_restore_dims - _forbidden_now),
        }
        _prot_all = _all_protected()
        _af_dims = set(filters)
        _prot_overlap = _af_dims & _prot_all
        if _af_dims and len(_prot_overlap) * 2 >= len(_af_dims):
            _w = (f"protected_dims 覆蓋 {len(_prot_overlap)}/{len(_af_dims)} 個已套用維度"
                  f"（{sorted(_prot_overlap)}）→ 放寬空間受限（#66 A）")
            if _w not in warnings_out:
                warnings_out.append(_w)
            logger.info(f"Protection coverage (#66 A): {_w}")

        # Scoring basis metadata (issue #4 — auditability; #35: dims_counted 由
        # score_persona 的實際計分集合產生，含 relaxed dims —— 它們由 original_filters
        # 以 tier_match 部分計分；不再用「filters ∩ dim_weights」推測而少列維度)
        scoring_basis = None
        try:
            from .persona_matcher import load_dim_weights, load_dim_weights_meta, scored_dims
            dim_weights = load_dim_weights()
            if dim_weights:
                scoring_basis = {
                    "method": "log-frequency × cross-dim normalized [0.5, 2.0]",
                    "weight_source": "DGBAS 113年 家庭收支調查 / 人力資源調查 / 交通部 2024",
                    # #44: 分數可溯性 —— 讓下游能偵測「權重表（= 分數尺度）換版」
                    "weight_version": load_dim_weights_meta().get("version"),
                    "score_scale": "relative-within-version",
                    "score_schema": 1,  # 分數定義版號；改 ranking 目標（如 #40 多樣性重排）時跳版
                    "dims_counted": scored_dims(
                        original_filters,
                        (llm_result or {}).get("dim_importance", {}),
                        relaxed_dims,
                        weights=dim_weights,
                    ),
                    "relaxed_dims_scored_at": None,  # Q3-A': relaxed dims not scored
                }
        except Exception as e:
            logger.warning(f"scoring_basis 建構失敗（不影響回應）: {e}")
            scoring_basis = None
        
        # #58: matched == 0 一律不得為 'ok'（原本 `too_strict` 需跑滿 3 輪 → 因 no_op_limit 在
        # 第 2 輪提早停止時，回傳 0 筆卻報 'ok'，只讀 status 的消費端會把「查無資料」當成功）
        status = "ok" if matched else "too_strict"
        
        if not matched:
            return CandidatesResponse(
                status=status,
                total_matched=0,
                persona_ids=[],
                returned=0,                    # #43
                pool_exhausted=(0 < top_k),    # #43: 池子比要求的小
                relaxed_dims=relaxed_dims,
                applied_filters=filters,
                broadening_attempts=broadening_attempts,
                broadening_stop_reason=stop_reason,   # #56 B
                protected_dims=sorted(_all_protected()),   # #57/#70
                subject=subject,            # #65
                subject_basis=subject_basis,          # #67 B
                warnings=warnings_out,      # #65/#66
                protected_dims_sources=protected_sources,   # #66 A/#70 A
                declared_protected_cap=_decl_cap,           # #71 B
                llm_calls=llm_calls,                        # #72
                llm_analysis=llm_analysis,
                scoring_basis=scoring_basis,
            )
        
        # Step 4: Relevance scoring + take top_k
        from .persona_matcher import sort_by_score, score_persona
        dim_importance = (llm_result or {}).get("dim_importance", {})
        matched = sort_by_score(matched, original_filters, dim_importance, relaxed_dims)
        top = matched[:top_k]
        
        # Build summary table (replaces full persona details)
        persona_ids = []
        summary = []
        
        for p in top:
            pid_str = p.get("id", "")
            try:
                pid_num = int(pid_str.split("-")[-1]) if "-" in pid_str else int(pid_str)
            except ValueError:
                pid_num = 0
            
            dims = p.get("dimensions", {})
            persona_ids.append(pid_num)
            summary.append(PersonaSummary(
                id=pid_str,
                name=p.get("name", ""),
                age=dims.get("age", ""),
                occupation=dims.get("occupation", ""),
                income=dims.get("income", ""),
                family_income=dims.get("family_income", ""),
                residence=dims.get("residence", ""),
                family_size=dims.get("family_size", ""),
                city_price_tier=dims.get("city_price_tier", ""),
                commute_mode=dims.get("commute_mode", ""),
                housing_cost=dims.get("housing_cost", ""),
                housing_burden=dims.get("housing_burden", ""),
                clothing_spend=dims.get("clothing_spend", ""),
                aesthetic_procedure=dims.get("aesthetic_procedure", ""),
                debt_status=dims.get("debt_status", ""),
                employment_status=dims.get("employment_status", ""),
                # #53: 補齊可篩維度（讓消費端能驗證 filter 生效）
                sex=dims.get("sex", ""),
                region=dims.get("region", ""),
                education=dims.get("education", ""),
                marriage=dims.get("marriage", ""),
                hobby=_as_list(dims.get("hobby")),      # 多值；coerce：list 原樣、str 包成 list
                politics=dims.get("politics", ""),
                media_diet=dims.get("media_diet", ""),
                score=score_persona(p, original_filters, dim_importance, relaxed_dims),
            ))
        
        # Step 5: Optional LLM simulation (populated in full detail)
        # Note: simulation is not included in summary table.
        # Use GET /personadb/detail?id=XXX for full persona detail. 
        if opMode == "篩選+模擬" and q_list:
            logger.info(f"Simulating {len(top)} personas with LLM...")
            for i, p in enumerate(top):
                sim = await simulate_with_llm(p, q_list)
                # Simulation is NOT included in summary table response.
                # Client can use /personadb/detail for full persona info.
                _ = sim  # consumed but not included in summary
        
        # Step 6: Important dimensions
        important_dims = get_important_dimensions(top)
        dim_summaries = [
            DimensionSummary(dim=d["dim"], values=d["values"])
            for d in important_dims
        ]
        
        return CandidatesResponse(
            status=status,
            total_matched=len(matched),
            persona_ids=persona_ids,
            summary=summary,
            returned=len(summary),                     # #43
            pool_exhausted=(len(matched) < top_k),     # #43: 池子比要求的小
            important_dimensions=dim_summaries,
            llm_analysis=llm_analysis,
            relaxed_dims=relaxed_dims,
            applied_filters=filters,
            broadening_attempts=broadening_attempts,
            broadening_stop_reason=stop_reason,        # #56 B
            protected_dims=sorted(_all_protected()),   # #57/#70
            subject=subject,            # #65
            subject_basis=subject_basis,          # #67 B
            warnings=warnings_out,      # #65/#66
            protected_dims_sources=protected_sources,   # #66 A/#70 A
            declared_protected_cap=_decl_cap,           # #71 B
            llm_calls=llm_calls,                        # #72
            scoring_basis=scoring_basis,
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Candidates endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Detail ─────────────────────────────────────────────────────────

@app.get(
    "/personadb/detail",
    response_model=DetailResponse,
    tags=["人設查詢"],
    summary="取單一人設的完整內容（毫秒級；不呼叫 LLM）",
    responses={
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    }
)
async def personadb_detail(
    persona_id: str = Query(..., description="Persona ID（TW-P-0234 這種格式，或純數字）")
):
    """
    **取完整人設內容** —— `persona_id` 取自 `candidates` 的 `summary[].id` 或 `persona_ids[]`。

    回應 `persona` 內含：

    - `dimensions`：全部維度（年齡／性別／地區／教育／職業／所得／家庭／消費… 共 20+ 項）
    - `name`／`type`：姓名／類型（虛構人設）
    - `prompt_prefix`：**可直接餵給 LLM 的人設敘述**（一段文字）
    - `reference_pre_prompt`：條列式輪廓（`年齡/地區/性別/婚姻/職業/…`）

    > 本端點**不呼叫 LLM、回應在毫秒級**，可放心對每個 ID 逐一取用。
    """
    try:
        p = get_persona_by_id(persona_id)
        if p is None:
            raise HTTPException(404, detail={
                "code": "PERSONA_NOT_FOUND",
                "message": f"Persona ID '{persona_id}' 不存在",
                "details": "有效範圍: TW-P-0001 ~ TW-P-1069"
            })
        
        return DetailResponse(
            status="ok",
            persona=PersonaDetail(
                id=p.get("id", ""),
                name=p.get("name", ""),
                type=p.get("type", "虛構人設"),
                dimensions=p.get("dimensions", {}),
                prompt_prefix=p.get("prompt_prefix", ""),
                reference_pre_prompt=p.get("reference_pre_prompt", ""),
            )
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Detail endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Status ────────────────────────────────────────────────────────

@app.get("/personadb/status", tags=["系統"], summary="服務狀態（含現行版本、人設筆數、LLM 可用性）")
async def persona_db_status():
    """
    Return persona-db status as raw text (like `hermes chat 'persona-db status'`).
    No parameters needed.
    """
    try:
        lines = []
        def L(s): lines.append(s)
        
        # Version（#77：與 openapi／health 共用同一 helper）
        version = _product_version()
        
        # Persona count
        db = load_persona_db()
        p_count = len(db)
        json_size = "N/A"
        json_path = Path(__file__).resolve().parent.parent / "tw_persona_1069.json"
        if json_path.exists():
            sz = json_path.stat().st_size
            json_size = f"{sz/1024/1024:.2f} MB" if sz > 1024*1024 else f"{sz/1024:.1f} KB"
        
        # Backup
        backup_path = json_path.parent / "tw_persona_1069_backup.json"
        backup_ok = backup_path.exists()
        
        # Name diversity
        names = set(p.get("name", "") for p in db)
        name_count = len(names)
        name_pct = round(name_count / p_count * 100, 1)
        from collections import Counter
        name_repeats = Counter(p.get("name", "") for p in db)
        max_repeat = max(name_repeats.values()) if name_repeats else 0
        
        # Python
        py_ver = sys.version.split()[0]
        
        # LLM status
        llm_status = "⛔ Not configured"
        if LLM_CONFIG.get("api_key"):
            llm_status = f"✅ {LLM_CONFIG.get('model', '?')} → {LLM_CONFIG.get('base_url', '?')}"
            # Live LLM test
            try:
                resp = await call_llm("回應「ok」就好", max_tokens=50)
                if resp is not None:
                    llm_status += " (responsive)"
                else:
                    llm_status += " (no response)"
            except Exception as e:
                llm_status += f" (error: {str(e)[:100]})"
        else:
            llm_status = "⛔ No API key configured"
        
        # Git
        git_info = "not a repo (filesystem boundary)"
        git_dir = Path(__file__).resolve().parent.parent / ".git"
        if git_dir.exists():
            try:
                import subprocess
                r = subprocess.run(["git", "log", "--oneline", "-1"], capture_output=True, text=True, cwd=str(git_dir.parent))
                if r.returncode == 0:
                    git_info = r.stdout.strip()
            except: pass
        
        # Hermes skills count (from mounted config volume or local)
        hermes_skills = "N/A"
        persona_skills = "N/A"
        for skills_candidate in ["/hermes-config/skills", str(Path.home() / ".hermes/skills")]:
            skills_path = Path(skills_candidate)
            if skills_path.exists() and skills_path.is_dir():
                try:
                    skill_files = list(skills_path.rglob("SKILL.md"))
                    hermes_skills = str(len(skill_files))
                    ps = [s for s in skill_files if "persona" in s.name.lower() or "persona" in str(s.parent).lower()]
                    persona_skills = str(len(ps))
                    break
                except Exception:
                    continue
        
        # QA
        qa_lines = []
        try:
            qa_script = Path(__file__).resolve().parent.parent / "qa_validate.py"
            if qa_script.exists():
                import subprocess
                r = subprocess.run([sys.executable, str(qa_script)], capture_output=True, text=True, cwd=str(qa_script.parent), timeout=30)
                if r.returncode == 0:
                    qa_lines = r.stdout.splitlines()[-6:]
                else:
                    qa_lines = ["❌ QA FAILED"]
        except subprocess.TimeoutExpired:
            qa_lines = ["⏱️ QA timeout"]
        except Exception as e:
            qa_lines = [f"❌ QA error: {e}"]
        
        # File artifacts
        tools_dir = Path(__file__).resolve().parent.parent
        py_files = list(tools_dir.glob("*.py")) + list(tools_dir.glob("api/*.py"))
        
        # ── Build output ──
        L(f"Persona DB Status")
        L(f"{'='*50}")
        L(f"")
        L(f"  Version         {version}")
        L(f"  Main personas   {p_count} (tw_persona_1069.json, {json_size})")
        L(f"  Backup          {'✅' if backup_ok else '❌'} {p_count} (tw_persona_1069_backup.json)")
        L(f"  QA (23 rules)   {'✅ ALL CHECKS PASSED' if qa_lines and 'PASSED' in qa_lines[-1] else '⏳ check below'}")
        L(f"  Name diversity  {name_count} unique names ({name_pct}%), max repeat {max_repeat}×")
        L(f"  Python          {py_ver}")
        L(f"  Git             {git_info}")
        L(f"  LLM             {llm_status}")
        L(f"  Hermes Skills   {hermes_skills} total, {persona_skills} persona-related")
        L(f"")
        L(f"  📁 Supporting Artifices: {len(py_files)} Python files")
        L(f"")
        if qa_lines:
            L(f"  QA Results:")
            for ql in qa_lines:
                if ql.strip():
                    L(f"    {ql.strip()}")
        
        return PlainTextResponse("\n".join(lines))
    
    except Exception as e:
        logger.exception("Status endpoint error")
        return PlainTextResponse(f"Error: {str(e)}", status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.server:app", host="0.0.0.0", port=8000, reload=True)
