# Persona DB v5.17 Release Notes

> 日期: 2026-09-17 | 上一版: v5.16 | 類型: **API 文件內建操作重點（甲方在 `/docs` 第一眼看到）**
> 來源: kstsai 指示 —— 把 `docs/swagger-quickstart.md` 的重點放進 `:8000/docs` 頁面並強調

## 變更（純文件內容，無行為變更）

| 位置 | 內容 |
|:--|:--|
| **頁首說明**（`info.description`） | 服務一句話簡介 ＋ **⏱ 最重要的一件事**（`/personadb/candidates` 需 **1–5 分鐘**；按 Execute 後 `Loading…` 時**不要關頁、不要重複按**（重按＝重新計費））＋ 兩步驟操作指引 ＋ 參數速查表 ＋ 常見狀況（`too_strict`／`returned < top_k`／`warnings` 保護維度／版本查詢） |
| `GET /personadb/candidates` | `summary` 帶 ⏱ 與時間；`description` 首段即為時間警告 ＋ 回應欄位重點（`summary[]`／`persona_ids[]`／`llm_analysis.reasoning`） |
| `GET /personadb/detail` | `summary` 標明「毫秒級；不呼叫 LLM」；`description` 說明 `prompt_prefix` 可直接餵 LLM |
| 參數說明 | `questions`（多題 `|` 分隔）、`top_k`（1–100＋時間提醒）、`opMode`（只接受三值）、`role`（可留空） |
| 端點分組 | `tags`：**人設查詢**（candidates／detail）／**系統**（health／status），附 tag 說明 |

## 相容性

- 無 API 行為／參數／回應結構變更（僅 OpenAPI 文件欄位內容）
- 客戶端若解析 `info.description` 做展示，內容會變長（已知）

## 驗證

- **單元**：`test_v5_17_fixes.py` —— 直接驗 **OpenAPI 輸出**（＝Swagger UI 渲染來源）：頁首含 ⏱ 警告／不要重複按／too_strict／reasoning；candidates 的 summary 與 description；四個參數說明要點；detail 說明；tags；版本單一來源（#77）不退化
- **出貨斷言新增**：從部署中的 `/openapi.json` 檢查 4 個關鍵字（⏱ 警告／不要重複按／summary 帶 ⏱／detail 說明 `prompt_prefix`）→ 確認**文件真的隨映像部署**
- **SOP（nodeB）**：fresh deploy → 全部斷言；0 紅旗
