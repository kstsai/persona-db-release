#!/usr/bin/env python3
"""Deep-dive into income cross-check violations from validate_income_restructure.py.

Analyzes:
  - family_income=3-5萬 + personal=>8萬: by occupation, family_size, education, age
  - family_income=1-3萬 + personal=>8萬: full detail on each violator
  - Single-person households (fs=1) with personal=>8萬 but family_income < 7萬
  - 家管/退休 occupations with >8萬 personal income (logically inconsistent)
  - Reverse: all >8萬 earners → family_income distribution

Usage:
  python3 ../.hermes/skills/research/tw-persona-db/scripts/deep_dive_income_violations.py
"""
import json, random
from collections import Counter

with open("tw_persona_1069.json") as f:
    personas = json.load(f)

def deep_dive_35():
    """family_income=3-5萬 + personal=>8萬"""
    v = [p for p in personas if p["dimensions"]["family_income"] == "3-5萬" and p["dimensions"]["income"] == ">8萬"]
    print(f"Total: {len(v)}")
    occ = Counter(p["dimensions"]["occupation"] for p in v)
    fs = Counter(p["dimensions"]["family_size"] for p in v)
    edu = Counter(p["dimensions"]["education"] for p in v)
    age = Counter(p["dimensions"]["age"] for p in v)
    print(f"By occupation: {dict(occ.most_common())}")
    print(f"By family_size: {dict(sorted(fs.items(), key=lambda x: int(x[0].replace('+','6'))))}")
    print(f"By education: {dict(edu.most_common())}")
    print(f"By age: {dict(age.most_common())}")

    # Severity breakdown
    singles = [p for p in v if p["dimensions"]["family_size"] == "1"]
    homemakers = [p for p in v if p["dimensions"]["occupation"] == "家管"]
    retired = [p for p in v if p["dimensions"]["occupation"] == "退休"]
    print(f"\n🔴 fs=1 (IMPOSSIBLE): {len(singles)}")
    print(f"🔴 家管 (occ-income mismatch): {len(homemakers)}")
    print(f"🟠 退休 (occ-income mismatch): {len(retired)}")
    print(f"🟡 fs≥2 (possibly equivalised): {len(v) - len(singles) - len(homemakers) - len(retired)}")

def deep_dive_13():
    """family_income=1-3萬 or <1萬 + personal=>8萬"""
    v = [p for p in personas if p["dimensions"]["family_income"] in ("<1萬", "1-3萬") and p["dimensions"]["income"] == ">8萬"]
    print(f"Total: {len(v)}")
    for p in v:
        d = p["dimensions"]
        print(f"  {p['id']} {p['name']}: age={d['age']}, occ={d['occupation']}, edu={d['education']}")
        print(f"    fam_size={d['family_size']}, marriage={d['marriage']}, region={d['region']}")
        print(f"    BG: {d['background_story']}")

def deep_dive_single_person():
    """Single-person households: personal=>8萬 but family_income<7萬"""
    v = [p for p in personas if p["dimensions"]["family_size"] == "1" and p["dimensions"]["income"] == ">8萬" and p["dimensions"]["family_income"] not in ("7萬", ">8萬")]
    print(f"fs=1 + pers=>8万 + fam_inc<7万: {len(v)}")
    for p in v:
        d = p["dimensions"]
        print(f"  ❌ {p['id']}: fam_inc={d['family_income']}, occ={d['occupation']}")
    if not v:
        print("  ✅ None found")

def high_earners_reverse():
    """All >8萬 earners → family_income distribution"""
    v = [p for p in personas if p["dimensions"]["income"] == ">8萬"]
    print(f"Total >8萬 earners: {len(v)}")
    fi = Counter(p["dimensions"]["family_income"] for p in v)
    occ = Counter(p["dimensions"]["occupation"] for p in v)
    print(f"By family_income: {dict(fi.most_common())}")
    print(f"By occupation: {dict(occ.most_common())}")

if __name__ == "__main__":
    print("=" * 60)
    print("DEEP DIVE: 3-5萬 + >8萬 personal")
    print("=" * 60)
    deep_dive_35()

    print("\n" + "=" * 60)
    print("DEEP DIVE: 1-3萬 + >8萬 personal")
    print("=" * 60)
    deep_dive_13()

    print("\n" + "=" * 60)
    print("DEEP DIVE: Single-person + pers=>8万 + fam<7万")
    print("=" * 60)
    deep_dive_single_person()

    print("\n" + "=" * 60)
    print("REVERSE: All >8万 earners → family_income")
    print("=" * 60)
    high_earners_reverse()
