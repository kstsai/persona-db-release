#!/usr/bin/env python3
"""Post-generation sanity checks — run after each `python3 _generate_997.py`.

Usage:
    python3 scripts/post_gen_checks.py [--json tw_persona_1069.json]
    
Exit 0 = all checks pass. Exits with first failure.
Checks are deterministic — no API calls, no LLM.
"""

import json, sys, os
from collections import Counter

def main():
    path = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] != '--json' else "tw_persona_1069.json"
    if len(sys.argv) > 2:
        path = sys.argv[2]
    
    data = json.load(open(path))
    t = len(data)
    errors = []
    
    # 1. QA validate
    import subprocess
    r = subprocess.run([sys.executable, "qa_validate.py"], capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        errors.append(f"QA FAILED (exit {r.returncode}): {r.stdout[-200:]}")
    
    # 2. No legacy 百萬 values
    fi_all = [p['dimensions']['family_income'] for p in data]
    if any(v == '百萬' for v in fi_all):
        errors.append("LEGACY: 百萬 found in family_income")
    
    # 3. All tiers present (no missing keys)
    expected_tiers = {'<1萬','1-3萬','3-5萬','5-7萬','7萬','>8萬'}
    actual_tiers = set(fi_all)
    missing = expected_tiers - actual_tiers
    if missing:
        errors.append(f"Missing family_income tiers: {missing}")
    
    # 4. No duplicate 老伴走了
    bgs = [p['dimensions']['background_story'] for p in data]
    dupes = sum(1 for bg in bgs if bg.count('老伴走了') > 1)
    if dupes > 0:
        errors.append(f"{dupes} personas with duplicate '老伴走了'")
    
    # 5. Unemployed rate in expected range (1-3%)
    occ = Counter(p['dimensions']['occupation'] for p in data)
    ue = occ.get('失業', 0)
    if not (0.008 <= ue/t <= 0.035):
        errors.append(f"Unemployed rate {ue/t*100:.1f}% out of range [0.8%, 3.5%]")
    
    # 6. Income vs occupation sanity: 失業 should not have >8萬
    for p in data:
        d = p['dimensions']
        if d['occupation'] == '失業' and d['income'] == '>8萬':
            errors.append(f"{p['id']} {p['name']}: 失業 with income >8萬")
    
    # 7. 22 cities covered
    cities = set(p['dimensions']['residence'] for p in data)
    if len(cities) < 22:
        errors.append(f"Only {len(cities)}/22 cities covered")
    
    # 8. Distribution drift: no dramatic shifts from expected
    fi_counts = Counter(fi_all)
    expected_ranges = {
        '<1萬': (0.01, 0.03), '1-3萬': (0.10, 0.18),
        '3-5萬': (0.40, 0.60), '5-7萬': (0.12, 0.25),
        '7萬': (0.06, 0.14), '>8萬': (0.02, 0.06),
    }
    for tier, (lo, hi) in expected_ranges.items():
        rat = fi_counts.get(tier, 0) / t
        if not (lo <= rat <= hi):
            errors.append(f"family_income={tier}: {rat*100:.1f}% out of range [{lo*100:.0f}%, {hi*100:.0f}%]")
    
    if errors:
        print("❌ Post-gen checks FAILED:")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    else:
        print(f"✅ Post-gen checks passed ({t} personas, {len(cities)} cities)")
        sys.exit(0)

if __name__ == '__main__':
    main()
