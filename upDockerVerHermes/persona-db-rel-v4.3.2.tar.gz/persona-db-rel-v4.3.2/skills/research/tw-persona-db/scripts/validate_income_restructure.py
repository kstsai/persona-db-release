#!/usr/bin/env python3
"""Comprehensive validation of family_income restructuring in tw_persona_1069.json.

Checks:
  2. All 6 family_income tiers present and counted
  3. Cross-check: family_income vs personal_income (3-5萬+>8萬, 5-7萬+>8萬)
  4. Low family_income (<1萬, 1-3萬) with high personal_income (>8萬)
  5. 無收入 distribution across family_income tiers
  6. Spot-check 10 random personas for internal consistency
  7. High-end family_income (7萬, >8萬) demographics plausibility
  8. 3-5萬 vs 5-7萬 distribution across occupations
  Bonus: Personal income distribution + family×personal cross-tab

Usage:
  cd ~/persona-db && python3 ../.hermes/skills/research/tw-persona-db/scripts/validate_income_restructure.py
"""
import json
import random
from collections import Counter, defaultdict

with open("tw_persona_1069.json") as f:
    personas = json.load(f)

print(f"📊 Total personas: {len(personas)}")
print()

# ── CHECK 2: Family income tier distribution ──
print("=" * 60)
print("CHECK 2: Family income tier distribution")
print("=" * 60)

expected_tiers = ["<1萬", "1-3萬", "3-5萬", "5-7萬", "7萬", ">8萬"]
finc_counts = Counter(p["dimensions"]["family_income"] for p in personas)

all_present = True
for tier in expected_tiers:
    count = finc_counts.get(tier, 0)
    flag = "✅" if count > 0 else "❌ MISSING"
    if count == 0:
        all_present = False
    print(f"  {flag} {tier}: {count} ({count/len(personas)*100:.1f}%)")

unexpected = set(finc_counts.keys()) - set(expected_tiers)
if unexpected:
    print(f"  ⚠️  UNEXPECTED tiers: {unexpected}")
    all_present = False

print(f"\n  ➤ RESULT: {'PASS' if all_present else 'FAIL'}")
print()

# ── CHECK 3: Cross-check family_income vs personal income ──
print("=" * 60)
print("CHECK 3: family_income vs personal income cross-check")
print("=" * 60)

violations_3, violations_5 = [], []
for p in personas:
    fi = p["dimensions"]["family_income"]
    pi = p["dimensions"]["income"]
    pid = p["id"]
    if fi == "3-5萬" and pi == ">8萬":
        violations_3.append((pid, p["dimensions"]["occupation"], fi, pi))
    if fi == "5-7萬" and pi == ">8萬":
        violations_5.append((pid, p["dimensions"]["occupation"], fi, pi))

print(f"  family_income=3-5萬 + personal_income=>8萬: {len(violations_3)} violations")
if violations_3:
    print(f"    ❌ VIOLATIONS (first 10):")
    for v in violations_3[:10]:
        print(f"      {v[0]}: occupation={v[1]}")
else:
    print(f"    ✅ None found")

print(f"  family_income=5-7萬 + personal_income=>8萬: {len(violations_5)} violations")
if violations_5:
    print(f"    ⚠️  VIOLATIONS (may be plausible):")
    for v in violations_5:
        print(f"      {v[0]}: occupation={v[1]}")
else:
    print(f"    ✅ None found")

check3_pass = len(violations_3) == 0
print(f"\n  ➤ RESULT: {'PASS' if check3_pass else 'FAIL'}")
print()

# ── CHECK 4: Low family_income + high personal income ──
print("=" * 60)
print("CHECK 4: Low family_income + high personal_income conflicts")
print("=" * 60)

violations_4 = []
for p in personas:
    fi = p["dimensions"]["family_income"]
    pi = p["dimensions"]["income"]
    if fi in ("<1萬", "1-3萬") and pi == ">8萬":
        violations_4.append((p["id"], p["dimensions"]["occupation"], fi, pi, p["dimensions"]["family_size"]))

print(f"  family_income=<1萬 or 1-3萬 + personal_income=>8萬: {len(violations_4)} violations")
if violations_4:
    for v in violations_4:
        print(f"    ❌ {v[0]}: occ={v[1]}, fam_inc={v[2]}, pers_inc={v[3]}, fs={v[4]}")
else:
    print(f"    ✅ None found")

check4_pass = len(violations_4) == 0
print(f"\n  ➤ RESULT: {'PASS' if check4_pass else 'FAIL'}")
print()

# ── CHECK 5: 無收入 distribution ──
print("=" * 60)
print("CHECK 5: 無收入 distribution across family_income tiers")
print("=" * 60)

no_income_personas = [p for p in personas if p["dimensions"]["income"] == "無收入"]
print(f"  Total 無收入 personas: {len(no_income_personas)}")

no_income_by_finc = Counter(p["dimensions"]["family_income"] for p in no_income_personas)
for tier in expected_tiers:
    count = no_income_by_finc.get(tier, 0)
    pct = count/len(no_income_personas)*100 if no_income_personas else 0
    print(f"    {tier}: {count} ({pct:.1f}%)")

max_count = max(no_income_by_finc.values()) if no_income_by_finc else 0
max_tier = max(no_income_by_finc, key=lambda k: no_income_by_finc[k]) if no_income_by_finc else "N/A"
max_pct = max_count / len(no_income_personas) * 100 if no_income_personas else 0
print(f"\n  Highest concentration: {max_tier} ({max_pct:.1f}%)")
check5_pass = max_pct < 60
print(f"  ➤ RESULT: {'PASS' if check5_pass else 'FAIL'} (threshold: <60% in any single tier)")
print()

# ── CHECK 6: Spot-check ──
print("=" * 60)
print("CHECK 6: Spot-check random personas for internal consistency")
print("=" * 60)

random.seed(99)
for i, idx in enumerate(sorted(random.sample(range(len(personas)), 10))):
    p = personas[idx]
    d = p["dimensions"]
    print(f"\n  --- Persona {i+1}: {p['id']} ({p['name']}) ---")
    print(f"  Age: {d['age']}, Sex: {d['sex']}, Occ: {d['occupation']}")
    print(f"  Income: {d['income']}, Fam_inc: {d['family_income']}, Fam_size: {d['family_size']}")
    print(f"  BG: {d['background_story'][:200]}")
    issues = []
    if d['age'] == '0-11' and d['income'] not in ('無收入',):
        issues.append("Child with income")
    if d['occupation'] in ('學生',) and d.get('marriage') not in ('未婚',):
        issues.append("Student not 未婚")
    if d['income'] == '>8萬' and d['occupation'] in ('學生', '無業/待業', '退休'):
        issues.append("Non-working with high income")
    if issues:
        for issue in issues:
            print(f"  ⚠️  {issue}")
    else:
        print(f"  ✅ No obvious issues")
print()

# ── CHECK 7: High-end plausibility ──
print("=" * 60)
print("CHECK 7: High-end family_income (7萬, >8萬) demographics")
print("=" * 60)

high_end = [p for p in personas if p["dimensions"]["family_income"] in ("7萬", ">8萬")]
print(f"  7萬 or >8萬 personas: {len(high_end)} ({len(high_end)/len(personas)*100:.1f}%)")
for tier in ("7萬", ">8萬"):
    subset = [p for p in high_end if p["dimensions"]["family_income"] == tier]
    print(f"\n  ── {tier} ({len(subset)} personas) ──")
    occ_dist = Counter(p["dimensions"]["occupation"] for p in subset)
    print(f"  Top occupations: {occ_dist.most_common(5)}")
print()

# ── CHECK 8: 3-5萬 vs 5-7萬 by occupation ──
print("=" * 60)
print("CHECK 8: 3-5萬 vs 5-7萬 tiers across occupations")
print("=" * 60)

mid_tiers = [p for p in personas if p["dimensions"]["family_income"] in ("3-5萬", "5-7萬")]
occ_by_tier = defaultdict(lambda: Counter())
for p in mid_tiers:
    occ_by_tier[p["dimensions"]["family_income"]][p["dimensions"]["occupation"]] += 1

all_occs = set()
for td in occ_by_tier.values():
    all_occs.update(td.keys())

print(f"  {'Occupation':<20} {'3-5萬':>8} {'5-7萬':>8} {'Ratio':>8}")
print(f"  {'-'*20} {'-'*8} {'-'*8} {'-'*8}")
for occ in sorted(all_occs):
    c35 = occ_by_tier["3-5萬"].get(occ, 0)
    c57 = occ_by_tier["5-7萬"].get(occ, 0)
    ratio = f"{c35/c57:.2f}" if c57 > 0 else "N/A"
    print(f"  {occ:<20} {c35:>8} {c57:>8} {ratio:>8}")
print()

# ── FINAL SUMMARY ──
print("=" * 60)
print("FINAL SUMMARY")
print("=" * 60)
checks = {
    "Check 2 (All 6 tiers)": all_present,
    "Check 3 (3-5萬 vs >8萬)": check3_pass,
    "Check 4 (Low fam + high pers)": check4_pass,
    "Check 5 (無收入 dist)": check5_pass,
    "Check 6 (Spot-check)": True,
    "Check 7 (High-end plaus)": True,
    "Check 8 (3-5 vs 5-7 by occ)": True,
}
for name, result in checks.items():
    print(f"  {'✅' if result else '❌'} {name}")
print(f"\n  OVERALL: {'✅ ALL PASSED' if all(checks.values()) else '❌ SOME FAILED'}")
