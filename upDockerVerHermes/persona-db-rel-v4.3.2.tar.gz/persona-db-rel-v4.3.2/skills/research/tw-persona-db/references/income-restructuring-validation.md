# Income Restructuring Validation

When `family_income` tiers change (e.g., splitting 百萬→>8萬, 3-7萬→3-5萬+5-7萬), run this two-phase validation:

## Phase 1: QA (structural rules)
```bash
cd ~/persona-db && python3 qa_validate.py
```
Must exit 0, all 23 rules pass.

## Phase 2: Income cross-check
```bash
cd ~/persona-db
python3 ../.hermes/skills/research/tw-persona-db/scripts/validate_income_restructure.py
```

### Checks performed (8 total):

| # | Check | What it catches |
|---|-------|----------------|
| 2 | All 6 tiers present | Missing tiers, unexpected tiers, distribution % |
| 3 | fam_inc vs pers_inc cross-check | 3-5萬 + >8萬 (should be 0), 5-7萬 + >8萬 (flag) |
| 4 | Low fam + high pers | <1萬/1-3萬 + >8萬 personal (impossible for single-person) |
| 5 | 無收入 distribution | All students distributed across 5+ tiers, no >60% in one tier |
| 6 | Spot-check 10 random | Age/occupation/income/marriage consistency |
| 7 | High-end demographics | 7萬/>8萬 tier occupations and ages plausible |
| 8 | 3-5萬 vs 5-7萬 by occupation | Both tiers present; ratios align with occupation prestige |

### Deep-dive on failures:
```bash
python3 ../.hermes/skills/research/tw-persona-db/scripts/deep_dive_income_violations.py
```

### Known failure categories:

| Severity | Pattern | Root Cause |
|----------|---------|------------|
| 🔴 CRITICAL | fs=1 + pers=>8万 + fam_inc<7万 | Single-person: personal_income IS family_income. Generation assigns them independently. |
| 🔴 CRITICAL | 家管 + pers=>8万 | Occupation-income mismatch: homemakers have no earned income |
| 🟠 HIGH | 退休 + pers=>8万 | Retirees should have low/no personal income (pension ≠ earned income field) |
| 🟡 MEDIUM | fs≥2 + pers=>8万 + fam_inc=3-5万 | Possibly correct if equivalised, but still worth auditing |

### Equivalised income note:
If `family_income` represents equivalised (per-capita-adjusted) income, then a single earner with >8万 in a 4-person family could have equivalised income of 2-4万 (√4 divisor), which falls in the 1-3万 or 3-5万 tier. But for `fs=1`, equivalised = actual, so family_income MUST be ≥ personal_income bracket. Any `fs=1` violation is a definitive bug.
