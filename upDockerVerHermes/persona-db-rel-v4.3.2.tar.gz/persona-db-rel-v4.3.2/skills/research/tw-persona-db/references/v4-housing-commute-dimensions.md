# v4.0–v4.1 New Dimensions: Housing & Commute

**Added in v4.0** (housing_cost, housing_burden) and **v4.1** (commute_mode).
**Data**: DGBAS 主計總處 113年度家庭收支調查 + 交通部2024運具分配統計。

## Dimension 16: housing_cost (居住支出/月)

5 tiers, capped at ≤50% of family_income midpoint:

| Tier | Monthly Range | Typical Scenario |
|:----|:-------------|:-----------------|
| <5千 | <5K | 住家裡、學生套房、偏鄉 |
| 5千~1.5萬 | 5K-15K | 合租/套房（中南部） |
| 1.5萬~3萬 | 15K-30K | 一房一廳~兩房（六都） |
| 3萬~5萬 | 30K-50K | 三房~四房房貸（六都） |
| >5萬 | >50K | 高房貸/大坪數 |

### Assignment Logic

1. **Base**: `HOUSING_COST_PROB[price_tier]` (price_tier: 極低→高)
2. **Shift**: family_size shift (1→-1, 4/5+→+1)
3. **Cap**: housing_cost_mid ≤ family_income_mid × 0.5

## Dimension 17: housing_burden (居住負擔率)

Auto-calculated from housing_cost / family_income:

| Level | Ratio | BG Phrases |
|:------|:------|:-----------|
| 低 | <20% | 住家裡不用付房租 / 房貸早就還完了 |
| 中 | 20-40% | 房貸還在可負擔範圍 / 房租佔比還可以接受 |
| 高 | >40% | 房租佔掉收入快一半 / 房貸壓力很大 |

## Dimension 18: commute_mode (通勤方式)

5 options, assigned by residence region × age group:

| Region | Primary | Secondary |
|:-------|:--------|:----------|
| 雙北 | 捷運/公車 (30-40%) | 機車 (25-35%) |
| 桃竹 | 機車 (35-45%) | 汽車 (25-40%) |
| 中南 | 機車 (35-50%) | 汽車 (25-35%) |
| 花東/離島 | 汽車 (30-45%) | 機車 (25-40%) |

Adjustments:
- WFH → shifted away for students/retired/unemployed
- High income (>8萬) + family ≥3 → 30% car bias

## v4.0 Distribution (1069 personas)

| housing_cost | % | housing_burden | % |
|:------------|--:|:---------------|--:|
| <5千 | 39% | 低 | 45% |
| 5千~1.5萬 | 44% | 中 | 52% |
| 1.5萬~3萬 | 17% | 高 | 3% |

| commute_mode | % |
|:-------------|--:|
| 機車 | 32% |
| 汽車 | 26% |
| 步行/腳踏車 | 23% |
| 捷運/公車 | 16% |
| 在家工作 | 2.5% |
