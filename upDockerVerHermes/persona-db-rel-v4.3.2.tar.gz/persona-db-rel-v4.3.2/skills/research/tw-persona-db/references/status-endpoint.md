# `/personadb/status` Endpoint Design

Added 2026-07-22. Mirrors `hermes chat 'persona-db status'` as a FastAPI endpoint returning raw text.

## Usage

```bash
curl localhost:8000/personadb/status
```

## Output Format

```
Persona DB Status
==================================================

  Version         v3.2
  Main personas   1069 (tw_persona_1069.json, 1.36 MB)
  Backup          ✅ 1069
  QA (23 rules)   ✅ ALL CHECKS PASSED
  Name diversity  168 unique names (15.7%), max repeat 15×
  Python          3.11.15
  Git             0ad52af fix(status): always touch LLM
  LLM             ✅ deepseek-chat → https://api.deepseek.com (responsive)
  Hermes Skills   88 total, 3 persona-related

  📁 Supporting Artifacts: 34 Python files

  QA Results:
    [R21] BG/PP語氣一致: ✅ 0 violations
    ...
    ✅ ALL CHECKS PASSED
```

## Checks Performed

| Field | Method |
|:------|:-------|
| Version | `VERSION` file or fallback "v3.2" |
| Persona count | Load JSON, `len()` |
| File size | `os.stat()` formatted |
| Backup | Check `_backup.json` exists |
| QA | Run `python3 qa_validate.py` timeout=30, capture last 6 lines |
| Name diversity | `set(names)`, `Counter()` |
| Python | `sys.version.split()[0]` |
| Git | `git log --oneline -1` or "not a repo" |
| LLM health | **Always touches LLM** — calls `call_llm("回應「ok」就好", max_tokens=5)` |
| Hermes Skills | Count SKILL.md files in `/hermes-config/skills/` or `~/.hermes/skills/` |
| Persona Skills | Count persona-related SKILL.md files |
| File count | Count `*.py` in root + `api/` |

## LLM Health Check Design

The LLM health check is **not optional** — it always runs when a key is configured. Speed is not a concern.

### Logic (v2 — async endpoint)

Since the endpoint is `async def`, use `await` directly:

```python
@app.get("/personadb/status")
async def persona_db_status():
    ...
    if LLM_CONFIG.get("api_key"):
        try:
            resp = await call_llm("回應「ok」就好", max_tokens=5)
            if resp:
                llm_status += " (responsive)"
            else:
                llm_status += " (no response)"
        except Exception as e:
            llm_status += f" (error: {str(e)[:100]})"
    else:
        llm_status = "⛔ No API key configured"
```

### v1 pitfall (now fixed)

Earlier versions used `asyncio.run()` inside the async handler, which failed because Uvicorn's event loop was already running. **Fix**: use `await` directly.

### Expected outputs

| Scenario | Output |
|:---------|:-------|
| No key | `⛔ No API key configured` |
| Key works | `✅ model → url (responsive)` |
| Key exists, API down | `✅ model → url (error: 401 Unauthorized)` |
| Key exists, wrong base_url | `✅ model → url (error: 404 Not Found)` |

## Hermes Skills Count

The endpoint counts SKILL.md files from the mounted Hermes config volume:

```python
for skills_candidate in ["/hermes-config/skills", str(Path.home() / ".hermes/skills")]:
    skills_path = Path(skills_candidate)
    if skills_path.exists() and skills_path.is_dir():
        skill_files = list(skills_path.rglob("SKILL.md"))
        hermes_skills = str(len(skill_files))
        ps = [s for s in skill_files if "persona" in s.name.lower() or "persona" in str(s.parent).lower()]
        persona_skills = str(len(ps))
        break
```

Replaces: `sudo docker exec hermes sh -c "find /opt/data/skills -name SKILL.md | wc -l"`

## LLM Config: .env File Reading

`_load_llm_config()` reads `.env` files in this priority:

1. Project root `.env` (next to `Dockerfile`)
2. `~/.hermes/.env`
3. `/app/.env` (Docker container path)

Only checks `LLM_API_KEY`, `LLM_BASE_URL`, `LLM_MODEL`. Environment variables still take precedence.

## Differences from `hermes chat 'persona-db status'`

| Aspect | Hermes CLI | /personadb/status |
|:-------|:-----------|:-----------------|
| Requires SSH | ✅ | ❌ (just curl) |
| Requires container exec | ✅ | ❌ |
| LLM check | Only if user asks | ✅ Always runs |
| Output format | Terminal-formatted | Same plain text |
| Hermes skills | Manual `find` command | ✅ Auto-detected |
| Response time | ~2-5s | ~3-10s (with LLM call) |
