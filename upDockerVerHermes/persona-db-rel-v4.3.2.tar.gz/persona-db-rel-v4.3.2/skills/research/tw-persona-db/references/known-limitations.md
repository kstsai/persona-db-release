
## 2026-07-29: Template pool dedup — 老伴走了 duplication (template-pool-dedup)

**問題**: 背景故事出現重複「老伴走了」，來自兩個不同模板池包含相同開頭：

| Pool | 原句 | 修復後 |
|:-----|:-----|:-------|
| `HH_SINGLE_WIDOWED` (line 544) | 老伴走了，現在獨居 | 不變 |
| `LIFE_SENIOR_WIDOWED` (line 673) | **老伴走了，孩子也都成年了** | **孩子都成年了，老伴也走了** |

**根因**: 兩個池各自合理，但被同一 persona 選用時，「老伴走了」重複出現。

**教訓**: 模板池之間不要共用開頭短語。加入新池時先 grep 檢查既有池的開頭。
