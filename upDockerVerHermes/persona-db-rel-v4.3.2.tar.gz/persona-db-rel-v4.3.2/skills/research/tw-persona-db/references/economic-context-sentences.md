# Economic Context Sentence System

**Added**: v3.2.0 (2026-07-11)
**Updated**: v3.8.0 (2026-07-25) — rename 百萬→>8萬, split 3-7萬→3-5萬+5-7萬
**Function**: `gen_econ_context()` in `_generate_997.py`
**Purpose**: Generates an income-vs-cost-of-living sentence appended to `prompt_prefix`.

## Logic Table

### With personal income (`>8萬`, `3-8萬`, `<3萬`)

| Income | Price Tier | Output |
|--------|-----------|--------|
| `>8萬` | 高, 中高 | 在{residence}收入不錯，但物價高還是要算著花。 |
| `>8萬` | 低, 極低 | 在{residence}收入算很高了，日子過得滿舒服的。 |
| `>8萬` | 中 | 在{residence}收入不錯，生活還算輕鬆。 |
| `3-8萬` | 高, 中高 | 在{residence}這個收入不太夠用，物價太高了。 |
| `3-8萬` | 低, 極低 | 在{residence}這個收入還不錯，不用太省。 |
| `3-8萬` | 中 | 在{residence}收入剛好夠生活。 |
| `<3萬` | 高, 中高 | 在{residence}收入低，生活壓力很大。 |
| `<3萬` | 低, 極低, 中 | 收入不高，在{residence}還是要省著點。 |

### Without personal income (`無收入` — students, retirees, homemakers)

Uses `fam_inc` (family income monthly) as proxy:

| Family Income | Output |
|--------------|--------|
| >8萬, 7萬 | 家裡經濟還不錯，不用擔心錢的問題。 |
| 1-3萬, <1萬 | 家裡經濟比較吃緊。 |
| 3-5萬, 5-7萬 | (empty — no sentence) |

### Skipped personas
- Minors (0-11, 12-18) always return empty string.

## Real Examples from Generation

| Persona | Residence | Income | Price Tier | Econ Context Sentence |
|---------|-----------|--------|------------|----------------------|
| 小白 | 台北市 | 3-8萬 | 高 | 在台北市這個收入不太夠用，物價太高了。 |
| 小宇 | 台北市 | >8萬 | 高 | 在台北市收入不錯，但物價高還是要算著花。 |
| 阿凱 | 台東縣 | >8萬 | 極低 | 在台東縣收入算很高了，日子過得滿舒服的。 |
| 小曦 | 花蓮縣 | 3-8萬 | 低 | 在花蓮縣這個收入還不錯，不用太省。 |
| 大雄 | 高雄市 | 3-8萬 | 中 | 在高雄市收入剛好夠生活。 |

## Integration in Templates

All three templates append `{econ_ctx}` after `{stance_suffix}`:
- Template A (40%): `...{stance}{econ_ctx}`
- Template B (35%): `...{stance}{econ_ctx}`
- Template C (25%): `...{stance}{econ_ctx}`

## Maintenance

To add/modify phrases, edit `gen_econ_context()` in `_generate_997.py`. The function is defined inline per-loop (inside the for-persona block). Keep the outputs as natural-sounding, first-person-compatible Chinese.
