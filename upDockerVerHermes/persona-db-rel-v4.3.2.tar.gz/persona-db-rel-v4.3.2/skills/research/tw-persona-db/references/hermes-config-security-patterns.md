# Hermes Config Security Patterns

## Move API Keys from config.yaml to .env

The default `hermes setup` or `hermes model` wizard stores API keys **inline** in `config.yaml`:

```yaml
# ❌ Insecure — key in config file
model:
  default: deepseek-v4-flash
  provider: custom
  base_url: https://api.deepseek.com
  api_key: sk-...                    # ← DO NOT DO THIS
```

Better: use `custom_providers` with `api_key_env` so the key lives in `.env` only:

```yaml
# ✅ Secure — key in .env, config has no secrets
model:
  default: deepseek-v4-flash
  provider: custom:deepseek-pro      # ← namespaced reference

custom_providers:
  - name: deepseek-pro
    base_url: https://api.deepseek.com
    api_key_env: LLM_API_KEY          # ← reads from .env
    model: deepseek-v4-pro
```

### Migration Steps

```bash
# 1. Get the current key (hidden in terminal output, use python/hex)
python3 -c "line = open('/home/ubuntu/.hermes/config.yaml','rb').readlines()[4]; print(line.decode().strip())"
# → api_key: sk-YOUR_ACTUAL_KEY_HERE  # replace with your key
echo 'LLM_API_KEY=sk-YOUR_ACTUAL_KEY_HERE'  # replace with your key

# 3. Change provider format (use hermes config set + sed)
hermes config set model.provider custom:deepseek-pro
sed -i '/^  base_url: https:\/\/api.deepseek.com/d; /^  api_key: sk-/d' ~/.hermes/config.yaml

# 4. Fix custom_providers to use api_key_env instead of api_key
sed -i 's/    api_key: sk-.*/    api_key_env: LLM_API_KEY/' ~/.hermes/config.yaml

# 5. Verify
hermes config check
hermes doctor
```

### Why

| Inline `api_key:` | `api_key_env:` |
|:------------------|:---------------|
| Key visible in `config.yaml` | Key only in `.env` (600 perms) |
| Accidentally committed to git | `.env` is gitignored by convention |
| Hard to rotate without editing config | Just change `.env` |
| Every provider's key visible at once | Only the env var you need |

### Known Quirks

- **`hermes config unset` does not exist**. Use `sed -i '/^  key:/d'` to remove config keys.
- **Provider format must be `custom:<name>`**, not bare `custom`. The `<name>` must match a `name:` field in `custom_providers`.
- **If both inline `model.api_key` AND `custom_providers` exist**, Hermes prefers the inline key. Remove the inline one after migration.
- **`custom_providers` must be a YAML list** (prefixed with `-`), not a dict. Each provider is a list item.
- **Delegation also needs the namespaced provider** if it uses a custom provider:
  ```yaml
  delegation:
    model: deepseek-v4-pro
    provider: custom:deepseek-pro
  ```

### Verification

After migration, confirm the key loads correctly:

```bash
# Check no inline keys remain
grep -n "api_key:" ~/.hermes/config.yaml
# Should only show references in comments or api_key_env

# Verify .env has the key
grep LLM_API_KEY ~/.hermes/.env

# Test model actually works
hermes chat -q "回應ok就好" --quiet 2>/dev/null
```

## Instance Comparison Methodology

When comparing two Hermes instances (e.g., 本尊 vs delivery VM container), diff these categories:

| Category | Command |
|:---------|:--------|
| **Hermes version** | `hermes version` |
| **Python version** | `python3 --version` |
| **Config size** | `wc -c ~/.hermes/config.yaml` |
| **Config structure** | `diff <(cat config1) <(cat config2)` or manual comparison |
| **Provider format** | `grep -A5 "custom_providers" config.yaml` |
| **Skills count** | `find ~/.hermes/skills -name "SKILL.md" \| wc -l` |
| **Skills missing** | Diff the `find` output between instances |
| **Model config** | `grep -A3 "^model:" config.yaml` |
| **Delegation model** | `grep -A2 "^delegation:" config.yaml` |
| **API key storage** | `grep -n "api_key:" config.yaml` vs `grep LLM_API_KEY .env` |
