# Persona DB API — LLM 整合模式

> 經驗總結：如何設計 LLM-powered persona 搜尋 API

## 核心模式：Hybrid Matching

```
questions (NL)
  → LLM 語意理解 → 產出 structured dimension filters
  → 確定性過濾 (filter_personas) → 回傳匹配結果
  → (選擇性) LLM 針對每個 persona 做遭遇模擬②
```

這個模式結合了 **LLM 的語意理解能力** + **確定性過濾的速度與可預測性**。

## Prompt 設計要點

### 1. 列出所有有效值（最重要）

❌ 不要只說「回傳年齡區間」— LLM 會發明「18-30」「上班族」等不存在於 DB 的值。

✅ 在 prompt 中列出所有有效選項，並強調「必須嚴格使用」：

```
有效選項：
- age: 0-11, 12-18, 19-24, 25-34, 35-44, 45-54, 55-64, 65+
- occupation: 學生, 科技, 金融, 服務, 製造, 教育, 醫療, 公務, 自營, 家管, 退休, 其他
- income: 無收入, <3萬, 3-8萬, >8萬
- hobby: 登山, 游泳, 球類, 打電動, 追劇, 閱讀, 逛街購物, 戶外活動, 運動
  （注意：資料庫不支援「賞鳥、露營、攝影」等，請對應到相近選項）
```

### 2. 指定 strict JSON 格式

- 用雙大括號 `{{ }}` 逃逸 Python format string
- 在 prompt 中展示完整的 JSON schema，不放寬
- 設定 `temperature=0.2` 讓輸出更穩定

### 3. 提供 Fallback

LLM 可能回傳無效值或空值。實作 `llm_filters_to_dimension_filters()` 做 validation：

```python
def llm_filters_to_dimension_filters(llm_result):
    valid_dims = {"age", "sex", "occupation", ...}
    for dim, values in llm_filters.items():
        if dim not in valid_dims: continue
        if not values: continue
        filters[dim] = values
```

## 已知陷阱 & 解決方案

### 陷阱 1：List 型維度比對失敗

**問題**：`hobby` 在 persona DB 中儲存為 list（`["登山", "游泳"]`），
但 `filter_personas` 用 `val not in accepted` 做比對。
Python 的 `["登山", "游泳"] not in ["登山"]` 永遠為 True，導致 hobby 篩選永遠匹配不到。

**解法**：在 `filter_personas` 中區分 list 型維度和 string 型維度：

```python
list_dims = {"hobby"}
for dim, accepted in filters.items():
    val = d.get(dim, "")
    if dim in list_dims and isinstance(val, list):
        # List-type: check if ANY accepted value matches
        if not any(v in val for v in accepted):
            match = False
    else:
        # String-type: standard comparison
        if val not in accepted:
            match = False
```

### 陷阱 2：LLM 回傳的 filter 值不在 DB 中

即使 prompt 列出了有效值，LLM 仍可能回傳「18-30」「上班族」「中等收入」等不存在的值。
解法：在 prompt 明確列出所有有效選項 + 在 `llm_filters_to_dimension_filters()` 中過濾。

### 陷阱 3：LLM prompt 沒有包含所有可過濾的維度

如果 prompt 的 filter 列表中沒有 `hobby`，LLM 就不會輸出 hobby filter。
解法：在 prompt 的有效選項中加入 `hobby`，即使不確定也列出可選值。

### 陷阱 4：LLM prompt 必須包含 DB 的維度有效值，否則 filter 會 mismatch 導致 0 結果

如果 prompt 只說「回傳 age brackets」但沒有列出 `0-11, 12-18, 19-24, 25-34…` 等確切值，LLM 會發明「18-30」「30-45」等不存在的區間 → filter 永遠匹配不到 0 筆。
解法：在 prompt 中用表格列出所有維度的 `有效值`。

## Usage Suggestion 設計

讓 LLM 在分析問題時一併判斷 retrieved persona 的建議用法：

| mode | 適合 | 建議 opMode |
|:-----|:------|:-----------|
| 模擬詢問 | 產品/服務評價、品牌偏好、決策行為 | `篩選+模擬` |
| 問卷答題者 | 族群看法調查、市場區隔研究 | `僅篩選` |
| 兩者皆可 | 通用探索型問題 | 視需求而定 |

### 判斷邏輯

- **模擬詢問（遭遇模擬②）**：問題在問「產品/服務怎麼樣、哪個好、你覺得如何」—
  目的是讓 LLM 扮演 persona 直接回答，回答本身就是產出。
  例：「哪家銀行利率最高？」→ persona 回答「台銀2.075%配99次。」

- **問卷答題者（自我模擬①）**：問題在描述一個情境，需要找「對的人來問意見/推薦」—
  目的是找到合適的 persona 當作問卷對象，再對他們發問卷。
  例：「找新竹課輔班推薦」→ 目標是找到新竹家長，然後問他們推薦哪家。

## Hobby 維度現狀

Persona DB 的 `hobby` 是 **list 型別**（不是 string），目前支援以下值：

`打電動, 追劇, 閱讀, 登山, 游泳, 球類, 逛街購物, 烹飪, 園藝, 泡茶, 下棋, 打牌, 繪畫, 音樂, 廣場舞`

不支持的值（會匹配 0 結果）：賞鳥、露營、攝影、健身、瑜珈、寵物等。

## API 文件對照

- `api/API-SPEC.md` — 完整 API spec
- `api/llm.py` — LLM client 實作（含 prompt template）
- `api/server.py` — FastAPI server
- `api/models.py` — Pydantic schema
- `api/persona_matcher.py` — 過濾引擎
- `api/test_llm_api.py` — 測試腳本
