# API Response Format — Summary vs Detail

> 從 v3.8 起，`/personadb/candidates` 回傳 **摘要表格** 而非完整人設 JSON

## Response 結構

```json
{
  "status": "ok",
  "total_matched": 19,
  "persona_ids": [233, 255, ...],
  "summary": [
    {
      "id": "TW-P-0233",
      "name": "丹尼爾",
      "age": "25-34",
      "occupation": "科技",
      "income": ">8萬",
      "family_income": "5-7萬",
      "residence": "高雄市",
      "family_size": "2",
      "price_tier": "中"
    }
  ],
  "important_dimensions": [
    {"dim": "age", "values": ["35-44", "25-34"]},
    {"dim": "occupation", "values": ["科技", "金融"]}
  ],
  "llm_analysis": {
    "domain": "汽車/電動車產業",
    "reasoning": "特斯拉是電動車品牌...",
    "question_analysis": [...],
    "usage_suggestion": {...}
  }
}
```

## 變更說明 (v3.8)

| 欄位 | v3.7 以前 | v3.8+ |
|:----|:----------|:------|
| `personas` | 完整人設 JSON（含 dimensions, prompt_prefix, background_story, reference_pre_prompt） | **移除** |
| `summary` | 無 | **新增**（id/name/age/occupation/income/family_income/residence/family_size/price_tier） |
| `llm_analysis.reasoning` | 有 | **保留** |
| `important_dimensions` | 有 | **保留** |

## 取得完整人設

摘要模式只回傳 key 維度。如需完整人設資料（background_story、hobby、政治立場等），使用 `/personadb/detail`：

```bash
curl -s "http://localhost:8000/personadb/detail?id=TW-P-0233"
```

## 設計理由

1. **回應體積縮小** — 完整人設 JSON 約 2-3KB/筆，10 筆就 20-30KB。摘要約 200B/筆
2. **客戶端渲染** — 摘要適合直接渲染成表格，`important_dimensions` 與 `summary` 已涵蓋決策所需資訊
3. **需要時才取得細節** — `/personadb/detail` 提供完全的單筆人設查詢
