# Persona DB REST API — Delivery Option

> Added 2026-07-18 as alternative to ZIP appliance or Hermes skill-based delivery.
> Full API spec: `api/API-SPEC.md` in repo.

## Overview

A FastAPI-based REST API that wraps Persona DB as a service. The API uses **LLM (DeepSeek Flash) to analyze natural-language questions** and determine which demographics match, then filters the persona DB accordingly.

### Client Use Case

```
銀行廣告行銷人員 (client's customer) thinks of questions
   ↓
GET /personadb/candidates?questions=問題一|問題二&top_k=12&opMode=篩選+模擬
   ↓
LLM analyzes questions → determines target demographics → filters 1069 personas
   ↓ (optional, opMode=篩選+模擬)
LLM扮演 persona 回答問題 (遭遇模擬②)
   ↓
API returns 12 matching personas + simulation answers
```

## Endpoints

| Endpoint | Method | Purpose |
|:---------|:------|:--------|
| `/personadb/candidates` | GET | LLM analyzes questions, filters matching personas, optionally simulates |
| `/personadb/detail` | GET | Single persona lookup by ID |
| `/personadb/status` | GET | **Replaces `hermes chat 'persona-db status'`** — DB health + QA + LLM liveliness + Hermes skills count |
| `/health` | GET | Basic health check (persona count, DB loaded) |
| `/docs` | GET | Auto-generated Swagger UI |

## Key Design Decisions

### opMode enum (not boolean simulate)

```
僅篩選 (default) — return persona list + LLM analysis only
篩選+模擬      — also run LLM encounter simulation for each persona
```

### usage_suggestion

LLM auto-suggests how to use matched personas:
- **模擬詢問** (遭遇模擬②): "which product is best?" → let LLM扮演 persona answer directly. Recommends opMode=篩選+模擬.
- **問卷答題者** (自我模擬①): "find the right people to ask" → use personas as survey panel. Recommends opMode=僅篩選.

### hobby filter fix (list-type dimension)

Persona DB stores `hobby` as a list (`["登山", "游泳"]`). The filter function must check if ANY accepted value is in the persona's list, not compare the whole list against a string.

### LLM Config Priority Chain

`_load_llm_config()` in `llm.py` resolves providers with this priority:

1. **Environment variables** (`LLM_API_KEY`, `LLM_BASE_URL`, `LLM_MODEL`) — highest
2. **.env file** (project root, `~/.hermes/.env`, or `/app/.env`) — fills gaps from env
3. **Hermes config** (`/hermes-config/config.yaml`) — fills remaining gaps (base_url, model)
4. **auth.json** (Nous OAuth token, if no API key found anywhere else)
5. **Defaults** — `https://api.deepseek.com` + `deepseek-chat`

**Critical trap**: When `LLM_API_KEY` is set in `.env` but `LLM_BASE_URL` is NOT, the Hermes config's URL fills the gap (e.g., `inference-api.nousresearch.com/v1`), causing 404 because DeepSeek model sent to wrong endpoint. Always set ALL THREE.

### `/personadb/status` as Hermes CLI Replacement

The status endpoint is designed to replace the manual workflow:
```
Before: ssh VM → docker exec hermes hermes chat 'persona-db status'
After:  curl localhost:8000/personadb/status
```

It always touches the LLM (not optional) to verify the key is usable. Also checks:
- Hermes skills count (from mounted `/hermes-config/skills/`)
- QA 23 rules (via `qa_validate.py` subprocess)
- Backup file presence, name diversity, git commit
- See `references/status-endpoint.md` for full design.

## Containerization

Dockerfile (Python 3.11-slim), health check every 30s.
API key injected via `.env` file or environment variables.
Hermes config volume: `-v /home/ubuntu/.hermes:/hermes-config:ro`.

See `references/docker-deployment-patterns.md` for full deployment workflow (tarball method, no git needed).

## Test Results (2026-07-18)

5 cross-scenario tests:

| Scenario | matched | domain | usage |
|:---------|:-------:|:-------|:------|
| 銀髮理財 (退休金+防詐騙) | 11 | 理財規劃 | 模擬詢問 |
| 寵物商機 (寵物險) | 318 | 寵物保險 | 兩者皆可 |
| 職涯轉換 (40歲裁員轉職) | 46 | 職業生涯 | 問卷答題者 |
| 新創融資 (AI小新創B2B) | 16 | 創業投資 | 兩者皆可 |
| 旅遊規劃 (單身女花東獨旅) | 28 | 自由行/獨旅 | 問卷答題者 |

## Hermes Skills Detection

The status endpoint replaces: `sudo docker exec hermes sh -c "find /opt/data/skills -name SKILL.md | wc -l"`
With: automatic counting from mounted volume or local `~/.hermes/skills/`.
