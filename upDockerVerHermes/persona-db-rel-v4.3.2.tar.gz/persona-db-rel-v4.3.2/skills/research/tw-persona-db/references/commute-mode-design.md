# Commute Mode Dimension Design

**Added**: v4.1 (2026-07-30)
**Dimension**: 21 — 通勤方式 Commute Mode
**Values**: 步行/腳踏車 / 機車 / 捷運/公車 / 汽車 / 在家工作

## Assignment Logic

### Base probability by residence region × age group

```
COMMUTE_PROB = {
    "雙北": {"0-18": {步行0.60, 捷運0.25, 機車0.10, 汽車0.05},
             "19-34": {捷運0.40, 機車0.35, 汽車0.15, 步行0.08, WFH0.02},
             "35-44": {捷運0.35, 機車0.25, 汽車0.30, 步行0.08, WFH0.02},
             "45-64": {捷運0.30, 機車0.20, 汽車0.38, 步行0.10, WFH0.02},
             "65+":   {步行0.40, 捷運0.35, 機車0.10, 汽車0.15}},
    "桃竹": {"0-18": {步行0.55, 機車0.20, 汽車0.15, 捷運0.10},
             "19-34": {機車0.45, 汽車0.25, 捷運0.15, 步行0.10, WFH0.05},
             "35-44": {機車0.35, 汽車0.40, 捷運0.12, 步行0.08, WFH0.05},
             "45-64": {機車0.30, 汽車0.40, 捷運0.12, 步行0.13, WFH0.05},
             "65+":   {步行0.50, 機車0.20, 汽車0.20, 捷運0.10}},
    "中南": {"0-18": {步行0.55, 機車0.25, 汽車0.10, 捷運0.10},
             "19-34": {機車0.50, 汽車0.25, 步行0.10, 捷運0.10, WFH0.05},
             "35-44": {機車0.40, 汽車0.35, 步行0.08, 捷運0.12, WFH0.05},
             "45-64": {機車0.35, 汽車0.38, 步行0.12, 捷運0.10, WFH0.05},
             "65+":   {步行0.45, 機車0.25, 汽車0.30, 捷運0.10}},
    "偏鄉": {"0-18": {步行0.50, 機車0.25, 汽車0.20, 捷運0.05},
             "19-34": {機車0.40, 汽車0.35, 步行0.15, 捷運0.05, WFH0.05},
             "35-44": {汽車0.45, 機車0.30, 步行0.10, 捷運0.05, WFH0.10},
             "45-64": {汽車0.45, 機車0.25, 步行0.15, 捷運0.05, WFH0.10},
             "65+":   {步行0.50, 汽車0.30, 機車0.15, 捷運0.05}},
}
```

### Post-assignment adjustments

1. **WFH exclusion**: Students/retired/unemployed assigned WFH are re-rolled into non-WFH modes
2. **High-income family car bias**: >8萬 income + family_size≥3 → 30% chance shifted to 汽車

### Background phrases

| Mode | Phrases |
|:-----|:--------|
| 步行/腳踏車 | 騎腳踏車上下班 / 離公司近，走路就到 |
| 機車 | 每天騎機車通勤 / 騎車上班，很方便 |
| 捷運/公車 | 搭捷運上下班 / 每天搭公車通勤 |
| 汽車 | 開車上下班 / 通勤都開車 |
| 在家工作 | 在家工作，不用通勤 |

### Known limitations

- No commute phrase for 0-11 age group (skipped)
- No commute_cost tier (mode only) — could be added later as dimension 22
- Regional probabilities are estimated (交通部2024 data), not exact census
