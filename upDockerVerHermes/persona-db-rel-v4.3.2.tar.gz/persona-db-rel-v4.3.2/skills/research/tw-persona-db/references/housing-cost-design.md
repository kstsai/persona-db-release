# Housing Cost + Housing Burden Design (v4.0)

**Added**: 2026-07-30
**Version**: v4.0
**Commit**: 2b45ead

## Dimensions

| # | Name | Levels | Description |
|---|------|--------|-------------|
| 19 | 居住支出（月） Housing Cost | <5千 / 5千~1.5萬 / 1.5萬~3萬 / 3萬~5萬 / >5萬 | Monthly rent/mortgage payment |
| 20 | 居住負擔率 Housing Burden | 低 (<20%) / 中 (20-40%) / 高 (>40%) | housing_cost / family_income ratio |

## Assignment Logic

**Base distribution** by price_tier (`HOUSING_COST_PROB`):

| price_tier | <5千 | 5千~1.5萬 | 1.5萬~3萬 | 3萬~5萬 | >5萬 |
|:-----------|:----:|:---------:|:---------:|:-------:|:----:|
| 極低 | 45% | 40% | 12% | 3% | 0% |
| 低 | 30% | 45% | 20% | 4% | 1% |
| 中 | 15% | 40% | 32% | 10% | 3% |
| 中高 | 5% | 25% | 40% | 22% | 8% |
| 高 | 2% | 15% | 30% | 32% | 21% |

**Adjustments:**
1. **family_size shift**: 1→-1 tier, 4/5+→+1 tier (bigger family needs more space)
2. **family_income cap**: housing_cost ≤ 50% of family_income midpoint (e.g., 5-7萬→cap 50%=30K→max tier = 1.5萬~3萬)

**Burden calculation:**
```python
hc_mid = {"<5千":2500, "5千~1.5萬":10000, "1.5萬~3萬":22500, "3萬~5萬":40000, ">5萬":60000}
fi_mid = {"<1萬":5000, "1-3萬":20000, "3-5萬":40000, "5-7萬":60000, "7萬":70000, ">8萬":90000}
ratio = hc_mid[housing_cost] / fi_mid[family_income]
if ratio < 0.20 → 低; elif ratio < 0.40 → 中; else → 高
```

## Background Story Phrases

**Low burden** (`HOUSING_BURDEN_LOW`): 「住家裡不用付房租」/「房貸早就還完了」/「住在自己的房子，沒有貸款壓力」

**Mid burden** (`HOUSING_BURDEN_MID`): 「房貸還在可負擔範圍」/「房租佔比還可以接受」

**High burden** (`HOUSING_BURDEN_HIGH`): 「房租佔掉收入快一半」/「房貸壓力很大」/「每個月房貸是最大開銷」

**Dedup**: Conflicting housing+economic phrases removed (e.g., "房租佔掉收入快一半" + "房貸早就還完了").

## Distribution (v4.0, 1069 personas)

| housing_cost | % | housing_burden | % |
|:------------|---:|:---------------|---:|
| <5千 | 39.3% | 低 | 45.0% |
| 5千~1.5萬 | 44.1% | 中 | 52.3% |
| 1.5萬~3萬 | 16.7% | 高 | 2.7% |
| 3萬~5萬 | 0% (capped) | | |
| >5萬 | 0% (capped) | | |
