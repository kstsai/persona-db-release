# Fresh VM Pre-Flight Checklist (Docker Deploy)

Before running `deploy-persona-db-compose.sh` on a new delivery VM, verify these items.

## 1. SSH Access
```bash
# Add agent's SSH public key to target VM
ssh-copy-id ubuntu@<VM-IP>   # or manually append to ~/.ssh/authorized_keys
ssh ubuntu@<VM-IP> "hostname && whoami"  # verify passwordless login works
```

## 2. Disk Space
```bash
df -h /
# Need at least 5GB free for full deploy (hermes ~3.8GB + api ~1GB)
# Need at least 1GB free for API-only (deploy with --skip-hermes)
# Common fix: docker system prune -af (needs sudo or docker group)
```

**Common pitfall**: Fresh VMs often have 100% disk from leftover Docker images or dangling layers. Check before cloning.

**Recovery sequence (aggressive — recovers 3–4GB on 9.8G disk)**:
```bash
sudo docker image prune -af          # remove dangling layers (~2-3GB)
sudo docker system prune -af         # remove all unused docker data
sudo snap remove lxd                 # not needed on edge VMs
sudo apt-get clean
sudo journalctl --vacuum-time=1d
```

**If disk is still tight** or Docker Hub is slow (>5 min pull):
```bash
bash deploy-persona-db-compose.sh --skip-hermes
# API-only: needs ~1GB, no hermes pull
```

## 3. Docker & Docker Compose
```bash
docker --version
docker compose version   # v2 preferred
```
**Common pitfall**: `ubuntu` user may not be in `docker` group → `sudo usermod -aG docker ubuntu` (relogin needed). Or run all docker commands via sudo (needs passwordless sudo).

## 4. Sudo Access
```bash
sudo -n true 2>&1  # returns 0 if passwordless sudo works
```
**Common pitfall**: Agent cannot pipe passwords to sudo. Three approaches:
- **Passwordless sudo** (best): `sudo visudo` → add `ubuntu ALL=(ALL) NOPASSWD:ALL`
- **Docker group** (avoids sudo for docker): `sudo usermod -aG docker ubuntu && newgrp docker`
- **SUDO_PASSWORD env var** (fallback): `export SUDO_PASSWORD=your_pass; bash deploy-persona-db-compose.sh` — the script uses it silently for mkdir/chown steps.

The updated `deploy-persona-db-compose.sh` (2026-07-24+) has built-in pre-flight checks for all three cases.

## 5. Environment Config
```bash
cat ~/.env  # should contain LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
```
If missing, copy from another delivery VM or create manually.

## 6. Git Clone
```bash
cd ~
git clone https://github.com/kstsai/persona-db-release.git
cd persona-db-release/upDockerVerHermes
ls deploy-persona-db-compose.sh test-persona-db-api.sh
```

## 7. Tailscale (if remote access needed)
```bash
# Install if missing
curl -fsSL https://tailscale.com/install.sh | sh

# Connect with reusable auth key
sudo tailscale up --auth-key=tskey-auth-<KEY> --advertise-tags=tag:dhvm
```
Use **reusable** auth keys for automation (set max-uses in admin console).
Tag convention: `tag:dhvm` for delivery VMs managed by lzc-cp.

## Verification
```bash
cd ~/persona-db-release/upDockerVerHermes
bash deploy-persona-db-compose.sh          # full deploy
bash deploy-persona-db-compose.sh --skip-hermes  # API-only (tight disk / slow network)
bash test-persona-db-api.sh                # verify all 3 endpoints pass
```
