# Ticker 01 — 更新 RFC 維度表

**What to build:** 在 `tw-persona-db-rfc.md` 的維度表格中新增 dimension 19：`clothing_spend`（服飾消費等級），含 tier 定義與資料來源說明。

**Blocked by:** None — can start immediately

**Status:** ready-for-agent

- [ ] 在維度表格中新增一行 `| 19 | 服飾消費（月） | <500 / 500~1500 / 1500~3000 / 3000~5000 / >5000 | DGBAS 家庭收支調查衣著支出分位 |`
