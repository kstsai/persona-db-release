# Spec: 新增居住支出與通勤方式維度

## Problem Statement

Persona DB 現有的 18 維度涵蓋人口統計、收入、職業等基礎資訊，但缺少兩個對消費行為影響重大的面向：**居住成本**（房貸/房租）和**通勤方式**。這限制了甲方在做市場區隔分析時的精準度 — 例如查「電動機車目標客戶」時，無法知道候選人騎車還是開車；查「房貸商品」時，無法知道誰的居住負擔重。

## Solution

在 persona DB 中新增三個衍生維度（dimension 16-18）：
1. **housing_cost** — 家庭月居住支出（<5千 / 5千~1.5萬 / 1.5萬~3萬 / 3萬~5萬 / >5萬）
2. **housing_burden** — 居住負擔率（低<20% / 中20-40% / 高>40%），自動由 housing_cost / family_income 計算
3. **commute_mode** — 主要通勤方式（步行/腳踏車 / 機車 / 捷運/公車 / 汽車 / 在家工作）

連帶更新 API response 的 `summary` 和 `important_dimensions` 以露出這些新維度。

## User Stories

1. 作為市場研究人員，我想在查詢結果中看到候選人的通勤方式，以便評估電動機車/電動車的潛在客群
2. 作為銀行產品經理，我想知道候選人的居住負擔率，以便篩選房貸/信貸的目標客戶
3. 作為甲方，我想在 summary 表格中直接看到居住支出和通勤方式，不必另外查 detail API
4. 作為系統管理者，我希望 housing_cost 不超過 family_income 的 50%，以維持背景故事的一致性
5. 作為資料分析師，我希望 important_dimensions 顯示 commute_mode 和 housing_burden 的分群結果，以便理解篩選後的族群特徵
6. 作為開發者，我希望新的維度被整合到 QA validate 流程中，確保 regen 後沒有退化

## Implementation Decisions

### housing_cost 指派邏輯

- **基底**：`price_tier`（極低→高）決定 housing_cost 的初始機率分布
- **偏移**：`family_size`（1人→-1偏移, 5+人→+1偏移）
- **上限**：housing_cost ≤ family_income 中位數的 50%（例如 5-7萬 最高只能到 1.5萬~3萬）
- **級距**：5 tier（<5千 / 5千~1.5萬 / 1.5萬~3萬 / 3萬~5萬 / >5萬），單位採台灣習慣的千/萬

### housing_burden 計算

- 公式：`housing_cost 中位數 / family_income 中位數`
- 分級：<20% = 低, 20-40% = 中, >40% = 高
- 背景故事依據 burden 選用不同短語池

### commute_mode 指派邏輯

- **基底**：`residence region`（雙北/桃竹/中南/偏鄉） × `age group` 決定運具分配比例（參考交通部2024統計）
- **例外**：學生/退休/失業 → 不指派 WFH
- **家庭車 bias**：高收入(>8萬) + 3人以上家庭 → 30%機率轉為汽車
- **WFH**：保留為獨立選項（~2.5%），限在職工作者

## Testing Decisions

- **QA rules（R1-R23）**：新增的 BG 短語不得含有「或」字（避免觸發 R3 模糊家庭描述）
- **housing burden 測試**：所有 persona 的 housing_cost 中位數不超過 family_income 中位數的 50%
- **region 相關性**：都會區 commmute_mode 以機車/捷運為主，偏鄉以汽車為主
- **regen 穩定性**：每次 regenerate 後分布應在 ±2% 以內

## Out of Scope

- housing_cost 的「有房/租房」區分（不在 tier 名稱中表達）
- commute_cost（交通支出維度），原因：可從 commute_mode + price_tier 推估
- 通勤時間（距離維度），原因：缺乏可靠的縣市級數據
- WFH 天數比例（僅存有/無）

## Further Notes

- 已實作並 release 為 v4.0 (housing) + v4.1 (commute)
- RFC 已更新 dimension 16-18
- API models.py / server.py / persona_matcher.py 已更新
- 分布驗證：housing_cost(<5千 39%, 5千~1.5萬 44%, 1.5萬~3萬 17%), commute_mode(機車 32%, 汽車 26%, 步行23%, 捷運17%, WFH 2.5%)
