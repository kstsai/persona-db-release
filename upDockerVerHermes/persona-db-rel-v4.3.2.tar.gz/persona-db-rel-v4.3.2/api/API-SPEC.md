# Persona DB REST API — 規格書 v0.2

> **專案**: Persona DB Transfer Delivery
> **狀態**: v0.2 — LLM-powered
> **對應 Issue**: [#1](https://github.com/kstsai/persona-db/issues/1)

---

## 1. 架構概覽

```
                    ┌──────────────┐
                    │   LLM        │ (DeepSeek Flash)
                    │  (問題分析)   │
                    └──────┬───────┘
                           │ dimension filters
                           v
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ 甲方 Client  │────>│  FastAPI     │────>│  Persona DB  │
│ (REST API)   │<────│  Server      │<────│  (1069 JSON) │
└──────────────┘     └──────────────┘     └──────────────┘
                           │
                     ┌─────┴──────┐
                     │  LLM        │ (選擇性: opMode=篩選+模擬)
                     │  (模擬回應)  │
                     └────────────┘
```

### 流程

1. Client 提交問題列表
2. Server 呼叫 **LLM (DeepSeek Flash)** 分析問題 → 推斷 target demographics
3. 根據 LLM 輸出篩選 Persona DB → 回傳 matching personas
4. (選擇性) 對每個 persona 呼叫 LLM 做**遭遇模擬②** → 模擬回答附在 response

---

## 2. Endpoints

### 2.1 `GET /personadb/candidates`

LLM 分析問題 → 篩選合適 Persona → (選擇性) 模擬回答。

#### Request

```http
GET /personadb/candidates?questions=哪家數位帳戶活存利率最高|轉帳免手續費次數最多的銀行|什麼時機點房貸轉換最適合&top_k=12&opMode=篩選+模擬
```

| 參數 | 型別 | 必填 | 預設值 | 說明 |
|:-----|:------|:----:|:-------|:------|
| `questions` | string | ✅ | — | 問題列表，用 `|` 分隔多題。至少 1 題 |
| `top_k` | int | ❌ | `12` | 最多回傳幾個 persona |
| `opMode` | enum | ❌ | `僅篩選` | `僅篩選`=只回傳 persona；`篩選+模擬`=額外做 LLM 遭遇模擬 |

#### Response `200 OK` (opMode=僅篩選)

```json
{
  "status": "ok",
  "total_matched": 252,
  "persona_ids": [187, 188, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199],
  "personas": [
    {
      "id": "TW-P-0187",
      "name": "理察",
      "dimensions": {
        "age": "25-34", "sex": "男", "residence": "台北市",
        "occupation": "科技", "income": ">8萬", "marriage": "未婚", "family_size": "1"
      },
      "prompt_prefix": "我叫理察，28歲，住台北市，做科技。...",
      "reference_pre_prompt": "【理察】25-34/男/台北市/科技/>8萬/未婚/1人...",
      "simulation": null
    }
  ],
  "important_dimensions": [
    {"dim": "occupation", "values": ["科技", "製造", "服務"]},
    {"dim": "income", "values": ["3-8萬", "<3萬", ">8萬"]}
  ],
  "llm_analysis": {
    "domain": "銀行數位帳戶 / 個人金融",
    "reasoning": "使用者問了利率、轉帳次數和房貸轉換，都屬於個人銀行業務範疇。會關心這些問題的通常是25-44歲有穩定收入的上班族。",
    "question_analysis": [
      {"question": "哪家數位帳戶活存利率最高", "topic": "活存利率比較", "target_user": "對利息收入有感的儲蓄者"},
      {"question": "轉帳免手續費次數最多的銀行", "topic": "轉帳手續費", "target_user": "經常轉帳的上班族/自由業"},
      {"question": "什麼時機點房貸轉換最適合", "topic": "房貸轉貸", "target_user": "有房貸的屋主/購屋族"}
    ]
  }
}
```

#### Response `200 OK` (opMode=篩選+模擬)

```json
{
  "status": "ok",
  "total_matched": 252,
  "persona_ids": [187, 188, 190],
  "personas": [
    {
      "id": "TW-P-0187",
      "name": "理察",
      "dimensions": {"...": "..."},
      "simulation": {
        "status": "completed",
        "answers": [
          "以我目前用的將來銀行，活存利率2%還不錯，搭配66次免手續費很夠用。台銀有2.075%配99次，但開戶麻煩就沒去辦。",
          "將來銀行66次對我來說用不完，但如果是業務常轉帳的話，台銀99次最多。",
          "我還在租房子啦，房貸的問題還不用想。"
        ]
      }
    }
  ],
  "important_dimensions": ["..."],
  "llm_analysis": {"...": "..."}
}
```

### 2.2 `GET /personadb/detail`

取得單一 Persona 完整資料。 (同 v0.1)

### 2.3 `GET /health`

健康檢查。 (同 v0.1)

---

## 3. LLM Prompt 設計

### 問題分析 Prompt

```
你是一個台灣市場研究助手。分析使用者提出的問題，判斷哪些 demographics 會對這些問題感興趣。

問題列表：
- 哪家數位帳戶活存利率最高
- 轉帳免手續費次數最多的銀行

輸出 JSON：
{
  "domain": "銀行數位帳戶",
  "reasoning": "...",
  "filters": {
    "age": ["25-34", "35-44"],
    "occupation": ["科技", "金融", "服務", "製造", "公務"],
    "income": [">8萬", "3-8萬"]
  },
  "question_analysis": [...]
}
```

### 模擬 Prompt (遭遇模擬②)

```
你是{name}，{age}歲，住{residence}，做{occupation}，收入{income}。
{background_story}

現在被問到：
Q1. 哪家數位帳戶活存利率最高？
Q2. 轉帳免手續費次數最多的銀行？

請以第一人稱「我」，用自然口語回答。2-4句話/題。
```

---

## 4. 錯誤處理

### 錯誤碼

| HTTP Status | Code | 情境 |
|:-----------|:-----|:------|
| 400 | `INVALID_PARAMETER` | opMode 值錯誤 |
| 400 | `MISSING_PARAMETER` | 未提供 questions |
| 404 | `PERSONA_NOT_FOUND` | persona_id 不存在 |
| 500 | `INTERNAL_ERROR` | LLM 呼叫失敗或其他伺服器錯誤 |
| 503 | `DB_NOT_LOADED` | Persona DB 尚未載入 |

---

## 5. 啟動方式

### 開發模式

```bash
cd ~/persona-db
pip install fastapi uvicorn httpx
python3 -m api.server
# → http://localhost:8000/docs (Swagger UI)
```

### 環境變數

| 變數 | 預設值 | 說明 |
|:-----|:-------|:------|
| `LLM_API_KEY` | (從 config 讀取) | DeepSeek API key |
| `LLM_BASE_URL` | `https://api.deepseek.com` | LLM endpoint |
| `LLM_MODEL` | `deepseek-v4-flash` | LLM 模型 |
| `PERSONA_DB_PATH` | `./tw_persona_1069.json` | Persona DB 路徑 |

---

## 6. vs v0.1 差異

| 項目 | v0.1 (keyword) | v0.2 (LLM-powered) |
|:-----|:---------------|:-------------------|
| **Endpoint** | `/personadb/init` | `/personadb/candidates` |
| **輸入** | `enduser` + `questions` | 僅 `questions`（用 \| 分隔） |
| **篩選方式** | 關鍵字比對 | LLM 分析問題 → 產出 dimension filters |
| **模擬方式** | Hermes delegate_task | 直接呼叫 LLM (DeepSeek Flash) |
| **回應內容** | `matched_criteria` | `llm_analysis` (含 domain/reasoning/question_analysis) |
| **LLM 費用** | 僅模擬階段 | 分析 + 模擬都經過 LLM |
