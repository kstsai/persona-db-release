"""
persona_matcher.py — Natural language → dimension parsing + persona filtering.

Uses keyword-based matching to parse enduser descriptions into dimension filters,
then filters the 1069 persona JSON accordingly.

Two modes:
  1. NL mode: parse enduser text → dimension filters → filter personas
  2. Direct mode: accept explicit dimension JSON → filter personas
"""

import json, re, os
from collections import Counter

# ── Dimension keywords ──────────────────────────────────────────────

AGE_KEYWORDS = {
    "0-11":  ["小學", "國小", "兒童", "小孩", "孩童", "0-11"],
    "12-18": ["中學", "國中", "高中", "青少年", "12-18", "teen"],
    "19-24": ["大學", "大學生", "19-24", "20出頭", "年輕"],
    "25-34": ["25-34", "25到34", "20多歲", "30左右", "年輕上班族"],
    "35-44": ["35-44", "35到44", "30多歲", "40左右", "中年", "青壯"],
    "45-54": ["45-54", "45到54", "40多歲", "50左右"],
    "55-64": ["55-64", "55到64", "50多歲", "60左右", "熟齡"],
    "65+":    ["65", "65以上", "老年", "長者", "銀髮"],
}

SEX_KEYWORDS = {
    "男": ["男", "男性", "先生", "男生"],
    "女": ["女", "女性", "女士", "小姐", "女生", "婦女"],
}

REGION_KEYWORDS = {
    "都會區(六都)": ["六都", "直轄市", "台北", "新北", "桃園", "台中", "台南", "高雄"],
    "北部": ["北部", "北台灣", "基隆", "新竹", "苗栗", "宜蘭"],
    "中部": ["中部", "中台灣", "彰化", "南投", "雲林"],
    "南部": ["南部", "南台灣", "嘉義", "屏東"],
    "花東": ["花蓮", "台東", "花東"],
    "離島": ["離島", "澎湖", "金門", "連江"],
}

CITY_KEYWORDS = {
    "台北市": ["台北", "臺北", "天龍"],
    "新北市": ["新北", "板橋", "中和", "永和", "新店"],
    "桃園市": ["桃園", "中壢"],
    "台中市": ["台中", "臺中", "逢甲"],
    "台南市": ["台南", "臺南"],
    "高雄市": ["高雄", "雄中"],
    "新竹市": ["新竹市"],
    "新竹縣": ["新竹縣", "竹北", "竹東"],
    "基隆市": ["基隆"],
    "嘉義市": ["嘉義市"],
    "嘉義縣": ["嘉義縣"],
}

OCC_KEYWORDS = {
    "科技":   ["科技", "工程師", "IT", "軟體", "硬體", "半導體", "電子", "程式", "數位", "資訊"],
    "金融":   ["金融", "銀行", "保險", "證券", "財經", "投信", "理財專員"],
    "服務":   ["服務", "餐飲", "零售", "sales", "業務", "店員", "門市", "銷售"],
    "製造":   ["製造", "工廠", "生產", "作業員", "傳產", "工程", "技術員"],
    "教育":   ["教育", "老師", "教授", "教師", "補習", "講師", "教職"],
    "醫療":   ["醫療", "醫生", "護士", "藥師", "醫", "護理", "診所"],
    "公務":   ["公務", "公職", "公家", "公部門", "軍公教", "公務員", "國營"],
    "自營":   ["自營", "老闆", "創業", "自由業", "接案", "工作室", "SOHO"],
    "家管":   ["家管", "主婦", "主夫", "全職媽媽", "家庭主婦", "全職爸爸", "家管"],
    "學生":   ["學生", "在學", "大學生", "研究生", "在學中", "進修"],
    "退休":   ["退休", "已退休", "屆退"],
    # 上班族 → 對應到多個職業 (OR logic across these)
    "上班族": ["上班族", "白領", "受薪", "職場"],
}

INCOME_KEYWORDS = {
    "無收入": ["無收入", "沒有收入"],
    "<3萬":   ["低收", "低薪", "3萬以下"],
    "3-8萬":  ["中產", "3到8萬", "一般收入", "上班族薪水"],
    ">8萬":   ["高收", "8萬以上", "高薪", "高階", "主管"],
}

MARRIAGE_KEYWORDS = {
    "未婚": ["未婚", "單身", "沒結婚"],
    "已婚": ["已婚", "結婚", "有配偶", "有家庭"],
    "離婚": ["離婚", "離異"],
    "鰥寡": ["鰥寡", "喪偶", "寡婦"],
}

FAMILY_KEYWORDS = {
    "1":  ["獨居", "一個人住", "單身"],
    "2":  ["夫妻", "兩人", "頂客", "dink", "新婚"],
    "3":  ["小家庭", "三口", "一家三口"],
    "4":  ["四口", "兩個小孩", "一家四口"],
    "5+": ["五口", "大家庭", "三個小孩", "一家五口", "兒女成群"],
}


def llm_filters_to_dimension_filters(llm_result: dict) -> dict:
    """
    Convert LLM question-analysis output into persona_matcher dimension filters.
    
    LLM output format:
    {
      "filters": {
        "age": ["25-34", "35-44"],
        "occupation": ["科技", "金融", "服務"],
        "sex": [],
        "residence": [],
        "income": [">8萬", "3-8萬"],
        "marriage": []
      }
    }
    """
    filters = {}
    llm_filters = llm_result.get("filters", {})
    
    # Valid dimension keys in persona DB
    valid_dims = {
        "age", "sex", "region", "residence", "education",
        "occupation", "income", "politics", "media_diet",
        "family_size", "family_income", "hobby", "marriage",
        "price_tier", "hh_income_tier",
        "commute_mode", "clothing_spend", "housing_burden",
    }
    
    for dim, values in llm_filters.items():
        if dim not in valid_dims:
            continue
        if not values or not isinstance(values, list):
            continue
        # Clean and validate values
        clean = [v.strip() for v in values if v.strip()]
        if clean:
            filters[dim] = clean
    
    return filters


def _match_keywords(text: str, keyword_map: dict) -> list[str]:
    """Return matched keys from a keyword map, sorted by match count desc."""
    scores = {}
    for key, kws in keyword_map.items():
        count = sum(1 for kw in kws if kw.lower() in text.lower())
        if count > 0:
            scores[key] = count
    return sorted(scores, key=scores.get, reverse=True)


def parse_age_range(text: str) -> list[str]:
    """Parse age descriptions that may span multiple brackets.
    
    Examples:
      '25-40' → ['25-34', '35-44']
      '30-50' → ['25-34', '35-44', '45-54']
      '20多歲' → ['19-24', '25-34']
      'young' → ['19-24', '25-34', '35-44']
    """
    result = []
    
    # Try number ranges like "25-40", "30-50"
    range_match = re.search(r'(\d{2})\s*[-–]\s*(\d{2})', text)
    if range_match:
        lo, hi = int(range_match.group(1)), int(range_match.group(2))
        brackets = [
            ("0-11", 0, 11), ("12-18", 12, 18), ("19-24", 19, 24),
            ("25-34", 25, 34), ("35-44", 35, 44), ("45-54", 45, 54),
            ("55-64", 55, 64), ("65+", 65, 120),
        ]
        for key, b_lo, b_hi in brackets:
            if lo <= b_hi and hi >= b_lo:
                result.append(key)
        return result
    
    # Try keyword matching
    kw_matches = _match_keywords(text, AGE_KEYWORDS)
    if kw_matches:
        # Expand adjacent brackets for fuzzy ranges
        all_brackets = ["0-11", "12-18", "19-24", "25-34", "35-44", "45-54", "55-64", "65+"]
        for m in kw_matches:
            if m in all_brackets:
                result.append(m)
                # If "25-34" was matched and the text has something like "多歲" or "左右"
                idx = all_brackets.index(m)
                if '多歲' in text or '左右' in text or '出頭' in text:
                    if idx > 0: result.append(all_brackets[idx - 1])
                    if idx < len(all_brackets) - 1: result.append(all_brackets[idx + 1])
    
    return list(set(result))  # dedupe


def parse_enduser(text: str) -> dict:
    """Parse natural language enduser description into dimension filters."""
    filters = {}

    # Age — try range parsing first
    age_matches = parse_age_range(text)
    if not age_matches:
        age_matches = _match_keywords(text, AGE_KEYWORDS)
    if age_matches:
        filters["age"] = age_matches[:3]

    sex_matches = _match_keywords(text, SEX_KEYWORDS)
    if sex_matches:
        filters["sex"] = [sex_matches[0]]

    region_matches = _match_keywords(text, REGION_KEYWORDS)
    if region_matches:
        filters["region"] = region_matches[:2]

    city_matches = _match_keywords(text, CITY_KEYWORDS)
    if city_matches:
        filters["residence"] = city_matches[:3]

    occ_matches = _match_keywords(text, OCC_KEYWORDS)
    if occ_matches:
        # Special handling: "上班族" is a meta-category → expand to multiple occupations
        if "上班族" in occ_matches:
            occ_matches.remove("上班族")
            # Add common office-worker occupations
            for occ in ["科技", "金融", "服務", "製造", "公務", "教育", "醫療"]:
                if occ not in occ_matches:
                    occ_matches.append(occ)
        filters["occupation"] = occ_matches[:5]

    income_matches = _match_keywords(text, INCOME_KEYWORDS)
    if income_matches:
        filters["income"] = [income_matches[0]]

    marriage_matches = _match_keywords(text, MARRIAGE_KEYWORDS)
    if marriage_matches:
        filters["marriage"] = [marriage_matches[0]]

    family_matches = _match_keywords(text, FAMILY_KEYWORDS)
    if family_matches:
        filters["family_size"] = [family_matches[0]]

    return filters


def filter_personas(personas: list[dict], filters: dict) -> list[dict]:
    """
    Filter personas by dimension filters.
    Each filter value is a list of acceptable values (OR logic within a dimension).
    Dimensions not mentioned are ignored (no filter).
    Handles both string and list-type dimensions (e.g. hobby is a list).
    """
    results = []
    # Dimensions stored as lists in persona DB
    list_dims = {"hobby"}
    
    for p in personas:
        d = p.get("dimensions", {})
        match = True
        for dim, accepted in filters.items():
            val = d.get(dim, "")
            
            if dim in list_dims and isinstance(val, list):
                # List-type: check if ANY accepted value is in the persona's list
                if not any(v in val for v in accepted):
                    match = False
                    break
            else:
                # String-type: standard comparison
                if isinstance(accepted, list):
                    if val not in accepted:
                        match = False
                        break
                else:
                    if val != accepted:
                        match = False
                        break
        if match:
            results.append(p)
    return results


def get_important_dimensions(personas: list[dict]) -> list[dict]:
    """Analyze which dimensions vary most in the result set."""
    if not personas:
        return []
    
    important = []
    score_dims = {
        "age": AGE_KEYWORDS,
        "sex": SEX_KEYWORDS,
        "region": REGION_KEYWORDS,
        "occupation": OCC_KEYWORDS,
        "income": INCOME_KEYWORDS,
        "family_income": None,
        "commute_mode": None,
        "clothing_spend": None,
        "housing_burden": None,
    }
    
    for dim, _ in score_dims.items():
        values = Counter()
        for p in personas:
            v = p.get("dimensions", {}).get(dim, "")
            if v:
                values[v] += 1
        if len(values) > 1:  # Only include if there's variety
            important.append({
                "dim": dim,
                "values": [v for v, _ in values.most_common(5)]
            })
    
    return important


def format_matched_criteria(filters: dict) -> str:
    """Human-readable summary of the parsed filters."""
    parts = []
    for dim, vals in filters.items():
        parts.append(f"{dim}:{'/'.join(vals)}")
    return ", ".join(parts)


# ── Singleton ──────────────────────────────────────────────────────

_persona_db = None


def load_persona_db(path: str = None) -> list[dict]:
    """Load the persona DB JSON. Uses PERSONA_DB_PATH env var or default."""
    global _persona_db
    if _persona_db is not None:
        return _persona_db
    
    if path is None:
        path = os.environ.get(
            "PERSONA_DB_PATH",
            os.path.join(os.path.dirname(__file__), "..", "tw_persona_1069.json")
        )
    
    with open(path) as f:
        _persona_db = json.load(f)
    
    # Build index by numeric ID too
    return _persona_db


def get_persona_by_id(persona_id: str) -> dict | None:
    """Find a persona by string ID (TW-P-XXXX) or numeric index."""
    db = load_persona_db()
    
    # Try direct lookup by id field
    for p in db:
        if p.get("id") == persona_id:
            return p
    
    # Try numeric index
    try:
        idx = int(persona_id) - 1
        if 0 <= idx < len(db):
            return db[idx]
    except ValueError:
        pass
    
    return None
