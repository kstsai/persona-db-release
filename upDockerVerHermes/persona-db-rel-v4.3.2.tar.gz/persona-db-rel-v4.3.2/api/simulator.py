"""
simulator.py — Optional sub-agent simulation wrapper.

When opMode=篩選+模擬, dispatches delegate_task calls for each persona
to answer the provided questions. Falls back gracefully if Hermes agent
APIs are not available (standalone mode).
"""

import json, os, logging
from typing import Optional

logger = logging.getLogger(__name__)

# Hermes delegate_task — only available inside Hermes Agent
_HERMES_AVAILABLE = False
try:
    from hermes_tools import delegate_task
    _HERMES_AVAILABLE = True
except ImportError:
    pass


async def simulate_persona(
    persona: dict,
    questions: list[str],
    timeout_seconds: int = 60
) -> dict:
    """
    Simulate a single persona answering the given questions.
    
    Uses Hermes delegate_task if available (full sub-agent simulation).
    Falls back to a simple prompt-based simulation otherwise.
    
    Returns: {"status": "completed"|"failed", "answers": [str, ...]}
    """
    if not questions:
        return {"status": "completed", "answers": []}
    
    name = persona.get("name", "unknown")
    prefix = persona.get("prompt_prefix", "")
    dims = persona.get("dimensions", {})
    
    if _HERMES_AVAILABLE:
        return await _simulate_with_subagent(name, prefix, dims, questions, timeout_seconds)
    else:
        return _simulate_local(name, prefix, dims, questions)


async def _simulate_with_subagent(
    name: str, prefix: str, dims: dict,
    questions: list[str], timeout: int
) -> dict:
    """Use Hermes delegate_task for full sub-agent simulation."""
    try:
        q_text = "\n".join(f"Q{i+1}: {q}" for i, q in enumerate(questions))
        context = f"""【Persona Profile】
姓名: {name}
年齡: {dims.get('age', '')} | 居住地: {dims.get('residence', '')}
職業: {dims.get('occupation', '')} | 收入: {dims.get('income', '')}
家庭: {dims.get('family_size', '')}人 | 婚姻: {dims.get('marriage', '')}

Persona voice:
{prefix}"""

        goal = f"""你正在扮演一位名叫{name}的消費者。
請以第一人稱「我」的口吻，用自然的口語中文，回答以下 {len(questions)} 個問題。
每題回答 2-4 句話，像真人受訪者一樣自然。
不要提到任何關於模擬、角色扮演的字眼。

{q_text}"""

        result = await delegate_task(
            goal=goal,
            context=context,
            role="leaf"
        )
        # Parse the sub-agent response
        summary = ""
        if isinstance(result, list) and len(result) > 0:
            r = result[0]
            if isinstance(r, dict):
                summary = r.get("summary", "") or str(r.get("result", ""))
            else:
                summary = str(r)
        elif isinstance(result, dict):
            summary = result.get("summary", "") or str(result.get("result", ""))
        else:
            summary = str(result)

        return {
            "status": "completed",
            "answers": [summary.strip()] if summary.strip() else ["（模擬無法產生回應）"]
        }
    except Exception as e:
        logger.error(f"Sub-agent simulation failed for {name}: {e}")
        return {"status": "failed", "answers": [f"（模擬錯誤: {str(e)}）"]}


def _simulate_local(name: str, prefix: str, dims: dict, questions: list[str]) -> dict:
    """Fallback: return structured info without actual LLM simulation."""
    answers = []
    for q in questions:
        answers.append(f"（{name} 的模擬回應需 Hermes Agent 環境支援）")
    
    return {
        "status": "limited",
        "answers": answers
    }


async def simulate_batch(
    personas: list[dict],
    questions: list[str]
) -> list[dict]:
    """Simulate a batch of personas in parallel (max 3 at a time)."""
    from asyncio import Semaphore, gather
    
    sem = Semaphore(3)
    
    async def _one(p):
        async with sem:
            return await simulate_persona(p, questions)
    
    tasks = [_one(p) for p in personas]
    results = await gather(*tasks)
    return results
