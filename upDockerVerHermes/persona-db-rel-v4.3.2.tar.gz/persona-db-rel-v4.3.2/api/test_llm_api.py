#!/usr/bin/env python3
"""Test LLM-powered /personadb/candidates endpoint"""
import json, urllib.request, urllib.parse

BASE = "http://localhost:8000"

def test(name, path, params):
    url = f"{BASE}{path}?{urllib.parse.urlencode(params, doseq=True)}"
    print(f"\n--- {name} ---")
    print(f"GET {url}")
    try:
        with urllib.request.urlopen(url, timeout=120) as r:
            d = json.loads(r.read())
        if d.get("status") == "ok":
            print(f"  ✅ total_matched={d['total_matched']}")
            llm = d.get("llm_analysis", {})
            if llm:
                print(f"  🧠 domain={llm.get('domain','?')}")
                print(f"  🧠 reasoning={llm.get('reasoning','?')[:120]}")
            for p in d.get("personas", [])[:3]:
                dim = p["dimensions"]
                sim = p.get("simulation")
                sim_status = f" sim={sim['status']}" if sim else ""
                print(f"  👤 {p['id']} {p['name']}: {dim['age']} {dim['residence']} {dim['occupation']}{sim_status}")
                if sim and sim.get("answers"):
                    for a in sim["answers"][:1]:
                        print(f"     > {a[:120]}")
            print(f"  📊 dims={d.get('important_dimensions',[])}")
        else:
            print(f"  ❌ {json.dumps(d, ensure_ascii=False)[:300]}")
    except Exception as e:
        print(f"  ❌ {e}")
    
    return d if 'd' in dir() else {}

# Test 1: 僅篩選 — 銀行數位帳戶問題
test("僅篩選 — 銀行數位帳戶", "/personadb/candidates", {
    "questions": "哪家數位帳戶活存利率最高|轉帳免手續費次數最多的銀行",
    "top_k": 3,
    "opMode": "僅篩選"
})

# Test 2: 篩選+模擬 — 銀行場景
test("篩選+模擬 — 銀行場景", "/personadb/candidates", {
    "questions": "哪家數位帳戶活存利率最高|轉帳免手續費次數最多的銀行",
    "top_k": 2,
    "opMode": "篩選+模擬"
})

# Test 3: 房貸轉換問題
test("房貸場景", "/personadb/candidates", {
    "questions": "什麼時機點房貸轉換最適合|有推薦的銀行嗎",
    "top_k": 3,
    "opMode": "僅篩選"
})

print("\n== DONE ==")
