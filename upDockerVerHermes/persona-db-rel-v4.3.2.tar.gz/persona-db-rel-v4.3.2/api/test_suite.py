#!/usr/bin/env python3
"""Persona DB API — full test suite"""
import json, urllib.request, urllib.parse, sys

BASE = "http://localhost:8000"
tests = {}

def fetch(name, path, params=None):
    url = f"{BASE}{path}"
    if params:
        url += "?" + urllib.parse.urlencode(params, doseq=True)
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
            tests[name] = {"status": resp.status, "response": data}
            print(f"  [{resp.status}] {name}")
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        tests[name] = {"status": e.code, "response": json.loads(body) if body else {}}
        print(f"  [{e.code}] {name} (HTTP error)")
    except Exception as e:
        tests[name] = {"status": "ERROR", "error": str(e)}
        print(f"  [ERR] {name}: {e}")

print("Persona DB API Test Suite")
print("=" * 50)

fetch("Health", "/health")
fetch("新竹科技男", "/personadb/init", {"enduser": "新竹市35-44科技業男性", "top_k": 3})
fetch("台北金融女", "/personadb/init", {"enduser": "台北市25-34女性金融", "top_k": 3})
fetch("台中家管", "/personadb/init", {"enduser": "台中市35-44家管已婚有小孩", "top_k": 3})
fetch("空查詢", "/personadb/init", {"enduser": "台灣", "top_k": 5})
fetch("銀行場景+模擬", "/personadb/init", {
    "enduser": "對銀行數位帳戶利率敏感的25-40歲上班族",
    "questions": ["哪家數位帳戶活存利率最高？"],
    "top_k": 3, "opMode": "篩選+模擬"
})
fetch("Detail字串", "/personadb/detail", {"persona_id": "TW-P-0301"})
fetch("Detail數字", "/personadb/detail", {"persona_id": "100"})
fetch("Detail不存在", "/personadb/detail", {"persona_id": "TW-P-9999"})
fetch("銀髮族", "/personadb/init", {"enduser": "65歲以上退休銀髮族", "top_k": 3})
fetch("離島", "/personadb/init", {"enduser": "連江縣", "top_k": 3})

output = {
    "test_date": "2026-07-17",
    "api_version": "3.2",
    "total": len(tests),
    "passed": sum(1 for t in tests.values() if isinstance(t.get("status"), int) and t["status"] < 400),
    "tests": tests
}

with open("/home/ubuntu/persona-db/api/test-results-2026-07-17.json", "w") as f:
    json.dump(output, f, ensure_ascii=False, indent=2)

passed = output["passed"]
total = output["total"]
print(f"\n{'='*50}")
print(f"Result: {passed}/{total} passed")
print(f"Saved: api/test-results-2026-07-17.json")
sys.exit(0 if passed == total else 1)
