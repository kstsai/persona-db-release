"""
persona_matcher.py — Natural language → dimension parsing + persona filtering.

Uses keyword-based matching to parse enduser descriptions into dimension filters,
then filters the 1069 persona JSON accordingly.

Two modes:
  1. NL mode: parse enduser text → dimension filters → filter personas
  2. Direct mode: accept explicit dimension JSON → filter personas
"""

import json, re, os, logging
from collections import Counter

logger = logging.getLogger(__name__)

# ── Dimension keywords ──────────────────────────────────────────────

AGE_KEYWORDS = {
    "0-11":  ["小學", "國小", "兒童", "小孩", "孩童", "0-11"],
    "12-18": ["中學", "國中", "高中", "青少年", "12-18", "teen"],
    "19-24": ["大學", "大學生", "19-24", "20出頭", "年輕"],
    "25-34": ["25-34", "25到34", "20多歲", "30左右", "年輕上班族"],
    "35-44": ["35-44", "35到44", "30多歲", "40左右", "中年", "青壯"],
    "45-54": ["45-54", "45到54", "40多歲", "50左右"],
    "55-64": ["55-64", "55到64", "50多歲", "60左右", "熟齡"],
    "65+":    ["65", "65以上", "老年", "長者", "銀髮"],
}

SEX_KEYWORDS = {
    "男": ["男", "男性", "先生", "男生"],
    "女": ["女", "女性", "女士", "小姐", "女生", "婦女"],
}

REGION_KEYWORDS = {
    "都會區(六都)": ["六都", "直轄市", "台北", "新北", "桃園", "台中", "台南", "高雄"],
    "北部": ["北部", "北台灣", "基隆", "新竹", "苗栗", "宜蘭"],
    "中部": ["中部", "中台灣", "彰化", "南投", "雲林"],
    "南部": ["南部", "南台灣", "嘉義", "屏東"],
    "花東": ["花蓮", "台東", "花東"],
    "離島": ["離島", "澎湖", "金門", "連江"],
}

CITY_KEYWORDS = {
    "台北市": ["台北", "臺北", "天龍"],
    "新北市": ["新北", "板橋", "中和", "永和", "新店"],
    "桃園市": ["桃園", "中壢"],
    "台中市": ["台中", "臺中", "逢甲"],
    "台南市": ["台南", "臺南"],
    "高雄市": ["高雄", "雄中"],
    "新竹市": ["新竹市"],
    "新竹縣": ["新竹縣", "竹北", "竹東"],
    "基隆市": ["基隆"],
    "嘉義市": ["嘉義市"],
    "嘉義縣": ["嘉義縣"],
}

OCC_KEYWORDS = {
    "科技":   ["科技", "工程師", "IT", "軟體", "硬體", "半導體", "電子", "程式", "數位", "資訊"],
    "金融":   ["金融", "銀行", "保險", "證券", "財經", "投信", "理財專員"],
    "服務":   ["服務", "餐飲", "零售", "sales", "業務", "店員", "門市", "銷售"],
    "製造":   ["製造", "工廠", "生產", "作業員", "傳產", "工程", "技術員"],
    "教育":   ["教育", "老師", "教授", "教師", "補習", "講師", "教職"],
    "醫療":   ["醫療", "醫生", "護士", "藥師", "醫", "護理", "診所"],
    "公務":   ["公務", "公職", "公家", "公部門", "軍公教", "公務員", "國營"],
    "employment_status": ["雇主", "老闆", "創業", "自營", "攤商", "小生意", "無酬家屬", "自家店", "自家工廠"],
    "家管":   ["家管", "主婦", "主夫", "全職媽媽", "家庭主婦", "全職爸爸", "家管"],
    "學生":   ["學生", "在學", "大學生", "研究生", "在學中", "進修"],
    "退休":   ["退休", "已退休", "屆退"],
    # 上班族 → 對應到多個職業 (OR logic across these)
    "上班族": ["上班族", "白領", "受薪", "職場"],
}

INCOME_KEYWORDS = {
    "無收入": ["無收入", "沒有收入"],
    "<3萬":   ["低收", "低薪", "3萬以下"],
    "3-8萬":  ["中產", "3到8萬", "一般收入", "上班族薪水"],
    ">8萬":   ["高收", "8萬以上", "高薪", "高階", "主管"],
}

MARRIAGE_KEYWORDS = {
    "未婚": ["未婚", "單身", "沒結婚"],
    "已婚": ["已婚", "結婚", "有配偶", "有家庭"],
    "離婚": ["離婚", "離異"],
    "鰥寡": ["鰥寡", "喪偶", "寡婦"],
}

FAMILY_KEYWORDS = {
    "1":  ["獨居", "一個人住", "單身"],
    "2":  ["夫妻", "兩人", "頂客", "dink", "新婚"],
    "3":  ["小家庭", "三口", "一家三口"],
    "4":  ["四口", "兩個小孩", "一家四口"],
    "5+": ["五口", "大家庭", "三個小孩", "一家五口", "兒女成群"],
}


def llm_filters_to_dimension_filters(llm_result: dict) -> dict:
    """
    Convert LLM question-analysis output into persona_matcher dimension filters.
    
    LLM output format:
    {
      "filters": {
        "age": ["25-34", "35-44"],
        "occupation": ["科技", "金融", "服務"],
        "sex": [],
        "residence": [],
        "income": [">8萬", "3-8萬"],
        "marriage": []
      }
    }
    """
    filters = {}
    llm_filters = llm_result.get("filters", {})
    
    # Valid dimension keys in persona DB
    valid_dims = {
        "age", "sex", "region", "residence", "education",
        "occupation", "income", "politics", "media_diet",
        "family_size", "family_income", "hobby", "marriage",
        "commute_mode", "clothing_spend", "housing_cost", "housing_burden",  # #54: housing_cost 原漏（prompt 已指示使用，卻被靜默丟棄）
        "aesthetic_procedure",
        "debt_status",
        "employment_status",
    }
    
    for dim, values in llm_filters.items():
        if dim not in valid_dims:
            continue
        if not values or not isinstance(values, list):
            continue
        # Clean and validate values (#33: LLM 常對數值型維度回 int，如 family_size=[3,4])
        clean = [s for s in (_coerce_filter_value(v) for v in values) if s]
        if clean:
            filters[dim] = clean
    
    return filters


def _coerce_filter_value(v) -> str:
    """把 LLM 回傳的單一 filter 值正規化為字串 (#33)。

    LLM 對數值型維度（family_size / age / housing_cost 等）常直接回數字
    （`{"family_size": [3, 4]}`），舊版直接呼叫 `v.strip()` → AttributeError →
    server 轉 HTTP 500，整個 query 失敗（issue #33；與 #14 的 dim_importance
    型別漂移同一類：LLM 結構化輸出的純量型別不可信）。

    DB 的值本身是字串（"3"），故 str(3) == "3" 能正確 match，不需維度特判。
    非純量（None / bool / dict / list）一律丟棄，避免污染 filters。
    """
    if v is None or isinstance(v, bool):
        return ""
    if isinstance(v, (int, float, str)):
        return str(v).strip()
    return ""


def _match_keywords(text: str, keyword_map: dict) -> list[str]:
    """Return matched keys from a keyword map, sorted by match count desc."""
    scores = {}
    for key, kws in keyword_map.items():
        count = sum(1 for kw in kws if kw.lower() in text.lower())
        if count > 0:
            scores[key] = count
    return sorted(scores, key=scores.get, reverse=True)


def parse_age_range(text: str) -> list[str]:
    """Parse age descriptions that may span multiple brackets.
    
    Examples:
      '25-40' → ['25-34', '35-44']
      '30-50' → ['25-34', '35-44', '45-54']
      '20多歲' → ['19-24', '25-34']
      'young' → ['19-24', '25-34', '35-44']
    """
    result = []
    
    # Try number ranges like "25-40", "30-50"
    range_match = re.search(r'(\d{2})\s*[-–]\s*(\d{2})', text)
    if range_match:
        lo, hi = int(range_match.group(1)), int(range_match.group(2))
        brackets = [
            ("0-11", 0, 11), ("12-18", 12, 18), ("19-24", 19, 24),
            ("25-34", 25, 34), ("35-44", 35, 44), ("45-54", 45, 54),
            ("55-64", 55, 64), ("65+", 65, 120),
        ]
        for key, b_lo, b_hi in brackets:
            if lo <= b_hi and hi >= b_lo:
                result.append(key)
        return result
    
    # Try keyword matching
    kw_matches = _match_keywords(text, AGE_KEYWORDS)
    if kw_matches:
        # Expand adjacent brackets for fuzzy ranges
        all_brackets = ["0-11", "12-18", "19-24", "25-34", "35-44", "45-54", "55-64", "65+"]
        for m in kw_matches:
            if m in all_brackets:
                result.append(m)
                # If "25-34" was matched and the text has something like "多歲" or "左右"
                idx = all_brackets.index(m)
                if '多歲' in text or '左右' in text or '出頭' in text:
                    if idx > 0: result.append(all_brackets[idx - 1])
                    if idx < len(all_brackets) - 1: result.append(all_brackets[idx + 1])
    
    return list(set(result))  # dedupe


def parse_enduser(text: str) -> dict:
    """Parse natural language enduser description into dimension filters."""
    filters = {}

    # Age — try range parsing first
    age_matches = parse_age_range(text)
    if not age_matches:
        age_matches = _match_keywords(text, AGE_KEYWORDS)
    if age_matches:
        filters["age"] = age_matches[:3]

    sex_matches = _match_keywords(text, SEX_KEYWORDS)
    if sex_matches:
        filters["sex"] = [sex_matches[0]]

    region_matches = _match_keywords(text, REGION_KEYWORDS)
    if region_matches:
        filters["region"] = region_matches[:2]

    city_matches = _match_keywords(text, CITY_KEYWORDS)
    if city_matches:
        filters["residence"] = city_matches[:3]

    occ_matches = _match_keywords(text, OCC_KEYWORDS)
    if occ_matches:
        # Special handling: "上班族" is a meta-category → expand to multiple occupations
        if "上班族" in occ_matches:
            occ_matches.remove("上班族")
            # Add common office-worker occupations
            for occ in ["科技", "金融", "服務", "製造", "公務", "教育", "醫療"]:
                if occ not in occ_matches:
                    occ_matches.append(occ)
        filters["occupation"] = occ_matches[:5]

    income_matches = _match_keywords(text, INCOME_KEYWORDS)
    if income_matches:
        filters["income"] = [income_matches[0]]

    marriage_matches = _match_keywords(text, MARRIAGE_KEYWORDS)
    if marriage_matches:
        filters["marriage"] = [marriage_matches[0]]

    family_matches = _match_keywords(text, FAMILY_KEYWORDS)
    if family_matches:
        filters["family_size"] = [family_matches[0]]

    return filters


def filter_personas(personas: list[dict], filters: dict) -> list[dict]:
    """
    Filter personas by dimension filters.
    Each filter value is a list of acceptable values (OR logic within a dimension).
    Dimensions not mentioned are ignored (no filter).
    Handles both string and list-type dimensions (e.g. hobby is a list).
    """
    results = []
    # Dimensions stored as lists in persona DB
    list_dims = {"hobby"}
    
    for p in personas:
        d = p.get("dimensions", {})
        match = True
        for dim, accepted in filters.items():
            val = d.get(dim, "")
            
            if dim in list_dims and isinstance(val, list):
                # List-type: check if ANY accepted value is in the persona's list
                if not any(v in val for v in accepted):
                    match = False
                    break
            else:
                # String-type: standard comparison
                if isinstance(accepted, list):
                    if val not in accepted:
                        match = False
                        break
                else:
                    if val != accepted:
                        match = False
                        break
        if match:
            results.append(p)
    return results


def get_important_dimensions(personas: list[dict]) -> list[dict]:
    """Analyze which dimensions vary most in the result set."""
    if not personas:
        return []
    
    important = []
    score_dims = {
        "age": AGE_KEYWORDS,
        "sex": SEX_KEYWORDS,
        "region": REGION_KEYWORDS,
        "occupation": OCC_KEYWORDS,
        "income": INCOME_KEYWORDS,
        "family_income": None,
        "commute_mode": None,
        "clothing_spend": None,
        "housing_burden": None,
        "aesthetic_procedure": None,
        "debt_status": None,
        "employment_status": None,
    }
    
    for dim, _ in score_dims.items():
        values = Counter()
        for p in personas:
            v = p.get("dimensions", {}).get(dim, "")
            if v:
                values[v] += 1
        if len(values) > 1:  # Only include if there's variety
            important.append({
                "dim": dim,
                "values": [v for v, _ in values.most_common(5)]
            })
    
    return important


def format_matched_criteria(filters: dict) -> str:
    """Human-readable summary of the parsed filters."""
    parts = []
    for dim, vals in filters.items():
        parts.append(f"{dim}:{'/'.join(vals)}")
    return ", ".join(parts)


# ── Relevance Scoring ─────────────────────────────────────────────

_dim_weights = None
_dim_weights_meta = None


def load_dim_weights() -> dict:
    """Load dim_weights.json (regen 產物) — graceful degradation if missing."""
    global _dim_weights
    if _dim_weights is not None:
        return _dim_weights
    path = os.environ.get(
        "DIM_WEIGHTS_PATH",
        os.path.join(os.path.dirname(__file__), "..", "dim_weights.json")
    )
    if os.path.exists(path):
        with open(path) as f:
            data = json.load(f)
        _dim_weights = {k: v for k, v in data.items() if not k.startswith("_")}
    else:
        _dim_weights = {}
        logger = logging.getLogger("persona_matcher")
        logger.warning(f"dim_weights.json not found at {path} — scoring disabled")
    return _dim_weights


def load_dim_weights_meta() -> dict:
    """Load `_meta` from dim_weights.json（#44）。

    刻意與 `load_dim_weights()` 分開：後者會剝掉 `_meta`（讓計分只看得到維度），
    但分數可溯性需要 `_meta.version`（= 產生權重表時的資料版號）。
    取不到時回 {}（graceful）。
    """
    global _dim_weights_meta
    if _dim_weights_meta is not None:
        return _dim_weights_meta
    path = os.environ.get(
        "DIM_WEIGHTS_PATH",
        os.path.join(os.path.dirname(__file__), "..", "dim_weights.json")
    )
    try:
        with open(path) as f:
            _dim_weights_meta = (json.load(f).get("_meta") or {})
    except Exception:
        _dim_weights_meta = {}
    return _dim_weights_meta


def tier_match(persona_val, filter_vals, dim: str) -> float:
    """
    How close is persona_val to any of the filter target values for this dim.
    
    Ordered dims (age, income, clothing_spend, housing_cost, family_income):
        same tier → 1.0, 1 away → 0.7, 2 away → 0.4, 3+ away → 0.1
    
    Nominal dims (occupation, residence, etc):
        in filter → 1.0, not in → 0.0
    
    hobby (list dim): max tier_match across persona's hobbies
    """
    if persona_val is None:
        return 0.0
    
    # Ordered dimensions with defined tiers
    ORDERED_TIERS = {
        "age": ["0-11", "12-18", "19-24", "25-34", "35-44", "45-54", "55-64", "65+"],
        "income": ["無收入", "<3萬", "3-8萬", ">8萬"],
        "family_income": ["<1萬", "1-3萬", "3-5萬", "5-7萬", "7萬", ">8萬"],
        "clothing_spend": ["<500", "500~1500", "1500~3000", "3000~5000", ">5000"],
        "housing_cost": ["<5千", "5千~1.5萬", "1.5萬~3萬", "3萬~5萬", ">5萬"],
    }
    
    if dim in ORDERED_TIERS:
        tiers = ORDERED_TIERS[dim]
        # Persona value must be in the tier list
        p_idx = tiers.index(persona_val) if persona_val in tiers else -1
        if p_idx < 0:
            return 0.0
        # Find closest filter value distance
        min_dist = float("inf")
        for fv in filter_vals:
            f_idx = tiers.index(fv) if fv in tiers else -1
            if f_idx >= 0:
                min_dist = min(min_dist, abs(p_idx - f_idx))
        if min_dist == float("inf"):
            return 0.0
        # Distance → match score
        if min_dist == 0:
            return 1.0
        elif min_dist == 1:
            return 0.7
        elif min_dist == 2:
            return 0.4
        else:
            return 0.1
    
    # Hobby (list dim)
    if dim == "hobby":
        if isinstance(persona_val, list):
            best = 0.0
            for h in persona_val:
                if h in filter_vals:
                    best = max(best, 1.0)
            return best
        return 1.0 if persona_val in filter_vals else 0.0
    
    # Nominal dims
    if isinstance(filter_vals, list):
        return 1.0 if persona_val in filter_vals else 0.0
    return 1.0 if persona_val == filter_vals else 0.0


def _to_float(v, default=0.5):
    """Coerce dim_importance values (LLM may return strings like '0.95' or ranges)."""
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        v = v.strip()
        # Handle range strings like "0.0~1.0" or "0.8"
        import re
        m = re.match(r"(\d+\.?\d*)", v)
        if m:
            return float(m.group(1))
    return default


_MISSING_WEIGHT_DIMS_WARNED = set()


def _rarity_weight(weights: dict, dim: str, value, accepted: list = None) -> float:
    """Look up the rarity weight for one (dim, value) pair (#35).

    Fallback is **1.0 (neutral), not 0.0**. A dim missing from `dim_weights.json`
    is a *structural gap* (typically a newly added filterable dimension whose weight
    table was not regenerated — the dim-20/21/22 case in #35). The old 0.0 fallback
    made such dims filter-only / never-affect-ranking **with no error surface**, and
    also made `dims_counted` under-report. Weight values are normalized into
    [0.5, 2.0] / [0.8, 1.4]; 0.0 is never an intended weight.
    """
    w = weights.get(dim)
    if not w:
        if dim not in _MISSING_WEIGHT_DIMS_WARNED:
            _MISSING_WEIGHT_DIMS_WARNED.add(dim)
            logger.warning(
                "dim '%s' 不在 dim_weights.json（權重表未涵蓋）→ rarity fallback 1.0；"
                "請把該維度加進 scripts/gen_dim_weights.py 的 SCORED_DIMS 後重跑權重表（#35）",
                dim,
            )
        return 1.0
    if isinstance(value, list):  # list-valued dim (hobby)
        pool = [x for x in value if accepted is None or x in accepted]
        return max((w.get(x, 1.0) for x in pool), default=1.0)
    if not value:
        return 1.0
    return w.get(str(value), 1.0)


def scored_dims(filters: dict, dim_importance: dict = None, relaxed_dims: list = None,
                weights: dict = None) -> list:
    """Declare exactly which dims `score_persona()` consumes (#35).

    Single source of truth for `scoring_basis.dims_counted`: the score sums over
    (a) every dim in `filters` — including relaxed ones (tier_match partial credit
    is intentionally kept, Q3-A'), and (b) every dim in `dim_importance` that is not
    already in `filters`. Dims absent from the weight table are still scored via the
    1.0 fallback, so they are listed as well — the old `filters ∩ dim_weights` filter
    silently dropped new dims.
    """
    weights = weights if weights is not None else load_dim_weights()
    if not weights:
        return []
    dim_importance = dim_importance or {}
    relaxed_dims = relaxed_dims or []
    dims = list(filters.keys())
    for d in dim_importance:
        if d in filters or d in relaxed_dims:
            continue
        dims.append(d)
    return dims


def score_persona(persona: dict, filters: dict, dim_importance: dict = None, relaxed_dims: list = None) -> float:
    """
    Relevance score: Σ importance[dim] × tier_match(value, target) × rarity_weight.
    
    - dim_importance: per-dim weight from LLM (0.0-1.0). If None, defaults to 0.5.
    - tier_match: how close persona's value is to filter target (uses ORIGINAL filters,
      including relaxed dims — partial credit for nearby values)
    - rarity_weight: log-frequency weight from dim_weights.json
    - For dims NOT in filters but IN dim_importance: use importance × 0.5 as baseline
      (no tier_match since no target to compare against)
    """
    relaxed_dims = relaxed_dims or []
    dim_importance = dim_importance or {}
    weights = load_dim_weights()
    if not weights:
        return 0.0

    dims = persona.get("dimensions", {})
    s = 0.0
    
    # Score filter dims (including relaxed — with tier_match)
    for dim, accepted in filters.items():
        v = dims.get(dim)
        imp = _to_float(dim_importance.get(dim, 0.5))
        # tier_match uses ORIGINAL filter values (relaxed dims included)
        tm = tier_match(v, accepted, dim)
        # rarity_weight（#35: 缺權重的維度 fallback 1.0，不再靜默乘 0）
        rw = _rarity_weight(weights, dim, v, accepted)
        s += imp * tm * rw
    
    # Score dim_importance dims NOT in filters (baseline: imp × 0.5 × rarity)
    for dim, imp in dim_importance.items():
        if dim in filters or dim in relaxed_dims:
            continue  # already scored above
        imp_f = _to_float(imp)
        v = dims.get(dim)
        rw = _rarity_weight(weights, dim, v)
        s += imp_f * 0.5 * rw  # baseline: no target, so 0.5 × importance

    return round(s, 4)


def sort_by_score(personas: list, filters: dict, dim_importance: dict = None, relaxed_dims: list = None) -> list:
    """
    Stable sort by relevance score (desc). Ties keep DB order (issue #4 Q7-A).
    """
    if not personas:
        return []
    scored = [(p, score_persona(p, filters, dim_importance, relaxed_dims)) for p in personas]
    scored.sort(key=lambda x: x[1], reverse=True)
    return [p for p, _ in scored]


# ── Singleton ──────────────────────────────────────────────────────

_persona_db = None


def load_persona_db(path: str = None) -> list[dict]:
    """Load the persona DB JSON. Uses PERSONA_DB_PATH env var or default."""
    global _persona_db
    if _persona_db is not None:
        return _persona_db
    
    if path is None:
        path = os.environ.get(
            "PERSONA_DB_PATH",
            os.path.join(os.path.dirname(__file__), "..", "tw_persona_1069.json")
        )
    
    with open(path) as f:
        _persona_db = json.load(f)
    
    # Build index by numeric ID too
    return _persona_db


def get_persona_by_id(persona_id: str) -> dict | None:
    """Find a persona by string ID (TW-P-XXXX) or numeric index."""
    db = load_persona_db()
    
    # Try direct lookup by id field
    for p in db:
        if p.get("id") == persona_id:
            return p
    
    # Try numeric index
    try:
        idx = int(persona_id) - 1
        if 0 <= idx < len(db):
            return db[idx]
    except ValueError:
        pass
    
    return None
