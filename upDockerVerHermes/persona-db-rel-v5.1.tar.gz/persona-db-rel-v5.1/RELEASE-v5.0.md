# Persona DB v5.0 Release Notes

> 日期: 2026-09-02 | 上一版: v4.9.3 | 類型: feature（新增 dimension 20 醫美療程經歷 + L2 filterable）

## 重點：Dimension 20 — 醫美療程經歷（近 12 個月）

甲方提供 ISAPS Global Survey 2024（p24 Chinese Taipei）資料，新增二元維度 `aesthetic_procedure`（無/有）：

- **語意**: 過去 12 個月有進行至少一次醫美療程（注射或手術型皆算）
- **來源**: ISAPS Global Survey 2024 p24 — 台灣年療程總數 658,320 → 全年齡年盛行率 ~2.8%（procedures ≠ patients，實際患者盛行率低於此）
- **實作**: **in-place annotation**（`_annotate_aesthetic.py`）於 v4.9.3 資料上，非重抽 — 原 19 維不動
- **Segment rates**（sex × age × income 條件化，甲方確認）: 女25-44 6% / 女45-64 3% / 女19-24 2% / 女65+ 0.5% / 男 0.5% / 0-18 與無收入 = 0
- **結果**: 16/1069 筆「有」（1.50%）— segment 達成率符合（女19-24 因 20 人 eligible × 2% = 0.4 → quota 0，已知限制）
- **API**: L2 filterable（valid_dims + PersonaSummary + 兩處 prompt + domain reinforcement 醫美/美容/整形/皮膚科）
- **Coherence**: 0-18 全無、無收入全無（QA 驗證）

## 附帶：regen 確定性修復（#31）

- `pick_hobbies` `list(chosen)` → `sorted(chosen)`（set 迭代受 PYTHONHASHSEED 影響 → 同 seed 兩次 regen 差 884 筆）
- v5.0 資料 base = #31-fixed regen（sorted hobby，可重現）；與 v4.9.3 差異 = 724 筆 hobby 純順序 + 14 筆科技業次要 hobby（良性，打電動保留）+ 新維度
- regen SOP 新增 determinism gate（`docs/regen-sop.md`）

## 版本鏈

```
v4.9.0 (retry firewall) → v4.9.1 (overshoot) → v4.9.2 (coherence 三連修)
→ v4.9.3 (ordering #30) → v5.0 (dimension 20 醫美 + #31 determinism)
```

## QA 狀態

此版供 QA 驗證（lzcdh1 pre-release SOP — 含新 case 6 醫美 query），若有必要再進版。
