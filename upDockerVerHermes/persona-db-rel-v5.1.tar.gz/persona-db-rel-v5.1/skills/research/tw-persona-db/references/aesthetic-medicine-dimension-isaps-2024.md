# 醫美維度候選資料 — ISAPS 2024 Chinese Taipei (Taiwan) + 設計方向

> 2026-09-02 甲方提供 `isaps-global-survey-2024.pdf`（repo 根目錄），p24 = Chinese Taipei 國家 profile。
> 用途：評估新增 dimension 20「醫美/美容療程經歷」。設計尚未定案 — 先記資料與決策方向。

## 資料摘要（p24，全文已驗證）

| 類別 | 數量 | 佔比 |
|:----|:----|:----|
| 總療程數 | 658,320/年 | — |
| 手術型 | 257,480 | 39% |
| 非手術型（注射/雷射等） | 400,840 | 61% |

Top 手術：眼皮手術 68,473（26.6%）> 臉部補脂 36,236（14.1%）> 隆乳 27,822（10.8%）> 抽脂 17,993（7.0%）> 疤痕修復 17,326
Top 非手術：肉毒 177,846（44.4%）> 玻尿酸 85,882（21.4%）> 除毛 37,069 > 緊膚 33,903
（PDF 內其他頁有 procedure-type 世界排名表 + 執行場所分布 — 引用時以 p24 country profile 為準）

## ⚠️ 三個資料轉換挑戰（引用時必須誠實）

1. **ISAPS 是「年療程量」不是「人口盛行率」** — 658,320 / ~2,340 萬人口 ≈ 每年 **2.8% 人口至少一次療程**（一人可多次，實際人數更低）。維度語意若為「過去 12 個月醫美消費者」可直接對應 2.8%；若為「一輩子做過」需累積盛行率假設（會高不少）。
2. **ISAPS 無 Taiwan 年齡/性別/收入 breakdown** — 誰做醫美（性別年齡收入分布）需合理假設 + 用既有維度條件化，不能假裝精確。
3. **ISAPS 是醫師自報量** — Taiwan 數字歷年偏高（高估風險）。引用標「ISAPS 2024」，別當 DGBAS 等級官方統計。

## 維度設計方向（甲方：根據佔人口比例選適合的人改）

- **tier 草案**：無 / 僅注射型（肉毒/玻尿酸）/ 有手術型（眼皮/隆乳/抽脂等）
- **必須 segment-conditioned**（性別/年齡/收入條件化），不能隨機挑 2.8% — 否則做出「0-11 打肉毒」荒謬人設。實測已知 LLM filter 系統性偏成年，但 generator 條件化是另一回事
- 女性 25-44 + 可支配所得 → 較高機率；男性 → 極低（真實男性手術：gynecomastia 5,748）；0-18 → 0（QA rule）；手術型需更高收入門檻
- 用途若為行銷客群 → filterable（API 3 層 + SCORED_DIMS），同 clothing_spend 模式

## 加維度到已 release DB：in-place annotation vs full regen

**建議：in-place annotation（deterministic post-process script），不要 full regen**。理由：
- full regen（seed 42）：現有 19 維全重抽 → v4.9.3 的 QA 驗證全作廢、regen 可能引入新 coherence 問題
- in-place：現有維度完全不動（v4.9.3 驗證仍有效），只在 segment 內選擇性加註；script 自帶 seed → 可重現（同 regen SOP 的 determinism 原則）
- annotation 不得改動既有欄位（要 coherence 就靠「條件化選 segment」，不靠事後改值）

## 待 grill-me 問題（RFC-first，先定案再 implement）

1. 維度語意：過去 12 個月消費者（→2.8% 直接對應）vs 一輩子做過（→需累積盛行率假設）？
2. tier 粒度：無 / 僅注射 / 有手術 夠嗎？
3. segment rates 誰定：甲方有 market research？還是 ISAPS 比例 + 既有維度條件化推？
4. 要 filterable（API 3 層 + SCORED_DIMS）還是先純資料維度？
