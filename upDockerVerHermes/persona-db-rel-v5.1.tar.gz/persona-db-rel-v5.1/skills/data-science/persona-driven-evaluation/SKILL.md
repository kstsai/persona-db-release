---
name: persona-driven-evaluation
description: >-
  Use Persona DB personas as test probes for LLM evaluation. Covers spawn-agent survey
  simulation (self-mode vs encounter-mode), brand visibility analysis across demographics,
  and multi-scenario testing to assess LLM recommendation bias and coverage.
domain:
  - persona-db
  - llm-evaluation
  - brand-visibility
  - survey-simulation
---

# Persona-Driven LLM Evaluation

Evaluate how an LLM responds to different demographic profiles by using **persona DB personas** as survey probes. This catches **contamination bias** (same-agent) and measures **brand visibility** (encounter-mode).

## When to Use

- User wants to test how an LLM recommends products (banks, insurance, retail) across different user profiles
- User asks for "persona simulation" or "role-playing Q&A" for survey research
- Brand wants to understand its **LLM share of voice** across demographics
- Need to detect **systematic bias** in LLM recommendations (favors certain brands for certain demographics)

## Core Methodology: Spawn Agent (not Same Agent)

### What NOT to do (Same-Agent Contamination)

Running multiple personas in the **same conversation** introduces contamination bias:
- Answers unconsciously converge toward the same brands
- Later personas inherit framing from earlier ones
- Responses are more "template-like", less localized

```python
# BAD: same agent, contaminates
# "I'm 麗華, answer..."
# "I'm 靜怡, answer..."
```

### What to do (Spawn Agent)

Use `delegate_task` to give each persona an **independent sub-agent**:

```python
delegate_task(
    context="...full persona background...",
    goal="Answer as {persona}: {question}",
    role="leaf"
)
```

Each sub-agent:
- Has its own isolated context
- Knows nothing about other personas
- Runs on the configured delegation model (Pro, if set)
- Returns independently when done

## Two Simulation Modes

### ① Self-Simulation (自我模擬)
Sub-agent **IS** the persona, answering the question directly.

**Best for:** Survey response simulation (persona filling out a questionnaire), predicting what a persona would say.

**Pitfall:** Responses can feel template-like with less localized detail.

### ② Encounter Simulation (遭遇模擬) — Preferred for brand analysis
Sub-agent **encounters** the persona asking a question and responds to them as an expert/friend.

**Best for:** Brand visibility analysis, assessing how LLM tailors advice to different demographics. Produces more authentic, locally-grounded responses.

**Why preferred (confirmed by user):**
- Encounter framing forces LLM to explicitly connect brand features to persona needs
- Produces richer localized details (靜怡 mentions 小孩教育費; 淑貞 mentions 轉錢給老公)
- More willing to state negatives ("沒有一家兩個都最高")
- User explicitly prefers this mode for formal brand visibility work

### Recommendation

| Phase | Mode | Why |
|-------|------|-----|
| Quick exploration | **Same-agent ① self-mode** | Fast, cheap, good for direction-finding |
| Formal brand report | **Spawn-agent ② encounter-mode** | Contamination-free, authentic, client-ready |

## Persona Selection Strategy

When building a test set, cover these **6 dimensions**:

| Dimension | Why it matters |
|-----------|---------------|
| **Age** | Different life stages have different product needs |
| **Income** | Affects price sensitivity and product tier preference |
| **Occupation** | Determines financial literacy and product familiarity |
| **Geography** | Regional bank/retail density affects recommendations |
| **Family/Marriage** | Single vs family changes product focus |
| **Education** | Affects how explanations are framed |

**Target:** 6–11 personas for statistically meaningful coverage.
**Tool:** Query `tw_persona_1069.json` filtering on `dimensions` fields.

## Analysis Framework: Brand Visibility Scoring

For each persona response, extract:

| Score | Weight | How to measure |
|-------|--------|----------------|
| **Recommendation rank** | 30% | Is brand first-choice, second-choice, or passing mention? |
| **Context fit** | 25% | Is the recommendation explicitly linked to persona demographics? |
| **Endorsement strength** | 20% | Is the language "strongly recommend" vs "also an option"? |
| **Defense stability** | 15% | Does the recommender hold position when challenged? |
| **Negative mentions** | -10% | Brand mentioned as "don't recommend" or "watch out for" |

**Output:** Per-brand visibility table showing coverage (out of N personas) + average recommendation rank.

## Multi-Scenario Testing

A single question gives limited credibility. Run **multiple scenarios** to see recommendation shifts:

| Scenario | Question focus | What it tests |
|----------|---------------|---------------|
| Savings | "Highest savings rate + free transfers" | Digital vs traditional banks |
| Mortgage | "Lowest mortgage rate + highest LTV" | Public vs private banks, government vs commercial |
| Dual-currency card | "Best dual-currency card, fastest approval" | Credit card issuers, travel banks |
| Mobile payment | "Best LINE Pay/街口 linked card" | Consumer retail banks |
| App UX | "Cleanest mobile banking app, no ads" | Digital experience leaders |

**Key finding: No bank wins all scenarios.** Rankings flip completely when the question changes:

| Bank | 🅰️ Savings 🥇 | 🅱️ Mortgage 🥇 | 🆕 Cards 🥇 |
|:----|:-------------:|:--------------:|:-----------:|
| 台銀 | 73% | 0% | 0% |
| 新青安(政府) | — | 64% | — |
| 台新 | 9% | 0% | 36% |
| 渣打 | 0% | 18% | 0% |

This **scene-dependent visibility** is the most powerful finding to present to clients — it shows that brand rankings are not absolute, but question-contingent.

## Document Review Mode（提案/文件壓力測試，2026-08-29 首例）

Persona 不只當問卷探針 — 也可以**以第一人稱閱讀一份文件並給出買方/使用者視角評論**。實例：lzc-cp BD 提案 v0.3 → 丹尼爾（中小企業 IT 主管）評論 → 提案方依評論修到 v0.4（3 個質疑直接對應 3 個修訂）。

**選人：用 persona-db API 的 `role` 參數（B2B 情境下比直接查 JSON 準）** — role 參數讓 LLM 帶入角色視角產生對應 filters：

```bash
curl -s --get 'http://localhost:8000/personadb/candidates' \
  --data-urlencode 'questions=<主題>' \
  --data-urlencode 'top_k=1' \
  --data-urlencode 'opMode=僅篩選' \
  --data-urlencode 'role=<角色，如 中小企業IT主管>' | jq '.summary[0]'
```

**委派角色扮演評論（sub-agent /w pro model）**：

```python
delegate_task(
    context="你是 <persona 名>（完整人設檔案）。你在評估「<主題>」— 有導入經驗、有決策權。<文件路徑>",
    goal="讀取 <文件路徑>（完整讀完），以 <persona> 第一人稱、買方/使用者角度評論：① 解決了什麼真實痛點 ② 哪些會質疑 ③ 怎麼評估 ④ 想問賣方的 3-5 個問題 ⑤ 會不會買/用。用繁體中文。",
)
```

**輸出形狀（pro model 實測品質）**：角色一致性高（全程維持決策框架：預算/導入複雜度/供應商風險/PoC 驗證）、具體指出文件缺口（定價/SLA 空白、單點風險、lock-in）、自然提出買方問題。等於「提案的客戶視角壓力測試」— 花資源做真實訪談前的低成本替代。

**落地用法**：評論存成 markdown 放文件旁（`<doc>-persona-review-<name>.md`）→ 提案方當 revision roadmap。實測閉環：質疑 → 修訂直接對應（黑盒子質疑 → agent 定位改口；lock-in 質疑 → 資料可攜性章節；實體機藍圖質疑 → 真機納管時程）。

**驗證閉環要查 git（先 pull）**：回報「評論讓提案從 v0.3 改到 v0.4」前，用 `git log --follow -- <file>` 確認修訂真的 commit 了 — 2026-08-30 實例：用 stale clone 斷言「v0.4 不存在」是錯的（a2 在另一台改完已 push，本地沒 pull）。**「repo 中某版本/檔案不存在」這種斷言最危險 — 一定先 `git pull` 再查**（同 persona-db-release-workflow pitfall #6）。

**原稿 + 整理版並列留檔**：sub-agent 原始輸出（delegation cache 是暫存、會被清）要複製進 repo 當 `<name>-raw.md`（原封不動），整理版另存 `<name>.md`（排版易讀），與被評論的文件放同一目錄 — 「提案 ↔ 評論 ↔ 原稿」三檔對照，任何時候查得到。

**敏感內容注意**：評論若給第三方（如甲方）看，先問 user 揭露層級 — 可只講「persona 回饋閉環」流程不洩文件內容，或揭露成案例研究。別自作主張隱藏或揭露。揭露成案例研究時，**誠實列出評論「沒修到」的點**（如定價/SLA 仍空白）反而證明評論的預測力 — 「它點出的缺口只補了一部分」比「評論超準」更有說服力，且把甲方變成共同開發者（邀請一起找可改進處）。

### 可重現性與人設匹配（2026-09-02 實測）

**⚠️ top 1 persona 不穩定 — 「流程可重現、樣本會變」**：同 role+q 連打多次，top 1 每次不同（實測：8/29 top1=丹尼爾；9/2 三次 top1=小艾，丹尼爾 #2-#3 或不在 top 3；total_matched 207-254 浮動）— LLM analysis（temp 0.2）每次產出不同 filters → ranking 跟著變。可重現的是**客群輪廓**（25-34/35-44 高收入科技金融…），不是特定 persona。評論品質看的是「客群視角」，不是「哪個 persona」— 別為了重跑同 persona 而卡住；若要特定 persona（如 demo 要丹尼爾），接受 variance 或換更 specific query。

**API 自然流程產不出錯配 persona（role 參數 = 人設-任務匹配的第一道保險）**：實測 role=中小企業IT主管 + q=邊緣計算 → matched 全是工作年齡成年人；連「q=12歲以下兒童 + role=兒童發展研究員」都回 494 筆**全成年人**（LLM filter 系統性偏「成年讀者/買家」— 童裝 query 也回父母不回小孩）。0-18 persona 在 DB 存在（117 筆 0-11）但 B2B-adjacent query 永遠不出現在 top。

**強制錯配（Daniel-inverse 實驗）→ 無實質輸出**：從 DB 直接抓 0-11 persona（豆豆）餵 sub-agent 評論 B2B 提案 → 小學生對 B2B 控制平面提案沒有可用的買方回饋（角色與任務無交集）。**跑 Document Review 前先問：這個 persona 是這份文件的目標讀者嗎？** 錯配的評論只有對照價值（證明匹配重要），沒有決策價值。

## Recommended Workflow

```python
# 1. Client provides N questions (e.g. 4 banking scenarios)
# 2. Select 6-11 personas covering age/sex/income/region/occupation/education
# 3. For each question-scenario:
#    a. Dispatch delegate_task(context=persona_bg, goal=encounter_question)
#    b. Batch 3 at a time (concurrent limit)
# 4. Extract brand mentions per response
# 5. Score: first-pick=3pts, second=2pts, mention=1pt, negative=-1pt
# 6. Produce cross-scenario visibility matrix
```

## Pitfalls

- **Contamination bias** is invisible if you use the same agent — always spawn sub-agents for formal testing
- **Encounter mode** can inadvertently add the "expert" persona's opinion — design the goal prompt carefully
- **Concurrent limits**: `delegate_task` maxes at 3 concurrent for this user — batch in groups of 3
- **Token cost**: spawn agent costs ~3-4× same-agent (each is a fresh context window)
- **Date-sensitive data**: savings rates, mortgage rates change — note the date in results
- **Model matters**: results differ between GPT, Claude, DeepSeek — note which model was used
- **Language**: sub-agents default to English if context doesn't specify — always include language instruction

## Example Workflow

```python
# 1. Select personas from DB
data = json.load(open("tw_persona_1069.json"))
candidates = [p for p in data if filter_conditions(p["dimensions"])]

# 2. Dispatch batch (3 at a time)
delegate_task(
    tasks=[{"context": ctx, "goal": goal} for ctx, goal in zip(contexts, goals)],
    role="leaf"
)

# 3. Collect results → extract brand mentions → score → produce visibility table
```

## Verification

✅ Spawn agent produces contamination-free responses
✅ Encounter mode produces richer localized details than self-mode
✅ Brand visibility rankings shift predictably when the question changes
✅ Different personas get different recommendations (no false universalization)
