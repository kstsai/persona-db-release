#!/usr/bin/env python3
"""
_annotate_debt.py — Dimension 21 債務背貸狀態 in-place annotation

RFC: tw-persona-db-rfc.md §「債務背貸狀態（dimension 21）」(commit 735c7f0)
Source: JCIC 聯徵中心個人授信統計 (uid=213 pid=190, 2026-03/04)
Decisions (grill-me 2026-09-03): A（存量債務類型）+ A3（房貸 derive、消費債 annotate）+ B1（信貸/卡債合併）
Tiers: 無 / 有房貸 / 有信貸或卡債 / 房貸+消費債（多重）

Design:
- 房貸 tier = DERIVE：prompt_prefix/background_story 含 active 房貸短語
  （房貸還在可負擔範圍 / 房貸壓力很大 / 每個月房貸是最大開銷）→ 有房貸。
  已知限制：persona 房貸盛行率 ~5.9% eligible，低於 JCIC 11.6%（housing 模型非貸款模型，A3 接受）
- 消費債 tier = ANNOTATE：seed 42 確定性；
  有房貸者以 18.7% 條件率（fid=1008 房貸×信貸交叉 422,592/2,259,959 → 多重）
  無房貸 eligible 以 band rate（JCIC 信貸 by 年齡×性別 加權，信貸∪卡債∪車貸 ~union 10%）
- 0-18、無收入 → 無（無還款能力）
Usage:
    python3 _annotate_debt.py            # annotate（先 backup）
    python3 _annotate_debt.py --check    # 驗證
"""
import json
import random
import shutil
import sys
import datetime

SEED = 42
DATA = "tw_persona_1069.json"

MORT_PHRASES = ["房貸還在可負擔範圍", "房貸壓力很大", "每個月房貸是最大開銷"]
MULTI_RATE = 0.187      # 房貸族中也有信貸（fid=1008, 2026-04: 422,592/2,259,959）
NOMORT_CC_RATE = 0.10   # 無房貸 eligible 的消費債基率（信貸 188萬∪卡債∪車貸 ≈ union ~10%）

# 無房貸 eligible 的消費債 band rate（JCIC 信貸 2026-04 年齡×性別分布加權，
# 年齡形狀：<30 高利率低量 → 30-50 高峰 → 60+ 急降；男略高於女）
BAND_RATES = {
    ("男", "19-24"): 0.050, ("男", "25-34"): 0.140, ("男", "35-44"): 0.200,
    ("男", "45-54"): 0.130, ("男", "55-64"): 0.065, ("男", "65+"): 0.015,
    ("女", "19-24"): 0.035, ("女", "25-34"): 0.095, ("女", "35-44"): 0.140,
    ("女", "45-54"): 0.100, ("女", "55-64"): 0.055, ("女", "65+"): 0.010,
}


def _txt(p):
    return str(p.get("prompt_prefix", "")) + str(p.get("background_story", ""))


def has_mortgage(p):
    return any(ph in _txt(p) for ph in MORT_PHRASES)


def cc_rate(sex, age):
    """無房貸 eligible 的消費債 rate。"""
    return BAND_RATES.get((sex, age), NOMORT_CC_RATE)


def annotate(data):
    """回傳 (data, stats)。"""
    rng = random.Random(SEED)
    stats = {"mortgage": 0, "cc_only": 0, "multi": 0, "none": 0, "ineligible": 0}
    for p in data:
        dims = p["dimensions"]
        # 先全標無
        dims["debt_status"] = "無"
        age, income = dims["age"], dims["income"]
        if age in ("0-11", "12-18") or income == "無收入":
            stats["ineligible"] += 1
            continue
        has_m = has_mortgage(p)
        if has_m:
            stats["mortgage"] += 1
            # 有房貸 → 18.7% 條件率加消費債 → 多重
            if rng.random() < MULTI_RATE:
                dims["debt_status"] = "房貸+消費債"
                stats["multi"] += 1
            else:
                dims["debt_status"] = "有房貸"
        else:
            rate = cc_rate(dims["sex"], age)
            if rng.random() < rate:
                dims["debt_status"] = "有信貸或卡債"
                stats["cc_only"] += 1
            else:
                stats["none"] += 1
    return data, stats


def run():
    with open(DATA) as f:
        data = json.load(f)
    bak = f"{DATA}.bak-{datetime.datetime.now():%Y%m%d-%H%M%S}"
    shutil.copy(DATA, bak)
    print(f"💾 備份: {bak}")
    annotated, stats = annotate(data)
    with open(DATA, "w") as f:
        json.dump(annotated, f, ensure_ascii=False, indent=2)
    print(f"✅ 已寫入 {DATA}")
    print(f"   有房貸: {stats['mortgage']} | 多重(房貸+消費債): {stats['multi']} | "
          f"有信貸或卡債: {stats['cc_only']} | 無(eligible): {stats['none']} | 不eligible: {stats['ineligible']}")


def check():
    with open(DATA) as f:
        data = json.load(f)
    problems = []
    for p in data:
        dims = p["dimensions"]
        ds = dims.get("debt_status", "")
        if not ds:
            problems.append(f"{p['id']} 缺 debt_status")
        if dims["age"] in ("0-11", "12-18") and ds != "無":
            problems.append(f"{p['id']} 未成年背債!")
        if dims["income"] == "無收入" and ds != "無":
            problems.append(f"{p['id']} 無收入背債!")
        if "房貸" in ds and not has_mortgage(p):
            problems.append(f"{p['id']} {ds} 但無房貸短語")
    from collections import Counter
    c = Counter(p["dimensions"].get("debt_status", "") for p in data)
    total = len(data)
    print(f"🧪 Check: {total} personas | {dict(c)}")
    if problems:
        for pr in problems[:10]:
            print("  ❌ " + pr)
        sys.exit(1)
    print("✅ 全規則 PASS（0-18/無收入無債、房貸 tier 有短語佐證）")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "run"
    (check if mode == "--check" else run)()
