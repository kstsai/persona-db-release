#!/usr/bin/env python3
"""
_annotate_aesthetic.py — Dimension 20 醫美療程經歷（近 12 個月）in-place annotation

RFC: tw-persona-db-rfc.md §「醫美療程經歷（dimension 20）」(commit 78b982c)
Source: ISAPS Global Survey 2024 p24 Chinese Taipei
Decisions (kstsai + 甲方, 2026-09-02):
  - in-place on v4.9.3 (NOT full regen) — 原 19 維完全不動
  - binary: 無 / 有（過去 12 個月有進行至少一次醫美療程）
  - exact segment quota: count = round(segment_size × rate)（比例精確對表）
  - 0-18 → 無（硬性）; income=無收入 → 無（無可支配所得）
  - seed=42 deterministic

Usage:
    python3 _annotate_aesthetic.py            # annotate tw_persona_1069.json（先 backup）
    python3 _annotate_aesthetic.py --check    # 驗證：0-18/無收入無「有」+ 全體比例
"""
import json
import random
import shutil
import sys
import datetime

SEED = 42
DATA = "tw_persona_1069.json"

# ── Segment rates: (sex, age_tier) → annual prevalence ──
FEMALE_RATES = {
    "19-24": 0.02,
    "25-34": 0.06,
    "35-44": 0.06,
    "45-54": 0.03,
    "55-64": 0.03,
    "65+": 0.005,
}
MALE_RATE = 0.005


def segment_rate(sex: str, age: str, income: str) -> float:
    """回傳該 persona 的目標年盛行率（0 = 不做）。"""
    if age in ("0-11", "12-18"):
        return 0.0          # 未成年硬性不做
    if income == "無收入":
        return 0.0          # 無可支配所得不做（甲方確認）
    if sex == "女":
        return FEMALE_RATES.get(age, 0.0)
    return MALE_RATE        # 男全齡（≥19）


def annotate(data: list) -> tuple:
    """依 segment quota 選人加註 aesthetic_procedure。回傳 (data, quota_stats)。"""
    rng = random.Random(SEED)

    # 先全標「無」
    for p in data:
        p["dimensions"]["aesthetic_procedure"] = "無"

    # 分 segment 收集候選人
    segments: dict = {}
    for p in data:
        dims = p["dimensions"]
        key = (dims["sex"], dims["age"]) if dims["sex"] == "女" else ("男", "全齡")
        segments.setdefault(key, []).append(p)

    quota_stats: dict = {}
    for key in sorted(segments.keys()):
        sex, age_key = key
        cands = segments[key]
        # eligible = segment_rate > 0（0-18 / 無收入自動排除）
        elig = [p for p in cands if segment_rate(p["dimensions"]["sex"], p["dimensions"]["age"], p["dimensions"]["income"]) > 0]
        rate = FEMALE_RATES.get(age_key, MALE_RATE) if sex == "女" else MALE_RATE
        quota = round(len(elig) * rate)
        rng.shuffle(elig)
        for p in elig[:quota]:
            p["dimensions"]["aesthetic_procedure"] = "有"
        quota_stats[f"{sex}/{age_key}"] = {"eligible": len(elig), "quota": quota}

    return data, quota_stats


def run() -> None:
    with open(DATA) as f:
        data = json.load(f)

    bak = f"{DATA}.bak-{datetime.datetime.now():%Y%m%d-%H%M%S}"
    shutil.copy(DATA, bak)
    print(f"💾 備份: {bak}")

    annotated, stats = annotate(data)
    with open(DATA, "w") as f:
        json.dump(annotated, f, ensure_ascii=False, indent=2)

    total = len(annotated)
    you = sum(1 for p in annotated if p["dimensions"]["aesthetic_procedure"] == "有")
    print(f"✅ 已寫入 {DATA}（{total} personas）")
    print(f"   有 = {you}（{you / total * 100:.2f}%）| 無 = {total - you}")
    print("\nSegment 配額（eligible → quota）:")
    for k, v in sorted(stats.items()):
        if v["quota"] > 0 or v["eligible"] > 0:
            pct = f"{v['quota'] / v['eligible'] * 100:.1f}%" if v["eligible"] else "-"
            print(f"  {k}: {v['eligible']} → {v['quota']} ({pct})")


def check() -> None:
    with open(DATA) as f:
        data = json.load(f)
    minors = [p for p in data if p["dimensions"]["age"] in ("0-11", "12-18") and p["dimensions"]["aesthetic_procedure"] == "有"]
    noinc = [p for p in data if p["dimensions"]["income"] == "無收入" and p["dimensions"]["aesthetic_procedure"] == "有"]
    total = len(data)
    you = sum(1 for p in data if p["dimensions"]["aesthetic_procedure"] == "有")
    print(f"🧪 Check: {total} personas | 有={you}（{you / total * 100:.2f}%）| 無={total - you}")
    ok = True
    if minors:
        print(f"  ❌ 0-18 有「有」: {len(minors)} 筆（{[(p['id'], p['dimensions']['age']) for p in minors[:3]]}）")
        ok = False
    else:
        print("  ✅ 0-18 全部「無」")
    if noinc:
        print(f"  ❌ 無收入有「有」: {len(noinc)} 筆")
        ok = False
    else:
        print("  ✅ 無收入全部「無」")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "run"
    if mode == "--check":
        check()
    else:
        run()
