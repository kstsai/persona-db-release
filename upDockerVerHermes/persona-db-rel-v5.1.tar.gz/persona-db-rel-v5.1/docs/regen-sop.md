# Persona DB — Regen SOP（可重現資料生成流程）

> 版本: 1.0 | 日期: 2026-09-02 | 對應 ticket: `.tickets/regen-sop/01-regen-flow-standardization.md`
> 核心原則: **regen 必須可重現**（seed=42 確定性）— 任何 code 變動前先 dryrun，任何 release 前先過 determinism gate

## 為什麼要有這份 SOP

2026-09-02 dryrun 實測抓到 #31：`pick_hobbies` 用 `list(chosen)` 回傳 set → 迭代順序受 PYTHONHASHSEED（每 process 隨機）影響 → **同 seed=42 兩次 regen 差 884/1069 筆**（hobby 順序 churn，擴散到文字欄位）。修復（`sorted(chosen)`，commit `2ff21b7`）後 regen 完全確定，但這個教訓要進流程：**每次 regen 前後都要驗證確定性**，否則 release 的資料不可重現、QA 對比失準。

## 流程

### Step 0: 前置檢查

```bash
cd ~/persona-db
git pull origin main --rebase        # 拿最新 code
git status --short                    # working tree 乾淨（避免混入未 commit 變更）
TZ='Asia/Taipei' date '+%Y-%m-%d'    # 取真實日期（寫報告/備份檔名用）
```

### Step 1: Dryrun（不覆蓋正式資料）

```bash
PERSONA_OUTPUT=/tmp/dryrun_$(date +%Y%m%d).json python3 _generate_997.py
# ~4.5s，無 LLM call；輸出到 /tmp，不碰 tw_persona_1069.json
```

用途：
- code 有變動 → 看差異範圍（對比現行資料）
- code 沒變動 → 確認輸出與現行一致

### Step 2: Determinism Gate（release gate，必過）

```bash
PERSONA_OUTPUT=/tmp/dryrun_a.json python3 _generate_997.py > /dev/null 2>&1
PERSONA_OUTPUT=/tmp/dryrun_b.json python3 _generate_997.py > /dev/null 2>&1
python3 -c "
import json
a = json.load(open('/tmp/dryrun_a.json'))
b = json.load(open('/tmp/dryrun_b.json'))
d = sum(1 for x, y in zip(a, b) if x != y)
print(f'determinism: {d}/1069 差異')
assert d == 0, '❌ generator 非確定性 — 先查 code（set 迭代/hash 依賴）再繼續'
print('✅ determinism gate PASSED')
"
```

**非 0 = 擋下**。找非確定性來源：`grep -n "= set()\|list(set\|set(.*)\|\.add(" _generate_997.py`（#31 就是 `list(set)` 的 case）。

### Step 3: 正式 Regen（確定性 gate 過才做）

```bash
cp tw_persona_1069.json tw_persona_1069.json.bak-$(date +%Y%m%d-%H%M%S)   # 先備份
python3 _generate_997.py                                                    # 覆蓋正式檔
```

### Step 4: 驗證

```bash
# 4a. QA 23 規則（支援傳檔：可先對 dryrun 檔跑）
python3 qa_validate.py /tmp/dryrun_a.json     # dryrun 驗證（可選）
python3 qa_validate.py                         # 正式檔驗證（必跑）→ ALL CHECKS PASSED

# 4b. Contradiction hunt（新基準）
python3 scripts/contradiction_hunt/hunt.py tw_persona_1069.json --skip-llm

# 4c. 已知殘留不回歸（#27/#28/#29/#30）
python3 -c "
import json
d = json.load(open('tw_persona_1069.json'))
def dim(p,k): return p.get('dimensions',{}).get(k)
checks = {
  '#27 未成年房貸': [p for p in d if p.get('age') in ('0-11','12-18') and '房貸' in str(p.get('story',''))],
  '#28 低所得高burden高消費': [p for p in d if dim(p,'housing_burden')=='高' and dim(p,'clothing_spend')=='>5000' and dim(p,'family_income') in ('<1萬','1-3萬')],
  '#29 未成年高服飾': [p for p in d if p.get('age') in ('0-11','12-18') and dim(p,'clothing_spend') in ('>5000','3000~5000')],
  '#30 R-03/R-08': [p for p in d if (dim(p,'family_income') in ('<1萬','1-3萬') and dim(p,'housing_cost') in ('1.5萬~3萬','3萬~5萬','>5萬')) or (dim(p,'family_income')=='1-3萬' and str(dim(p,'family_size'))=='1' and dim(p,'commute_mode')=='汽車')],
}
for k, v in checks.items(): print(f'{k}: {len(v)} 筆', '✅' if not v else '❌ 回歸！')
"
```

### Step 5: 驗證報告

產 `GENERATION-VERIFICATION-<date>-v<X.Y>.md`：
- 分布統計（年齡/區域/性別/縣市覆蓋）
- coherence_fixes counters（regen 輸出已印）
- QA 結果 + 殘留檢查
- 資料來源對照表（DGBAS 等）
- **determinism gate 結果**（證明可重現）

### Step 6: Release 決策

照 persona-db-release-workflow skill：
- 資料/generator 變動 → bump VERSION + do-release.sh
- 「進版供 QA 循環」：fix → 進版 → QA → 有必要再 bump
- 資料沒變（如 #31 修復驗證 0 差異）→ 不需進版，純 code commit

## 檢查清單（每次 regen 後）

- [ ] Dryrun 跑過（差異範圍確認）
- [ ] Determinism gate = 0 差異
- [ ] QA 23 rules ALL PASS
- [ ] #27/#28/#29/#30 殘留 = 0
- [ ] 驗證報告產出
- [ ] Release 決策記錄（進版 or 純 commit）

## 歷史

| 日期 | 事件 |
|:----|:----|
| 2026-09-02 | 本 SOP 建立（#31 教訓：dryrun 抓到非確定性 bug → determinism gate） |
