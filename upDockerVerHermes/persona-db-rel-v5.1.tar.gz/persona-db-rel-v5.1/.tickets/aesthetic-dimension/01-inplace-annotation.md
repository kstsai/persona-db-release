# Ticket — dimension 20 醫美療程經歷：in-place annotation + L2 filterable（v5.0）

**RFC 依據:** `tw-persona-db-rfc.md` §「醫美療程經歷（dimension 20）」（commit 78b982c）
**決策（甲方/kstsai 確認 2026-09-02）:** in-place 不重抽、二元維度、過去 12 個月語意、L2 filterable、v5.0、無收入者不做
**Blocked by:** RFC committed ✅

## Ticket 01 — Annotation script

- [ ] 寫 `_annotate_aesthetic.py`：
  - 讀 `tw_persona_1069.json`（v4.9.3）→ 依 segment rates 選人 → 加 `aesthetic_procedure: 有/無` 到 dimensions
  - Segment rates（RFC）：女19-24=2%、女25-44=6%、女45-64=3%、女65+=0.5%、男=0.5%、0-18=0、無收入=0
  - seed=42 確定性選擇（可重現）
  - 原 19 維完全不動；輸出新檔（或覆蓋前先 backup）
- [ ] Determinism check：連跑兩次 → 0 差異

## Ticket 02 — QA 驗證

- [ ] diff 驗證：只有新維度變，其他欄位 untouched
- [ ] 新 QA rule：0-18 → aesthetic=無；無收入 → 無
- [ ] qa_validate.py 23 rules 仍 ALL PASS
- [ ] 分布報告：有/無 比例 vs segment rates 目標（女25-44 ≈6% 等）

## Ticket 03 — L2 API 整合（filterable）

- [ ] `persona_matcher.py` valid_dims + `get_important_dimensions()` 加 `aesthetic_procedure`
- [ ] `models.py` PersonaSummary 加欄位
- [ ] `server.py` summary builder 讀新欄位
- [ ] `llm.py` QUESTION_ANALYSIS_PROMPT 有效選項加 `aesthetic_procedure: 無/有`
- [ ] `server.py` domain_filters 加 domain reinforcement（醫美/美容/整形/皮膚科 → aesthetic_procedure: [有]）
- [ ] `test-persona-db-api.sh` 加醫美 query test case

## Ticket 04 — Release v5.0

- [ ] VERSION → v5.0
- [ ] RELEASE-v5.0.md
- [ ] do-release.sh（tarball 含新資料 + API code）
- [ ] pre-release SOP（lzcdh1 fresh deploy + test + LLM verify — 醫美 query 驗證）
- [ ] wiki-meeting-digest 產包

## 驗收

- 醫美 query（role=醫美診所行銷, q=醫美療程）→ applied_filters 含 aesthetic_procedure:[有]，top 全為「有」
- 0-18/無收入 persona 無一為「有」
- regen SOP determinism gate 概念套用 annotation script（兩次跑 0 差異）
