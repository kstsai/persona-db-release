# Ticket 01 — Regen Flow 標準化 / SOP 文件化

**What to build:** 把 persona-db regen 流程標準化並寫成一份可執行的 SOP 文件，納入本次 session 的兩個關鍵發現：dryrun 模式（`PERSONA_OUTPUT` env var）與 determinism gate（#31 修復後 regen 應完全可重現）。

**背景（2026-09-02 實測發現）：**
- dryrun 用 `PERSONA_OUTPUT=/tmp/xxx.json python3 _generate_997.py`（不覆蓋正式檔，4.5s，無 LLM call）
- 抓出 #31：`pick_hobbies` 的 `list(chosen)` set 迭代受 PYTHONHASHSEED 影響 → 同 seed 兩次 regen 差 884/1069 筆（已修：`sorted(chosen)`，commit `2ff21b7`，驗證 0 差異）
- 修復後：同 code 兩次 regen = 0 差異（完全確定）；fixed 輸出 vs 現行 v4.9.3 資料 = 0 差異（不需進版）
- qa_validate.py 目前寫死讀 `tw_persona_1069.json`（不支援傳檔）— SOP 需處理 dryrun 階段的 QA 驗證方式

**Blocked by:** None — #31 已修，regen 已確定性

**Status:** ready-for-agent

## 交付內容

- [ ] 寫 `docs/regen-sop.md`（或更新 persona-db-release-workflow skill 的 regen 章節）：
  1. **前置**：git pull、確認 working tree 乾淨、`TZ='Asia/Taipei' date` 取真實日期
  2. **Dryrun**：`PERSONA_OUTPUT=/tmp/dryrun_<date>.json python3 _generate_997.py` → 對比現行資料（code 沒改 → 0 差異）
  3. **Determinism gate（release gate）**：同 code 連跑兩次 → diff 必須 0；非 0 = generator 有非確定性 bug，先修再 regen
  4. **正式 regen**：`cp tw_persona_1069.json tw_persona_1069.json.bak-<date>` → `python3 _generate_997.py`
  5. **驗證**：QA 23 rules（qa_validate.py）→ contradiction hunt（`hunt.py tw_persona_1069.json --skip-llm`）→ 殘留檢查（#27/#28/#29/#30 不回歸）
  6. **報告**：GENERATION-VERIFICATION-<date>-vX.Y.md（distribution + 資料來源表）
  7. **Release 決策**：進版供 QA / 定版
- [ ] 決定 SOP 文件的家：`persona-db/docs/` vs skill reference（`persona-db-release-workflow` skill 的 references/）
- [ ] （可選）qa_validate.py 支援傳資料檔參數，讓 dryrun 檔案也能跑 QA

**Acceptance criteria:**
- SOP 文件存在且照它跑一遍 dryrun + determinism check 全過
- Determinism gate 寫進 release 流程（persona-db-release-workflow skill 或 SOP 明列）
- SOP 文件 commit + push（spec/tickets 先行原則）
