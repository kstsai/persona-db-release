"""
dsl.py — Condition DSL parser (restricted, no code execution).

Supported syntax:
    dim == 'value'
    dim != 'value'
    dim in ['a', 'b', 'c']
    AND, OR, ( )

Parses LLM-generated condition strings into callable predicates.

Usage:
    from dsl import parse_condition
    pred = parse_condition("occupation == '學生' AND income == '>8萬'")
    result = pred({"occupation": "學生", "income": ">8萬"})  # → True

Design: whitelist approach — only the above ops are allowed. No eval,
no imports, no function calls. Malformed input raises DSLSyntaxError.
"""
import re
from operator import eq, ne

# ── Tokenizer ─────────────────────────────────────────────────────

TOKEN_RE = re.compile(r"""
    \s*(?P<logic>AND|OR)\s*       |
    \s*(?P<compare>[=!]=|<[=>]|>=?)\s* |
    \s*(?P<bracket>[\[\]])\s*       |
    \s*(?P<comma>,)\s*               |
    \s*(?P<paren>[()])\s*           |
    \s*(?P<membership>in\s)\s*      |
    '(?P<str>[^']*)'              |
    "(?P<str2>[^"]*)"             |
    (?P<boolean>True|False)       |
    (?P<identifier>[a-zA-Z_][a-zA-Z0-9_]*)
""", re.VERBOSE)

COMP_OPS = {"==", "!=", "<", "<=", ">", ">="}


def tokenize(s: str) -> list[tuple[str, str]]:
    tokens = []
    pos = 0
    while pos < len(s):
        m = TOKEN_RE.match(s, pos)
        if not m:
            raise DSLSyntaxError(f"Unexpected token at position {pos}: ...{s[pos:pos+20]}")
        pos = m.end()
        # Check which named group matched
        matched = None
        for name in ("logic", "compare", "bracket", "comma", "paren", "membership", "str", "str2", "boolean", "identifier"):
            v = m.group(name)
            if v is not None:
                # Normalise string and membership types
                if name == "str2":
                    matched = ("string", v)
                elif name == "membership":
                    matched = ("in", "in")
                elif name == "str":
                    matched = ("string", v)
                else:
                    matched = (name, v)
                break
        if matched:
            tokens.append(matched)
    return tokens


# ── Parser (recursive descent) ────────────────────────────────────

class DSLSyntaxError(Exception):
    pass


def _compare(val, target, op):
    """Compare two values with the given operator. Handles None."""
    if val is None:
        return False
    if op == "==":
        return val == target
    if op == "!=":
        return val != target
    return False


def parse_condition(source: str):
    """
    Parse a condition string → callable predicate function.

    predicate(dimensions: dict) -> bool
    """
    tokens = tokenize(source)
    pos = [0]

    def peek():
        return tokens[pos[0]] if pos[0] < len(tokens) else None

    def consume():
        t = tokens[pos[0]]
        pos[0] += 1
        return t

    def parse_or():
        left = parse_and()
        while peek() and peek()[1] == "OR":
            consume()
            right = parse_and()
            left_fn = left
            left = lambda d, l=left_fn, r=right: l(d) or r(d)
        return left

    def parse_and():
        left = parse_atom()
        while peek() and peek()[1] == "AND":
            consume()
            right = parse_atom()
            left_fn = left
            left = lambda d, l=left_fn, r=right: l(d) and r(d)
        return left

    def parse_atom():
        t = peek()
        if t is None:
            raise DSLSyntaxError("Unexpected end of input")

        # Parens
        if t[0] == "paren" and t[1] == "(":
            consume()  # (
            expr = parse_or()
            t = peek()
            if not t or t[0] != "paren" or t[1] != ")":
                raise DSLSyntaxError(f"Expected ')', got {t}")
            consume()  # )
            return expr

        # Identifier → comparison
        if t[0] != "identifier":
            raise DSLSyntaxError(f"Expected identifier (dimension name), got {t}")
        dim = consume()[1]  # dimension name

        t = peek()
        if not t:
            raise DSLSyntaxError(f"Expected comparison after '{dim}'")

        op_tok = t
        # membership: dim in [...]
        if op_tok[1] == "in":
            consume()  # in
            values = []
            while peek():
                t = peek()
                if t[0] == "string":
                    values.append(consume()[1])
                else:
                    consume()  # skip comma, bracket, etc
                    if t[0] == "bracket" and t[1] == "]":
                        break
            return lambda d, dim=dim, vals=values: d.get(dim) in vals if d.get(dim) else False

        # comparison: dim OP 'value'
        if op_tok[0] in ("compare", "logic"):
            op = consume()[1]
            t = consume()
            if t[0] not in ("string", "identifier", "boolean"):
                raise DSLSyntaxError(f"Expected value after '{dim} {op}', got {t}")
            val = t[1]
            if op in ("==", "!=", "<", "<=", ">", ">="):
                return lambda d, dim=dim, v=val, o=op: _compare(d.get(dim), v, o)

        raise DSLSyntaxError(f"Unexpected token after '{dim}': {op_tok}")

    result = parse_or()
    if pos[0] < len(tokens):
        extra = " ".join(str(t) for t in tokens[pos[0]:])
        raise DSLSyntaxError(f"Extra tokens after end of expression: {extra}")
    return result


# ── Convenience ───────────────────────────────────────────────────

def evaluate(condition: str, dimensions: dict) -> bool:
    """Parse and evaluate a condition string against persona dimensions."""
    pred = parse_condition(condition)
    return pred(dimensions)
