#!/usr/bin/env python3
"""v5.9 regression tests — #57（核心維度保護機制）、#58（status）、#59（503 兩型態 / 列舉）。

決定性、無外部 LLM 呼叫（endpoint 的 LLM 以 fake 替換）。

Run:  python3 scripts/test_v5_9_fixes.py
"""
import sys, os, json, asyncio, logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FAIL = []
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def check(name, cond, detail=None):
    print(("  ✅ " if cond else "  ❌ ") + name + ("" if cond else f"  → {detail}"))
    if not cond:
        FAIL.append(name)


logging.basicConfig(level=logging.WARNING)
import api.llm as llm_mod
import api.server as server_mod
from api.server import _reasoning_protected_dims, _vetoed_dims, _constraint_hint
from api.models import CandidatesResponse, BroadeningAttempt

llm_mod.LLM_CONFIG["api_key"] = "test-key"
db = server_mod.load_persona_db()
server_mod.app.state.db_loaded = True

print("=== #57 ② 分析步驟必要性宣告 → 保護維度 ===")
r1 = "問題關於債務整合貸款方案的目標客戶。需使用 housing_burden、housing_cost、debt_status、family_income 等消費與債務維度來精準篩選。"
cands = {"age", "income", "housing_burden", "housing_cost", "debt_status", "family_income"}
got = _reasoning_protected_dims(r1, cands)
check("含「需使用」的句子 → 四個維度全納入",
      got == {"housing_burden", "housing_cost", "debt_status", "family_income"}, got)
check("未提及的維度不被納入", "age" not in got and "income" not in got, got)
r2 = "這個問題的目標客戶是中年人，可能對金融商品有興趣。"
check("無必要性標記的敍述 → 不納入任何維度", _reasoning_protected_dims(r2, cands) == set(),
      _reasoning_protected_dims(r2, cands))
check("詞界比對：`income` 不得因 `family_income` 的子字串而被納入",
      "income" not in _reasoning_protected_dims("需使用 family_income 篩選。", cands),
      _reasoning_protected_dims("需使用 family_income 篩選。", cands))
check("只認已在 filters 中的維度（保守）",
      _reasoning_protected_dims(r1, {"debt_status"}) == {"debt_status"},
      _reasoning_protected_dims(r1, {"debt_status"}))
check("reasoning 為空 → 空集合", _reasoning_protected_dims("", cands) == set())

print("\n=== #57 ③ veto 判定 ===")
prev = {"debt_status": ["有房貸", "房貸+消費債"], "age": ["35-44"], "income": [">8萬"]}
check("整個維度被移除 → veto",
      _vetoed_dims({"debt_status"}, prev, {"age": ["35-44"], "income": [">8萬"]}) == ["debt_status"])
check("值集縮小 → veto",
      _vetoed_dims({"debt_status"}, prev,
                   {"debt_status": ["有房貸"], "age": ["35-44"], "income": [">8萬"]}) == ["debt_status"])
check("值集替換（非超集）→ veto",
      _vetoed_dims({"debt_status"}, prev,
                   {"debt_status": ["有信貸或卡債"], "age": ["35-44"]}) == ["debt_status"])
check("純新增值（超集）→ 不 veto",
      _vetoed_dims({"debt_status"}, prev,
                   {"debt_status": ["有房貸", "房貸+消費債", "有信貸或卡債"]}) == [])
check("受保護維度值集完全不變 → 不 veto",
      _vetoed_dims({"debt_status"}, prev, dict(prev)) == [])
check("非保護維度被移除 → 不 veto",
      _vetoed_dims({"debt_status"}, prev, {"debt_status": ["有房貸", "房貸+消費債"]}) == [])
check("保護維度不在 filters 中 → 略過（不誤判）",
      _vetoed_dims({"sex"}, prev, {"age": ["35-44"]}) == [])

print("\n=== endpoint 級：#57 保護集三來源（fake LLM）===")


async def _parse(domain, reasoning, filters):
    return {"domain": domain, "reasoning": reasoning, "question_analysis": [],
            "usage_suggestion": None, "filters": filters, "dim_importance": {}}


def _mk_parser(domain, reasoning, filters):
    async def _p(q_list, role=None, distribution=None):
        return await _parse(domain, reasoning, filters)
    return _p


async def _broaden_return(new_filters, protected=None, text="測試放寬"):
    return json.dumps({"broadening": text, "protected_dims": protected or [], "filters": new_filters},
                      ensure_ascii=False)


def _run(parse_fn, llm_fn):
    orig_parse, orig_llm = server_mod.parse_questions_with_llm, llm_mod.call_llm
    server_mod.parse_questions_with_llm = parse_fn
    llm_mod.call_llm = llm_fn
    try:
        loop = asyncio.new_event_loop()
        return loop.run_until_complete(
            server_mod.personadb_candidates(questions="測試用問題", top_k=3, opMode="僅篩選", role=""))
    finally:
        server_mod.parse_questions_with_llm, llm_mod.call_llm = orig_parse, orig_llm


# 案例 07 型態：domain 不含關鍵字、query 原文含「債務」→ query-safe 比對應命中
D07_DOMAIN = "金融/銀行/貸款"
D07_REASON = "問題關於債務整合貸款方案。需使用 housing_burden、housing_cost、debt_status、family_income。"
D07_FILTERS = {"housing_burden": ["中", "高"], "housing_cost": ["5千~1.5萬"],
               "debt_status": ["有房貸", "房貸+消費債"], "family_income": [">8萬"]}


async def _b_remove_debt(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    """模擬第九輪 loop2：移除受保護的 debt_status。"""
    return await _broaden_return({"housing_burden": ["中", "高"], "housing_cost": ["5千~1.5萬"],
                                  "family_income": [">8萬"]},
                                 text="移除 debt_status 維度。該維度非本問題的核心判斷")


async def _b_add_age(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    """合法放寬：新增 income 值（超集）→ 不該被 veto。"""
    return await _broaden_return({"housing_burden": ["中", "高"], "housing_cost": ["5千~1.5萬"],
                                  "debt_status": ["有房貸", "房貸+消費債"], "family_income": [">8萬"],
                                  "income": ["3-8萬", ">8萬"]}, text="新增 income 值")


# query 原文含「債務」→ query-safe 觸發；但端點傳入的是固定 questions，故用含「債務」的 query 重建
def _run_with_query(query, parse_fn, llm_fn):
    orig_parse, orig_llm = server_mod.parse_questions_with_llm, llm_mod.call_llm
    server_mod.parse_questions_with_llm = parse_fn
    llm_mod.call_llm = llm_fn
    try:
        loop = asyncio.new_event_loop()
        return loop.run_until_complete(
            server_mod.personadb_candidates(questions=query, top_k=3, opMode="僅篩選", role=""))
    finally:
        server_mod.parse_questions_with_llm, llm_mod.call_llm = orig_parse, orig_llm


res = _run_with_query("債務整合的目標客戶", _mk_parser(D07_DOMAIN, D07_REASON, D07_FILTERS), _b_remove_debt)
check("query-safe 比對：query 含「債務」→ 保護集含 debt_status（即使 domain 零命中）",
      "debt_status" in (res.protected_dims or []), res.protected_dims)
check("reasoning 必要性宣告亦納入保護集",
      {"housing_burden", "housing_cost", "debt_status", "family_income"} <= set(res.protected_dims or []),
      res.protected_dims)
check("★ 移除受保護維度 → 該輪被還原（applied_filters 保留 debt_status）",
      "debt_status" in (res.applied_filters or {}), res.applied_filters)
check("★ stop_reason == 'protected_veto'", res.broadening_stop_reason == "protected_veto",
      res.broadening_stop_reason)
check("★ 該筆 attempt 標記 protected_veto + vetoed_dims",
      bool(res.broadening_attempts) and res.broadening_attempts[-1].protected_veto
      and res.broadening_attempts[-1].vetoed_dims == ["debt_status"],
      [(b.protected_veto, b.vetoed_dims) for b in (res.broadening_attempts or [])])

res2 = _run_with_query("債務整合的目標客戶", _mk_parser(D07_DOMAIN, D07_REASON, D07_FILTERS), _b_add_age)
check("合法放寬（值集超集）不被 veto",
      all(not b.protected_veto for b in (res2.broadening_attempts or [])),
      [(b.protected_veto, b.vetoed_dims) for b in (res2.broadening_attempts or [])])

# 顧客語意反例：query 含「老闆」但 domain 為餐飲 → 不得保護/套用 employment_status
CUST_FILTERS = {"age": ["35-44"], "occupation": ["服務"]}
res3 = _run_with_query("小吃攤老闆的目標客群",
                       _mk_parser("餐飲/夜市商圈", "目標是攤商的顧客。", CUST_FILTERS),
                       _b_add_age)
check("顧客語意反例：「老闆」不得因 query 比對而保護 employment_status",
      "employment_status" not in (res3.protected_dims or []), res3.protected_dims)

print("\n=== #57 ③ 單調累積：模型自我宣告 ===")


class _SeqLLM:
    """loop1 宣告 protected_dims 並做合法放寬；loop2 移除該維度 → 應被擋。"""
    def __init__(self):
        self.n = 0

    async def __call__(self, prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
        self.n += 1
        if self.n == 1:
            return await _broaden_return({**D07_FILTERS, "income": ["3-8萬", ">8萬"]},
                                         protected=["debt_status"], text="新增 income；宣告 debt_status 不可放寬")
        return await _broaden_return({"housing_burden": ["中", "高"], "housing_cost": ["5千~1.5萬"],
                                      "family_income": [">8萬"]}, text="移除 debt_status")


# 用 query 不含「債務」+ domain 不含關鍵字 → 保護集原本為空，只能靠模型宣告
res4 = _run_with_query("貸款方案的目標客戶",
                       _mk_parser("金融/銀行", "需使用 family_income 與 housing_cost。",
                                  {"housing_burden": ["中", "高"], "housing_cost": ["5千~1.5萬"],
                                   "debt_status": ["有房貸", "房貸+消費債"], "family_income": [">8萬"]}),
                       _SeqLLM())
check("loop1 宣告 → 累積進 protected_dims", "debt_status" in (res4.protected_dims or []), res4.protected_dims)
check("loop2 移除已宣告維度 → veto（自我矛盾被機制擋下）",
      res4.broadening_stop_reason == "protected_veto" and "debt_status" in (res4.applied_filters or {}),
      (res4.broadening_stop_reason, res4.applied_filters))

print("\n=== #57 hint：受保護維度不得列出倍率 ===")
# 用第九輪案例 07 的真實 filter 集（含 age → debt_status lift 7.25×，才會進倍率清單）
HINT_FILTERS = {"age": ["35-44", "45-54", "25-34", "55-64"], "income": [">8萬"],
                "housing_burden": ["中", "高"], "housing_cost": ["5千~1.5萬", "1.5萬~3萬"],
                "family_income": [">8萬"], "debt_status": ["有房貸", "房貸+消費債"]}
_hint_n = len(server_mod.filter_personas(db, HINT_FILTERS))
hint_raw = _constraint_hint(db, HINT_FILTERS, _hint_n)
check("對照：不排除時 debt_status 會出現在倍率清單（v5.8 的誘餌）",
      "`debt_status`：" in hint_raw, hint_raw[:200])
hint = _constraint_hint(db, HINT_FILTERS, _hint_n, core_dims={"debt_status"})
check("受保護維度不出現在倍率清單", "`debt_status`：" not in hint, hint[:200])
check("hint 有「核心維度（已排除，勿放寬）」段並列出該維度",
      "核心維度（已排除，勿放寬）" in hint and "debt_status" in hint, hint[-200:])

print("\n=== #57 ④ 分析步驟結構化宣告（core_dims）===")


async def _parse_with_core(domain, reasoning, filters, core):
    return {"domain": domain, "reasoning": reasoning, "question_analysis": [],
            "usage_suggestion": None, "filters": filters, "dim_importance": {}, "core_dims": core}


def _mk_core_parser(domain, reasoning, filters, core):
    async def _p(q_list, role=None, distribution=None):
        return await _parse_with_core(domain, reasoning, filters, core)
    return _p


BANK_FILTERS = {"age": ["35-44", "45-54"], "income": [">8萬"], "housing_burden": ["中", "高"],
                "family_income": [">8萬"], "debt_status": ["有房貸", "房貸+消費債"]}
BANK_REASON = "問題「房貸優惠方案」指向房貸相關金融產品，目標是已有房貸、想轉貸降息的客戶，因此需以房貸持有、居住負擔與收入能力等維度進行過濾。"
res_bank = _run_with_query("房貸優惠方案",
                           _mk_core_parser("金融/銀行房貸領域", BANK_REASON, BANK_FILTERS, ["debt_status"]),
                           _b_remove_debt)
check("分析步驟宣告 core_dims → 進保護集（即使 reasoning 未點出 dim 名、domain 表也不含）",
      "debt_status" in (res_bank.protected_dims or []), res_bank.protected_dims)
check("★ 銀行房貸題：移除 debt_status 被 veto",
      res_bank.broadening_stop_reason == "protected_veto"
      and "debt_status" in (res_bank.applied_filters or {}),
      (res_bank.broadening_stop_reason, res_bank.applied_filters))
res_bank2 = _run_with_query("房貸優惠方案",
                            _mk_core_parser("金融/銀行房貸領域", BANK_REASON, BANK_FILTERS, []),
                            _b_remove_debt)
check("對照：分析步驟未宣告 core_dims → 不會被保護（來源 ④ 是必要條件）",
      "debt_status" not in (res_bank2.protected_dims or []), res_bank2.protected_dims)
check("core_dims 非 list（LLM 髒輸出）不炸",
      True)
_weird = _run_with_query("房貸優惠方案",
                         _mk_core_parser("金融/銀行房貸領域", BANK_REASON, BANK_FILTERS, "debt_status"),
                         _b_remove_debt)
check("core_dims 為字串（非 list）→ 安全忽略、不炸",
      isinstance(_weird.protected_dims, list), type(_weird.protected_dims))

print("\n=== #58 status：matched=0 不得為 'ok' ===")
NO_MATCH = {"aesthetic_procedure": ["有"], "region": ["火星區"]}


async def _b_noop(prompt, temperature=0.2, max_tokens=2000, model_override=None, return_meta=False):
    return await _broaden_return({**NO_MATCH, "age": ["35-44", "火星年齡"]}, text="加入不存在的值（空轉）")


res5 = _run_with_query("火星市場的目標客戶", _mk_parser("測試", "一般敍述。", NO_MATCH), _b_noop)
check("matched=0 → status != 'ok'", res5.status != "ok", (res5.status, res5.total_matched))
check("matched=0 且提早停止（no_op_limit）仍為 too_strict",
      res5.status == "too_strict" and res5.broadening_stop_reason == "no_op_limit",
      (res5.status, res5.broadening_stop_reason))
check("returned=0 與 pool_exhausted=True 仍在回應中",
      res5.returned == 0 and res5.pool_exhausted is True, (res5.returned, res5.pool_exhausted))

print("\n=== #59 503 兩型態 ===")


def _run_503(status: str, detail: str):
    from fastapi import HTTPException
    llm_mod._set_analysis_status(status, detail)

    async def _empty_parse(q_list, role=None, distribution=None):
        return {}   # 模擬「LLM 失敗或無 filters」→ 關鍵字 fallback 也無結果

    orig = server_mod.parse_questions_with_llm
    server_mod.parse_questions_with_llm = _empty_parse
    try:
        loop = asyncio.new_event_loop()
        loop.run_until_complete(server_mod.personadb_candidates(
            questions="目標客戶", top_k=3, opMode="僅篩選", role=""))
        return None
    except HTTPException as e:
        return e.detail
    finally:
        server_mod.parse_questions_with_llm = orig


det_call = _run_503("call_failed", "ReadTimeout") or {}
check("呼叫失敗 → message 指向 LLM 呼叫失敗", "呼叫失敗" in det_call.get("message", ""), det_call.get("message"))
check("呼叫失敗 → details 指向金鑰/連線且含 error 細節",
      "API key" in det_call.get("details", "") and "ReadTimeout" in det_call.get("details", ""),
      det_call.get("details"))
check("呼叫失敗 → retryable=True", det_call.get("retryable") is True, det_call.get("retryable"))
det_no = _run_503("no_filters", "") or {}
check("回應但無 filter → message 指向問題籠統", "籠統" in det_no.get("message", ""), det_no.get("message"))
check("回應但無 filter → details 建議換問法", "換更具體的問法" in det_no.get("details", ""), det_no.get("details"))
check("回應但無 filter → retryable=False", det_no.get("retryable") is False, det_no.get("retryable"))
check("兩者皆為 FILTER_FAILED 且形狀一致（#47 不回歸）",
      det_call.get("code") == det_no.get("code") == "FILTER_FAILED", (det_call.get("code"), det_no.get("code")))

print("\n=== 契約（OpenAPI / 列舉）===")
sch = CandidatesResponse.model_json_schema()["properties"]
enum = sch["broadening_stop_reason"]["enum"]
check("enum 含 protected_veto", "protected_veto" in enum, enum)
check("enum 仍保留空字串（模型預設值，已文件化）", "" in enum, enum)
check("protected_dims 為 array（可為空）", sch["protected_dims"]["type"] == "array")
att = BroadeningAttempt(loop=1)
check("BroadeningAttempt 向後相容（未帶新欄位可建構）",
      att.model_dump()["protected_veto"] is False and att.model_dump()["vetoed_dims"] == [])
r_old = CandidatesResponse(status="ok", total_matched=1, persona_ids=[1])
check("CandidatesResponse 未帶新欄位仍可建構", r_old.protected_dims == [])

print("\n" + "=" * 62)
print(f"FAILED: {len(FAIL)}" + ("" if not FAIL else " → " + "; ".join(FAIL)))
sys.exit(1 if FAIL else 0)
