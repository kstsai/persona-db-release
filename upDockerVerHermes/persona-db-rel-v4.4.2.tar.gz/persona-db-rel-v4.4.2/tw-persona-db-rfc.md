# [RFC] TW Persona Database — 1069 個台灣人設模板 for GEO Operator

> 狀態：實作中 · 建立日期：2026-07-03 · 最後更新：2026-07-11
> 最新 tag：`persona-v3.1`
> 來源：Hermes Slack 對話記錄（thread「persona-db-dev」）

---

## 動機

建立一個包含 **1069 個**分層抽樣人設（persona templates）的資料庫，代表台灣 2,300 萬人口結構。

用途：**GEO（Generative Engine Optimization）Operator** 在回應各領域問題時，能根據問題類型載入對應的人設視角，提問更精準、回答更到位。

### 適用場景

- 用戶問「竹北市長誰勝算高」→ 載入選區選民人設
- 用戶問「高雄開火鍋店推薦地點」→ 載入當地消費者人設
- 用戶問「推年輕族群信用卡」→ 載入目標客群人設

---

## 核心運作流程

```
用戶提問
    ↓
GEO Operator 掃描 reference_pre_prompt 庫
    ↓  找出匹配的 N 個 persona
載入對應的 prompt_prefix
    ↓
組合多 persona 視角思考
    ↓
產出最終回答
```

---

## 維度設計（通用底層 13 維度）

| # | 維度 | 分層 |
|---|------|------|
| 1 | 年齡 | 0-11 / 12-18 / 19-24 / 25-34 / 35-44 / 45-54 / 55-64 / 65+ |
| 2 | 性別 | 男 / 女 |
| 3 | 區域 | 都會區(六都) / 北部 / 中部 / 南部 / 花東 / 離島 |
| 4 | 教育 | 國中以下 / 高中 / 大學 / 研究所以上 |
| 5 | 職業 | 學生 / 科技 / 服務 / 製造 / 教育 / 醫療 / 公務 / 自營 / 家管 / 退休 / 失業 / 其他 |
| 6 | 個人收入 | <3萬 / 3-8萬 / >8萬 / 無收入 |
| 7 | 政治傾向 | 泛綠 / 泛藍 / 白/第三勢力 / 無政治傾向 |  (與年齡相關, 未成年不予貼標)
| 8 | 媒體習慣 | 傳統媒體為主 / 社群為主 / 混合 / 國際來源 |
| 9 | 家庭口數 | 1 / 2 / 3 / 4 / 5+ |
| 10 | 家庭可支配所得（月） | <1萬 / 1-3萬 / 3-5萬 / 5-7萬 / 7萬 / >8萬 |
| 11 | 興趣嗜好 | 打電動 / 追劇 / 閱讀 / 登山 / 遊泳 / 球類 / 逛街購物 / 烹飪 / 園藝 / 泡茶 / 下棋 / 打牌 |
| 12 | 婚姻狀況 | 未婚 / 已婚 / 離婚 / 鰥寡 |
| 13 | 戶籍地 | 台北市 / 新北市 / 桃園市 / 台中市 / 台南市 / 高雄市 / 基隆市 / 新竹縣 / 新竹市 / 苗栗縣 / 宜蘭縣 / 彰化縣 / 南投縣 / 雲林縣 / 嘉義市 / 嘉義縣 / 屏東縣 / 花蓮縣 / 台東縣 / 澎湖縣 / 金門縣 / 連江縣 |
| 14 | 物價分級 | 高 / 中高 / 中 / 低 / 極低 |（基於主計總處113年平均每人月消費支出，影響經濟短語選取權重）|
| 15 | 家戶所得分級 | 極高 / 高 / 中 / 中低 / 低 |（基於主計總處113年家庭收支調查，調整家庭收入分配）|
| 16 | 居住支出（月） | <5千 / 5千-1.5萬 / 1.5萬-3萬 / 3萬-5萬 / >5萬 | 房貸或房租，依 price_tier × family_size 指派，上限 ≤ 家庭可支配所得 50% |
| 17 | 居住負擔率 | 低 / 中 / 高 | 自動計算：housing_cost / family_income。低<20%, 中20-40%, 高>40%。影響背景故事中的經濟短語選取 |
| 18 | 通勤方式 | 步行/腳踏車 / 機車 / 捷運/公車 / 汽車 / 在家工作 | 依 residence × age 為基底，income / family_size / occ 微調 |
| 19 | 服飾消費（月） | <500 / 500-1500 / 1500-3000 / 3000-5000 / >5000 | 家庭月衣著支出（DGBAS 113年家庭收支調查），依 family_income × sex × occ × age 指派 |

> **⚠️ 注意 — 家庭可支配所得的定義（對甲方重要）**  
> 本欄位採用 **DGBAS 主計總處「家庭可支配所得」** 定義：  
> `家庭可支配所得 = 所得總額 − 稅金 − 社會保險（勞健保/勞退）`  
>  
> **已扣除：** 所得稅、勞健保、勞退  
> **尚未扣除（要從這裡面付）：** 房貸/房租、伙食費、水電瓦斯、教育費、交通費…全部消費支出  
>  
> 換句話說，**`<1萬` ~ `>8萬` 是稅後、但要拿去付所有開銷（含房貸房租）的錢**，不是淨儲蓄。  
>  
> **舉例：** 丹尼爾（TW-P-0233）個人月收 >8萬，家庭可支配所得 5-7萬  
> → 稅後全家有 5-7萬可花用，要付房租+養媽媽+生活費，  
>    「經濟壓力非常大」在 v3.8 以前是 BG 模板遺漏造成的 bug，已修復。

### 城市職業加權

Occupation probabilities are adjusted by city to reflect real-world industry clustering:

| 城市 | 職業加權 | 說明 |
|:-----|:---------|:-----|
| 新竹縣、新竹市 | 科技↑30% | 竹科效應 |
| 台北市 | 金融↑20% | 金融中心 |
| 桃園市 | 製造↑20% | 工業大城 |
| 台中市、台南市、高雄市 | 製造↑15% | 製造業重鎮 |

Implementation: post-selection redirect (if base occ ≠ target, X% chance to switch).

可依領域疊加 domain-specific 維度：
- 選舉 → 疊加「投票記錄」、「在地連結感」
- 金融 → 疊加「風險偏好」、「理財知識」
- 餐飲 → 疊加「外食頻率」、「口味偏好」

---

## 每個人設的輸出格式

### JSON 欄位結構

```json
{
  "id": "TW-P-0001",
  "name": "叩莓",
  "type": "虛構人設 (fictional persona)",
  "note": "姓名與地點/校名皆虛構，無對應真實人物",
  "input_dimensions": { "...9 維度值..." },
  "generated": {
    "location": "泉台（桃竹苗都會區）",
    "school": "星辰綜合高中",
    "age": "15 歲"
  },
  "interests": ["貓咪", "拍照", "K-pop"],
  "persona_profile": {
    "summary": "叩莓，泉台的高中生，15歲。每天上課滑手機跟朋友打屁。",
    "values": ["同儕認同", "當下快樂", "視覺美感", "不踩雷"],
    "pain_points": ["零用錢不夠", "補習好累", "父母碎念"],
    "decision_logic": "朋友推薦 → 查 Threads/Dcard → 確認安全 → 買",
    "trust_signals": ["網紅推薦", "同學用過", "按讚數高"],
    "distrust_signals": ["太像業配", "政治內容", "字太多", "長輩文"]
  },
  "prompt_prefix": "（沉浸式角色代入，供 LLM 直接使用）",
  "reference_pre_prompt": "（結構化摘要，供 GEO operator 篩選用）"
}
```

---

## 雙 Prompt 格式

### ① prompt_prefix — 沉浸式角色代入

**用途：** GEO operator 已選定此人設後，直接作為 system prompt 前綴餵給 LLM。

範例 — 高中生：

> 你是叩莓，一位 15 歲的高中生，住在桃竹苗都會區。
> 你的世界以學校和社群網路為中心。每天滑 IG、Threads、TikTok。
> 你對政治完全無感。決策模式：朋友推薦 → 查評價 → 確認安全 → 決定。
> 請用這個人設的語氣和視角來回應。

範例 — 工程師：

> 你是阿睿，31 歲，竹科資深韌體工程師，碩士畢業，年薪約 200 萬。
> 你單身，在竹北租屋。對政治冷感——覺得藍綠都一樣爛。
> 消費決策：爬 PTT/Dcard 看災情 → Mobile01 比 spec → 等折扣 → 才買。
> 你相信數據和實測，不信廣告和名人代言。
> 請用這個人設的視角和語氣來回應。理性、務實、帶一點工程師的冷幽默。

### ② reference_pre_prompt — 結構化查閱

**用途：** GEO operator 篩選比對時快速掃描用。

範例 — 高中生：

```
【參考人設 #叩莓】
年齡區間：12-18（15 歲）
教育程度：高中
居住區域：桃竹苗 / 都會核心
職業狀態：學生（無收入）
政治傾向：無 / 冷感
決策風格：同儕驗證型
興趣信號：貓咪, 拍照, K-pop
觸發因子：網紅推薦、同儕使用、限時限量
排斥因子：業配感、政治內容、長文
【適用場景】Z 世代高中生消費決策、社群傳播、政治冷感
```

範例 — 工程師：

```
【參考人設 #阿睿】
年齡區間：25-34（31 歲）
教育程度：碩士
居住區域：桃竹苗 / 都會核心
職業：資深工程師（年薪 200 萬）
政治傾向：無 / 厭惡藍綠
決策風格：理性比價型
興趣信號：科技產品、健身、PC Game
觸發因子：客觀評測、數據對比、CP 值分析
排斥因子：業配文、政治語言、太廉價感
【適用場景】高收入科技族群消費決策、竹科生活圈、房市/租屋
```

---

## 命名原則：名字對應人設屬性

名字不是隨機產生的，而是根據人設的年齡、性別、職業屬性自動匹配適當的命名風格：

| 人設類型 | 命名風格 | 範例 |
|---------|---------|------|
| 🧑 學生/青少年 | 可愛、疊字、醬系 | 叩莓、星醬、小雲、芽泉 |
| 👨‍💻 工程師/科技業 | 科技感、克/斯/睿/達 | 阿睿、科克、達森、老雲斯 |
| 👔 金融/商務 | 穩重、爾/瑞/邦/貿 | 益安、金爾、艾貿 |
| 👨‍💼 中年管理/自營 | 江湖感、哥/董/老大 | 強哥、老大、威爾、麥斯 |
| 🏭 中年傳產/勞工 | 本土味、昇/坤/雄 | 阿昇、志強、秀蘭、淑貞 |
| 👴 銀髮族 | 伯/嬸/媽系 | 春伯、天伯、金花嬸、阿好嬸 |

### 命名規則對照

```
年齡層 12-18     → 可愛系（小型、疊字、醬）
年齡層 19-34     → 年輕系（英文感、阿/小/艾）
年齡層 35-54     → 穩重系（哥/姐/中文雙字）
年齡層 55+       → 傳統系（伯/嬸/媽/叔）

職業 科技/工程 → 科技感字根（芯、科、達、睿）
職業 金融/商務 → 商務感字根（金、信、誠、貿）
職業 製造/傳產 → 本土感字根（宏、信、雄、坤）
```

---

## 隱私原則

| 原則 | 說明 | 範例 |
|------|------|------|
| 全虛構名稱 | 命名風格貼合人設，但不似真人姓名 | 叩莓、阿睿、春伯 |
| 無真實地名 | 合成地名，非真實行政區 | 泉台、光華庄、星崎 |
| 無真實校名 | 未成年使用虛構校名 | 星辰綜合高中、彩虹藝術中學 |
| 免責標註 | 每個人設 JSON 內標明虛構身份 | `"type": "虛構人設"` |

---

## 與 Hermes Agent 的整合

| 層級 | 用途 | 範例 |
|------|------|------|
| 🎭 Personality | 改變語氣/風格 | kawaii, noir, pirate |
| 🗂️ Profile | 改變工具/技能/記憶 | default vs work |
| 🧬 Persona DB | 扮演特定人口視角 | 叩莓（15歲高中生）、阿睿（31歲工程師） |

建議做法：將 Persona DB 包成 Hermes **skill**，agent 需要時載入查詢，不影響現有系統。

---

## 相關檔案

| 檔案 | 說明 |
|------|------|
| `hermesa3/persona/tw-persona-db-rfc.md` | 本文件 |
| `hermesa3/persona/tw_persona_1069.json` | **最新輸出** — 1069 人設, 16 維度, ~1.4MB |
| `hermesa3/persona/_generate_997.py` | 產生器（seed=42, target=1069） |
| `hermesa3/persona/qa_validate.py` | 18 條自動化驗證規則 |
| `hermesa3/persona/query_persona.py` | 查詢 CLI 工具 |
| `hermesa3/persona/sample_stratified.py` | 分層抽樣（96 combos, seed=42） |
| `hermesa3/persona/population_by_region_age_sex_2025.csv` | 6區×8年齡×2性別人口資料 |
| `hermesa3/persona/tw_persona_prototype_001_v3.json` | Prototype v3 — 高中生「叩莓」 |
| `hermesa3/persona/tw_persona_prototype_002_engineer.json` | Prototype v2 — 工程師「阿睿」 |
| `hermesa3/persona/MILESTONE-v3.0.md` | v3.0 milestone 文件 |

## Scoring 演算法（Relevance Ranking）

> 2026-08-05 新增（issue #4）— `/personadb/candidates` 的 `persona_ids` 依相關性分數排序，不再只是 DB 檔案順序。

### 動機

LLM 產出 filters 後，`matched` 可能遠多於 `top_k`。舊行為直接取檔案前 N 筆 — 可能挑到「剛好符合 filter 但其實最不像目標客戶」的人。Scoring 讓「命中稀有維度值」的人排前面。

### 權重表（dim_weights.json）

- **產出：** `scripts/gen_dim_weights.py`（regen 時或獨立執行）
- **公式：** `raw = log(total / count(dim, value))` → 跨維度正規化到 `[0.5, 2.0]`
- **覆蓋 15 個維度**（對齊 LLM filter 能力）：
  `age, sex, region, residence, education, occupation, income, family_income, family_size, marriage, commute_mode, housing_cost, housing_burden, clothing_spend, hobby`
- **不計分：** `political_stance, political_issues, politics, media_diet, background_story, prompt_prefix`（LLM 幾乎不用它們 filter；文字欄位無法計分）
- **資料源對照**（寫入 `_meta.data_sources`）：
  - 年齡/性別/區域/居住地/婚姻/家戶人數 — 內政部戶政司 113年人口統計
  - 教育/職業/收入/家庭所得/居住/服飾消費 — DGBAS 113年 家庭收支調查 / 人力資源調查
  - 通勤方式 — 交通部 2024 運具分配調查

### 分數計算

```
score(persona) = Σ [ weight(dim, persona.value)  for dim in filters ]
```

- **只算 LLM filter 有出現的維度**（Q2b-B）
- `hobby`（list 型）：命中任一 filter 值即加分，取命中值中最大權重
- **被 relaxation 丟掉的維度不計分**（Q3-A'）— 因為丟維度的原因就是「matched 無人命中該維度」，計分恆為 0
- 同分 → DB 檔案順序（Q7-A，確定性、可重現）
- 權重表缺失時 graceful degradation：所有 score=0，回歸無排序（不 crash）

### Response 揭露（可稽核性）

```json
{
  "summary": [{ "id": "TW-P-0195", "score": 2.77, ... }],
  "applied_filters": { "occupation": ["自營"], "age": ["25-34"] },
  "scoring_basis": {
    "method": "log-frequency × cross-dim normalized [0.5, 2.0]",
    "weight_source": "DGBAS 113年 家庭收支調查 / 人力資源調查 / 交通部 2024",
    "dims_counted": ["occupation", "age"],
    "relaxed_dims_scored_at": null
  }
}
```

### 限制

- 權重反映**靜態稀有度**，不反映**語意相關性** — 「花蓮高消費」與「台北時尚圈」可能同分
- 真正的語意理解需要 LLM 打分（未來工作，spec 見 `specs/2026-08-05-relevance-scoring.md`）
- 新增維度時必須同步更新 `SCORED_DIMS`（`scripts/gen_dim_weights.py`）與權重表

---

## 下一步討論方向

- [ ] 確認最終維度表（9 維度是否完備？需增減？）
- [ ] Domain 疊加設計 — 選舉 / 金融 / 餐飲
- [ ] 人口比例加權抽樣邏輯（各維度組合佔真實人口比例）
- [ ] 批次生成 1,000 個 persona 的 script
- [ ] Hermes skill 包裝 + 查詢 CLI 工具
- [ ] 第一版試用場景 — 建議從選舉分析開始
