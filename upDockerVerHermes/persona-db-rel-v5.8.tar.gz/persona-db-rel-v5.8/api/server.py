"""
Persona DB REST API — FastAPI Server (LLM-powered)

Endpoints:
  GET /personadb/candidates — LLM analyzes questions → filter personas (+ simulate)
  GET /personadb/detail     — Get full persona profile by ID
  GET /health               — Health check

Run:  uvicorn api.server:app --reload
"""

import os, sys, json, logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import FastAPI, Query, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import PlainTextResponse, JSONResponse

from .models import (
    OpMode, CandidatesResponse, PersonaSummary,
    PersonaSimulation, DimensionSummary, LLMAnalysis,
    DetailResponse, PersonaDetail, HealthResponse, ErrorResponse
)
from .persona_matcher import (
    filter_personas, get_important_dimensions,
    format_matched_criteria, load_persona_db, get_persona_by_id,
    llm_filters_to_dimension_filters
)
from .llm import parse_questions_with_llm, simulate_with_llm, call_llm, LLM_CONFIG

logger = logging.getLogger(__name__)


def _rare_dims_hint(db: list, filters: dict, reinforced_dims: set = None,
                    matched_count: int = 0, threshold: float = 0.05) -> str:
    """稀有維度的放寬提示（#36 引入；#42 收斂為 rescue-only + 核心性排除）。

    #42 的教訓：原本只要覆蓋率 <5% 就提示「優先放寬」，導致 broadening 在
    **第一輪（matched 非 0）** 就把核心維度當「非核心且極稀有」移除
    （案例 07 債務整合：`debt_status` 覆蓋 4.0% → matched 6 → 45，回傳 10 筆中
    4 筆無債務）。三道護欄：

    1. **rescue-only**：只有 `matched == 0` 才提示（救援用，不是首選手段）
    2. **核心性排除**：由 `domain_filters` reinforcement 補上的維度（`reinforced_dims`）
       是本問題語意的主體 → 永不出現在提示中（確定性判定，不依賴 LLM 自評）
    3. **提示文案強制理由**：若 LLM 仍決定放寬，必須在 `change` 寫明為何它不是核心條件

    只「提示」不「硬刪」—— 該維度是否為核心語意最終仍由 LLM 判（確定性硬刪會把
    正確的稀有維度也殺掉，例如醫美 query 的 `aesthetic_procedure`）。
    """
    if matched_count > 0:
        return ""  # #42: rescue-only —— 非 0 不放寬稀有維度
    reinforced_dims = reinforced_dims or set()
    total = len(db) or 1
    rare = []
    for dim, vals in filters.items():
        if not isinstance(vals, list) or not vals:
            continue
        if dim in reinforced_dims:
            continue  # #42: 由 domain reinforcement 補上的維度視為核心，不提示放寬
        hits = len(filter_personas(db, {dim: vals}))
        cov = hits / total
        if cov < threshold:
            rare.append(f"{dim}={vals}（DB 只有 {hits}/{total} = {cov*100:.1f}% 符合）")
    if not rare:
        return ""
    return (
        f"**注意：目前無任何 persona 符合篩選（matched=0），且下列維度在資料庫中極稀有"
        f"（覆蓋率 < {threshold*100:.0f}%）。若要放寬，可優先考慮它們，但必須先判斷語意：**\n- "
        + "\n- ".join(rare)
        + "\n\n**若你決定放寬上述任一維度，必須在 `change` 明確寫出「為何它不是本問題的核心條件」；"
          "若它是本問題的核心條件（例如債務整合之於 debt_status、醫美之於 aesthetic_procedure），"
          "請**保留不要放寬**，並說明必須保留的理由。**"
    )


def _constraint_hint(db, filters: dict, matched_count: int, top_n: int = 4,
                     core_dims: set | None = None) -> str:
    """#56 A: 提供「移除各維度後的樣本數」給放寬 prompt，讓模型挑**真正的約束維度**。

    第八輪（v5.7）實測：空轉率 60%（9/15），案例 4 三輪全空轉 —— 模型挑了非約束維度
    （housing_cost）放寬，真正的限制在 housing_burden / debt_status / marriage / family_size。
    純本地計數（無 LLM 成本），故每輪都附。

    `core_dims`（= #42 的 reinforced_dims）：即使倍率最高也**排除在「優先放寬」清單外**。
    否則提示會把模型推向放寬語意核心維度（v5.8 首次 e2e 實測：醫美案例依「倍率最高」
    把 `aesthetic_procedure` 放寬掉 → overshoot 154），正是 #42 要防的行為。
    """
    core_dims = core_dims or set()
    try:
        from .persona_matcher import dim_constraint_report
        rep = [r for r in dim_constraint_report(db, filters, top_n=top_n + len(core_dims))
               if r["dim"] not in core_dims][:top_n]
    except Exception as e:  # 不影響放寬流程
        logger.warning(f"維度約束分析失敗（不影響放寬）: {e}")
        return ""
    if not rep:
        return ""
    lines = [
        f"**當前限制條件分析**（目前 {matched_count} 人；移除各維度後的樣本數，"
        f"倍率越高＝該維度限制越強）："
    ]
    for r in rep:
        lines.append(f"- `{r['dim']}`：{matched_count} → {r['without']}（{r['lift']}×）")
    binding = {r["dim"] for r in rep}
    ineffective = [d for d in filters if d not in binding and d not in core_dims]
    if ineffective:
        lines.append(
            "- **放寬無效**（移除後樣本數不變）："
            + ", ".join(f"`{d}`" for d in ineffective)
            + " ← 不要放寬這些（放了也不會增加樣本數）"
        )
    if core_dims & set(filters):
        lines.append(
            "- **核心維度（已排除，勿放寬）**："
            + ", ".join(f"`{d}`" for d in sorted(core_dims & set(filters)))
            + " ← 即使移除後樣本數最多，也**不可**放寬（它們是本問題的語意主體）"
        )
    lines.append("**請優先放寬倍率最高的非核心維度；若你放寬的不是倍率最高的維度，必須說明理由。**")
    return "\n".join(lines)


def _is_overshoot(match_count: int, target_min: int = 20) -> bool:
    """#42: 放寬後樣本數遠超目標（> 2×TARGET_MIN）＝ 放寬過頭（例：債務整合 6 → 45）。"""
    return match_count > 2 * target_min


def _as_list(v) -> list:
    """#53: 多值維度（`hobby`）coerce —— 不假設型別（資料為 list，但容忍 str/None）。

    同族教訓見 issue #33 / #14：LLM 或資料衍生產物的型別不可信，一律 coerce。
    """
    if isinstance(v, list):
        return [str(x) for x in v if x not in (None, "")]
    if v in (None, ""):
        return []
    return [str(v)]


app = FastAPI(
    title="Persona DB API",
    description="台灣人口加權合成人設資料庫 — LLM-powered 查詢與模擬 API",
    version="3.2.0",
    docs_url="/docs",
    redoc_url="/redoc",
)


# ── 統一錯誤回應（#47）─────────────────────────────────────────────
# 端點宣告 `responses={400/404/500/503: {"model": ErrorResponse}}`，但實作一律
# `raise HTTPException(code, detail=...)` → FastAPI 會包成 `{"detail": ...}`，
# 與宣告的 `ErrorResponse`（required `error`）不符 → 依 schema 寫的 client 取不到
# `error`。此 handler 一次把**所有**錯誤碼正規化成 `{"status":"error","error":{...}}`。

def _normalize_error_detail(detail, status_code: int) -> dict:
    """把 HTTPException.detail（dict 或 string）轉成 ErrorResponse.error 的形狀。"""
    if isinstance(detail, dict):
        err = {
            "code": str(detail.get("code", f"HTTP_{status_code}")),
            "message": str(detail.get("message", "")),
            "details": str(detail.get("details", "")),
        }
        # 保留額外欄位（例：retryable）
        for k, v in detail.items():
            if k not in ("code", "message", "details"):
                err[k] = v
        return err
    return {"code": f"HTTP_{status_code}", "message": str(detail), "details": ""}


@app.exception_handler(HTTPException)
async def _http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content=ErrorResponse(
            status="error", error=_normalize_error_detail(exc.detail, exc.status_code)
        ).model_dump(),
        headers=getattr(exc, "headers", None),
    )


@app.exception_handler(RequestValidationError)
async def _validation_exception_handler(request: Request, exc: RequestValidationError):
    """422 也統一形狀（狀態碼不變，維持 FastAPI 語意）。"""
    return JSONResponse(
        status_code=422,
        content=ErrorResponse(status="error", error={
            "code": "VALIDATION_ERROR",
            "message": "請求參數驗證失敗",
            "details": str(exc.errors())[:500],
        }).model_dump(),
    )

# ── Startup ────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    try:
        load_persona_db()
        db = load_persona_db()
        logger.info(f"Persona DB loaded: {len(db)} personas")
        app.state.db_loaded = True
        app.state.persona_count = len(db)
    except Exception as e:
        logger.error(f"Failed to load Persona DB: {e}")
        app.state.db_loaded = False
        app.state.persona_count = 0


# ── Health ─────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health():
    return HealthResponse(
        status="ok",
        version="3.2",
        persona_count=getattr(app.state, "persona_count", 0),
        db_loaded=getattr(app.state, "db_loaded", False),
    )


# ── Candidates (LLM-powered filter + optional simulate) ────────────

@app.get(
    "/personadb/candidates",
    response_model=CandidatesResponse,
    responses={
        400: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
        503: {"model": ErrorResponse},
    }
)
async def personadb_candidates(
    questions: str = Query(..., description="問題列表，用 | 分隔多題"),
    top_k: int = Query(20, ge=1, le=100, description="要回傳幾個最相關的 persona"),
    opMode: str = Query(default="僅篩選", description="操作模式: 篩選+模擬 / 僅篩選 / 模擬詢問"),
    role: str = Query(default="", description="詢問者角色（例：房仲業者、銀行業者）。讓 LLM 調整 filter 方向。"),
):
    # Validate
    if opMode not in ("僅篩選", "篩選+模擬", "模擬詢問"):
        raise HTTPException(status_code=400, detail={
            "code": "INVALID_OPMODE",
            "message": f"無效的 opMode: {opMode}",
            "details": "有效值: 僅篩選, 篩選+模擬, 模擬詢問",
        })
    if top_k > 100:
        raise HTTPException(status_code=400, detail={
            "code": "TOP_K_TOO_LARGE",
            "message": "top_k 最大為 100",
            "details": f"收到 top_k={top_k}",
        })
    if not getattr(app.state, "db_loaded", False):
        raise HTTPException(503, detail={
            "code": "DB_NOT_LOADED",
            "message": "Persona DB 尚未載入",
            "details": ""
        })
    
    # Parse questions (split by |)
    q_list = [q.strip() for q in questions.split("|") if q.strip()]
    if not q_list:
        raise HTTPException(400, detail={
            "code": "MISSING_PARAMETER",
            "message": "請提供至少一個問題",
            "details": "多個問題請用 | 分隔"
        })
    
    try:
        db = load_persona_db()
        
        # Step 1: LLM analyzes questions → dimension filters
        logger.info(f"LLM analyzing {len(q_list)} questions...")
        from .llm import build_distribution_summary
        data_overview = build_distribution_summary(db)
        llm_result = await parse_questions_with_llm(q_list, role=role or None, distribution=data_overview)
        
        llm_analysis = None
        if llm_result:
            llm_analysis = LLMAnalysis(
                domain=llm_result.get("domain", ""),
                reasoning=llm_result.get("reasoning", ""),
                question_analysis=llm_result.get("question_analysis", []),
                usage_suggestion=llm_result.get("usage_suggestion"),
            )
        
        # Step 2: Convert LLM output to filters
        filters = llm_filters_to_dimension_filters(llm_result) if llm_result else {}
        
        # Step 2b: Domain-aware filter reinforcement (issue #4 — LLM 常漏消費維度)
        # 依 LLM 判定的 domain，自動補上關鍵消費維度（確定性兜底，不依賴 LLM 自覺）
        domain = (llm_result or {}).get("domain", "")
        domain_filters = {
            "時尚": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "服飾": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "美妝": {"clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "運動": {"hobby": ["登山", "球類", "游泳", "廣場舞"]},
            "健身": {"hobby": ["登山", "球類", "游泳", "廣場舞"]},
            "跑鞋": {"hobby": ["登山", "球類", "游泳"], "clothing_spend": ["1500~3000", "3000~5000", ">5000"]},
            "電動車": {"income": [">8萬", "3-8萬"]},
            "汽車": {"income": [">8萬", "3-8萬"]},
            "房產": {"housing_burden": ["中", "高"], "family_income": ["5-7萬", "7萬", ">8萬"]},
            "房貸": {"housing_burden": ["中", "高"], "family_income": ["5-7萬", "7萬", ">8萬"]},
            "旅遊": {"family_income": ["5-7萬", "7萬", ">8萬"]},
            "醫美": {"aesthetic_procedure": ["有"]},
            "醫美診所": {"aesthetic_procedure": ["有"]},
            "整形": {"aesthetic_procedure": ["有"]},
            "皮膚科": {"aesthetic_procedure": ["有"]},
            # ⚠️ #36: 「美容」不再對應 aesthetic_procedure —— 美容不等於醫美療程，
            #    且該維度 DB 覆蓋率僅 1.5%，誤套會把候選池限縮到 1 人（藥妝零售案例）。
            #    泛指美容/藥妝/零售的美妝消費請走 clothing_spend（見上方「美妝」）。
            "債務": {"debt_status": ["有信貸或卡債", "房貸+消費債"]},
            "貸款整合": {"debt_status": ["有信貸或卡債", "房貸+消費債"]},
            "債務協商": {"debt_status": ["有信貸或卡債", "房貸+消費債"]},
            "卡債": {"debt_status": ["有信貸或卡債", "房貸+消費債"]},
            "老闆": {"employment_status": ["雇主", "自營作業者"]},
            "業主": {"employment_status": ["雇主", "自營作業者"]},
            "企業主": {"employment_status": ["雇主"]},
            "創業": {"employment_status": ["雇主", "自營作業者"]},
            "自營": {"employment_status": ["自營作業者"]},
            "攤商": {"employment_status": ["自營作業者"]},
            "加盟": {"employment_status": ["雇主", "自營作業者"]},
            "小生意": {"employment_status": ["自營作業者"]},
            # 註（#34）：本表是 domain 標籤的關鍵字兜底，只在 LLM 判定的 domain 字串含
            # 該關鍵字時觸發（例：案例 08 domain=「餐飲/夜市商圈/市場研究」→ 全部不觸發）。
            # 主要機制是 QUESTION_ANALYSIS_PROMPT 的 must-use 指引；且問「某店/某攤的
            # 目標客群」（顧客）時不該套 employment_status（語意歧義，見 issue #34）。
        }
        reinforced = {}
        for kw, add_filters in domain_filters.items():
            if kw in domain:
                reinforced.update(add_filters)
        if reinforced:
            for dim, vals in reinforced.items():
                if dim not in filters or not filters[dim]:
                    filters[dim] = vals
                    logger.info(f"Domain reinforcement ({domain}): added {dim}={vals}")
                # hobby: LLM 常用通用詞（如"運動"），但 DB 只有具體活動。
                # 若 hobby 已在 filters 但 DB 值可能不匹配，用 domain 值覆蓋
                elif dim == "hobby":
                    filters[dim] = vals
                    logger.info(f"Domain reinforcement ({domain}): replaced hobby with {vals}")
        
        # Fallback: if LLM returned no filters, use keyword-based parsing from questions text
        if not filters:
            from .persona_matcher import parse_enduser
            combined_text = " ".join(q_list)
            filters = parse_enduser(combined_text)
            logger.warning("LLM returned no filters, falling back to keyword parsing")
        
        # If still no filters, refuse to match everything (would return all 1069)
        if not filters:
            raise HTTPException(503, detail={
                "code": "FILTER_FAILED",
                "message": "無法從問題中解析出篩選條件（LLM 分析失敗且關鍵字解析無結果）",
                "details": "請確認 LLM API key / model 設定，或換一種問法",
                # #46: 這是瞬時失敗（LLM 回應格式不穩）也可能發生 → 明確標示可重試，
                # 讓 client 不必把「重試」與「換問法」混為一談
                "retryable": True
            })
        
        # Step 3: Filter personas
        matched = filter_personas(db, filters)
        
        # NOTE: scoring_basis 的建構移到 broadening loop 之後（見下方）—— #35：
        # dims_counted 必須反映 score_persona 的實際計分集合（含 relaxed dims；
        # relaxed dims 由 original_filters 計分），舊版在 loop 前用「當下 filters」
        # 推測會少列維度。
        
        # Step 3b: Filter relaxation — threshold-based (issue #4 v4.4.2)
        # Step 3b: Interactive broadening loop (replaces blind relaxation, issue #12)
        TARGET_MIN = 20
        original_filters = dict(filters)
        relaxed_dims = []
        broadening_attempts = []
        loop = 0
        max_loops = 3
        # D4: per-request token budget（analysis 1 次 + broadening ≤3 次）
        analysis_model = LLM_CONFIG.get("analysis_model") or None
        # pro model is reasoning-heavy: 2000 tokens gets eaten by reasoning
        # and content comes back empty → silent break (issue: 房仲 total=3)
        broaden_max_tokens = 8000 if analysis_model and "pro" in analysis_model.lower() else 2000
        TOKEN_BUDGET = 40000
        tokens_spent = 12000  # analysis call（pro = 12000，v5.8 起）
        # v5.8: TOKEN_BUDGET 由 32000 → 40000 —— 基礎預算提高後（8000 → 12000）若不同步
        # 提高上限，per-request 預算會讓「最多 3 輪放寬」**靜默降為 2 輪**
        # （12000 + 2×8000 = 28000 < 32000，第三輪需 36000 > 32000）。維持設計意圖
        # （analysis 1 次 + broadening ≤ 3 次 = 12000 + 3×8000 = 36000 ≤ 40000）。
        # #56 B: 連續 no_op 上限 —— 第八輪實測空轉率 60%（9/15），每次空轉都是完整 LLM
        # 呼叫。連續 2 輪無效即停（省下一次呼叫；代價是放棄「第 3 輪可能 +2」的小幅增益，
        # 已由 kstsai 2026-09-14 定案接受）。停止原因記於 `broadening_stop_reason`。
        consecutive_no_op = 0
        stop_reason = ""

        while (len(matched) < TARGET_MIN and loop < max_loops and filters
               and tokens_spent + broaden_max_tokens <= TOKEN_BUDGET):
            loop += 1
            logger.info(f"Broadening loop {loop}/{max_loops}: {len(matched)} matches < {TARGET_MIN}")
            from .llm import call_llm, BROADEN_PROMPT
            # #36 → #42: 稀有維度提示改為 rescue-only + 核心性排除（reinforced_dims）
            broaden_prompt = BROADEN_PROMPT.format(
                match_count=len(matched),
                target_min=TARGET_MIN,
                current_filters=json.dumps(filters, ensure_ascii=False, indent=2),
                rare_dims_hint=_rare_dims_hint(
                    db, filters,
                    reinforced_dims=set(reinforced.keys()),
                    matched_count=len(matched),
                ),
                constraint_hint=_constraint_hint(db, filters, len(matched),
                                                 core_dims=set(reinforced.keys())),
            )
            prev_filters = dict(filters)
            result = await call_llm(broaden_prompt, temperature=0.2, max_tokens=broaden_max_tokens, model_override=analysis_model)
            tokens_spent += broaden_max_tokens
            if not result:
                stop_reason = "llm_empty"
                break
            try:
                result = result.strip()
                if "```json" in result:
                    result = result.split("```json")[1].split("```")[0].strip()
                elif "```" in result:
                    result = result.split("```")[1].split("```")[0].strip()
                new_data = json.loads(result)
                new_filters = new_data.get("filters", {})
                broadening = new_data.get("broadening", "unknown")
            except Exception:
                stop_reason = "llm_parse_error"
                break
            if not new_filters:
                stop_reason = "llm_no_filters"
                break
            # #25: 限制每 loop 最多移除 1 個維度（防止 overshoot：一次刪多維度 → total 暴增）
            removed_this_loop = [dim for dim in list(filters.keys()) if dim not in new_filters]
            if len(removed_this_loop) > 1:
                logger.info(f"Broadening loop {loop}: LLM 移除 {len(removed_this_loop)} 維度，cap 到 1（還原 {removed_this_loop[1:]}）")
                for dim in removed_this_loop[1:]:
                    new_filters[dim] = filters[dim]  # 還原多餘移除的維度（保留舊值）
                removed_this_loop = removed_this_loop[:1]
            relaxed_dims.extend(removed_this_loop)
            filters = new_filters
            prev_count = len(matched)
            matched = filter_personas(db, filters)
            # #37: no-op 偵測 —— filters 未變更（或變了但樣本數沒動）時再放寬只是白燒
            # 一次 pro call（8000 token），提前中止而不是耗掉剩餘迴圈額度
            filters_changed = (filters != prev_filters)
            no_op = (len(matched) == prev_count)
            # #42: overshoot 旗標 —— 放寬後樣本數遠超目標（> 2×TARGET_MIN）代表放寬過頭
            # （案例：債務整合第一次放寬 6 → 45）。只標記與記錄，不強制中斷（overshoot 時
            # `while len(matched) < TARGET_MIN` 本就會讓迴圈退出）。
            overshoot = _is_overshoot(len(matched), TARGET_MIN)
            broadening_attempts.append({
                "loop": loop, "change": broadening,
                "match_count_before": prev_count, "match_count_after": len(matched),
                "filters_changed": filters_changed, "no_op": no_op, "overshoot": overshoot,
            })
            if overshoot:
                logger.warning(
                    f"Broadening loop {loop}: overshoot —— {prev_count} → {len(matched)} "
                    f"（> 2×TARGET_MIN={2 * TARGET_MIN}），放寬可能過頭"
                )
            if no_op and not filters_changed:
                logger.info(f"Broadening loop {loop}: no-op（filters 未變更、樣本數不變）→ 提前中止")
                stop_reason = "no_op_limit"
                break
            if no_op:
                consecutive_no_op += 1
                logger.info(
                    f"Broadening loop {loop}: filters 有變更但樣本數不變"
                    f"（{prev_count}→{len(matched)}，連續空轉 {consecutive_no_op}）"
                )
                if consecutive_no_op >= 2:
                    logger.info(
                        f"Broadening loop {loop}: 連續 {consecutive_no_op} 輪空轉 → 停止放寬"
                        f"（#56 B；節省後續 LLM 呼叫）"
                    )
                    stop_reason = "no_op_limit"
                    break
            else:
                consecutive_no_op = 0

        # #56 B: 停止原因（供呼叫端判讀「為何沒達到 TARGET_MIN」）
        if not stop_reason:
            if len(matched) >= TARGET_MIN:
                stop_reason = "target_reached"
            elif loop >= max_loops:
                stop_reason = "loop_limit"
            elif not filters:
                stop_reason = "no_filters"
            else:
                stop_reason = "budget_limit"

        # Scoring basis metadata (issue #4 — auditability; #35: dims_counted 由
        # score_persona 的實際計分集合產生，含 relaxed dims —— 它們由 original_filters
        # 以 tier_match 部分計分；不再用「filters ∩ dim_weights」推測而少列維度)
        scoring_basis = None
        try:
            from .persona_matcher import load_dim_weights, load_dim_weights_meta, scored_dims
            dim_weights = load_dim_weights()
            if dim_weights:
                scoring_basis = {
                    "method": "log-frequency × cross-dim normalized [0.5, 2.0]",
                    "weight_source": "DGBAS 113年 家庭收支調查 / 人力資源調查 / 交通部 2024",
                    # #44: 分數可溯性 —— 讓下游能偵測「權重表（= 分數尺度）換版」
                    "weight_version": load_dim_weights_meta().get("version"),
                    "score_scale": "relative-within-version",
                    "score_schema": 1,  # 分數定義版號；改 ranking 目標（如 #40 多樣性重排）時跳版
                    "dims_counted": scored_dims(
                        original_filters,
                        (llm_result or {}).get("dim_importance", {}),
                        relaxed_dims,
                        weights=dim_weights,
                    ),
                    "relaxed_dims_scored_at": None,  # Q3-A': relaxed dims not scored
                }
        except Exception as e:
            logger.warning(f"scoring_basis 建構失敗（不影響回應）: {e}")
            scoring_basis = None
        
        status = "ok" if len(matched) >= TARGET_MIN else "too_strict" if loop >= max_loops and len(matched) == 0 else "ok"
        
        if not matched:
            return CandidatesResponse(
                status=status,
                total_matched=0,
                persona_ids=[],
                returned=0,                    # #43
                pool_exhausted=(0 < top_k),    # #43: 池子比要求的小
                relaxed_dims=relaxed_dims,
                applied_filters=filters,
                broadening_attempts=broadening_attempts,
                broadening_stop_reason=stop_reason,   # #56 B
                llm_analysis=llm_analysis,
                scoring_basis=scoring_basis,
            )
        
        # Step 4: Relevance scoring + take top_k
        from .persona_matcher import sort_by_score, score_persona
        dim_importance = (llm_result or {}).get("dim_importance", {})
        matched = sort_by_score(matched, original_filters, dim_importance, relaxed_dims)
        top = matched[:top_k]
        
        # Build summary table (replaces full persona details)
        persona_ids = []
        summary = []
        
        for p in top:
            pid_str = p.get("id", "")
            try:
                pid_num = int(pid_str.split("-")[-1]) if "-" in pid_str else int(pid_str)
            except ValueError:
                pid_num = 0
            
            dims = p.get("dimensions", {})
            persona_ids.append(pid_num)
            summary.append(PersonaSummary(
                id=pid_str,
                name=p.get("name", ""),
                age=dims.get("age", ""),
                occupation=dims.get("occupation", ""),
                income=dims.get("income", ""),
                family_income=dims.get("family_income", ""),
                residence=dims.get("residence", ""),
                family_size=dims.get("family_size", ""),
                city_price_tier=dims.get("city_price_tier", ""),
                commute_mode=dims.get("commute_mode", ""),
                housing_cost=dims.get("housing_cost", ""),
                housing_burden=dims.get("housing_burden", ""),
                clothing_spend=dims.get("clothing_spend", ""),
                aesthetic_procedure=dims.get("aesthetic_procedure", ""),
                debt_status=dims.get("debt_status", ""),
                employment_status=dims.get("employment_status", ""),
                # #53: 補齊可篩維度（讓消費端能驗證 filter 生效）
                sex=dims.get("sex", ""),
                region=dims.get("region", ""),
                education=dims.get("education", ""),
                marriage=dims.get("marriage", ""),
                hobby=_as_list(dims.get("hobby")),      # 多值；coerce：list 原樣、str 包成 list
                politics=dims.get("politics", ""),
                media_diet=dims.get("media_diet", ""),
                score=score_persona(p, original_filters, dim_importance, relaxed_dims),
            ))
        
        # Step 5: Optional LLM simulation (populated in full detail)
        # Note: simulation is not included in summary table.
        # Use GET /personadb/detail?id=XXX for full persona detail. 
        if opMode == "篩選+模擬" and q_list:
            logger.info(f"Simulating {len(top)} personas with LLM...")
            for i, p in enumerate(top):
                sim = await simulate_with_llm(p, q_list)
                # Simulation is NOT included in summary table response.
                # Client can use /personadb/detail for full persona info.
                _ = sim  # consumed but not included in summary
        
        # Step 6: Important dimensions
        important_dims = get_important_dimensions(top)
        dim_summaries = [
            DimensionSummary(dim=d["dim"], values=d["values"])
            for d in important_dims
        ]
        
        return CandidatesResponse(
            status=status,
            total_matched=len(matched),
            persona_ids=persona_ids,
            summary=summary,
            returned=len(summary),                     # #43
            pool_exhausted=(len(matched) < top_k),     # #43: 池子比要求的小
            important_dimensions=dim_summaries,
            llm_analysis=llm_analysis,
            relaxed_dims=relaxed_dims,
            applied_filters=filters,
            broadening_attempts=broadening_attempts,
            broadening_stop_reason=stop_reason,        # #56 B
            scoring_basis=scoring_basis,
        )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Candidates endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Detail ─────────────────────────────────────────────────────────

@app.get(
    "/personadb/detail",
    response_model=DetailResponse,
    responses={
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    }
)
async def personadb_detail(
    persona_id: str = Query(..., description="Persona ID (TW-P-XXXX 或數字)")
):
    try:
        p = get_persona_by_id(persona_id)
        if p is None:
            raise HTTPException(404, detail={
                "code": "PERSONA_NOT_FOUND",
                "message": f"Persona ID '{persona_id}' 不存在",
                "details": "有效範圍: TW-P-0001 ~ TW-P-1069"
            })
        
        return DetailResponse(
            status="ok",
            persona=PersonaDetail(
                id=p.get("id", ""),
                name=p.get("name", ""),
                type=p.get("type", "虛構人設"),
                dimensions=p.get("dimensions", {}),
                prompt_prefix=p.get("prompt_prefix", ""),
                reference_pre_prompt=p.get("reference_pre_prompt", ""),
            )
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Detail endpoint error")
        raise HTTPException(500, detail={
            "code": "INTERNAL_ERROR",
            "message": f"伺服器錯誤: {str(e)}",
            "details": ""
        })


# ── Status ────────────────────────────────────────────────────────

@app.get("/personadb/status")
async def persona_db_status():
    """
    Return persona-db status as raw text (like `hermes chat 'persona-db status'`).
    No parameters needed.
    """
    try:
        lines = []
        def L(s): lines.append(s)
        
        # Version
        version = "v3.2"
        try:
            vf = Path(__file__).resolve().parent.parent / "VERSION"
            if vf.exists():
                version = vf.read_text().strip()
        except: pass
        
        # Persona count
        db = load_persona_db()
        p_count = len(db)
        json_size = "N/A"
        json_path = Path(__file__).resolve().parent.parent / "tw_persona_1069.json"
        if json_path.exists():
            sz = json_path.stat().st_size
            json_size = f"{sz/1024/1024:.2f} MB" if sz > 1024*1024 else f"{sz/1024:.1f} KB"
        
        # Backup
        backup_path = json_path.parent / "tw_persona_1069_backup.json"
        backup_ok = backup_path.exists()
        
        # Name diversity
        names = set(p.get("name", "") for p in db)
        name_count = len(names)
        name_pct = round(name_count / p_count * 100, 1)
        from collections import Counter
        name_repeats = Counter(p.get("name", "") for p in db)
        max_repeat = max(name_repeats.values()) if name_repeats else 0
        
        # Python
        py_ver = sys.version.split()[0]
        
        # LLM status
        llm_status = "⛔ Not configured"
        if LLM_CONFIG.get("api_key"):
            llm_status = f"✅ {LLM_CONFIG.get('model', '?')} → {LLM_CONFIG.get('base_url', '?')}"
            # Live LLM test
            try:
                resp = await call_llm("回應「ok」就好", max_tokens=50)
                if resp is not None:
                    llm_status += " (responsive)"
                else:
                    llm_status += " (no response)"
            except Exception as e:
                llm_status += f" (error: {str(e)[:100]})"
        else:
            llm_status = "⛔ No API key configured"
        
        # Git
        git_info = "not a repo (filesystem boundary)"
        git_dir = Path(__file__).resolve().parent.parent / ".git"
        if git_dir.exists():
            try:
                import subprocess
                r = subprocess.run(["git", "log", "--oneline", "-1"], capture_output=True, text=True, cwd=str(git_dir.parent))
                if r.returncode == 0:
                    git_info = r.stdout.strip()
            except: pass
        
        # Hermes skills count (from mounted config volume or local)
        hermes_skills = "N/A"
        persona_skills = "N/A"
        for skills_candidate in ["/hermes-config/skills", str(Path.home() / ".hermes/skills")]:
            skills_path = Path(skills_candidate)
            if skills_path.exists() and skills_path.is_dir():
                try:
                    skill_files = list(skills_path.rglob("SKILL.md"))
                    hermes_skills = str(len(skill_files))
                    ps = [s for s in skill_files if "persona" in s.name.lower() or "persona" in str(s.parent).lower()]
                    persona_skills = str(len(ps))
                    break
                except Exception:
                    continue
        
        # QA
        qa_lines = []
        try:
            qa_script = Path(__file__).resolve().parent.parent / "qa_validate.py"
            if qa_script.exists():
                import subprocess
                r = subprocess.run([sys.executable, str(qa_script)], capture_output=True, text=True, cwd=str(qa_script.parent), timeout=30)
                if r.returncode == 0:
                    qa_lines = r.stdout.splitlines()[-6:]
                else:
                    qa_lines = ["❌ QA FAILED"]
        except subprocess.TimeoutExpired:
            qa_lines = ["⏱️ QA timeout"]
        except Exception as e:
            qa_lines = [f"❌ QA error: {e}"]
        
        # File artifacts
        tools_dir = Path(__file__).resolve().parent.parent
        py_files = list(tools_dir.glob("*.py")) + list(tools_dir.glob("api/*.py"))
        
        # ── Build output ──
        L(f"Persona DB Status")
        L(f"{'='*50}")
        L(f"")
        L(f"  Version         {version}")
        L(f"  Main personas   {p_count} (tw_persona_1069.json, {json_size})")
        L(f"  Backup          {'✅' if backup_ok else '❌'} {p_count} (tw_persona_1069_backup.json)")
        L(f"  QA (23 rules)   {'✅ ALL CHECKS PASSED' if qa_lines and 'PASSED' in qa_lines[-1] else '⏳ check below'}")
        L(f"  Name diversity  {name_count} unique names ({name_pct}%), max repeat {max_repeat}×")
        L(f"  Python          {py_ver}")
        L(f"  Git             {git_info}")
        L(f"  LLM             {llm_status}")
        L(f"  Hermes Skills   {hermes_skills} total, {persona_skills} persona-related")
        L(f"")
        L(f"  📁 Supporting Artifices: {len(py_files)} Python files")
        L(f"")
        if qa_lines:
            L(f"  QA Results:")
            for ql in qa_lines:
                if ql.strip():
                    L(f"    {ql.strip()}")
        
        return PlainTextResponse("\n".join(lines))
    
    except Exception as e:
        logger.exception("Status endpoint error")
        return PlainTextResponse(f"Error: {str(e)}", status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.server:app", host="0.0.0.0", port=8000, reload=True)
