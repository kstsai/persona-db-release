"""
llm.py — LLM client for Persona DB API.

Calls DeepSeek API (or any OpenAI-compatible endpoint) to:
1. Analyze questions → determine target persona demographics
2. Generate simulation responses for matched personas
"""

import json, os, logging, asyncio, time
from typing import Optional, Union, Literal, overload
import httpx
import yaml

logger = logging.getLogger(__name__)

# ── Config ─────────────────────────────────────────────────────────

HERMES_CONFIG_PATH = "/hermes-config/config.yaml"

def _load_llm_config() -> dict:
    """
    Load LLM configuration from Hermes config file.
    
    Priority:
    1. Environment variables (LLM_API_KEY, LLM_MODEL, LLM_BASE_URL)
    2. Hermes config file (mounted at /hermes-config/config.yaml)
    
    Returns dict with: api_key, base_url, model
    """
    config = {
        "api_key": "",
        "base_url": "",
        "model": "",
        "analysis_model": "",  # 專用於 question analysis 的 model（可覆蓋 model）
    }
    
    # 0. Check local .env file (project root)
    env_paths = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"),
        os.path.expanduser("~/.hermes/.env"),
        "/app/.env",  # Docker container path
    ]
    try:
        for env_path in env_paths:
            if os.path.exists(env_path):
                with open(env_path) as ef:
                    for line in ef:
                        line = line.strip()
                        if line and not line.startswith("#") and "=" in line:
                            k, v = line.split("=", 1)
                            k, v = k.strip(), v.strip().strip("'\"")
                            if k == "LLM_API_KEY" and not config["api_key"]:
                                config["api_key"] = v
                            elif k == "LLM_BASE_URL" and not config["base_url"]:
                                config["base_url"] = v
                            elif k == "LLM_MODEL" and not config["model"]:
                                config["model"] = v
                            elif k == "LLM_ANALYSIS_MODEL" and not config["analysis_model"]:
                                config["analysis_model"] = v
    except Exception:
        pass
    
    # 1. Environment variables (highest priority)
    env_key = os.environ.get("LLM_API_KEY")
    env_url = os.environ.get("LLM_BASE_URL")
    env_model = os.environ.get("LLM_MODEL")
    env_analysis_model = os.environ.get("LLM_ANALYSIS_MODEL")
    
    if env_key:
        config["api_key"] = env_key
    if env_url:
        config["base_url"] = env_url
    if env_model:
        config["model"] = env_model
    if env_analysis_model:
        config["analysis_model"] = env_analysis_model
    
    # 2. Try Hermes config file (middle priority, only fills gaps)
    if os.path.exists(HERMES_CONFIG_PATH):
        try:
            with open(HERMES_CONFIG_PATH) as f:
                cfg = yaml.safe_load(f)
            
            model_cfg = cfg.get("model", {})
            
            # Get api_key from config (if not already set from env)
            if not config["api_key"]:
                config["api_key"] = model_cfg.get("api_key", "")
                
                # Also check custom providers for keys
                custom_providers = cfg.get("custom_providers", {})
                for prov_name, prov_cfg in custom_providers.items():
                    prov_key = prov_cfg.get("api_key", "")
                    if prov_key and not config["api_key"]:
                        config["api_key"] = prov_key
                
                # Check auth.json for OAuth tokens (Nous provider)
                if not config["api_key"]:
                    auth_path = os.path.join(os.path.dirname(HERMES_CONFIG_PATH), "auth.json")
                    if os.path.exists(auth_path):
                        try:
                            with open(auth_path) as af:
                                auth_data = json.load(af)
                            # Try Nous OAuth token
                            nous_cred = auth_data.get("credential_pool", {}).get("nous", {})
                            if nous_cred:
                                token = nous_cred.get("access_token", "") or nous_cred.get("token", "")
                                if token:
                                    config["api_key"] = token
                                    config["base_url"] = "https://inference-api.nousresearch.com/v1"
                                    if not config["model"]:
                                        config["model"] = cfg.get("model", {}).get("default", "tencent/hy3:free")
                                    logger.info("Found Nous OAuth token — using Nous provider")
                        except Exception as e:
                            logger.debug(f"Could not read auth.json: {e}")
            
            # Get base_url from config (if not already set)
            if not config["base_url"]:
                config["base_url"] = model_cfg.get("base_url", "")
            
            # Get model from config (if not already set)
            if not config["model"]:
                config["model"] = model_cfg.get("default", "")
        
        except Exception as e:
            logger.warning(f"Failed to read Hermes config: {e}")
    
    # 3. Fallback defaults
    if not config["base_url"]:
        config["base_url"] = "https://api.deepseek.com"
    if not config["model"]:
        config["model"] = "deepseek-chat"
    
    return config


LLM_CONFIG = _load_llm_config()


# ── Prompts ────────────────────────────────────────────────────────

# 發問者角色 → 具體 filter 指引（issue #13 role parameter）
# 關鍵：不只定性描述，而是明確指出「哪個維度該偏哪個值」，否則 LLM 會收斂到相同 filters
ROLE_GUIDANCE = {
    "房仲": "你是房仲業者，要找「購屋/換屋」的潛在客戶。年齡偏 30-45（首購/換屋主力），family_size 偏大（3-4，有小孩想換大房），housing_burden 偏「低」（現有房貸已還清、有換房能力）。",
    "銀行": "你是銀行業者，要找「轉貸/穩定還款」的既有房貸戶。年齡偏 40-55（已有房貸想轉貸降息），housing_burden 偏「中」或「高」（有既有房貸），income/family_income 偏「>8萬」（穩定還款能力）。",
    "設計": "你是室內設計師，要找「裝修/翻新」需求的客戶。housing_cost 偏中高（有房子要裝修），family_income 偏中高（有裝修預算），housing_burden 偏「低」（房貸已還清、有餘裕裝修）。",
    "行銷": "你是行銷人員，要找「目標市場的潛在客戶」，重點是找出對產品有需求的族群，維度放寬、覆蓋多樣。",
    "研究": "你是研究者，要找「具代表性的多樣化樣本」，維度應寬鬆多元，不要過度聚焦單一族群。",
}

QUESTION_ANALYSIS_PROMPT = """你是一個台灣市場研究助手。你的任務是分析使用者提出的問題，判斷哪些 demographics 會對這些問題感興趣。

請分析以下問題，輸出 JSON 格式：

問題列表：
{questions}

請考慮：
1. 這是什麼領域/產業的問題？
2. 哪些年齡層、性別、居住地、職業、收入、家庭狀況的人會關心這個主題？
3. 這個主題是否與「消費行為」相關？若是（例如時尚、服飾、美妝、3C、汽車、餐飲、零售、房產、旅遊），**必須**使用 clothing_spend / housing_cost / commute_mode / family_income 等消費維度來過濾 — 不要只靠 age/occupation/income
4. 問題的主體是「業主本人」還是「他的顧客」？若主體是雇主／自營作業者／攤商／創業者／企業主本人（而不是他們賣東西的對象），**必須**使用 employment_status 過濾
5. 這些 persona 最適合怎麼使用？

**重要：filter 的值必須嚴格使用下方提供的有效選項，不要自己創造新值。**
**重要：如果問題與消費行為相關（時尚/服飾/美妝/零售/汽車/3C/餐飲/旅遊/房產），clothing_spend 與其他消費維度不是「可選」而是「必須考慮」— 用它們區分「會買的人」與「不會買的人」。**
**重要：aesthetic_procedure 只適用於明確指向「醫美療程／整形／皮膚科／醫美診所」的問題。零售、藥妝、美妝、通路、時尚等非療程語意**不要**使用本維度 — 資料庫中僅約 1.5% 的人為「有」，誤用會把候選池限縮到個位數。**
**重要：若問題主體是業主身分（雇主／自營作業者／攤商／創業者／企業主），employment_status 不是「可選」而是「必須」；但若問的是「某店／某攤的目標客群」（即其顧客），則不要使用 employment_status。**
**重要：除非問題明確指定地區（如「台北的…」「南部…」），否則 residence 一律留空 [] — 不要自己假設目標客戶集中在六都，台灣各縣市都有潛在客戶。**

有效選項：
- age: 0-11, 12-18, 19-24, 25-34, 35-44, 45-54, 55-64, 65+ （可選多個，最多3個）
- sex: 男, 女 （不確定就留空 []）
- occupation: 學生, 科技, 金融, 服務, 製造, 教育, 醫療, 公務, 家管, 退休, 其他
- employment_status: 受僱者, 雇主, 自營作業者, 無酬家屬, 不適用 （就業者從業身分。問題主體是業主本人＝老闆/攤商/創業者/企業主時**必須**使用；問其顧客時不要用。不確定就留空 []）
  （可選多個，上班族/SOHO/白領請對應到科技/金融/服務/製造等）
- residence: 台北市, 新北市, 桃園市, 台中市, 台南市, 高雄市, 基隆市, 新竹市, 新竹縣, 苗栗縣, 宜蘭縣, 彰化縣, 南投縣, 雲林縣, 嘉義市, 嘉義縣, 屏東縣, 花蓮縣, 台東縣, 澎湖縣, 金門縣, 連江縣 （不確定就留空 []）
- income: 無收入, <3萬, 3-8萬, >8萬 （可選多個）
- marriage: 未婚, 已婚, 離婚, 鰥寡 （不確定就留空 []）
- family_size: 1, 2, 3, 4, 5+ （不確定就留空 []）
|- hobby: 追劇, 閱讀, 打電動, 登山, 球類, 逛街購物, 園藝, 烹飪, 泡茶, 游泳, 打牌, 下棋, 音樂, 繪畫, 廣場舞
  （可選多個，不確定就留空 []。注意：資料庫只支援上述 15 個具體活動，沒有泛用詞如「運動」「戶外活動」。若問題提到「運動」，請挑選對應的具體活動如 登山/球類/游泳，而非發明不存在的值）
|- clothing_spend: <500, 500~1500, 1500~3000, 3000~5000, >5000 （月服飾消費等級，依 DGBAS 資料。不確定就留空 []）
|- commute_mode: 步行/腳踏車, 機車, 捷運/公車, 汽車, 在家工作 （主要通勤方式。不確定就留空 []）
|- family_income: <1萬, 1-3萬, 3-5萬, 5-7萬, 7萬, >8萬 （家庭月可支配所得。不確定就留空 []）
|- region: 都會區(六都), 北部, 中部, 南部, 花東, 離島
|- education: 國中以下, 高中, 大學, 研究所以上
|- housing_burden: 低, 中, 高 （居住負擔率，房貸/房租佔收入比）
|- housing_cost: <5千, 5千~1.5萬, 1.5萬~3萬 （每月居住支出。不確定就留空 []）
|- aesthetic_procedure: 無, 有 （醫美療程經歷，過去 12 個月有進行過醫美療程。不確定就留空 []）
|- debt_status: 無, 有房貸, 有信貸或卡債, 房貸+消費債 （債務背貸狀態。不確定就留空 []）

{data_overview}

{role_guidance}

回應格式（嚴格 JSON，不要有其他文字）：
{{
  "domain": "判斷這是什麼領域的問題",
  "reasoning": "簡短說明判斷理由",
  "filters": {{
    "age": ["年齡區間，使用上方有效值"],
    "occupation": ["職業，使用上方有效值"],
    "sex": [],
    "residence": [],
    "income": ["收入區間，使用上方有效值"],
    "marriage": []
  }},
  "dim_importance": {{
    "age": "0.0~1.0 (這個維度對問題有多重要，1.0=極重要，0.0=無關)",
    "income": "0.0~1.0",
    "occupation": "0.0~1.0",
    "family_income": "0.0~1.0",
    "family_size": "0.0~1.0"
  }},
  "question_analysis": [
    {{"question": "問題一", "topic": "主題", "target_user": "誰會關心這個"}}
  ],
  "usage_suggestion": {{
    "mode": "模擬詢問 或 問卷答題者 或 兩者皆可",
    "reason": "簡短說明為什麼這些 persona 適合這個用法",
    "recommended_opMode": "僅篩選 或 篩選+模擬"
  }}
}}

注意：
- 不確定的維度就留空陣列 []。
- 判斷邏輯：
  - 模擬詢問（遭遇模擬②）：問題是在問「產品/服務怎麼樣、哪個好、你覺得如何」— 目的是讓 LLM 扮演 persona 直接回答，回答本身就是產出。例如：「哪家銀行利率最高？」→ persona 回答「台銀2.075%配99次。」
  - 問卷答題者（自我模擬①）：問題是在描述一個情境、需要找「對的人來問意見/推薦」— 目的是找到合適的 persona 當作問卷對象，再對他們發問卷。例如：「找新竹課輔班推薦」→ 目標是找到新竹家長，然後問他們推薦哪家。
  - 兩者皆可：如果問題兼具兩種特性。
- usage_suggestion.recommended_opMode: 模擬詢問建議用「篩選+模擬」；問卷答題者建議用「僅篩選」（拿 list 自己做問卷）。
"""

BROADEN_PROMPT = """你剛才對問題的分析產出了一組篩選條件（filters），但篩選後只匹配到 **{match_count}** 人（目標是至少 **{target_min}** 人）。
現有篩選條件太嚴格了。請在不改變對問題的核心判斷下，**只放寬或移除 1 個篩選維度**（不要一次動多個維度，否則樣本數會暴增失去精準度）。

你可以：
- 在現有維度中加入更多值（如 income 從 [>8萬] 擴大到 [>8萬, 3-8萬]）
- 刪除一個非核心的維度（如 hobby、marriage）
- 不要刪除核心維度（對這個問題最重要的 2-3 個 dims）
- **嚴格限制：每次回覆只能放寬或刪除 1 個維度**
- 若你判斷已無法在不改變核心判斷的前提下放寬（例如剩下的都是核心維度），請**原樣回傳** filters，並在 broadening 說明原因 — 不要為了放寬而放寬（原樣回傳會被視為「無法再放寬」而提前結束迴圈）
- **若你要放寬一個「資料庫中極稀有」的維度，必須在 `change` 明確寫出「為何它不是本問題的核心條件」**；若它是本問題的核心條件，請保留不要放寬（並說明理由）

你已看過資料庫的分布（資料庫概覽），請參考分布來決定放寬方式。

**維度有效值（只能使用下列值，不要發明不存在的值）：**
- age: 0-11, 12-18, 19-24, 25-34, 35-44, 45-54, 55-64, 65+
- sex: 男, 女
- occupation: 學生, 科技, 金融, 服務, 製造, 教育, 醫療, 公務, 家管, 退休, 其他
- employment_status: 受僱者, 雇主, 自營作業者, 無酬家屬, 不適用 （就業者從業身分。問題主體是業主本人＝老闆/攤商/創業者/企業主時**必須**使用；問其顧客時不要用。不確定就留空 []）
- residence: 台北市, 新北市, 桃園市, 台中市, 台南市, 高雄市, 基隆市, 新竹市, 新竹縣, 苗栗縣, 宜蘭縣, 彰化縣, 南投縣, 雲林縣, 嘉義市, 嘉義縣, 屏東縣, 花蓮縣, 台東縣, 澎湖縣, 金門縣, 連江縣
- income: 無收入, <3萬, 3-8萬, >8萬
- marriage: 未婚, 已婚, 離婚, 鰥寡
- family_size: 1, 2, 3, 4, 5+
- hobby: 追劇, 閱讀, 打電動, 登山, 球類, 逛街購物, 園藝, 烹飪, 泡茶, 游泳, 打牌, 下棋, 音樂, 繪畫, 廣場舞
- clothing_spend: <500, 500~1500, 1500~3000, 3000~5000, >5000
- commute_mode: 步行/腳踏車, 機車, 捷運/公車, 汽車, 在家工作
- family_income: <1萬, 1-3萬, 3-5萬, 5-7萬, 7萬, >8萬
- region: 都會區(六都), 北部, 中部, 南部, 花東, 離島
- education: 國中以下, 高中, 大學, 研究所以上
- housing_burden: 低, 中, 高
- housing_cost: <5千, 5千~1.5萬, 1.5萬~3萬
- aesthetic_procedure: 無, 有 （醫美療程經歷。只用在醫美療程/整形/皮膚科語意的問題）
- debt_status: 無, 有房貸, 有信貸或卡債, 房貸+消費債

{rare_dims_hint}

{constraint_hint}

當前篩選條件：
```json
{current_filters}
```

你的回覆（嚴格 JSON）：
{{
  "broadening": "簡短說明放寬了什麼（繁體中文）。只描述你改了哪個維度、怎麼改；不要預測或承諾樣本數（例如不要寫「預期可增加至 20 人以上」）",
  "filters": {{ ... }}
}}
"""

SIMULATION_PROMPT = """你正在進行市場研究模擬。以下是 persona 的完整背景：

Persona ID: {persona_id}
姓名: {name}
年齡: {age} | 居住地: {residence}
職業: {occupation} | 收入: {income}
家庭: {family_size}人 | 婚姻: {marriage}
興趣: {hobby}

背景故事: {background_story}
Persona 語氣: {prompt_prefix}

現在這個 persona 被問到以下問題：
{questions}

請以第一人稱「我」的口吻，用自然的口語中文，為每個問題回答 2-4 句話。
回答要符合 persona 的年齡、職業、收入、居住地等背景。
不要提到任何關於模擬、角色扮演的字眼。

輸出 JSON 格式：
{{
  "answers": [
    {{"question": "問題一", "answer": "以 persona 身份的回答"}},
    {{"question": "問題二", "answer": "以 persona 身份的回答"}}
  ]
}}
"""


# ── LLM Call ───────────────────────────────────────────────────────

def _extract_json_or_text(text: str) -> str:
    """Extract a JSON block (or fallback text) from reasoning_content."""
    if not text or not text.strip():
        return ""
    # Look for JSON blocks (markdown fences or bare { ... })
    import re
    if "```json" in text:
        m = text.split("```json", 1)[1].split("```", 1)
        if m[0].strip():
            return m[0].strip()
    elif "```" in text:
        m = text.split("```", 1)[1].split("```", 1)
        if m[0].strip():
            return m[0].strip()
    # Try to find a JSON object at the start
    stripped = text.strip()
    if stripped.startswith("{"):
        # Return the whole thing if it looks like JSON (caller will parse)
        return stripped
    return stripped


# v5.8（kstsai 2026-09-14 定案）：analysis 呼叫的 token 預算表。
# 基礎預算 pro 8000 → 12000：依 v5.7 SOP/第八輪累積的 4 次截斷事件（3 天內，全部
# finish_reason=length），每次救援都要一整通額外呼叫（單案延遲約 2.4 倍）。提高上限
# 不強迫模型多產生 token（成本影響≈0），但可避免多數重試。
# 重試仍須「帶變化」（#46）：pro 12000 → 18000。
ANALYSIS_MAX_TOKENS = {"pro": 12000, "flash": 4000}
ANALYSIS_RETRY_MAX_TOKENS = {"pro": 18000, "flash": 8000}


def analysis_max_tokens_for(model: Optional[str], retry: bool = False) -> int:
    """回傳 analysis 呼叫的 token 預算（pro = reasoning-heavy 需較大預算，見上表）。"""
    is_pro = bool(model) and "pro" in (model or "").lower()
    table = ANALYSIS_RETRY_MAX_TOKENS if retry else ANALYSIS_MAX_TOKENS
    return table["pro"] if is_pro else table["flash"]


def _resolve_max_tokens(model: str, requested: int) -> int:
    """D1 (retry firewall): pro model 是 reasoning-heavy，至少 8000 tokens
    才能一次產出 JSON（reasoning + content）。requested 視為「建議下限」，
    pro 不足 8000 就補到 8000；flash 關 thinking，requested 就夠。"""
    if "pro" in model.lower():
        return max(requested, 8000)
    return requested


# ── D4 circuit breaker (module-level state) ──────────────────────
_fail_count = 0
_cooldown_until = 0.0
CIRCUIT_FAIL_THRESHOLD = 3
CIRCUIT_COOLDOWN_S = 60


def _circuit_open() -> bool:
    return _cooldown_until > time.monotonic()


def _record_failure() -> None:
    global _fail_count, _cooldown_until
    _fail_count += 1
    if _fail_count >= CIRCUIT_FAIL_THRESHOLD:
        _cooldown_until = time.monotonic() + CIRCUIT_COOLDOWN_S
        logger.warning(f"Circuit breaker OPEN: {_fail_count} consecutive LLM failures — cooling down {CIRCUIT_COOLDOWN_S}s")
        _fail_count = 0


def _record_success() -> None:
    global _fail_count
    _fail_count = 0


# #50: 最近一次 LLM 回應的診斷資訊（finish_reason 等）。讓 caller 能分辨
# 「被截斷（token 不夠）」與「其他格式問題」—— 過去 finish_reason 只在 content
# **為空**時才被用到；content 非空即使被截斷也直接回傳，caller 完全看不到。
_LAST_LLM_META: dict = {}


def _llm_result(text, return_meta: bool, meta: Optional[dict] = None):
    """#50: return_meta=True 時回 `(text, meta)`，否則回純 text（既有呼叫端不受影響）。"""
    if not return_meta:
        return text
    return text, dict(meta if meta is not None else _LAST_LLM_META)


@overload
async def call_llm(
    prompt: str,
    system_prompt: str = ...,
    temperature: float = ...,
    max_tokens: int = ...,
    model_override: Optional[str] = None,
    return_meta: Literal[False] = False,
) -> Optional[str]: ...


@overload
async def call_llm(
    prompt: str,
    system_prompt: str = ...,
    temperature: float = ...,
    max_tokens: int = ...,
    model_override: Optional[str] = None,
    *,
    return_meta: Literal[True],
) -> tuple[Optional[str], dict]: ...


async def call_llm(
    prompt: str,
    system_prompt: str = "你是一個有用的台灣市場研究助手，請用繁體中文回應。",
    temperature: float = 0.3,
    max_tokens: int = 2000,
    model_override: Optional[str] = None,
    return_meta: bool = False,
) -> Union[Optional[str], tuple[Optional[str], dict]]:
    """Call the LLM API and return the response text.

    Retry firewall (RFC #24):
    - D1: pro model 依 _resolve_max_tokens 給足 8000，避免 reasoning 餓死 content。
    - D2: 只在 finish_reason=length（真截斷）才 retry 1 次（+50%）；garbage /
      reasoning-only 非截斷直接回 None，不重試。
    - D3: content 空先挖 reasoning_content（已付費，白拿）。
    - D4 (#50): `return_meta=True` 回 `(text, meta)`，meta 含
      `finish_reason` / `truncated` / `model` / `max_tokens` / `usage`
      → caller 可從 log 直接分辨截斷與其他失敗。content 非空但被截斷時也會警告。
    """
    api_key = LLM_CONFIG["api_key"]
    base_url = LLM_CONFIG["base_url"]
    model = model_override or LLM_CONFIG["model"]
    max_tokens = _resolve_max_tokens(model, max_tokens)  # D1: 依 model 給足預算

    if not api_key:
        logger.warning("No LLM API key configured — LLM features disabled")
        return None

    if _circuit_open():
        logger.warning("Circuit breaker open — skipping LLM call, returning None")
        return None

    truncation_retried = False
    for attempt in range(3):
        meta = None
        try:
            # flash model: disable reasoning mode (verbose self-talk eats budget)
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt},
                ],
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
            if "flash" in model.lower():
                payload["thinking"] = {"type": "disabled"}
            async with httpx.AsyncClient(timeout=90) as client:
                resp = await client.post(
                    f"{base_url}/chat/completions",
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )
                resp.raise_for_status()
                data = resp.json()
                choice = data["choices"][0]
                message = choice.get("message", {})
                content = message.get("content") or ""
                reasoning = message.get("reasoning_content") or ""
                finish_reason = choice.get("finish_reason", "")
                # #50: 記錄本次回應的診斷資訊（供 caller 判斷截斷 vs 其他失敗）
                meta = {
                    "finish_reason": finish_reason,
                    "truncated": finish_reason == "length",
                    "model": model,
                    "max_tokens": max_tokens,
                    "usage": data.get("usage") or {},
                }
                _LAST_LLM_META.clear()
                _LAST_LLM_META.update(meta)
                if content.strip():
                    _record_success()
                    if finish_reason == "length":
                        # #50: content 非空但被截斷 —— 結構化輸出（JSON）很可能不完整，
                        # 過去這種情況完全不記錄，導致解析失敗只能靠猜。
                        logger.warning(
                            f"LLM content 非空但被截斷（finish_reason=length, max_tokens={max_tokens}, "
                            f"model={model}）—— 若要求結構化輸出，可能無法解析"
                        )
                    return _llm_result(content, return_meta, meta)
                # D3: reasoning 已付費，先挖 JSON 再決定要不要 retry
                if reasoning:
                    extracted = _extract_json_or_text(reasoning)
                    if extracted:
                        _record_success()
                        return _llm_result(extracted, return_meta, meta)
                # D2: 只在「真截斷」才 retry（token 不夠），+50% 非翻倍
                if finish_reason == "length" and not truncation_retried:
                    truncation_retried = True
                    max_tokens = int(max_tokens * 1.5)
                    logger.warning(f"LLM truncated (finish_reason=length), retrying with max_tokens={max_tokens}")
                    await asyncio.sleep(1)
                    continue
                # reasoning-only 非截斷 / garbage → 真失敗，不重試
                _record_failure()
                return _llm_result(None, return_meta, meta)
        except Exception as e:
            # #55: httpx 的逾時／連線類例外 str(e) 常為空（log 只剩 "LLM call failed: " 無法歸因）
            # → 一律帶例外型別，並保留非空訊息
            _detail = f"{type(e).__name__}" + (f": {e}" if str(e) else "")
            logger.error(
                f"LLM call failed [{_detail}] (model={model}, max_tokens={max_tokens}, "
                f"timeout={LLM_CONFIG.get('timeout')})"
            )
            _LAST_LLM_META.clear()
            _LAST_LLM_META.update({"error": _detail, "error_type": type(e).__name__,
                                   "model": model, "max_tokens": max_tokens})
            if attempt < 2:
                backoff = [1, 3][attempt]
                logger.warning(f"Retrying in {backoff}s (network error, attempt {attempt+1}/3)...")
                await asyncio.sleep(backoff)
                continue
            _record_failure()
            return _llm_result(None, return_meta, meta)
    return _llm_result(None, return_meta)


def build_distribution_summary(db: list) -> str:
    """
    Build per-dim value distribution summary for LLM data grounding.
    Format: "dim: value(N), value(N), ..."
    Dynamically computed from persona data (no hardcode).
    """
    from collections import Counter
    SCORED_DIMS = [
        "age", "sex", "region", "residence", "education", "occupation",
        "income", "family_income", "family_size", "marriage",
        "commute_mode", "housing_cost", "housing_burden", "clothing_spend",
    ]
    lines = ["資料庫概覽（1069 位台灣人設，依人數排列）："]
    for dim in SCORED_DIMS:
        c = Counter()
        for p in db:
            v = p.get("dimensions", {}).get(dim)
            if isinstance(v, list):
                for x in v:
                    c[x] += 1
            elif v:
                c[v] += 1
        # Top 8 values only
        top = [f"{v}({n})" for v, n in c.most_common(8)]
        lines.append(f"- {dim}: {', '.join(top)}")
    return "\n".join(lines)


async def parse_questions_with_llm(questions: list[str], role: Optional[str] = None, distribution: str = "") -> dict:
    """
    Use LLM to analyze questions and determine target demographics.
    Args:
        questions: list of question strings
        role: optional role context (e.g. 房仲業者, 銀行業者) — helps LLM tailor filters
    Returns structured filters or empty dict on failure.
    """
    if not questions:
        return {}
    
    # Inject role context into prompt if provided
    role_guidance = ""
    if role:
        for kw, guidance in ROLE_GUIDANCE.items():
            if kw in role:
                role_guidance = f"**發問者角色：{role}**\n{guidance}"
                break
        if not role_guidance:
            role_guidance = f"**發問者角色：{role}**\n請思考這個角色為什麼問這個問題、想找什麼樣的人，並據此調整 filter 方向。"
    
    prompt = QUESTION_ANALYSIS_PROMPT.format(
        questions="\n".join(f"- {q}" for q in questions),
        data_overview=distribution or "（未載入資料分布）",
        role_guidance=role_guidance or "",
    )
    
    # Retry once on JSON parse failure (truncated/invalid response)
    analysis_model = LLM_CONFIG.get("analysis_model") or None
    # pro model keeps reasoning mode: give it more budget so reasoning_content
    # doesn't consume the window and leave content empty (issue #14).
    # flash has reasoning disabled (thinking=disabled), so 4000 is enough.
    # v5.8: 預算表見模組常數 ANALYSIS_MAX_TOKENS / ANALYSIS_RETRY_MAX_TOKENS
    analysis_max_tokens = analysis_max_tokens_for(analysis_model)
    # #46: 重試要「帶變化」—— 同一組參數重試只會複製同一個失敗（實測 TESLA query：
    # 兩次都回非 JSON → 硬 503）。解析失敗時提高 token 預算（pro 12000→18000、
    # flash 4000→8000，僅在失敗時發生，不做 doubling 輪詢），讓被 reasoning 吃光的
    # 回應有機會吐出完整 JSON。
    retry_max_tokens = analysis_max_tokens_for(analysis_model, retry=True)
    for parse_attempt in range(2):
        attempt_max_tokens = analysis_max_tokens if parse_attempt == 0 else max(analysis_max_tokens, retry_max_tokens)
        # #50: return_meta=True 取得 finish_reason（分辨「截斷」vs「其他格式問題」）
        _resp = await call_llm(prompt, temperature=0.2, max_tokens=attempt_max_tokens,
                               model_override=analysis_model, return_meta=True)
        if isinstance(_resp, tuple) and len(_resp) == 2:   # 兼容舊 stub / 非 meta 回傳
            response, meta = _resp
        else:
            response, meta = _resp, {}
        fr = (meta or {}).get("finish_reason") or "unknown"
        truncated = (meta or {}).get("truncated")
        if not response:
            if parse_attempt == 0:
                logger.warning(
                    f"LLM returned empty response (finish_reason={fr}, truncated={truncated}, "
                    f"max_tokens={attempt_max_tokens}), retrying with max_tokens={max(analysis_max_tokens, retry_max_tokens)}..."
                )
                await asyncio.sleep(1)
                continue
            logger.error(
                f"LLM returned empty response twice (finish_reason={fr}, truncated={truncated}) "
                f"— giving up (fallback: keyword parsing)"
            )
            return {}
        
        # Try to extract JSON from response
        try:
            # Find JSON block (handle markdown code fences)
            if "```json" in response:
                json_str = response.split("```json")[1].split("```")[0].strip()
            elif "```" in response:
                json_str = response.split("```")[1].split("```")[0].strip()
            else:
                json_str = response.strip()
            
            result = json.loads(json_str)
            return result
        except (json.JSONDecodeError, IndexError) as e:
            # #46: 失敗原因必須在生產環境（INFO level）看得見 —— 原本 raw response
            # 只在 logger.debug，導致 503 事故只能靠推測（無法判斷是空回應、截斷、
            # 還是 reasoning 洩漏）。截斷後以 WARNING 記錄（不記完整內容，避免 log 爆炸）。
            # #50: 一併記錄 finish_reason —— 可直接分辨「被截斷」與「其他格式問題」。
            logger.warning(
                f"Failed to parse LLM response as JSON (attempt {parse_attempt + 1}/2, "
                f"finish_reason={fr}, truncated={truncated}, max_tokens={attempt_max_tokens}): {e}"
            )
            logger.warning(f"Raw LLM response (first 300 chars): {response[:300]!r}")
            if parse_attempt == 0:
                logger.warning(
                    f"JSON parse failed, retrying with max_tokens={max(analysis_max_tokens, retry_max_tokens)}..."
                )
                await asyncio.sleep(1)
                continue
            logger.error(
                f"LLM response unparseable twice (finish_reason={fr}, truncated={truncated}) "
                f"— giving up (fallback: keyword parsing)"
            )
            return {}
    return {}


async def simulate_with_llm(persona: dict, questions: list[str]) -> dict:
    """
    Use LLM to simulate a persona answering questions (遭遇模擬②).
    """
    dims = persona.get("dimensions", {})
    q_text = "\n".join(f"Q{i+1}. {q}" for i, q in enumerate(questions))
    
    prompt = SIMULATION_PROMPT.format(
        persona_id=persona.get("id", ""),
        name=persona.get("name", ""),
        age=dims.get("age", ""),
        residence=dims.get("residence", ""),
        occupation=dims.get("occupation", ""),
        income=dims.get("income", ""),
        family_size=dims.get("family_size", ""),
        marriage=dims.get("marriage", ""),
        hobby=", ".join(dims.get("hobby", [])),
        background_story=dims.get("background_story", ""),
        prompt_prefix=persona.get("prompt_prefix", "")[:500],
        questions=q_text,
    )
    
    response = await call_llm(prompt, temperature=0.7, max_tokens=3000)
    if not response:
        return {"status": "failed", "answers": []}
    
    try:
        if "```json" in response:
            json_str = response.split("```json")[1].split("```")[0].strip()
        elif "```" in response:
            json_str = response.split("```")[1].split("```")[0].strip()
        else:
            json_str = response.strip()
        
        result = json.loads(json_str)
        answers = result.get("answers", [])
        return {
            "status": "completed",
            "answers": [a.get("answer", "") for a in answers]
        }
    except (json.JSONDecodeError, IndexError) as e:
        logger.warning(f"Failed to parse simulation response: {e}")
        return {
            "status": "completed",
            "answers": [response[:500]]  # Return raw text as fallback
        }
