# Persona DB — 部署管線與版本管理

## 兩個 Repo 架構

| Repo | 角色 | 上層目錄 |
|:-----|:------|:----------|
| `persona-db` | 資料來源 (source of truth) | `~/persona-db/` |
| `persona-db-release` | 甲方拿到的 deploy bundle | `~/persona-db-release/` |

## 版本生命週期

```
persona-db/hermesa3/persona/VERSION  (v3.2)
       │
       ├── build_appliance.py → persona-appliance-v3.2.zip (分身交付)
       └── pack-persona-db-release.sh → persona-db-rel-1.0.tar.gz
                │
                ├── tarball 內含 VERSION = v3.2
                └── 複製到 persona-db-release/upDockerVerHermes/
                     │
                     deploy-hermes-personadb-containers.sh
                     deploy-persona-db-compose.sh
                     deploy-persona-db-api.sh
```

## ⚠️ 陷阱：Deploy Script 中硬寫死 VERSION

**問題**:
`deploy-hermes-personadb-containers.sh` 和 `deploy-persona-db-compose.sh`
如果在部署時硬寫 `echo "vX.Y" > VERSION`，會蓋掉 tarball 內的真實版本，
導致 dh5 (deploy VM) 顯示的版本跟 a3 本尊不一致。

**修正方向**:
Deploy script 不應自己產生 VERSION，而是直接讀取從 tarball 解出來的 VERSION 檔案：
```bash
READ_VERSION=$(cat "${PERSONA_DB_DATA}/VERSION" 2>/dev/null || echo "unknown")
echo "  ✅ VERSION from data: ${READ_VERSION}"
```

**部署到 dh5 的完整流程**:
```bash
# 1. 在 a3 本尊重新打包（最新 persona-db repo）
cd ~/persona-db
bash pack-persona-db-release.sh

# 2. 複製到 persona-db-release repo
cp persona-db-rel-1.0.tar.gz ~/persona-db-release/upDockerVerHermes/

# 3. Commit + push
cd ~/persona-db-release
git add -A
git commit -m "sync: repack tarball from latest persona-db"
git push origin main

# 4. 在 dh5 上 pull + deploy
ssh lzcdh5
cd ~/persona-db-release
git pull origin main
bash upDockerVerHermes/deploy-hermes-personadb-containers.sh
```

## Tarball 內容
由 `pack-persona-db-release.sh` 產生，包含：
- Python source (`api/`, `*.py`)
- Persona 資料 (`tw_persona_1069.json`, CSV files)
- Skills (`skills/`)
- VERSION file (根目錄)
