# Gitea for hermesa3.clone

Start Gitea:
```bash
sudo systemctl start gitea
```

Open http://localhost:3000 to complete setup.
Create repos for your AI agent to work with.
