# hermesa3.clone

An AI Agent appliance. Includes ~70 sanitized skills + Gitea.

## Quick Start
1. `cp env/.env.template ~/.hermes/.env` — fill in API keys
2. `hermes setup` — run the wizard
3. `hermes` — start chatting

See an issue? Contact your appliance provider.
