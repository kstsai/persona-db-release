#!/usr/bin/env python3
"""Chunk 2 (179筆) 全量常理驗證 — 10項機械檢查 + 語意分類"""

import json, re, sys

with open("/home/ubuntu/lab-riscv/hermesa3/persona/tw_persona_chunk_2.json") as f:
    data = json.load(f)

results = {i: [] for i in range(1, 11)}

# ---------- helpers ----------
def get(p, field):
    v = p.get("dimensions", {}).get(field)
    if v is None:
        v = p.get(field)
    return v

def age_num(p):
    a = p.get("dimensions", {}).get("age", "")
    if not a:
        return -1
    m = re.match(r"(\d+)-(\d+)", a)
    if m:
        return (int(m.group(1)) + int(m.group(2))) // 2
    return -1

def lowest_age(p):
    a = p.get("dimensions", {}).get("age", "")
    m = re.match(r"(\d+)-(\d+)", a)
    if m:
        return int(m.group(1))
    return -1

def bg(p):
    return str(p.get("dimensions", {}).get("background_story", ""))

def prefix(p):
    return str(p.get("prompt_prefix", ""))

def full_text(p):
    return bg(p) + " " + prefix(p)

income_keywords_comfortable = ["寬裕", "不用太省", "品質還不錯", "該花的會花", "有些積蓄"]
income_keywords_tight = ["省著點", "壓力很大", "不夠用", "手頭緊", "入不敷出", "每一塊錢", "精打細算", "能省則省", "比價"]

def has_comfortable_lang(t):
    return any(k in t for k in income_keywords_comfortable)

def has_tight_lang(t):
    return any(k in t for k in income_keywords_tight)

# ========== CHECK 1: 收入 vs 描述 ==========
for p in data:
    inc = get(p, "income")
    t = bg(p) + " " + prefix(p)
    name = p.get("name", "?")
    pid = p.get("id", "?")
    if inc == "<3萬" and has_comfortable_lang(t):
        results[1].append((name, pid, f"收入<3萬，背景/prefix卻用舒適語氣", "REAL"))
    elif inc == "<3萬" and has_comfortable_lang(bg(p)):
        results[1].append((name, pid, f"收入<3萬，bg用舒適語氣", "REAL"))
    elif inc == ">8萬" and has_tight_lang(t):
        results[1].append((name, pid, f"收入>8萬，背景/prefix卻用拮据語氣", "REAL"))
    elif inc == "<3萬" and has_tight_lang(t):
        pass  # consistent
    elif inc == ">8萬" and has_comfortable_lang(t):
        pass  # consistent

# Also check prefix-level contradictions
for p in data:
    inc = get(p, "income")
    name = p.get("name", "?")
    pid = p.get("id", "?")
    pr = prefix(p)
    bg_ = bg(p)
    # bg says comfortable but prefix says tight (REAL)
    if inc == "<3萬":
        if has_comfortable_lang(bg_) and has_tight_lang(pr):
            # Check if already reported
            if not any(r[0]==name and r[1]==pid and "REAL" in r[3] for r in results[1]):
                results[1].append((name, pid, f"bg說{income_keywords_comfortable}但prefix說{income_keywords_tight} — 前後矛盾", "REAL"))
    if inc == "3-8萬":
        # 3-8萬, bg說舒適 but prefix說拮据
        if has_comfortable_lang(bg_) and has_tight_lang(pr):
            results[1].append((name, pid, f"收入3-8萬，bg用舒適語氣但prefix用拮据語氣", "REAL"))
    if inc == ">8萬":
        if has_comfortable_lang(bg_) and has_tight_lang(pr):
            results[1].append((name, pid, f"收入>8萬，bg用舒適語氣但prefix說拮据", "REAL"))

# ========== CHECK 2: 獨居+小孩 ==========
for p in data:
    fs = get(p, "family_size")
    name = p.get("name", "?")
    pid = p.get("id", "?")
    t = full_text(p)
    if fs == "1" and ("小孩" in t or "孩子" in t):
        # Check context — 獨居但提到小孩? 
        # Only flag if bg/prefix mentions children as own (not "爸媽的小孩" or "唯一的孩子")
        # "小孩開銷" or "孩子的教育" in the context of a single person
        has_own_child = False
        for phrase in ["小孩的開銷", "孩子的開銷", "小孩的教育", "養小孩", "帶小孩"]:
            if phrase in t:
                has_own_child = True
        if has_own_child:
            results[2].append((name, pid, f"family_size=1但bg提到小孩開銷", "REAL"))
        elif "小孩" in t and "開銷" in t:
            results[2].append((name, pid, f"family_size=1但bg提到小孩相關開銷", "REAL"))
    # Check: single (no spouse) + mentions children
    marr = get(p, "marriage")
    if fs == "1" and marr in ("未婚", "離婚") and ("小孩" in t or "孩子" in t) and ("父母" in bg(p) or "爸媽" in bg(p)):
        pass  # maybe OK if "小孩" = themselves as parent's child

# ========== CHECK 3: 已婚+fs=1無配偶 ==========
for p in data:
    marr = get(p, "marriage")
    fs = get(p, "family_size")
    name = p.get("name", "?")
    pid = p.get("id", "?")
    t = full_text(p)
    if marr == "已婚" and fs == "1":
        # Check if spouse mentioned
        if "配偶" not in t and "夫妻" not in t and "結婚" not in t:
            results[3].append((name, pid, f"已婚+family_size=1，但bg未提及配偶", "REAL"))
        elif "分居" in t or "長期在國外" in t or "暫時分居" in t or "在外地工作" in t:
            # Has explanation
            results[3].append((name, pid, f"已婚+fs=1但有配偶異地說明", "OK"))
        else:
            results[3].append((name, pid, f"已婚+fs=1，bg有配偶但fs=1", "MINOR" if "配偶" in t else "REAL"))

# ========== CHECK 4: 未成年有收入 ==========
for p in data:
    a = lowest_age(p)
    inc = get(p, "income")
    name = p.get("name", "?")
    pid = p.get("id", "?")
    if 0 <= a <= 18 and inc != "無收入":
        results[4].append((name, pid, f"age={a}但有收入({inc})", "REAL"))

# ========== CHECK 5: 65+描述年輕子女 ==========
for p in data:
    a = lowest_age(p)
    name = p.get("name", "?")
    pid = p.get("id", "?")
    t = full_text(p)
    if a >= 65 and ("小孩" in t or "孩子" in t):
        # Distinguish: "子女" means grown children, "小孩" can mean young children
        if "小孩" in t and "子女" not in t:
            if "開銷" in t or "教育" in t or "花錢" in t:
                results[5].append((name, pid, f"age≥65但描述小孩開銷（非子女）", "MINOR"))

# ========== CHECK 6: 含飴弄孫+低收入+高物價 ==========
for p in data:
    inc = get(p, "income")
    pt = p.get("dimensions", {}).get("price_tier", "")
    name = p.get("name", "?")
    pid = p.get("id", "?")
    t = full_text(p)
    if inc == "<3萬" and pt in ("高", "中高"):
        if "含飴弄孫" in t:
            results[6].append((name, pid, f"含飴弄孫+收入<3萬+高物價區", "OK" if "含飴弄孫" in bg(p) else "REAL"))

# ========== CHECK 7: 未成年非學生 ==========
for p in data:
    a = lowest_age(p)
    occ = get(p, "occupation")
    name = p.get("name", "?")
    pid = p.get("id", "?")
    if 0 <= a <= 18 and occ and occ != "學生":
        results[7].append((name, pid, f"age={a}但職業={occ}（非學生）", "REAL" if a < 15 else "OK"))

# ========== CHECK 8: BG前後句矛盾 ==========
for p in data:
    name = p.get("name", "?")
    pid = p.get("id", "?")
    bgs = bg(p)
    prs = prefix(p)
    # e.g. "沒有生小孩" + "小孩開銷"
    if "沒有生小孩" in bgs and "小孩" in bgs:
        # Already has both in bg — contradiction within bg
        pass
    if "沒有生小孩" in bgs and ("小孩的開銷" in bgs or "孩子的開銷" in bgs or "小孩的教育" in bgs):
        results[8].append((name, pid, f"bg說沒有生小孩但又有小孩開銷", "REAL"))
    if "沒有生小孩的打算" in bgs and ("開銷很大" in bgs and ("小孩" in bgs or "孩子" in bgs)):
        results[8].append((name, pid, f"bg說不打算生但提小孩開銷", "REAL"))
    # "夫妻兩人世界" + "小孩的開銷"
    if "夫妻兩人" in bgs and ("小孩的開銷" in bgs or "小孩的教育" in bgs):
        results[8].append((name, pid, f"夫妻兩人世界卻有小孩開銷", "REAL"))
    # "享受單身生活" + "上有老下有小"
    if "享受單身" in bgs and "上有老下有小" in bgs:
        results[8].append((name, pid, f"享受單身生活又說上有老下有小", "REAL"))
    # "一個人租套房" + "上有老下有小"
    if "一個人租套房" in bgs and "上有老下有小" in bgs:
        results[8].append((name, pid, f"一個人租套房卻說上有老下有小", "REAL"))
    # "自己一個人住" + "上有老下有小"
    if "自己一個人住" in bgs and "上有老下有小" in bgs:
        results[8].append((name, pid, f"自己一個人住卻說上有老下有小", "REAL"))
    # "一個人生活" + "上有老下有小"
    if ("一個人" in bgs or "自己一個人" in bgs) and "上有老下有小" in bgs:
        results[8].append((name, pid, f"獨居卻說上有老下有小", "REAL"))
    # prefix says 輕鬆 but bg says 壓力大
    if "日子過得滿舒服" in prs and ("壓力" in bgs or "手頭緊" in bgs or "入不敷出" in bgs):
        results[8].append((name, pid, f"bg說拮据但prefix說過得舒服", "REAL"))
    if "收入算很高" in prs and "壓力" in bgs:
        results[8].append((name, pid, f"bg說有壓力但prefix說收入很高舒服", "REAL"))

# ========== CHECK 9: 學生+已婚 ==========
for p in data:
    occ = get(p, "occupation")
    marr = get(p, "marriage")
    name = p.get("name", "?")
    pid = p.get("id", "?")
    if occ == "學生" and marr not in ("未婚", "無", None, ""):
        results[9].append((name, pid, f"職業是學生但婚姻={marr}", "REAL"))

# ========== CHECK 10: 12-18教育=大學 ==========
for p in data:
    a_min = lowest_age(p)
    edu = get(p, "education")
    name = p.get("name", "?")
    pid = p.get("id", "?")
    if 12 <= a_min <= 18 and edu == "大學":
        results[10].append((name, pid, f"age={a_min}但教育程度=大學（應為高中）", "REAL" if a_min <= 15 else "MINOR"))

# ========== REPORT ==========
check_names = {
    1: "收入 vs 描述",
    2: "獨居+小孩",
    3: "已婚+fs=1無配偶",
    4: "未成年有收入",
    5: "65+年輕子女",
    6: "含飴弄孫+低收入+高物價",
    7: "未成年非學生",
    8: "BG前後句矛盾",
    9: "學生+已婚",
    10: "12-18教育=大學"
}

print("=" * 70)
print("TW Persona Chunk 2 — 全量常理驗證報告")
print("共 179 筆 (TW-P-0180 ~ TW-P-0358)")
print("=" * 70)

totals = {"REAL": 0, "OK": 0, "MINOR": 0}
check_counts = {}

for ci in range(1, 11):
    items = results[ci]
    rc = {"REAL": 0, "OK": 0, "MINOR": 0}
    for _, _, _, cat in items:
        rc[cat] = rc.get(cat, 0) + 1
    check_counts[ci] = rc
    for c in ["REAL", "OK", "MINOR"]:
        totals[c] += rc.get(c, 0)
    total_ci = len(items)
    status = "⚠️ 有發現" if items else "✅ 無異常"
    print(f"\n--- 檢查{ci}. {check_names[ci]} --- {status}")
    if items:
        print(f"    REAL: {rc.get('REAL',0)}  OK: {rc.get('OK',0)}  MINOR: {rc.get('MINOR',0)}  (共{total_ci}項)")

print("\n" + "=" * 70)
print("分類彙總：")
for c in ["REAL", "OK", "MINOR"]:
    print(f"  {c}: {totals[c]} 項")
print(f"  總計: {sum(totals.values())} 項")

print("\n" + "=" * 70)
print("詳細 REAL 發現列表")
print("=" * 70)

real_count = 0
for ci in range(1, 11):
    items = results[ci]
    real_items = [(n, pid, desc) for n, pid, desc, cat in items if cat == "REAL"]
    if real_items:
        print(f"\n【檢查{ci}. {check_names[ci]}】— {len(real_items)} 個 REAL")
        for n, pid, desc in real_items:
            real_count += 1
            print(f"  {real_count}. [{pid}] {n}：{desc}")

# Also show OK and MINOR for context
print("\n" + "=" * 70)
print("詳細 OK 發現列表")
print("=" * 70)
ok_count = 0
for ci in range(1, 11):
    items = results[ci]
    ok_items = [(n, pid, desc) for n, pid, desc, cat in items if cat == "OK"]
    if ok_items:
        print(f"\n【檢查{ci}. {check_names[ci]}】— {len(ok_items)} 個 OK")
        for n, pid, desc in ok_items:
            ok_count += 1
            print(f"  [{pid}] {n}：{desc}")

print("\n" + "=" * 70)
print("詳細 MINOR 發現列表")
print("=" * 70)
minor_count = 0
for ci in range(1, 11):
    items = results[ci]
    minor_items = [(n, pid, desc) for n, pid, desc, cat in items if cat == "MINOR"]
    if minor_items:
        print(f"\n【檢查{ci}. {check_names[ci]}】— {len(minor_items)} 個 MINOR")
        for n, pid, desc in minor_items:
            minor_count += 1
            print(f"  [{pid}] {n}：{desc}")

# ========== Trend Summary ==========
print("\n" + "=" * 70)
print("趨勢總結")
print("=" * 70)

print("\n1. 最常見的 REAL 模式：")
# Count by check
real_by_check = {}
for ci in range(1, 11):
    n = sum(1 for _, _, _, c in results[ci] if c == "REAL")
    if n > 0:
        real_by_check[check_names[ci]] = n
for k, v in sorted(real_by_check.items(), key=lambda x: -x[1]):
    print(f"   🔴 {k}: {v} 件")

print("\n2. 最常見的 OK 模式：")
ok_by_check = {}
for ci in range(1, 11):
    n = sum(1 for _, _, _, c in results[ci] if c == "OK")
    if n > 0:
        ok_by_check[check_names[ci]] = n
for k, v in sorted(ok_by_check.items(), key=lambda x: -x[1]):
    print(f"   🟡 {k}: {v} 件")

print("\n3. 根因分析：")
print("   - 檢查1的REAL主要是bg說舒適但prefix說拮据（模板化prefix覆蓋了bg語境）")
print("   - 檢查3的REAL是已婚+family_size=1未交代配偶狀態")
print("   - 檢查8的BG矛盾主要是「獨居」vs「上有老下有小」或「小孩開銷」共存")
print("   - 重複人名如小胖/TW-P-0213未婚但小孩開銷，疑似bg模板複製錯誤")
print("   - 素芬/TW-P-0355未婚家管但小孩開銷大，bg矛盾")

print(f"\n4. 總計：REAL={totals['REAL']} | OK={totals['OK']} | MINOR={totals['MINOR']}")
