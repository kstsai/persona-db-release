#!/usr/bin/env python3
"""
Chunk 4 常理驗證 — 10 項機械檢查 + 語意分類 (REAL / OK / MINOR)
"""
import json, re, sys

# ── 1. 載入資料 ──────────────────────────────────────────────
with open("/home/ubuntu/lab-riscv/hermesa3/persona/tw_persona_chunk_4.json", "r") as f:
    data = json.load(f)

print(f"載入 {len(data)} 筆 persona")

# ── 輔助函數 ────────────────────────────────────────────────
def income_val(inc):
    """收入數值化"""
    if not inc: return None
    inc = str(inc).strip()
    if inc in ("無收入", "0"): return 0
    if inc == "<3萬": return 1.5
    if inc == "3-8萬": return 5.5
    if inc == ">8萬": return 9
    if inc == "<1萬": return 0.5
    if inc == "1-3萬": return 2
    if inc == "3-7萬": return 5
    if inc == "7萬": return 7
    if inc == "百萬": return 12
    return None

def age_range_min(age):
    """年齡區間下界"""
    if not age: return None
    m = re.search(r'(\d+)', str(age))
    return int(m.group(1)) if m else None

def age_range_max(age):
    """年齡區間上界"""
    if not age: return None
    m = re.findall(r'(\d+)', str(age))
    return int(m[-1]) if m else None

def has_word(text, keywords):
    """檢查 text 是否包含任一 keyword"""
    if not text: return False
    for kw in keywords:
        if kw in text: return True
    return False

# ── 檢查結果儲存 ──────────────────────────────────────────────
findings = {i: [] for i in range(1, 11)}  # check_id -> list of (persona, classification, detail)

def add_finding(check_id, p, cls, detail):
    findings[check_id].append({
        "id": p["id"],
        "name": p.get("name", "?"),
        "classification": cls,
        "detail": detail
    })

# ── 逐筆檢查 ──────────────────────────────────────────────────
for p in data:
    dims = p.get("dimensions", {})
    bg = dims.get("background_story", "")
    age = dims.get("age", "")
    income = dims.get("income", "")
    family_size = dims.get("family_size", "")
    marriage = dims.get("marriage", "")
    occupation = dims.get("occupation", "")
    education = dims.get("education", "")
    residence = dims.get("residence", "")
    price_tier = dims.get("price_tier", "")
    prefix = p.get("prompt_prefix", "")
    combined_text = bg + " " + prefix

    inc_val = income_val(income)
    age_min = age_range_min(age)
    age_max = age_range_max(age)

    # ─── Check 1: 收入 vs 描述 ───────────────────────────────
    is_low_income = inc_val is not None and inc_val < 3
    is_high_income = inc_val is not None and inc_val > 8
    comfortable_bg = has_word(bg, ["寬裕", "寬鬆", "不用太省", "品質還不錯", "該花的會花", "滿舒服", "滿寬裕", "還不錯"])
    tight_bg = has_word(bg, ["省著點", "壓力很大", "不夠用", "精打細算", "喘不過氣", "手頭緊", "入不敷出", "省則省", "算清楚", "要省"])

    if is_low_income and comfortable_bg:
        detail = f"收入={income}(低), bg說: [{bg}], 但prefix說: [{prefix[:60]}...]"
        # 語意判斷
        if has_word(bg, ["有些積蓄", "積蓄"]):
            add_finding(1, p, "OK", f"低收入但有積蓄描述: {detail}")
        else:
            add_finding(1, p, "REAL", f"低收入但描述寬裕: {detail}")

    if is_high_income and tight_bg:
        detail = f"收入={income}(高), bg說: [{bg}]"
        add_finding(1, p, "REAL", f"高收入但描述拮据: {detail}")

    # ─── Check 2: 獨居+小孩 ──────────────────────────────────
    if str(family_size) == "1":
        # 檢查 bg 或 prefix 中有提到小孩但沒有配偶上下文
        has_kid_expense = has_word(combined_text, ["小孩", "孩子"])
        has_spouse = has_word(combined_text, ["配偶", "夫妻"])
        if has_kid_expense and not has_spouse:
            # 語意判斷：配偶在外地/分居則 OK
            if has_word(combined_text, ["配偶在外地", "配偶長期", "夫妻分居"]):
                add_finding(2, p, "OK", f"fs=1提到小孩但有配偶分居上下文: bg=[{bg[:60]}...]")
            elif has_word(bg, ["子女在外", "孩子在外地"]):
                add_finding(2, p, "OK", f"fs=1但子女在外地: bg=[{bg[:60]}...]")
            else:
                add_finding(2, p, "REAL", f"fs=1提到小孩且無配偶上下文: bg=[{bg[:60]}...]")

    # ─── Check 3: 已婚+fs=1無配偶 ────────────────────────────
    if marriage == "已婚" and str(family_size) == "1":
        has_any_spouse_context = has_word(combined_text, ["配偶", "夫妻", "分居", "老伴"])
        if not has_any_spouse_context:
            add_finding(3, p, "REAL", f"已婚+fs=1但無任何配偶/分居語境: bg=[{bg[:80]}...]")
        else:
            add_finding(3, p, "OK", f"已婚+fs=1但有配偶語境: bg=[{bg[:80]}...]")

    # ─── Check 4: 未成年有收入 ────────────────────────────────
    if age_min is not None and age_min < 18 and inc_val is not None and inc_val > 0:
        add_finding(4, p, "REAL", f"age={age}但收入={income} (未成年應無收入)")

    # ─── Check 5: 65+年輕子女 ────────────────────────────────
    if age_min is not None and age_min >= 65:
        if has_word(combined_text, ["小孩"]) and not has_word(combined_text, ["子女", "孩子"]):
            add_finding(5, p, "MINOR", f"{age}歲提到「小孩」而非「子女」: [{bg[:60]}...]")

    # ─── Check 6: 含飴弄孫+低收入+高物價 ──────────────────────
    has_grandparent = has_word(combined_text, ["含飴弄孫", "孫", "帶孫"])
    if has_grandparent and is_low_income and price_tier in ("高", "中高"):
        add_finding(6, p, "OK", f"含飴弄孫+低收入+高物價(可能是期望而非現實): [{bg[:60]}...]")

    # ─── Check 7: 未成年非學生 ────────────────────────────────
    if age_min is not None and age_min < 18 and occupation and occupation != "學生":
        add_finding(7, p, "REAL", f"age={age}(未成年)但職業={occupation}")

    # ─── Check 8: BG前後句矛盾 ────────────────────────────────
    has_no_kids = has_word(bg, ["沒有生小孩", "沒生小孩"])
    has_kid_expense = has_word(bg, ["小孩的開銷", "孩子開銷"])
    if has_no_kids and has_kid_expense:
        add_finding(8, p, "REAL", f"bg前後矛盾: 說沒有生小孩又提到小孩開銷: [{bg}]")

    # 簡單過日子 vs 經濟壓力非常大在同一 bg 中
    contradictory_pairs = [
        (["生活品質還不錯", "該花的會花", "寬裕", "寬鬆"], ["精打細算", "省則省", "喘不過氣", "手頭緊", "入不敷出", "壓力很大"]),
        (["有些積蓄", "積蓄", "偶爾會出國玩"], ["精打細算", "省則省", "手頭緊", "入不敷出", "壓力很大"]),
    ]
    for comfy_words, tight_words in contradictory_pairs:
        has_comfy = has_word(bg, comfy_words)
        has_tight = has_word(bg, tight_words)
        if has_comfy and has_tight:
            # 語意判斷
            if has_word(bg, ["有些積蓄"]) and has_word(bg, ["精打細算"]):
                add_finding(8, p, "OK", f"有積蓄但精打細算(可解釋為務實): bg=[{bg[:80]}...]")
            elif has_word(bg, ["生活品質還不錯"]) and has_word(bg, ["精打細算"]):
                add_finding(8, p, "OK", f"品質不錯但要精打細算(可解釋): bg=[{bg[:80]}...]")
            else:
                add_finding(8, p, "REAL", f"bg前後矛盾: [{bg}]")

    # ─── Check 9: 學生+已婚 ──────────────────────────────────
    if occupation == "學生" and marriage not in ("未婚", "單身"):
        add_finding(9, p, "REAL", f"職業=學生但婚姻={marriage}")

    # ─── Check 10: 12-18教育=大學 ─────────────────────────────
    if age_min is not None and 12 <= age_min <= 18 and education == "大學":
        add_finding(10, p, "REAL", f"age={age}(12-18歲)但教育程度=大學")

# ── 輸出報告 ──────────────────────────────────────────────────
total_findings = sum(len(v) for v in findings.values())
real_count = sum(1 for v in findings.values() for f in v if f["classification"] == "REAL")
ok_count = sum(1 for v in findings.values() for f in v if f["classification"] == "OK")
minor_count = sum(1 for v in findings.values() for f in v if f["classification"] == "MINOR")

print(f"\n{'='*70}")
print(f"              CHUNK 4 常理驗證總報告")
print(f"{'='*70}")
print(f"總檢查發現: {total_findings}")
print(f"  REAL (真矛盾): {real_count}")
print(f"  OK   (可解釋): {ok_count}")
print(f"  MINOR(文編問題): {minor_count}")
print(f"{'='*70}\n")

for check_id in sorted(findings.keys()):
    items = findings[check_id]
    if not items:
        continue
    check_names = {
        1: "1. 收入 vs 描述",
        2: "2. 獨居+小孩",
        3: "3. 已婚+fs=1無配偶",
        4: "4. 未成年有收入",
        5: "5. 65+年輕子女",
        6: "6. 含飴弄孫+低收入+高物價",
        7: "7. 未成年非學生",
        8: "8. BG前後句矛盾",
        9: "9. 學生+已婚",
        10: "10. 12-18教育=大學"
    }
    real_items = [f for f in items if f["classification"] == "REAL"]
    ok_items = [f for f in items if f["classification"] == "OK"]
    minor_items = [f for f in items if f["classification"] == "MINOR"]

    print(f"\n{'─'*70}")
    print(f"  {check_names.get(check_id, f'檢查{check_id}')}")
    print(f"  共 {len(items)} 項 → REAL={len(real_items)}  OK={len(ok_items)}  MINOR={len(minor_items)}")
    print(f"{'─'*70}")

    if real_items:
        print(f"\n  🔴 REAL 發現:")
        for f in real_items:
            print(f"    [{f['id']}] {f['name']} — {f['detail'][:120]}")
    if ok_items:
        print(f"\n  🟢 OK 發現:")
        for f in ok_items:
            print(f"    [{f['id']}] {f['name']} — {f['detail'][:120]}")
    if minor_items:
        print(f"\n  🟡 MINOR 發現:")
        for f in minor_items:
            print(f"    [{f['id']}] {f['name']} — {f['detail'][:120]}")

print(f"\n{'='*70}")
print(f"                 趨勢總結")
print(f"{'='*70}")

# 統計各檢查 REAL 分布
real_by_check = {}
for check_id in sorted(findings.keys()):
    rs = [f for f in findings[check_id] if f["classification"] == "REAL"]
    if rs:
        real_by_check[check_id] = len(rs)

print("\n  REAL 分布（由多到少）:")
for cid, cnt in sorted(real_by_check.items(), key=lambda x: -x[1]):
    print(f"    檢查 {cid}: {cnt} 項")

print(f"\n  主要根因分析:")
if real_by_check:
    top = sorted(real_by_check.items(), key=lambda x: -x[1])[0]
    print(f"    最常見: 檢查 {top[0]} ({top[1]} 項REAL)")
    print(f"    可能根因: ", end="")
    if top[0] == 1:
        print("prompt_prefix 模板與 background_story 未保持一致，尤其中高收入配拮据描述")
    elif top[0] == 3:
        print("已婚+fs=1但未補配偶關係說明，background_story 模板化不足")
    elif top[0] == 8:
        print("background_story 多句模板拼接未檢查語意一致性")
    elif top[0] == 2:
        print("fs=1但有小孩敘述，未充分處理配偶/子女關係")

print(f"\n{'='*70}")
print(f"                 逐項詳細分析")
print(f"{'='*70}")
print()
