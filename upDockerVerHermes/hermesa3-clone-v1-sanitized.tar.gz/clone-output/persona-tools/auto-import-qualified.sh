#!/bin/bash
# auto-import-qualified.sh — 從 release artifact 匯入最新 qualified memory
# 用法: bash auto-import-qualified.sh release-v3.2.zip

set -e

ZIP="$1"
if [ -z "$ZIP" ]; then
    echo "用法: $0 <release-vX.Y.zip>"
    echo "範例: $0 release-v3.2.zip"
    exit 1
fi

if [ ! -f "$ZIP" ]; then
    echo "❌ 找不到 $ZIP"
    exit 1
fi

echo "🔍 解壓縮 $ZIP ..."
TMPDIR=$(mktemp -d)
unzip -q "$ZIP" -d "$TMPDIR"

# 1. 更新 skill
if [ -d "$TMPDIR/skills/tw-persona-db" ]; then
    echo "📦 更新 skill ..."
    mkdir -p ~/.hermes/skills/research/
    cp -r "$TMPDIR/skills/tw-persona-db/" ~/.hermes/skills/research/
    echo "   ✅ tw-persona-db skill 已更新"
fi

# 2. 更新資料
if [ -d "$TMPDIR/data" ]; then
    echo "📊 更新資料 ..."
    mkdir -p ~/persona-db/
    cp "$TMPDIR/data/"* ~/persona-db/
    echo "   ✅ 資料已更新"
fi

# 3. 更新工具
if [ -d "$TMPDIR/tools" ]; then
    echo "🔧 更新工具 ..."
    mkdir -p ~/persona-db/
    cp "$TMPDIR/tools/"*.py ~/persona-db/
    chmod +x ~/persona-db/*.py
    echo "   ✅ 工具已更新"
fi

# 4. 顯示 qualified memory 供參考
if [ -f "$TMPDIR/qualified-memory.md" ]; then
    echo ""
    echo "📝 Qualified Memory 已準備好:"
    echo "   檔案: $TMPDIR/qualified-memory.md"
    echo "   請手動 review 並 merge 到 ~/.hermes/memories/MEMORY.md"
    echo "   建議先看 CHANGELOG.md 了解更新內容"
fi

if [ -f "$TMPDIR/CHANGELOG.md" ]; then
    echo ""
    echo "📋 CHANGELOG:"
    head -20 "$TMPDIR/CHANGELOG.md"
fi

echo ""
echo "✅ Import 完成！"
echo "   保留暫存目錄: $TMPDIR"
echo "   確認沒問題後可手動刪除: rm -rf $TMPDIR"
