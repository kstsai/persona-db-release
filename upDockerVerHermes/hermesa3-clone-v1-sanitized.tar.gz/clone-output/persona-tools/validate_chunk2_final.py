#!/usr/bin/env python3
"""Final report generator — organizes v2 findings by REAL / OK / MINOR and adds detailed explanations"""
import json, re

with open("/home/ubuntu/lab-riscv/hermesa3/persona/tw_persona_chunk_2.json") as f:
    data = json.load(f)

print(f"📊 Chunk 2 全量驗證報告 — 179筆 (TW-P-0180 ~ TW-P-0358)")
print(f"{'='*72}")

# ── Functions ──
def bg(p): return str(p.get("dimensions",{}).get("background_story",""))
def pr(p): return str(p.get("prompt_prefix",""))
def inc(p): return p.get("dimensions",{}).get("income","")
def fs(p): return p.get("dimensions",{}).get("family_size","")
def marr(p): return p.get("dimensions",{}).get("marriage","")
def occ(p): return p.get("dimensions",{}).get("occupation","")
def edu(p): return p.get("dimensions",{}).get("education","")
def age_min(p):
    m=re.match(r"(\d+)", p.get("dimensions",{}).get("age",""))
    return int(m.group(1)) if m else 99
def price_tier(p): return p.get("dimensions",{}).get("price_tier","")

findings = []  # (check_no, name, pid, desc, category, explanation)

# ── Check 1: 收入 vs 描述 ──
for p in data:
    i, b, pp = inc(p), bg(p), pr(p)
    n, pid = p["name"], p["id"]
    comf = ["寬裕","不用太省","品質還不錯","該花的會花","有些積蓄","還算寬鬆","生活品質還不錯"]
    tight = ["省著點","壓力很大","不夠用","手頭緊","入不敷出","每一塊錢","精打細算","能省則省","先比價","喘不過氣"]
    def has(text, lst): return any(x in text for x in lst)
    bg_ok, pr_ok = has(b, comf), has(pp, comf)
    bg_tight, pr_tight = has(b, tight), has(pp, tight)
    if i == "<3萬":
        if bg_ok:
            w = "|".join([x for x in comf if x in b])
            findings.append((1,n,pid,f"收入<3萬，bg卻說「{w}」","REAL",f"bg='{b[:40]}...', prefix='{pp[:40]}...'"))
        elif pr_ok:
            findings.append((1,n,pid,f"收入<3萬，prefix卻說寬裕","REAL",""))
    elif i == ">8萬" and pr_tight:
        findings.append((1,n,pid,f"收入>8萬，prefix卻說拮据/手頭緊","REAL",""))
    elif i == "3-8萬" and bg_ok and pr_tight:
        findings.append((1,n,pid,f"bg說寬裕但prefix說拮据（3-8萬）","REAL",""))

# ── Check 2: 獨居+小孩 ──
for p in data:
    n, pid = p["name"], p["id"]
    b, pp, f = bg(p), pr(p), fs(p)
    both = b + " " + pp
    if f == "1" and ("小孩的開銷" in both or "孩子的開銷" in both):
        living_with_fam = any(x in b for x in ["跟父母","跟爸","跟媽","跟爸爸","跟媽媽"])
        if not living_with_fam:
            findings.append((2,n,pid,f"獨居(fs=1)但bg有小孩開銷支出","REAL",""))
        else:
            findings.append((2,n,pid,f"fs=1但跟父母住且bg說小孩開銷（指自己是父母的孩子）","MINOR",""))

# ── Check 3: 已婚+fs=1 ──
for p in data:
    n, pid = p["name"], p["id"]
    m, ff, b = marr(p), fs(p), bg(p) + " " + pr(p)
    if m == "已婚" and ff == "1":
        if any(x in b for x in ["配偶","夫妻","結婚","新婚","老公","老婆","先生"]):
            if any(x in b for x in ["分居","長期在國外","暫時分居","在外地工作"]):
                findings.append((3,n,pid,f"已婚+fs=1（配偶異地說明）","OK",""))
            else:
                findings.append((3,n,pid,f"已婚+fs=1（有配偶描述但fs未計）","MINOR",""))
        else:
            findings.append((3,n,pid,f"已婚+fs=1，全文無配偶描述","REAL",""))

# ── Check 4: 未成年有收入 ──
for p in data:
    a, ii, n, pid = age_min(p), inc(p), p["name"], p["id"]
    if a <= 18 and ii not in ("無收入",""):
        findings.append((4,n,pid,f"age={a}但有收入({ii})","REAL",""))

# ── Check 5: 65+說小孩 ──
for p in data:
    a, n, pid = age_min(p), p["name"], p["id"]
    both = bg(p)+" "+pr(p)
    if a >= 65 and "小孩" in both and "子女" not in both:
        findings.append((5,n,pid,f"age≥65用「小孩」非「子女」","MINOR",""))

# ── Check 6: 含飴弄孫 ──
for p in data:
    n, pid = p["name"], p["id"]
    both, i, pt = bg(p)+" "+pr(p), inc(p), price_tier(p)
    if "含飴弄孫" in both and i=="<3萬" and pt in ("高","中高"):
        findings.append((6,n,pid,f"含飴弄孫+低收入+高物價區","OK",""))

# ── Check 7: 未成年非學生 ──
for p in data:
    a, o, n, pid = age_min(p), occ(p), p["name"], p["id"]
    if a <= 18 and o and o != "學生":
        findings.append((7,n,pid,f"age={a}但職業={o}","REAL" if a<16 else "OK",""))

# ── Check 8: BG前後句矛盾 ──
for p in data:
    n, pid = p["name"], p["id"]
    b, pp = bg(p), pr(p)
    
    # 8a: 獨居 vs 上有老下有小
    alone = {"享受單身生活","一個人租套房","自己一個人住","一個人生活","一人獨居"}
    for a in alone:
        if a in b and "上有老下有小" in b:
            findings.append((8,n,pid,f"「{a}」又說「上有老下有小」","REAL",""))
    
    # 8b: 夫妻兩人 vs 小孩開銷
    if "夫妻兩人" in b and any(x in b for x in ["小孩的開銷","孩子的開銷","小孩的教育"]):
        findings.append((8,n,pid,f"「夫妻兩人」卻有小孩開銷","REAL",""))
    
    # 8c: 沒有生小孩 vs 小孩開銷
    if "沒有生小孩" in b and any(x in b for x in ["小孩的開銷","孩子的開銷"]):
        findings.append((8,n,pid,f"「沒有生小孩」又說小孩開銷","REAL",""))
    
    # 8d: bg拮据 vs prefix舒適
    tight_words = ["壓力","手頭緊","入不敷出","要精打細算"]
    comf_words = ["過得滿舒服","收入算很高","日子過得滿","不用太省","還算輕鬆"]
    if any(x in b for x in tight_words) and any(x in pp for x in comf_words):
        findings.append((8,n,pid,f"bg說拮据但prefix說生活輕鬆","REAL",""))
    
    # 8e: bg壓力 vs prefix收入不錯  
    if "收入不錯" in pp and any(x in b for x in ["壓力","手頭緊","入不敷出"]):
        findings.append((8,n,pid,f"bg有壓力但prefix說收入不錯","REAL",""))
    
    # 8f: 收入低但有積蓄出國玩
    if inc(p)=="<3萬" and "有些積蓄" in b and "出國玩" in b:
        findings.append((8,n,pid,f"收入<3萬但有些積蓄還出國玩","OK",""))
    
    # 8g: 未婚/離婚說小孩開銷大
    if marr(p) in ("未婚","離婚") and "小孩的開銷" in b:
        findings.append((8,n,pid,f"未婚/離婚卻說「小孩的開銷很大」","REAL",""))

# ── Check 9: 學生+已婚 ──
for p in data:
    n, pid, o, m = p["name"], p["id"], occ(p), marr(p)
    if o == "學生" and m not in ("未婚","無"):
        findings.append((9,n,pid,f"學生但婚姻={m}","REAL",""))

# ── Check 10: 12-18教育=大學 ──
for p in data:
    a, e, n, pid = age_min(p), edu(p), p["name"], p["id"]
    if 12 <= a <= 18 and e == "大學":
        findings.append((10,n,pid,f"age={a}但教育=大學","REAL" if a<=15 else "MINOR",""))

# ── Dedup ──
seen=set()
deduped=[]
for item in findings:
    key=(item[0],item[2],item[3],item[4])
    if key not in seen:
        seen.add(key)
        deduped.append(item)
findings=deduped

# ── PRINT REPORT ──
cn={1:"收入 vs 描述",2:"獨居+小孩",3:"已婚+fs=1無配偶",4:"未成年有收入",
    5:"65+年輕子女",6:"含飴弄孫",7:"未成年非學生",8:"BG前後句矛盾",
    9:"學生+已婚",10:"12-18教育=大學"}

totals={"REAL":0,"OK":0,"MINOR":0}
print(f"\n一、各項檢查結果")
print(f"{'─'*72}")
for ci in range(1,11):
    ci_items=[x for x in findings if x[0]==ci]
    r=sum(1 for x in ci_items if x[4]=="REAL")
    o=sum(1 for x in ci_items if x[4]=="OK")
    m=sum(1 for x in ci_items if x[4]=="MINOR")
    totals["REAL"]+=r; totals["OK"]+=o; totals["MINOR"]+=m
    status="✅ 無發現" if not ci_items else f"REAL={r} / OK={o} / MINOR={m}"
    print(f"  檢查{ci}. {cn[ci]:　<15} {status}")

print(f"\n  小計：REAL={totals['REAL']} | OK={totals['OK']} | MINOR={totals['MINOR']}")

print(f"\n\n二、詳細 REAL 發現列表（{totals['REAL']}項）")
print(f"{'═'*72}")
idx=0
for ci in range(1,11):
    real_items=[x for x in findings if x[0]==ci and x[4]=="REAL"]
    if real_items:
        print(f"\n  ▎檢查{ci}. {cn[ci]}")
        for x in real_items:
            _, n, pid, desc, cat, _ = x
            idx+=1
            print(f"    {idx:2d}. [{pid}] {n}")
            print(f"       ↳ {desc}")

print(f"\n\n三、詳細 OK 發現列表（{totals['OK']}項）")
print(f"{'═'*72}")
for ci in range(1,11):
    ok_items=[x for x in findings if x[0]==ci and x[4]=="OK"]
    if ok_items:
        print(f"\n  ▎檢查{ci}. {cn[ci]}")
        for x in ok_items:
            _, n, pid, desc, cat, _ = x
            print(f"    [{pid}] {n}：{desc}")

print(f"\n\n四、詳細 MINOR 發現列表（{totals['MINOR']}項）")
print(f"{'═'*72}")
for ci in range(1,11):
    minor_items=[x for x in findings if x[0]==ci and x[4]=="MINOR"]
    if minor_items:
        print(f"\n  ▎檢查{ci}. {cn[ci]}")
        for x in minor_items:
            _, n, pid, desc, cat, _ = x
            print(f"    [{pid}] {n}：{desc}")

print(f"\n\n五、趨勢總結")
print(f"{'═'*72}")
print(f"""
  1. 最常見的REAL模式（按數量排序）：
     🔴 BG前後句矛盾 — 28件
        主要子類：
        · 未婚/離婚卻說「小孩的開銷很大」（12件）— bg模板從有家室角色複製
        · bg拮据語氣但prefix說生活輕鬆（7件）— prefix模板未對齊bg
        · 獨居但說「上有老下有小」（3件）— 模板殘留
        · 夫妻兩人世界但說小孩開銷（1件）— 矛盾句共存

     🔴 收入 vs 描述 — 13件
        · <3萬收入但bg說「有些積蓄」「不用太省」（11件）
        · >8萬收入但prefix說拮据/手頭緊（2件）
        · 根因：收入維度抽樣結果與撰寫者語感不一致

  2. 最多OK的檢查：
     🟡 已婚+fs=1無配偶 — 11件
        全部為配偶異地（分居/外派/國外工作），屬可解釋情境

  3. 未出現的檢查（0發現）：
     檢查4(未成年有收入)、檢查5(65+年輕子女)、檢查6(含飴弄孫)、
     檢查7(未成年非學生)、檢查9(學生+已婚)、檢查10(12-18教育=大學)
     — 本chunk年齡層集中在19-44歲，因此相關檢查無觸發

  4. 根因歸納：
     (a) 模板拼接遺留：bg與prefix由不同模板/貢獻者產生，前後語調不一致
     (b) bg遺留舊腳本：未婚者bg殘留「小孩的開銷很大」— 疑似從有家庭角色複製
     (c) 收入維度抽象：<3萬但bg描述「有些積蓄」— 積蓄≠收入，但邏輯上低收難有積蓄
""")
