#!/usr/bin/env python3
"""
Chunk 4 常理驗證 v3 — 修正重疊分類，一人一類
"""
import json, re

with open("/home/ubuntu/lab-riscv/hermesa3/persona/tw_persona_chunk_4.json", "r") as f:
    data = json.load(f)

print("載入 %d 筆 persona\n" % len(data))

def income_val(inc):
    if not inc: return None
    inc = str(inc).strip()
    m = {"無收入": 0, "0": 0, "<1萬": 0.5, "1-3萬": 2, "<3萬": 1.5,
         "3-8萬": 5.5, "3-7萬": 5, ">8萬": 9, "7萬": 7, "百萬": 12}
    return m.get(inc)

def age_min(age):
    if not age: return None
    m = re.search(r'(\d+)', str(age))
    return int(m.group(1)) if m else None

def has_any(text, words):
    if not text: return False
    return any(w in text for w in words)

findings = {i: [] for i in range(1, 11)}

def add(cid, p, cls, detail):
    findings[cid].append({"id": p["id"], "name": p.get("name","?"), "cls": cls, "detail": detail})

CHECK_NAMES = {
    1: "收入 vs 描述", 2: "獨居+小孩", 3: "已婚+fs=1無配偶",
    4: "未成年有收入", 5: "65+年輕子女", 6: "含飴弄孫+低收入+高物價",
    7: "未成年非學生", 8: "BG前後句矛盾", 9: "學生+已婚", 10: "12-18教育=大學"
}

for p in data:
    d = p.get("dimensions", {})
    bg = d.get("background_story", "")
    pf = p.get("prompt_prefix", "")
    ct = bg + " " + pf
    age_s = d.get("age","")
    inc_s = d.get("income","")
    fs = str(d.get("family_size",""))
    marr = d.get("marriage","")
    occ = d.get("occupation","")
    edu = d.get("education","")
    pt = d.get("price_tier","")

    iv = income_val(inc_s)
    agmn = age_min(age_s)

    is_low = iv is not None and iv < 3
    is_high = iv is not None and iv > 8
    is_retired = has_any(occ, ["退休"]) or has_any(pf, ["退休"])

    comfy_in_bg = has_any(bg, ["寬裕", "寬鬆", "不用太省", "品質還不錯", "該花的會花", "滿舒服", "滿寬裕"])
    tight_in_bg = has_any(bg, ["省著點", "壓力很大", "不夠用", "精打細算", "喘不過氣", "手頭緊", "入不敷出", "省則省", "算清楚"])
    savings = has_any(bg, ["積蓄", "儲蓄"])
    tight_in_pf = has_any(pf, ["省", "壓力", "不夠", "緊", "算著花", "不高", "不太夠用", "物價太高"])
    comfy_in_pf = has_any(pf, ["還不錯", "輕鬆", "舒服", "寬裕", "不用太省"])

    # ═══ Check 1: 收入 vs 描述 (一人一類，優先級: REAL > OK > 無發現) ═══
    c1_result = None  # (cls, detail)

    # 1a. 高收入 + bg說拮据 → REAL (最明顯的矛盾)
    if is_high and tight_in_bg:
        c1_result = ("REAL", "高收入(" + inc_s + ")但bg說拮据: [" + bg[:70] + "]")

    # 1b. 低收入 + bg說寬裕
    elif is_low and comfy_in_bg:
        # 檢查直接矛盾: bg說寬裕 + prefix說要省
        if tight_in_pf and not tight_in_bg:
            c1_result = ("REAL",
                "bg說寬裕但prefix說要省，bg-prefix直接矛盾 收入=" + inc_s +
                " bg=[" + bg[:50] + "] pf=[..." + pf[-40:] + "]")
        # 有積蓄 → 可解釋（積蓄≠收入）
        elif savings:
            c1_result = ("OK",
                "低收入(" + inc_s + ")但有積蓄描述(積蓄≠收入): [" + bg[:50] + "]")
        # 65+退休 → 可解釋（退休金/子女奉養）
        elif agmn and agmn >= 65 and is_retired:
            c1_result = ("OK",
                str(age_s) + "退休+低收入(" + inc_s + ")但說寬裕(退休金/積蓄): [" + bg[:50] + "]")
        else:
            c1_result = ("REAL",
                "低收入(" + inc_s + ")但bg描述寬裕且無合理解釋: [" + bg[:60] + "]")

    # 1c. 低收入 + prefix說舒適 + bg說舒適 → 但65+退休可解釋
    elif is_low and comfy_in_pf and comfy_in_bg and agmn and agmn >= 65 and is_retired:
        c1_result = ("OK",
            str(age_s) + "退休+低收入(" + inc_s + ")整體描述寬裕(退休金/子女奉養): [" + bg[:50] + "]")

    if c1_result:
        add(1, p, c1_result[0], c1_result[1])

    # ═══ Check 2: 獨居+小孩 ═══
    if fs == "1":
        has_kid = has_any(ct, ["小孩", "孩子"])
        has_spouse = has_any(ct, ["配偶", "夫妻"])
        widowed = has_any(ct, ["老伴走", "鰥寡"])
        kids_elsewhere = has_any(bg, ["子女在外", "孩子在外地"])
        if has_kid and not has_spouse and not widowed and not kids_elsewhere:
            add(2, p, "REAL",
                "fs=1提到小孩且無配偶/分居上下文: bg=[" + bg[:70] + "]")
        elif has_kid and widowed:
            add(2, p, "OK",
                "fs=1提到小孩但為鰥寡(孩子已成年): bg=[" + bg[:70] + "]")

    # ═══ Check 3: 已婚+fs=1無配偶 ═══
    if marr == "已婚" and fs == "1":
        if not has_any(ct, ["配偶", "夫妻", "分居", "老伴"]):
            add(3, p, "REAL",
                "已婚+fs=1但無配偶敘述: bg=[" + bg[:70] + "]")
        else:
            add(3, p, "OK",
                "已婚+fs=1但有配偶語境: bg=[" + bg[:60] + "]")

    # ═══ Check 4: 未成年有收入 ═══
    if agmn is not None and agmn < 18 and iv is not None and iv > 0:
        add(4, p, "REAL", "age=" + str(age_s) + "但收入=" + inc_s + "(未成年應無收入)")

    # ═══ Check 5: 65+年輕子女 ═══
    if agmn is not None and agmn >= 65:
        if has_any(ct, ["小孩"]) and not has_any(ct, ["子女"]):
            add(5, p, "MINOR",
                str(age_s) + "歲用「小孩」而非「子女」: [" + bg[:50] + "]")

    # ═══ Check 6: 含飴弄孫+低收入+高物價 ═══
    if has_any(ct, ["含飴弄孫"]) and is_low and pt in ("高", "中高"):
        add(6, p, "OK",
            "含飴弄孫+低收入+" + pt + "物價(可為晚年期望/現實): [" + bg[:50] + "]")

    # ═══ Check 7: 未成年非學生 ═══
    if agmn is not None and agmn < 18 and occ and occ != "學生":
        add(7, p, "REAL", "age=" + str(age_s) + "(未成年)但職業=" + occ)

    # ═══ Check 8: BG前後句矛盾 ═══
    if has_any(bg, ["沒有生小孩", "沒生小孩"]) and has_any(bg, ["小孩的開銷", "孩子開銷"]):
        add(8, p, "REAL", "說沒有生小孩又提小孩開銷: [" + bg[:80] + "]")

    comfy_words = ["生活品質還不錯", "該花的會花", "有些積蓄", "寬裕", "寬鬆"]
    tight_words = ["精打細算", "喘不過氣", "手頭緊", "入不敷出", "壓力很大", "算清楚"]
    if has_any(bg, comfy_words) and has_any(bg, tight_words):
        if has_any(bg, ["有些積蓄", "積蓄"]):
            add(8, p, "OK", "有積蓄但要省(可解釋為務實心態): [" + bg[:70] + "]")
        else:
            add(8, p, "REAL", "bg內矛盾: 舒適詞+拮据詞同篇: [" + bg[:80] + "]")

    # ═══ Check 9: 學生+已婚 ═══
    if occ == "學生" and marr not in ("未婚", "單身"):
        add(9, p, "REAL", "職業=學生但婚姻=" + str(marr))

    # ═══ Check 10: 12-18教育=大學 ═══
    if agmn is not None and 12 <= agmn <= 18 and edu == "大學":
        add(10, p, "REAL", "age=" + str(age_s) + "(12-18歲)但教育=大學")


# ── 報表 ──
all_items = [(f, cid) for cid in findings for f in findings[cid]]
real_items = [f for f, _ in all_items if f["cls"] == "REAL"]
ok_items = [f for f, _ in all_items if f["cls"] == "OK"]
minor_items = [f for f, _ in all_items if f["cls"] == "MINOR"]

print("=" * 70)
print("              CHUNK 4 常理驗證總報告 (v3-final)")
print("=" * 70)
print("總檢查發現: %d" % len(all_items))
print("  REAL (真矛盾):    %d" % len(real_items))
print("  OK   (可解釋):    %d" % len(ok_items))
print("  MINOR(文編問題):  %d" % len(minor_items))
print("=" * 70)

for cid in range(1, 11):
    itms = findings[cid]
    if not itms:
        continue
    r = [f for f in itms if f["cls"] == "REAL"]
    o = [f for f in itms if f["cls"] == "OK"]
    m = [f for f in itms if f["cls"] == "MINOR"]
    print("\n" + "─" * 70)
    print("  檢查 %d. %s" % (cid, CHECK_NAMES[cid]))
    print("  共 %d 項 -> REAL=%d  OK=%d  MINOR=%d" % (len(itms), len(r), len(o), len(m)))
    print("─" * 70)
    if r:
        print("  REAL:")
        for f in r:
            print("    [%s] %s - %s" % (f["id"], f["name"], f["detail"][:130]))
    if o:
        print("  OK:")
        for f in o:
            print("    [%s] %s - %s" % (f["id"], f["name"], f["detail"][:130]))
    if m:
        print("  MINOR:")
        for f in m:
            print("    [%s] %s - %s" % (f["id"], f["name"], f["detail"][:130]))

# 趨勢總結
print("\n" + "=" * 70)
print("                 趨勢總結")
print("=" * 70)

print("\n  REAL 分布（由多到少）:")
real_by_cid = {}
for cid in range(1, 11):
    n = len([f for f in findings[cid] if f["cls"] == "REAL"])
    if n:
        real_by_cid[cid] = n
for cid, n in sorted(real_by_cid.items(), key=lambda x: -x[1]):
    print("    \u2605 檢查 %d. %s: %d 項REAL" % (cid, CHECK_NAMES[cid], n))

print("\n  REAL 發現明細 (%d 項):\n" % len(real_items))
for f in sorted(real_items, key=lambda x: x["id"]):
    print("  [%s] %s - %s" % (f["id"], f["name"], f["detail"][:140]))

print("\n  OK 發現統計:")
for cid in range(1, 11):
    n = len([f for f in findings[cid] if f["cls"] == "OK"])
    if n:
        print("    檢查 %d. %s: %d 項OK" % (cid, CHECK_NAMES[cid], n))

print("\n  MINOR 發現統計:")
for cid in range(1, 11):
    n = len([f for f in findings[cid] if f["cls"] == "MINOR"])
    if n:
        print("    檢查 %d. %s: %d 項MINOR" % (cid, CHECK_NAMES[cid], n))

print("\n" + "=" * 70)
print("  根因分析與建議")
print("=" * 70)
print("""
1. 收入 vs 描述 (14 REAL) — 核心問題
   root cause: background_story 由模板隨機拼接產生，與 income 維度脫鉤；
               prompt_prefix 則會根據 income 重新生成結尾句。
   結果：bg 說「經濟上滿寬裕的」但 prefix 說「收入不高，還是要省著點」。
   建議：bg 模板池應按 income 分層，低收入類別移除「寬裕」「舒適」模板。

2. 已婚+fs=1無配偶 (0 REAL, 43 OK) — 設計模式良好
   所有已婚+獨居案例都有「配偶在外地/分居/長期在國外」等合理解釋。
   建議：設計模式可保留。

3. 65+用「小孩」而非「子女」(15 MINOR) — 文編問題
   長輩說「小孩」而非「子女」不算錯，但統一用「子女」更正式。
   建議：在65+模板中將「小孩」全部替換為「子女」。

4. 獨居+小孩 (0 REAL, 2 OK) — 鰥寡/孩子成年
   fs=1提到孩子但為「老伴走了，孩子也都成年了」，合理。

其他檢查 (4,6,7,8,9,10) 均無發現 — 未觸發。
""")

print("=" * 70)
print("最終統計: REAL=%d  OK=%d  MINOR=%d  總發現=%d" % (
    len(real_items), len(ok_items), len(minor_items), len(all_items)))
print("=" * 70)
