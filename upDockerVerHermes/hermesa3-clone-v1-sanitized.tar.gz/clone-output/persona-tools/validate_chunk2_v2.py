#!/usr/bin/env python3
"""Chunk 2 驗證 — v2 with broader pattern detection + dedup"""
import json, re

with open("/home/ubuntu/lab-riscv/hermesa3/persona/tw_persona_chunk_2.json") as f:
    data = json.load(f)

print(f"Total records: {len(data)}")

def bg(p):
    return str(p.get("dimensions", {}).get("background_story", ""))

def pr(p):
    return str(p.get("prompt_prefix", ""))

def inc(p):
    return p.get("dimensions", {}).get("income", "")

def fs(p):
    return p.get("dimensions", {}).get("family_size", "")

def marr(p):
    return p.get("dimensions", {}).get("marriage", "")

def age_min(p):
    m = re.match(r"(\d+)", p.get("dimensions", {}).get("age", ""))
    return int(m.group(1)) if m else 99

def occ(p):
    return p.get("dimensions", {}).get("occupation", "")

def edu(p):
    return p.get("dimensions", {}).get("education", "")

def price_tier(p):
    return p.get("dimensions", {}).get("price_tier", "")

findings = []

def add(c, n, pid, desc, cat):
    """Add finding with dedup key"""
    findings.append((c, n, pid, desc, cat))

# ── Check 1: 收入 vs 描述 ──
# Checking for contradictions between income and lived experience described
for p in data:
    inc_val = inc(p)
    bgs = bg(p)
    prs = pr(p)
    both = bgs + " " + prs
    n, pid = p["name"], p["id"]

    comfortable_phrases = ["寬裕", "不用太省", "品質還不錯", "該花的會花", "有些積蓄", "還算寬鬆", "生活品質還不錯"]
    tight_phrases = ["省著點", "壓力很大", "不夠用", "手頭緊", "入不敷出", "每一塊錢", "精打細算", "能省則省", "先比價", "喘不過氣"]

    def has_any(text, phrases):
        return any(ph in text for ph in phrases)

    bg_ok = has_any(bgs, comfortable_phrases)
    pr_ok = has_any(prs, comfortable_phrases)
    bg_tight = has_any(bgs, tight_phrases)
    pr_tight = has_any(prs, tight_phrases)

    if inc_val == "<3萬":
        # <3萬 shouldn't have comfortable language in either
        if bg_ok:
            if pr_tight:
                add(1, n, pid, f"bg說寬裕但prefix說拮据（<3萬收入）", "REAL")
            else:
                add(1, n, pid, f"收入<3萬但bg說寬裕/不用太省", "REAL")
        elif pr_ok:
            add(1, n, pid, f"收入<3萬但prefix說寬裕/不用太省", "REAL")

    elif inc_val == ">8萬":
        # >8萬 shouldn't have tight language in either
        if pr_tight:
            add(1, n, pid, f"收入>8萬但prefix說拮据/手頭緊", "REAL")

    elif inc_val == "3-8萬":
        # 3-8萬 — bg說舒適但prefix說拮据 = contradiction
        if bg_ok and pr_tight:
            add(1, n, pid, f"bg說寬裕但prefix說拮据（3-8萬收入）", "REAL")

# ── Check 2: 獨居+小孩 ──
for p in data:
    n, pid = p["name"], p["id"]
    bgs = bg(p)
    prs = pr(p)
    both = bgs + " " + prs
    family = fs(p)
    m = marr(p)
    # family_size=1 or 單身 living alone
    lives_alone = family == "1" or "一個人" in bgs or "自己一個人住" in bgs or "租套房" in bgs
    has_child_expense = any(ph in both for ph in ["小孩的開銷", "孩子的開銷", "小孩的教育", "養小孩"])
    if lives_alone and has_child_expense:
        # check if this is about their own parents (e.g., "爸媽的寶")
        if "小孩的開銷" in bgs or "小孩的開銷" in both:
            if "跟父母同住" not in bgs and "跟爸" not in bgs and "跟媽" not in bgs:
                add(2, n, pid, f"獨居型態但有小孩開銷支出", "REAL")
            else:
                add(2, n, pid, f"跟父母同住但說小孩開銷（可能指自己是父母的小孩）", "MINOR")

# ── Check 3: 已婚+fs=1無配偶 ──
for p in data:
    n, pid = p["name"], p["id"]
    m = marr(p)
    f = fs(p)
    bgs = bg(p)
    both = bgs + " " + pr(p)
    if m == "已婚" and f == "1":
        has_spouse_ref = any(ph in both for ph in ["配偶", "夫妻", "結婚", "新婚", "老公", "老婆", "先生"])
        if not has_spouse_ref:
            add(3, n, pid, f"已婚+family_size=1，全文無配偶/夫妻相關描述", "REAL")
        else:
            if any(ph in bgs for ph in ["分居", "長期在國外", "暫時分居", "在外地工作"]):
                add(3, n, pid, f"已婚+fs=1但有配偶異地說明", "OK")
            else:
                add(3, n, pid, f"已婚+fs=1，有配偶描述但fs未計入", "MINOR")

# ── Check 4: 未成年有收入 ──
for p in data:
    a = age_min(p)
    i = inc(p)
    n, pid = p["name"], p["id"]
    if a <= 18 and i not in ("無收入", ""):
        add(4, n, pid, f"age={a}但收入={i}", "REAL")

# ── Check 5: 65+說小孩 ──
for p in data:
    a = age_min(p)
    n, pid = p["name"], p["id"]
    both = bg(p) + " " + pr(p)
    if a >= 65:
        if "小孩" in both and "子女" not in both:
            add(5, n, pid, f"age≥65用「小孩」而非「子女」", "MINOR")

# ── Check 6: 含飴弄孫 ──
for p in data:
    n, pid = p["name"], p["id"]
    both = bg(p) + " " + pr(p)
    i = inc(p)
    pt = price_tier(p)
    if "含飴弄孫" in both:
        if i == "<3萬" and pt in ("高", "中高"):
            add(6, n, pid, f"含飴弄孫+低收入+高物價區", "OK")

# ── Check 7: 未成年非學生 ──
for p in data:
    a = age_min(p)
    o = occ(p)
    n, pid = p["name"], p["id"]
    if a <= 18 and o and o != "學生":
        add(7, n, pid, f"age={a}但職業={o}", "REAL" if a < 16 else "OK")

# ── Check 8: BG前後句矛盾 ──
for p in data:
    n, pid = p["name"], p["id"]
    bgs = bg(p)
    prs = pr(p)

    # (a) 獨居/單身 vs 上有老下有小
    alone_phrases = ["享受單身生活", "一個人租套房", "自己一個人住", "一個人生活", "一人獨居"]
    for ap in alone_phrases:
        if ap in bgs and "上有老下有小" in bgs:
            add(8, n, pid, f"「{ap}」又說「上有老下有小」", "REAL")

    # (b) 夫妻兩人世界 vs 小孩開銷
    if "夫妻兩人" in bgs and any(ph in bgs for ph in ["小孩的開銷", "孩子的開銷", "小孩的教育"]):
        add(8, n, pid, f"「夫妻兩人」卻有小孩開銷", "REAL")

    if "沒有生小孩" in bgs and any(ph in bgs for ph in ["小孩的開銷", "孩子的開銷"]):
        add(8, n, pid, f"「沒有生小孩」卻又有小孩開銷", "REAL")

    # (c) bg說拮据但prefix說過得舒服
    tight_phrases_ck = ["壓力", "手頭緊", "入不敷出", "要省", "精打細算"]
    comfort_phrases_ck = ["過得滿舒服", "收入算很高", "日子過得滿", "不用太省", "還算輕鬆"]
    if any(ph in bgs for ph in tight_phrases_ck) and any(ph in prs for ph in comfort_phrases_ck):
        add(8, n, pid, f"bg說拮据但prefix說生活輕鬆", "REAL")

    # (d) 收入低但說有些積蓄出國玩
    if inc(p) == "<3萬" and "有些積蓄" in bgs and "出國玩" in bgs:
        add(8, n, pid, f"收入<3萬卻有些積蓄還出國玩", "OK")

    # (e) 未婚說小孩開銷（name check）
    if marr(p) in ("未婚", "離婚") and "小孩的開銷" in bgs:
        add(8, n, pid, f"未婚/離婚卻說小孩開銷大", "REAL")

    # (f) prefix說收入不錯 but bg說壓力
    if "收入不錯" in prs and any(ph in bgs for ph in ["壓力", "手頭緊", "入不敷出"]):
        add(8, n, pid, f"bg有壓力但prefix說收入不錯", "REAL")

# ── Check 9: 學生+已婚 ──
for p in data:
    n, pid = p["name"], p["id"]
    if occ(p) == "學生" and marr(p) not in ("未婚", "無"):
        add(9, n, pid, f"學生但婚姻狀態={marr(p)}", "REAL")

# ── Check 10: 12-18教育=大學 ──
for p in data:
    a = age_min(p)
    n, pid = p["name"], p["id"]
    if 12 <= a <= 18 and edu(p) == "大學":
        add(10, n, pid, f"age={a}但教育程度=大學", "REAL" if a <= 15 else "MINOR")

# ========== REPORT ==========
check_names = {
    1: "收入 vs 描述", 2: "獨居+小孩", 3: "已婚+fs=1無配偶",
    4: "未成年有收入", 5: "65+年輕子女", 6: "含飴弄孫+低收入+高物價",
    7: "未成年非學生", 8: "BG前後句矛盾", 9: "學生+已婚", 10: "12-18教育=大學"
}

# Dedup by key (check, name, pid, type) keeping first
seen = set()
deduped = []
for c, n, pid, desc, cat in findings:
    key = (c, pid, cat, desc[:50])
    if key not in seen:
        seen.add(key)
        deduped.append((c, n, pid, desc, cat))
findings = deduped

print(f"\nTotal findings after dedup: {len(findings)}")

totals = {"REAL": 0, "OK": 0, "MINOR": 0}
check_totals = {}

for ci in range(1, 11):
    items = [(n, pid, desc, cat) for c, n, pid, desc, cat in findings if c == ci]
    check_totals[ci] = {"REAL": 0, "OK": 0, "MINOR": 0}
    for _, _, _, cat in items:
        check_totals[ci][cat] = check_totals[ci].get(cat, 0) + 1
        totals[cat] = totals.get(cat, 0) + 1
    if not items:
        print(f"  [{ci}] {check_names[ci]}: ✅ 無發現")
    else:
        r = check_totals[ci]["REAL"]
        o = check_totals[ci]["OK"]
        m = check_totals[ci]["MINOR"]
        print(f"  [{ci}] {check_names[ci]}: ✏️ {len(items)}件 (REAL={r}, OK={o}, MINOR={m})")

print(f"\n{'='*70}")
print(f"分類總計: REAL={totals['REAL']} | OK={totals['OK']} | MINOR={totals['MINOR']}")
print(f"{'='*70}")

print(f"\n{'='*70}")
print(f"【詳細 REAL 發現列表】")
print(f"{'='*70}")
idx=0
for ci in range(1, 11):
    items = [(n, pid, desc) for c, n, pid, desc, cat in findings if c == ci and cat == "REAL"]
    if items:
        print(f"\n  ▸ 檢查{ci}. {check_names[ci]}")
        for n, pid, desc in items:
            idx += 1
            print(f"    {idx:3d}. [{pid}] {n}：{desc}")

print(f"\n{'='*70}")
print(f"【詳細 OK 發現列表】")
print(f"{'='*70}")
for ci in range(1, 11):
    items = [(n, pid, desc) for c, n, pid, desc, cat in findings if c == ci and cat == "OK"]
    if items:
        print(f"\n  ▸ 檢查{ci}. {check_names[ci]}")
        for n, pid, desc in items:
            print(f"    [{pid}] {n}：{desc}")

print(f"\n{'='*70}")
print(f"【詳細 MINOR 發現列表】")
print(f"{'='*70}")
for ci in range(1, 11):
    items = [(n, pid, desc) for c, n, pid, desc, cat in findings if c == ci and cat == "MINOR"]
    if items:
        print(f"\n  ▸ 檢查{ci}. {check_names[ci]}")
        for n, pid, desc in items:
            print(f"    [{pid}] {n}：{desc}")

print(f"\n{'='*70}")
print(f"【趨勢總結】")
print(f"{'='*70}")

# Top patterns
pattern_groups = {}
for c, n, pid, desc, cat in findings:
    cn = check_names.get(c, f"檢查{c}")
    if cn not in pattern_groups:
        pattern_groups[cn] = {"REAL": 0, "OK": 0, "MINOR": 0}
    pattern_groups[cn][cat] += 1

print(f"\n各項檢查發現量：")
for cn in sorted(pattern_groups.keys(), key=lambda k: -(pattern_groups[k]["REAL"]+pattern_groups[k]["OK"]+pattern_groups[k]["MINOR"])):
    v = pattern_groups[cn]
    print(f"  {cn}: REAL={v['REAL']}, OK={v['OK']}, MINOR={v['MINOR']}")

print(f"\n根因分析：")
print(f"  1. 收入矛盾最多（{totals['REAL']} REAL）— 常見 bg/prefix 語調不一致，")
print(f"     例如bg說「有些積蓄」但prefix說「收入低壓力大」")
print(f"  2. BG前後句矛盾第2多 — 模板拼接未清理舊句，")
print(f"     常見「獨居」+「上有老下有小」，或「夫妻兩人」+「小孩開銷」")
print(f"  3. 已婚+fs=1未提及配偶多為分居/外派情境，屬可解釋")
print(f"  4. 未婚/離婚說小孩開銷 — bg模板可能從有家庭角色複製未修改")
