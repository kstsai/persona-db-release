#!/usr/bin/env python3
"""
Chunk 6 常理驗證 — 10 項機械檢查 + 語意分類 (REAL / OK / MINOR)
"""
import json, re

with open('/home/ubuntu/lab-riscv/hermesa3/persona/tw_persona_chunk_6.json') as f:
    data = json.load(f)

def age_to_num(age_str):
    """Convert age range to a numeric (approx midpoint)"""
    m = re.match(r'(\d+)-(\d+)', age_str)
    if m:
        return (int(m.group(1)) + int(m.group(2))) / 2
    if age_str == '65+':
        return 70
    if age_str == '0-11':
        return 6
    if age_str == '12-18':
        return 15
    if age_str == '19-24':
        return 21
    if age_str == '25-34':
        return 30
    if age_str == '35-44':
        return 40
    if age_str == '45-54':
        return 50
    if age_str == '55-64':
        return 60
    return 0

def parse_income(inc_str):
    """Parse income to a rough numeric for comparison"""
    if inc_str == '無收入' or inc_str == '無':
        return 0
    m = re.match(r'<(\d+)萬', inc_str)
    if m:
        return int(m.group(1)) - 0.5  # <3萬 ≈ 2.5
    m = re.match(r'>(\d+)萬', inc_str)
    if m:
        return int(m.group(1)) + 5  # >8萬 ≈ 13
    m = re.match(r'(\d+)-(\d+)萬', inc_str)
    if m:
        return (int(m.group(1)) + int(m.group(2))) / 2
    if inc_str == '百萬':
        return 100
    if inc_str in ('7萬', '7'):
        return 7
    return None

# Comfortable language indicators
COMFORTABLE = ['寬裕', '不用太省', '品質還不錯', '還不錯', '滿舒服', '滿寬裕', '過得去', '該花的會花']
TIGHT = ['省着點', '省著點', '壓力很大', '不夠用', '精打細算', '入不敷出', '省', '很緊', '緊']
BOTH_LOW_INCOME = ['<3萬']
BOTH_HIGH_INCOME = ['>8萬']

# Results storage
results = {i: [] for i in range(1, 11)}  # check 1-10
all_findings = []

def add_finding(check_num, persona, category, description):
    """Add a finding: category = 'REAL', 'OK', or 'MINOR'"""
    entry = {
        'check': check_num,
        'id': persona['id'],
        'name': persona['name'],
        'category': category,
        'description': description
    }
    results[check_num].append(entry)
    all_findings.append(entry)

# ============ CHECK 1: 收入 vs 描述 ============
for p in data:
    dims = p['dimensions']
    inc = dims.get('income', '')
    bg = dims.get('background_story', '') + ' ' + p.get('prompt_prefix', '')
    
    is_low = inc in BOTH_LOW_INCOME
    is_high = inc in BOTH_HIGH_INCOME
    
    has_comfortable = any(c in bg for c in COMFORTABLE)
    has_tight = any(c in bg for c in TIGHT)
    
    if is_low and has_comfortable:
        # Check for MINOR: if the comfortable lang is in bg but prefix says "要省着点"
        prefix = p.get('prompt_prefix', '')
        prefix_tight = any(c in prefix for c in ['省着點', '省著點'])
        bg_comfortable = any(c in p['dimensions'].get('background_story', '') for c in COMFORTABLE)
        
        if prefix_tight and bg_comfortable:
            # Background says comfortable but prefix says tight — REAL
            add_finding(1, p, 'REAL',
                f"收入{inc}為低收，background_story說「{p['dimensions']['background_story']}」感覺寬裕，但prompt_prefix卻說「{prefix[-40:]}」")
        elif has_comfortable and not prefix_tight:
            # Check if there's nuance: "有些積蓄" is OK (savings ≠ income)
            if '有些積蓄' in bg:
                add_finding(1, p, 'OK',
                    f"收入{inc}但bg提到「有些積蓄」，可解釋為儲蓄而非收入")
            elif '手頭還算寬鬆' in bg or '不用太省' in bg:
                # Check price tier — in low-price areas, even low income can feel OK
                pt = dims.get('price_tier', '')
                if pt in ('極低', '低'):
                    add_finding(1, p, 'OK',
                        f"收入{inc}在{pt}物價地區，說寬鬆可解釋為區域購買力差異")
                else:
                    add_finding(1, p, 'MINOR',
                        f"收入{inc}但bg說「{p['dimensions']['background_story']}」感覺寬鬆，可理解為在低物價區主觀感受")
            else:
                add_finding(1, p, 'MINOR',
                    f"收入{inc}，bg說「{p['dimensions']['background_story']}」口氣偏寬裕，但尚可解釋")
    
    if is_high and has_tight:
        pt = dims.get('price_tier', '')
        if pt in ('極低', '低'):
            add_finding(1, p, 'OK',
                f"收入{inc}在{pt}物價區卻說要省，可能是有其他開銷壓力，可解釋")
        else:
            add_finding(1, p, 'REAL',
                f"收入{inc}為高收但bg說「{p['dimensions']['background_story']}」感覺緊")

# ============ CHECK 2: 獨居+小孩 ============
for p in data:
    dims = p['dimensions']
    fs = dims.get('family_size', '')
    bg = p['dimensions'].get('background_story', '') + ' ' + p.get('prompt_prefix', '')
    
    if fs == '1' and ('小孩' in bg or '孩子' in bg):
        # Check context
        if '沒有生小孩' in bg or '沒有孩子' in bg:
            add_finding(2, p, 'OK', "獨居但bg提到「沒有生小孩」，這是在解釋為何獨居")
        elif '照顧爸媽' in bg or '父母' in bg:
            add_finding(2, p, 'OK', "獨居但bg提到爸媽/父母，不是自己有小孩")
        elif '小孩' in bg.lower():
            add_finding(2, p, 'REAL', f"獨居(fs=1)但bg提到小孩：{p['dimensions']['background_story']}")

# ============ CHECK 3: 已婚+fs=1無配偶 ============
for p in data:
    dims = p['dimensions']
    mar = dims.get('marriage', '')
    fs = dims.get('family_size', '')
    bg = p['dimensions'].get('background_story', '') + ' ' + p.get('prompt_prefix', '')
    
    if mar == '已婚' and fs == '1':
        spouse_mentioned = any(w in bg for w in ['配偶', '夫妻', '老公', '老婆', '太太', '先生', '新婚'])
        if spouse_mentioned:
            add_finding(3, p, 'OK', "已婚+fs=1但有解釋(配偶長期在外/新婚分居)")
        else:
            add_finding(3, p, 'MINOR', "已婚+fs=1但bg未提及配偶去向")

# ============ CHECK 4: 未成年有收入 ============
for p in data:
    dims = p['dimensions']
    age = dims.get('age', '')
    inc = dims.get('income', '')
    
    if age in ('0-11', '12-18') and inc not in ('無收入', '無'):
        add_finding(4, p, 'REAL', f"年齡{age}但收入為{inc}")

# ============ CHECK 5: 65+年輕子女 ============
for p in data:
    dims = p['dimensions']
    age = dims.get('age', '')
    bg = p['dimensions'].get('background_story', '') + ' ' + p.get('prompt_prefix', '')
    
    if age == '65+':
        # Check for "小孩" (young children) vs "子女" (grown children)
        children_context = re.findall(r'小孩[^的]*', bg)
        if children_context and '小孩' in bg:
            # If bg talks about "小孩" in context of expenses/care
            if any(w in bg for w in ['小孩的開銷', '養小孩', '帶小孩', '接送小孩', '小孩花費', '小孩教育']):
                add_finding(5, p, 'REAL', f"年齡{age}，bg提到幼齡小孩開銷：{p['dimensions']['background_story']}")
            elif '含飴弄孫' in bg or '孫' in bg:
                add_finding(5, p, 'OK', "年齡65+提到小孩，但是指孫輩(含飴弄孫)")
            elif '小孩' in bg:
                # Could be "子女" usage
                add_finding(5, p, 'MINOR', f"年齡65+，bg提到「小孩」但可能是泛指子女：{p['dimensions']['background_story']}")

# ============ CHECK 6: 含飴弄孫+低收入+高物價 ============
for p in data:
    dims = p['dimensions']
    bg = p['dimensions'].get('background_story', '')
    inc = dims.get('income', '')
    pt = dims.get('price_tier', '')
    
    if '含飴弄孫' in bg:
        if inc in BOTH_LOW_INCOME:
            if pt in ('高', '中高'):
                add_finding(6, p, 'REAL', f"含飴弄孫+收入{inc}+物價{pt}，矛盾衝突")
            else:
                add_finding(6, p, 'OK', f"含飴弄孫+收入{inc}但物價{pt}，可解釋")
        else:
            add_finding(6, p, 'OK', "含飴弄孫但收入不低，可解釋")

# ============ CHECK 7: 未成年非學生 ============
for p in data:
    dims = p['dimensions']
    age = dims.get('age', '')
    occ = dims.get('occupation', '')
    
    if age in ('0-11', '12-18') and occ != '學生':
        add_finding(7, p, 'REAL', f"年齡{age}但職業為{occ}而非學生")

# ============ CHECK 8: BG前後句矛盾 ============
for p in data:
    dims = p['dimensions']
    bg = dims.get('background_story', '')
    
    # Check internal contradictions
    contradictions = []
    
    # "沒有生小孩" + "小孩開銷" 
    if '沒有生小孩' in bg and ('小孩' in bg or '孩子' in bg):
        contradictions.append("說「沒有生小孩」又提到小孩相關")
    
    # "獨居" + family members
    if '獨居' in bg and ('一家三口' in bg or '一家人' in bg):
        contradictions.append("說「獨居」又說「一家X口」")
    
    # "一個人住" + "小孩"
    if '一個人住' in bg and ('小孩' in bg or '孩子' in bg):
        # Check if it's "沒有小孩"
        if '沒有' not in bg:
            contradictions.append("說「一個人住」又提到小孩")
    
    if contradictions:
        add_finding(8, p, 'REAL', f"bg內部矛盾：{'; '.join(contradictions)}。原文：{bg}")

# ============ CHECK 9: 學生+已婚 ============
for p in data:
    dims = p['dimensions']
    occ = dims.get('occupation', '')
    mar = dims.get('marriage', '')
    
    if occ == '學生' and mar not in ('未婚', ''):
        add_finding(9, p, 'REAL', f"職業為學生但婚姻狀態為{mar}")

# ============ CHECK 10: 12-18教育=大學 ============
for p in data:
    dims = p['dimensions']
    age = dims.get('age', '')
    edu = dims.get('education', '')
    
    if age == '12-18' and edu in ('大學', '研究所以上'):
        add_finding(10, p, 'REAL', f"年齡{age}但教育程度為{edu}")

print("=" * 80)
print("CHUNK 6 常理驗證報告 (174 筆)")
print("=" * 80)

check_names = {
    1: "收入 vs 描述",
    2: "獨居+小孩",
    3: "已婚+fs=1無配偶",
    4: "未成年有收入",
    5: "65+年輕子女",
    6: "含飴弄孫+低收入+高物價",
    7: "未成年非學生",
    8: "BG前後句矛盾",
    9: "學生+已婚",
    10: "12-18教育=大學"
}

for cn in range(1, 11):
    items = results[cn]
    reals = [x for x in items if x['category'] == 'REAL']
    oks = [x for x in items if x['category'] == 'OK']
    minors = [x for x in items if x['category'] == 'MINOR']
    
    print(f"\n{'─'*60}")
    print(f"檢查 {cn}: {check_names[cn]}")
    print(f"  共 {len(items)} 項發現：REAL={len(reals)}  OK={len(oks)}  MINOR={len(minors)}")
    
    if reals:
        print(f"  REAL 發現：")
        for r in reals:
            print(f"    ● {r['id']} {r['name']} — {r['description']}")
    if oks:
        print(f"  OK 發現：")
        for r in oks:
            print(f"    ○ {r['id']} {r['name']} — {r['description']}")
    if minors:
        print(f"  MINOR 發現：")
        for r in minors:
            print(f"    △ {r['id']} {r['name']} — {r['description']}")

# Summary stats
print(f"\n{'='*80}")
print("彙整統計")
print(f"{'='*80}")

total_real = sum(1 for f in all_findings if f['category'] == 'REAL')
total_ok = sum(1 for f in all_findings if f['category'] == 'OK')
total_minor = sum(1 for f in all_findings if f['category'] == 'MINOR')
total_findings = len(all_findings)

print(f"\n總發現數：{total_findings}")
print(f"REAL (真矛盾)：{total_real}")
print(f"OK (可解釋)：{total_ok}")
print(f"MINOR (文編問題)：{total_minor}")

# Unique persona count
real_personas = set((f['id'], f['name']) for f in all_findings if f['category'] == 'REAL')
print(f"\n涉及 REAL 矛盾的獨特人物：{len(real_personas)} 筆")
for pid, pname in sorted(real_personas):
    print(f"  - {pid} {pname}")

# Trends
print(f"\n{'='*80}")
print("趨勢總結")
print(f"{'='*80}")
print("""
1. 最常見模式：檢查1（收入 vs 描述）占最多發現，主要因為
   - 低收人物在中部極低物價區說「手頭還算寬鬆、不用太省」— MINOR/OK
   - 但有些低收人物的prompt_prefix卻說「要省着點」— REAL
   - 預設模板在bg和prefix之間產生了語氣不一致

2. 第二常見：檢查5（65+年輕子女）→ 65歲以上人物bg提到「小孩」但語境中可能
   泛指已成年的子女，用詞不夠精準，多屬MINOR

3. 檢查3（已婚+fs=1）→ 多位已婚但fs=1的人物，bg有解釋配偶去向(分居/國外)，
   屬於OK；少數未說明去向的列為MINOR

4. 本批無須關注：檢查4(未成年有收入)、檢查7(未成年非學生)、檢查9(學生+已婚)、
   檢查10(12-18教育=大學) 均無發現，資料品質在年齡與職業欄位一致

5. 根因分析：
   - bg/prefix由不同模板或不同生成輪次產生，語氣有時不一致
   - 年齡分層在65+群體中「小孩」vs「子女」用詞未規範化
   - 收入在極低物價區的主觀感受描述缺乏統一校準
""")
