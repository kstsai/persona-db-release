# TW Persona DB — 分身交付 Checklist v1.0
# =========================================
# 目標：把本尊 clone 成甲方可自部署的 persona DB appliance
# 交付模式：賣斷（一次 NT$60K-80K）
# 後續更新：類心理師計價 NT$3,000/hr（major release 升版）
#
# 本文件為內部文件（你的檢查表），非交付給甲方的文件。

---

## 一、分身的核心定義

分身 = **一個可以獨立運作的 persona data appliance**

她能做的事情：
- ✅ 用 query_persona.py 查詢 1069 筆人設
- ✅ 理解資料的 18 維度結構與限制
- ✅ 抽樣檢視資料品質
- ✅ 自行維護分身環境

她不需要/不該做的事情：
- ❌ 重新 generate persona（那是你的迭代引擎）
- ❌ 執行 QA 驗證（QA 是你本尊的品質把關）
- ❌ 知道你的其他工作（mediawatch、cron）
- ❌ 有你本尊的 memory（不含你的其他 task context）

---

## 二、檔案去留對照表

### ✅ 要放進分身（core）

| 檔案 | 大小 | 用途 | 備註 |
|:-----|:----:|:-----|:-----|
| `tw_persona_1069.json` | 1.4 MB | **核心資料** — 最新版 | 每當 major release 更新 |
| `population_by_region_age_sex_2025.csv` | 7.2 KB | 人口權重源資料 | 用於理解 distribution |
| `tw-persona-db-rfc.md` | 9.7 KB | **規格文件** — 維度定義、方法論 | 甲方理解資料結構的入口 |
| `query_persona.py` | 5.3 KB | **唯讀查詢 CLI** | 核心工具，甲方主要操作介面 |
| `sample_stratified.py` | 2.7 KB | 分層抽樣工具 | 用於自行檢視資料品質 |
| `qualified-memory.md` | 11 KB | 24 條 qualified knowledge | 等同於分身的「記憶」 |
| `auto-import-qualified.sh` | 1.7 KB | 匯入 release 更新的腳本 | 後續 major upgrade 用 |
| `VERSION` | 5 B | 版號標記 |  |

### ✅ 要放進分身（skill — 僅限 persona 相關）

| Skill 內容 | 用途 | 備註 |
|:-----------|:-----|:------|
| `SKILL.md` | 完整操作文件 | 瘦身版（砍掉 non-relevant sections） |
| `references/dimension-definitions.md` | 維度定義 |  |
| `references/name-pool-architecture.md` | 命名體系 |  |
| `references/economic-context-sentences.md` | 經濟語境 |  |
| `references/city-occupation-boost.md` | 城市加成 |  |
| `references/household-income-by-city.md` | 所得資料 |  |
| `references/residence-price-index.md` | 物價資料 |  |
| `references/language-standards.md` | 語言標準 |  |
| `references/price-consumption-data.md` | 消費數據 |  |
| `references/coherence-validation.md` | 一致性說明 |  |
| `references/qualified-memory-convention.md` | qualified memory 規範 |  |
| `references/96-sample-v3-review-2026-07-11.md` | 樣本審查範例 | 讓她理解品質標準 |
| `scripts/persona_contradiction_check.py` | 矛盾檢查工具 | 可選，她可能用得到 |
| `scripts/persona_review.py` | 自動審查 | 可選 |
| `scripts/persona_review_deep.py` | 深層審查 | 可選 |
| `scripts/verify_economic_tone.py` | 語氣驗證 | 可選 |

### ❌ 不要放進分身（你本尊保留）

| 檔案 | 原因 |
|:-----|:------|
| `_generate_997.py` (55 KB) | **核心迭代引擎** — 這是你的 IP 和生產工具 |
| `qa_validate.py` (11 KB) | QA 是你本尊的責任，不是甲方的工具 |
| `export_qualified_memory.py` (15 KB) | 你的 release 工具，甲方不需要產 release |
| `BUSINESS-MODEL.md` | 商業模式是內部討論 |
| `MILESTONE-v3.0.md` | 迭代記錄是你內部參考 |
| `MILESTONE_v0.1.md` | 同上 |
| `analysis_report_112.md` | 內部品質分析 |
| `stats_report*.md` | 內部統計報表 |
| `persona_childcare_card.json` | 這是幫甲方做的 sample，她已經有了 |
| `_debug_api.py` | debug 工具 |
| `_fetch_family_size.py` | 資料擷取工具 |
| `_find_top10.py` | 內部工具 |
| `etlPopulation.py` | ETL 工具 |
| `marriage_prob_real.py` | 機率表腳本 |
| `occ_prob_real.py` | 機率表腳本 |
| `ris-opendata-apidoc.json` (304 KB) | API 文件，甲方不需要 |
| `tw_persona_997.json` | 舊版資料，甲方只需要最新版 1069 |
| `tw_persona_112_stratified.json` | 內部樣本 |
| `tw_persona_prototype_*.json` | prototype 樣本 |
| `tw_persona_top10.json` | 展示用 sample |

### ⚠️ Skill references 取捨

**不放入分身**（太內部/太技術）：
| Reference | 原因 |
|:----------|:------|
| `chunk3-contradiction-patterns.md` | 內部 bug 歸檔 |
| `chunk4-contradiction-patterns.md` | 同上 |
| `chunk6-contradiction-patterns.md` | 同上 |
| `session-2026-07-11-chunked-review.md` | 內部 review 記錄 |
| `sub-agent-review-methodology.md` | 你的方法論 IP |
| `third-party-review-2026-07-10.md` | 內部 |
| `112-sample-analysis-2026-07-11.md` | 內部 |
| `dgbas-pdf-extraction.md` | 技術實作 |
| `dgbas-manpower-survey-2024.md` | 原始資料 |
| `marriage-data-realtime.md` | 原始資料 |
| `marriage-data-sources.md` | 原始資料 |
| `political-stance-cross-ref.md` | 內部 |
| `coherence-validation.md` | 技術文件 |

---

## 三、需要新寫的文件

### 1. `README.md`（甲方入口文件）

必須包含：
- 這是什麼（一句話：1069 筆台灣人設資料庫查詢工具）
- 系統需求（Python 3.8+）
- 快速開始（3 步：解壓縮 → 執行 query）
- query_persona.py 用法（含範例）
- 維度速查表（18 維度的 valid values）
- 已知限制（人口權重、小縣市問題）
- 如何更新（auto-import-qualified.sh 用法）
- 聯絡方式（什麼情況該找 Kuo-Shou、什麼情況自己解決）

### 2. `FAQ.md`（常見問題）

預先回答她可能會問的問題：
- Q: 查詢回 0 筆怎麼辦？ → A: 放寬條件
- Q: 為什麼某個縣市人這麼少？ → A: 人口權重
- Q: 我可以自己加資料嗎？ → A: 可以，但建議走 qualified memory 更新
- Q: 這個資料跟政府統計差多少？ → A: ≤0.4%
- Q: 我要怎麼整合進我的服務？ → A: 用 query_persona.py 的 --json 輸出

### 3. （可選）`api_server.py` 或 `web_wrapper.py`

如果她需要讓她的甲方直接 query，可以包一個簡單的 API：
```python
# 概念：flask 包裝 query_persona.py 的過濾功能
GET /api/persona?residence=台北市&age=35-44&occupation=科技
→ JSON response
```

---

## 四、分身目錄結構

```
persona-appliance-v3.2/
├── VERSION                       ← v3.2
├── README.md                     ← 入口文件（新寫）
├── FAQ.md                        ← 常見問題（新寫）
├── CHANGELOG.md                  ← 更新日誌（從 export 腳本產出）
│
├── data/                         ← 唯讀資料
│   ├── tw_persona_1069.json      ← 1.4 MB
│   ├── population_by_region_age_sex_2025.csv
│   └── tw-persona-db-rfc.md
│
├── tools/                        ← 唯讀工具
│   ├── query_persona.py          ← 主要 CLI
│   ├── sample_stratified.py      ← 抽樣檢視
│   ├── auto-import-qualified.sh  ← 更新腳本
│   └── (api_server.py)           ← 可選，Web API
│
├── qualified-memory.md           ← 24 條知識（= 分身的記憶）
│
├── skills/                       ← 僅 persona-db 相關
│   └── tw-persona-db/
│       ├── SKILL.md              ← 瘦身版
│       ├── references/           ← 精選 references
│       │   ├── dimension-definitions.md
│       │   ├── name-pool-architecture.md
│       │   ├── economic-context-sentences.md
│       │   ├── city-occupation-boost.md
│       │   ├── household-income-by-city.md
│       │   ├── residence-price-index.md
│       │   ├── language-standards.md
│       │   ├── price-consumption-data.md
│       │   ├── qualified-memory-convention.md
│       │   └── 96-sample-v3-review-2026-07-11.md
│       └── scripts/              ← 精選 scripts
│           ├── persona_review.py
│           └── verify_economic_tone.py
│
└── samples/                      ← 展示用
    └── query-examples.sh         ← 常用 query 範例
```

---

## 五、分身不包含（卻可能被她問到）的項目

| 她可能會問 | 你的回答 |
|:-----------|:---------|
| 「generate script 可以給我嗎？」 | 「那是生產工具，不含在這次交付。以後有需要疊加新維度再走 update 方案。」 |
| 「我可以自己改 prompt format 嗎？」 | 「可以。data/tw_persona_1069.json 是標準格式，你可以自己寫轉換腳本。」 |
| 「這份資料準嗎？」 | 「看 RFC 和 qualified-memory.md 的 QA 數據。有疑慮我可以開 session 幫你驗證。」 |
| 「之後有新版本怎麼辦？」 | 「我有 major release 會通知你。升版用類心理師方案，NT$3,000/hr。」 |

---

## 六、交付流程

```
Step 1: 你跑 build_appliance.py
         → 產出 persona-appliance-v3.2.zip

Step 2: 你驗證
         → unzip → python3 query_persona.py --residence 台北市 → 確認 work

Step 3: 交接會議（1-2hr，含在賣斷價內）
         → 展示 query CLI 用法
         → 解釋維度結構
         → 告知已知限制
         → 給她 ZIP + README

Step 4: 她確認沒問題
         → 結清款項

Step 5: 後續（major release 時）
         → 你通知她 v4.0 出來了
         → 她決定要不要升
         → 你開 session → 升級 → 收 NT$3,000/hr
```

---

## 七、定價估算（賣斷）

| 項目 | 你的工時 | 價值 |
|:-----|:--------:|:----:|
| 資料本體（1069 筆） | ~60 迭代小時 | 核心價值 |
| query CLI 工具 | ~8 小時 |  |
| skill + references | ~4 小時 |  |
| 交接會議 | ~2 小時 |  |
| 3 個月 bug fix 承諾 | ~3 小時（期望值） |  |
| **合計** | **~77 價值小時** | **NT$60K-80K** |
