#!/usr/bin/env python3
"""
export_qualified_memory.py — 將本尊的 qualified memory + skill + data 打包成 release artifact

用法:
    python3 export_qualified_memory.py                          # 自動版號 v3.x+1
    python3 export_qualified_memory.py --version v3.2            # 指定版號
    python3 export_qualified_memory.py --list-qualified          # 只列出 qualified entries
    python3 export_qualified_memory.py --dry-run                 # 試跑，不產檔案

輸出: release-v3.2.zip 放在目前目錄
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

# ─── 路徑設定 ────────────────────────────────────────────────
HOME = Path.home()
MEMORY_DIR = HOME / ".hermes" / "memories"
SKILL_DIR = HOME / ".hermes" / "skills" / "research" / "tw-persona-db"
PERSONA_DIR = Path("/home/ubuntu/lab-riscv/hermesa3/persona")
OUTPUT_DIR = Path("/home/ubuntu/lab-riscv/hermesa3/releases")

# ─── 要包進 release 的資料檔案 ──────────────────────────────
DATA_FILES = [
    "tw_persona_1069.json",
    "population_by_region_age_sex_2025.csv",
    "tw-persona-db-rfc.md",
    "qualified-memory.md",        # ← 新增：完整的 28 條 qualified memory
]

# ─── 要包進 release 的工具腳本（唯讀介面） ──────────────────
TOOL_SCRIPTS = [
    "query_persona.py",
    "sample_stratified.py",
]

# ─── VERSION 檔案路徑 ────────────────────────────────────────
VERSION_FILE = PERSONA_DIR / "VERSION"


def read_current_version() -> str:
    """讀取現行版號，沒有就回傳 v3.0"""
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    return "v3.0"


def bump_version(current: str) -> str:
    """自動 bump minor version: v3.1 → v3.2"""
    match = re.match(r"v(\d+)\.(\d+)", current)
    if not match:
        return "v3.1"
    major, minor = int(match.group(1)), int(match.group(2))
    return f"v{major}.{minor + 1}"


# ─── Memory Tagging Convention ──────────────────────────────
#
# 在你的 MEMORY.md 中，用 #qualified 標記要 export 的條目：
#
#   Persona DB: v3.1 — 1069 personas, OCC_CITY_BOOST. #qualified
#   🟢 已知限制：查新竹市+科技業+45-54 可能回 0，因人口權重低。 #qualified
#   🟢 最佳 query：--residence 台中市 --age 30-44 --politics 泛綠 #qualified
#
# 不含 #qualified 的條目不會被 export。


def extract_qualified_entries(text: str, source_label: str) -> list[dict]:
    """從 memory markdown 中提取 tagged entries"""
    entries = []
    # 以 § 或空白行分段
    paragraphs = re.split(r'\n§\n|\n{2,}', text)
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if '#qualified' in para or '#export' in para:
            # 移除 tag 本身
            clean = re.sub(r'\s*#(qualified|export)\s*', '', para).strip()
            if clean:
                entries.append({
                    "source": source_label,
                    "content": clean,
                    "tag": "qualified",
                })
    return entries


def scan_qualified_memory() -> list[dict]:
    """掃描 MEMORY.md 和 USER.md 中的 qualified entries"""
    all_entries = []

    for fname in ["MEMORY.md", "USER.md"]:
        fpath = MEMORY_DIR / fname
        if fpath.exists():
            text = fpath.read_text(encoding="utf-8")
            entries = extract_qualified_entries(text, fname)
            all_entries.extend(entries)

    return all_entries


def make_changelog(entries: list[dict], current_version: str, new_version: str) -> str:
    """從 qualified entries 自動產生 CHANGELOG"""
    lines = [
        f"# TW Persona DB — Qualified Memory Release",
        f"",
        f"## {new_version} → {new_version}",
        f"**Release date:** {datetime.now().strftime('%Y-%m-%d')}",
        f"",
        f"### Qualified Memory ({len(entries)} entries)",
    ]
    for i, e in enumerate(entries, 1):
        # 取第一句作為摘要
        first_sentence = e["content"].split("。")[0].split("\n")[0][:80]
        lines.append(f"{i}. {first_sentence}… (from {e['source']})")

    lines.extend([
        "",
        "### 更新內容",
        "- 資料：最新版 tw_persona_1069.json",
        "- Skill：tw-persona-db (含 QA rules、references)",
        "- 工具：query_persona.py、sample_stratified.py",
        "- 文件：RFC、使用說明",
        "",
        "### Import 方式",
        "```bash",
        "# 1. 解壓縮",
        f"unzip qualified-memory-{new_version}.zip -d ~/persona-db-release/",
        "",
        "# 2. 更新 skill",
        "cp -r ~/persona-db-release/skills/tw-persona-db/ ~/.hermes/skills/research/",
        "",
        "# 3. 更新資料",
        "cp ~/persona-db-release/data/tw_persona_1069.json ~/persona-db/",
        "",
        "# 4. 更新工具（覆蓋唯讀腳本）",
        "cp ~/persona-db-release/tools/*.py ~/persona-db/",
        "",
        "# 5. 匯入 qualified memory",
        "# 開啟 ~/.hermes/memories/MEMORY.md，在適當位置貼上 qualified-memory.md 內容",
        "# 或手動參考 CHANGELOG 決定要 merge 哪些條目",
        "```",
    ])
    return "\n".join(lines)


def build_release_manifest(
    entries: list[dict],
    version: str,
    file_hashes: dict[str, str],
) -> dict:
    """產出 release manifest JSON"""
    return {
        "release_version": version,
        "release_date": datetime.now().isoformat(),
        "qualified_memory_count": len(entries),
        "qualified_memory": entries,
        "files": file_hashes,
        "source_repo": "github.com/kstsai/media-narrative",
        "persona_db_version": version,
        "qa_status": "20/20 pass (see skill references)",
        "install_instructions": {
            "1": "unzip → copy skill dir to ~/.hermes/skills/research/",
            "2": "copy data/tw_persona_1069.json to working dir",
            "3": "copy tools/*.py to working dir (read-only CLI)",
            "4": "merge qualified-memory.md into MEMORY.md (manual review)",
        },
    }


def hash_file(path: Path) -> str:
    """SHA256 of a file"""
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()[:16]


def build_release(
    version: str,
    entries: list[dict],
    dry_run: bool = False,
) -> Path | None:
    """
    打包 release artifact:
      release-v<version>.zip
        ├── qualified-memory.md       ← 可匯入的 memory 條目
        ├── manifest.json             ← metadata
        ├── CHANGELOG.md              ← 更新日誌
        ├── skills/tw-persona-db/     ← 更新版 skill 目錄
        ├── data/                     ← JSON + CSV
        └── tools/                    ← query CLI
    """
    if dry_run:
        print(f"🧪 [DRY RUN] 將產出 release-{version}.zip")
        print(f"    qualified entries: {len(entries)}")
        print(f"    skill dir: {SKILL_DIR}")
        print(f"    data files: {DATA_FILES}")
        print(f"    tool scripts: {TOOL_SCRIPTS}")
        return None

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = OUTPUT_DIR / f"release-{version}.zip"

    file_hashes = {}

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)

        # — qualified-memory.md —
        mem_lines = [
            f"# TW Persona DB — Qualified Memory ({version})",
            f"# 產出日期: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"# 用法: merge 到 ~/.hermes/memories/MEMORY.md 中",
            f"",
        ]
        for i, e in enumerate(entries, 1):
            mem_lines.append(f"§")
            mem_lines.append(f"{e['content']}  #qualified")
        mem_content = "\n".join(mem_lines)
        (tmp / "qualified-memory.md").write_text(mem_content, encoding="utf-8")
        file_hashes["qualified-memory.md"] = hash_file(tmp / "qualified-memory.md")

        # — CHANGELOG.md —
        current_ver = read_current_version()
        changelog = make_changelog(entries, current_ver, version)
        (tmp / "CHANGELOG.md").write_text(changelog, encoding="utf-8")

        # — manifest.json —
        manifest = build_release_manifest(entries, version, file_hashes)
        (tmp / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        # — skills/tw-persona-db/ —
        if SKILL_DIR.exists():
            skill_target = tmp / "skills" / "tw-persona-db"
            shutil.copytree(SKILL_DIR, skill_target,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            # hash skill files
            for f in skill_target.rglob("*"):
                if f.is_file():
                    rel = f.relative_to(tmp)
                    file_hashes[str(rel)] = hash_file(f)

        # — data/ —
        data_dir = tmp / "data"
        data_dir.mkdir()
        for fname in DATA_FILES:
            fpath = PERSONA_DIR / fname
            if fpath.exists():
                shutil.copy2(fpath, data_dir / fname)
                file_hashes[f"data/{fname}"] = hash_file(data_dir / fname)

        # — tools/ —
        tools_dir = tmp / "tools"
        tools_dir.mkdir()
        for fname in TOOL_SCRIPTS:
            fpath = PERSONA_DIR / fname
            if fpath.exists():
                shutil.copy2(fpath, tools_dir / fname)
                file_hashes[f"tools/{fname}"] = hash_file(tools_dir / fname)

        # — VERSION file —
        (tmp / "VERSION").write_text(version + "\n")

        # — 打包 ZIP —
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for f in tmp.rglob("*"):
                if f.is_file():
                    arcname = f.relative_to(tmp)
                    zf.write(f, arcname)

    print(f"✅ release-{version}.zip 已產出 ({len(entries)} qualified entries)")
    print(f"   檔案大小: {zip_path.stat().st_size / 1024:.1f} KB")
    print(f"   路徑: {zip_path}")
    return zip_path


def list_qualified(entries: list[dict]):
    """僅列出 qualified entries，不產檔案"""
    print(f"\n📋 Qualified Memory Entries ({len(entries)} 條)")
    print("=" * 60)
    for i, e in enumerate(entries, 1):
        print(f"\n--- Entry {i} (from {e['source']}) ---")
        print(e["content"][:200])
        if len(e["content"]) > 200:
            print(f"    … ({len(e['content'])} chars total)")
    print(f"\n總計 {len(entries)} 條 qualified entries")


def generate_import_script(dry_run: bool = False):
    """產生甲方端的 import script — 讓甲方可以一行指令匯入"""
    content = r"""#!/bin/bash
# auto-import-qualified.sh — 從 release artifact 匯入最新 qualified memory
# 用法: bash auto-import-qualified.sh release-v3.2.zip

set -e

ZIP="$1"
if [ -z "$ZIP" ]; then
    echo "用法: $0 <release-vX.Y.zip>"
    echo "範例: $0 release-v3.2.zip"
    exit 1
fi

if [ ! -f "$ZIP" ]; then
    echo "❌ 找不到 $ZIP"
    exit 1
fi

echo "🔍 解壓縮 $ZIP ..."
TMPDIR=$(mktemp -d)
unzip -q "$ZIP" -d "$TMPDIR"

# 1. 更新 skill
if [ -d "$TMPDIR/skills/tw-persona-db" ]; then
    echo "📦 更新 skill ..."
    mkdir -p ~/.hermes/skills/research/
    cp -r "$TMPDIR/skills/tw-persona-db/" ~/.hermes/skills/research/
    echo "   ✅ tw-persona-db skill 已更新"
fi

# 2. 更新資料
if [ -d "$TMPDIR/data" ]; then
    echo "📊 更新資料 ..."
    mkdir -p ~/persona-db/
    cp "$TMPDIR/data/"* ~/persona-db/
    echo "   ✅ 資料已更新"
fi

# 3. 更新工具
if [ -d "$TMPDIR/tools" ]; then
    echo "🔧 更新工具 ..."
    mkdir -p ~/persona-db/
    cp "$TMPDIR/tools/"*.py ~/persona-db/
    chmod +x ~/persona-db/*.py
    echo "   ✅ 工具已更新"
fi

# 4. 顯示 qualified memory 供參考
if [ -f "$TMPDIR/qualified-memory.md" ]; then
    echo ""
    echo "📝 Qualified Memory 已準備好:"
    echo "   檔案: $TMPDIR/qualified-memory.md"
    echo "   請手動 review 並 merge 到 ~/.hermes/memories/MEMORY.md"
    echo "   建議先看 CHANGELOG.md 了解更新內容"
fi

if [ -f "$TMPDIR/CHANGELOG.md" ]; then
    echo ""
    echo "📋 CHANGELOG:"
    head -20 "$TMPDIR/CHANGELOG.md"
fi

echo ""
echo "✅ Import 完成！"
echo "   保留暫存目錄: $TMPDIR"
echo "   確認沒問題後可手動刪除: rm -rf $TMPDIR"
"""
    if not dry_run:
        script_path = PERSONA_DIR / "auto-import-qualified.sh"
        script_path.write_text(content)
        os.chmod(script_path, 0o755)
        print(f"✅ auto-import-qualified.sh 已產出 → {script_path}")
    else:
        print("[DRY RUN] 將產出 auto-import-qualified.sh")


def main():
    parser = argparse.ArgumentParser(
        description="export_qualified_memory.py — 打包 qualified memory release"
    )
    parser.add_argument("--version", help="指定版號 (如 v3.2)，預設自動 bump")
    parser.add_argument("--list-qualified", action="store_true",
                        help="只列出 qualified entries，不產檔案")
    parser.add_argument("--dry-run", action="store_true",
                        help="試跑，不產檔案")
    parser.add_argument("--gen-import-script", action="store_true",
                        help="同時產出甲方端的 auto-import-qualified.sh")
    args = parser.parse_args()

    # ── 1. 掃描 qualified memory ──
    entries = scan_qualified_memory()
    print(f"🔍 掃描 qualified memory: {len(entries)} 條 tagged #qualified")

    if args.list_qualified:
        list_qualified(entries)
        return

    # ── 2. 決定版號 ──
    if args.version:
        version = args.version
    else:
        current = read_current_version()
        version = bump_version(current)
    print(f"📌 版號: {version}")

    # ── 3. 建構 release ──
    zip_path = build_release(version, entries, dry_run=args.dry_run)

    # ── 4. 可選：產出甲方 import script ──
    if args.gen_import_script:
        generate_import_script(dry_run=args.dry_run)

    # ── 5. 更新 VERSION 檔案（非 dry-run 時） ──
    if not args.dry_run and zip_path:
        VERSION_FILE.write_text(version + "\n")
        print(f"📝 VERSION 已更新 → {version}")

    # ── 6. 提示本尊 publish ──
    if not args.dry_run and zip_path:
        print(f"\n🚀 要 publish 給甲方:")
        print(f"    git add releases/release-{version}.zip")
        print(f"    git commit -m \"qualified memory release {version}\"")
        print(f"    git push origin main")
        print(f"\n   或直接寄檔案給甲方。")


if __name__ == "__main__":
    main()
