---
name: persona-db-billing
description: "TW Persona DB 商業模式 — Lite/Transfer/Upgrade 三層定價 + Session Log 計費 + 分身交付"
version: 2.0.0
author: kstsai
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [persona, billing, business-model, pricing, taiwan, appliance]
  user:
    kstsai:
      billing_defaults:
        lite_price: "NT$25,000"
        transfer_price: "NT$60,000-80,000"
        upgrade_rate: "NT$2,000/hr"
        currency: "TWD"
---

# TW Persona DB — 計費模式與商業提案（v2）

> 最終結論，2026-07-13 定案。取代舊版 Phase 1 + 類心理師 NT$3K/hr。

---

## 適用情境

當 kstsai 與前主管（或任何客戶）討論合作、報價、或產出提案時，載入此 skill。

關鍵關係定位：**不是 vendor，是合作夥伴。交付工具，各自發展，不必每月對帳。**

---

## 三層定價結構

```
Lite     NT$25,000    ← 資料 + 生成引擎，不含 QA，品質自行負責
Transfer NT$60-80K    ← 全部 tool + QA + 方法論，品質有 baseline
Upgrade  NT$2,000/hr  ← 需要 main branch 新版時，依 session log 計費
```

---

### Lite 方案 — NT$25,000

| 項目 | 內容 |
|:----|:------|
| 交付物 | `tw_persona_1069.json` + `query_persona.py` + `_generate_997.py` + RFC + qualified-memory + README/FAQ |
| 授權 | 永久授權，可用於商業內部。**可自行修改/regenerate，可賣改進後的 1069.json** |
| 禁止 | ❌ 不可轉售 tool 本身（`_generate_997.py` 等） |
| 品質免責 | ⚠️ 不含 QA 驗證工具，再生品質由甲方自行負責 |

**適合：** 預算有限但有技術能力自行 QA 的客戶。之後可補差價 NT$35K-55K 升 Transfer。

**ZIP 路徑：** `releases/persona-appliance-lite-v3.2.zip`（140 KB）

---

### Transfer 方案 — NT$60,000-80,000

| 項目 | 內容 |
|:----|:------|
| 交付物 | Lite 全部 + `qa_validate.py` + 機率表 + 完整 scripts + skills 目錄 + 完整 SKILL.md（含 methodology） |
| 授權 | 同 Lite：可自行 iterate、可賣改進後的 1069.json、不可轉售 tool |
| 品質保固 | ✅ 含 23 條 QA 規則驗證、Pro sub-agent review pipeline、方法論交接 |
| 交接 | 1 次會議（1hr），展示 CLI + 維度 + 已知限制 |

**適合：** 想要完整生產工具 + 品質 baseline 的客戶。

**ZIP 路徑：** `releases/persona-appliance-pro-v3.2.zip`（197 KB）

---

### Upgrade — NT$2,000/hr（類心理師 session log 計費）

客戶需要 main branch 新版或新功能時，按實際工作時數計費：

| 項目 | 數值 |
|:----|:----:|
| 費率 | **NT$2,000/hr** |
| 最低計費 | **15 分鐘** |
| 透明機制 | 每次 upgrade 產出 `WORKLOG-YYYY-MM-DD.md`，記錄每個時間段工作內容、對應 git commit、產出檔案 |
| 驗證方式 | Session log + git log 交叉驗證，甲方確認後結算 |

#### 計時規則

| 算時數 | 不算 |
|:------|:-----|
| 修改 code、分析資料的實際工作時間 | AI API 費用（NT$~0.4/次，客戶不負擔） |
| 見面討論/線上會議時間 | LINE 聊兩句確認事項 |
| 調整參數 + re-run + QA iteration | 背景發想的時間 |
| 操作教學與交接會議 | 學新工具的時間 |

#### 估算參考

| 升級類型 | 預估工時 | 預估金額 |
|:---------|:--------:|:--------:|
| Minor bug fix / QA rule 新增 | 0.5-1.0h | NT$1,000-2,000 |
| Major version bump (v3→v4) | 3.0-5.0h | NT$6,000-10,000 |
| Domain 疊加（選舉/消費/金融） | 2.0-4.0h | NT$4,000-8,000 |
| 全新建置（日本/越南版） | 8.0-15.0h | NT$16,000-30,000 |

#### Worklog 格式範例

```markdown
# Persona DB v3.0→v3.7 工時紀錄
日期: 2026-07-11 ~ 07-13 | 費率: NT$2,000/hr | 總計: 10.1h = NT$20,200

## 7/11（六）— 主力架構迭代 — 5.7h

### 09:30-10:00 — Session 開啟 + 脈絡重建 (0.5h)
- 從 home session handoff persona improvement 討論

### 10:00-10:30 — Hybrid 驗證方向決策 (0.5h)
...

## 總計

| 日期 | 工時 | 內容 | 金額 |
|:----|:----:|:-----|:----:|
| 7/11 | 5.7h | v3.0核心架構 + v3.1 + 65+自然化 + 2輪Pro | NT$11,400 |
| 7/12 | 1.6h | 真實OCC/MARRIAGE數據 + QA R19-R20 | NT$3,200 |
| 7/13 | 2.8h | v3.7全量 + 6×Pro + post-hoc + QA R21-R23 | NT$5,600 |
| 總計 | 10.1h | 25+ commits, 1069 personas, 23 QA rules | NT$20,200 |
```

---

## 三方案對照

| | Lite | Transfer |
|:--|:----:|:--------:|
| **價格** | **NT$25,000** | **NT$60,000-80,000** |
| 資料（1069.json） | ✅ | ✅ |
| 查詢 CLI | ✅ | ✅ |
| `_generate_997.py` | ✅ | ✅ |
| `qa_validate.py` | ❌ | ✅ |
| 機率表 + scripts | ❌ | ✅ |
| skills 目錄 | ❌ | ✅ |
| 可賣改進後的 1069.json | ✅ | ✅ |
| 品質保固 | ❌ 自行負責 | ✅ 含 QA 驗證 |
| 後續升級 | NT$2,000/hr | NT$2,000/hr |

---

## 授權核心條款

| 項目 | 允許 | 不允許 |
|:-----|:----|:-------|
| 使用資料 | ✅ 可用於商業產品內部 | ❌ 不可轉售 tool 本身 |
| 改進資料 | ✅ 可自行 iterate、regenerate | ❌ 不可轉售 `_generate_997.py` 等 |
| 販售改進資料 | ✅ **可賣改進後的 1069.json** | ❌ 不可作為獨立 tool 轉售 |
| 重新生成 | ✅ 可用 `_generate_997.py` | |
| 子授權 | | ❌ 不可再授權予第三方 |

---

## 交付機制

### 分身 Appliance（ZIP 交付）

每次 build 產出可獨立運作的 ZIP，客戶解壓縮即可使用：

```bash
# Lite
python3 build_appliance.py --lite

# Transfer (=Pro)
python3 build_appliance.py --pro

# Standard (唯讀 query，無 generate)
python3 build_appliance.py
```

ZIP 內含路徑已修復為相對路徑（`PERSONA_OUTPUT` / `PERSONA_DB` env var 或 `../data/` 自動偵測），離線可執行。

### Qualified Memory Release

本尊迭代後，透過 `#qualified` tag 策展知識，用 `export_qualified_memory.py` 打包 release：

```bash
python3 export_qualified_memory.py --version v3.3
```

Release ZIP 含：qualified-memory.md + data + skill + CHANGELOG + manifest。

---

## 關係動態

- 我們保留 main branch 持續迭代
- 甲方自行開發改進，與我們各自獨立
- 甲方需要我們的更新 → 類心理師 NT$2,000/hr 依 session log
- 乙方無 ongoing 維護義務
- 關係定位：**交棒夥伴，不是 vendor**

---

## 成本結構（內部參考）

```
API 費用（DeepSeek V4 Flash）:  ~NT$100/密集專案
基礎設施（電費+網路）:          ~NT$90/月
domain 判斷力:                   無價（但不可複製）
Hermes Agent 執行力:            免費（Nous 訂閱）
```

---

## Repo 位置

```
lab-riscv/hermesa3/persona/
├── TRANSFER-MODEL.md         ← Transfer 方案完整說明
├── UPGRADE-PRICING.md        ← Session log 計費詳情
├── LITE-MODEL.md             ← Lite 方案完整說明
├── BUILD_APPLIANCE.md        ← 分身打包方法
├── WORKLOG-2026-07-11-13.md  ← 實際 worklog 範例
├── build_appliance.py        ← 打包腳本
├── export_qualified_memory.py ← Release 工具
└── releases/                 ← ZIP 產出
```

公開 repo: `github.com/kstsai/media-narrative/persona/`
