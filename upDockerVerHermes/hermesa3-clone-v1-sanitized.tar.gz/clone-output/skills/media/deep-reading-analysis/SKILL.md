---
name: deep-reading-analysis
description: "Read one news article (or batch of articles across outlets), identify narrative characteristics, author's viewpoint, emotional stance, reader emotion targeting. Cross-media comparison of same event. Supports single-article deep reading and batch cron-driven workflows."
version: 1.3.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [media, narrative, deep-reading, sentiment, framing, journalism, batch-analysis]
    related_skills: [cross-media-analysis]
---

# Deep Reading Analysis

Read a news article and analyze:

## 1. Narrative Characteristics

| Aspect | Questions to ask |
|--------|-----------------|
| **Form** | Pure quote-reporting / live coverage / commentary column / interview / translation |
| **Protagonist** | Who is centered in this article? |
| **Scene** | Where does the reporting take place? (parliament/press conference/on-site/online) |
| **Structure** | How does it open → who speaks → how does it close |
| **Sources** | Single source / multi-source / anonymous / official data |
| **Photo/Image** | What emotion does the photo convey? Who provided it? |

## 2. Author's Viewpoint / Stance

- **Casting bias**: Who gets to speak? Who is excluded?
- **Language bias**: What words describe each side? ("撂重話" vs "表示" vs "坦言")
- **Context bias**: What background is given? What is omitted?

## 3. Author's Emotional Stance Toward Subjects

Table format:
| Subject | Emotion Label | Evidence |
|---------|--------------|----------|
| Person A | 🟢 positive / 🔴 negative / 🟡 neutral | quote or phrase |

Use the persona label system:
- 😇 Build (正面建立) / 🗑️ Destroy (負面毀滅) / 😐 Neutral / ⚠️ Question

## 4. Emotions the Article Tries to Provoke in Readers

| Emotion | How it's done |
|---------|---------------|
| 😡 anger | specific phrase or choice |
| ✅ reassurance | specific framing |

Common emotions: anger, fear, reassurance, disgust, hope, helplessness, pride, suspicion, intellectual superiority

## 5. Cross-Media Comparison (same event, different outlets)

| Dimension | Outlet A | Outlet B |
|-----------|----------|----------|
| Protagonist | President Lai | Minister Shih |
| Reader emotion | Reassured | Dissatisfied |
| Excluded voices | Opposition | Presidential office |

## 6. Batch Deep Reading Workflow (for cron / automated reports)

When analyzing 5+ topics across multiple outlets as part of the daily cross-media-analysis cron, follow this scaled workflow:

### 6.1 Article Selection

1. **Run the automated report** (`_eight_media_report.py --date YYYY-MM-DD`) first
2. **Read §4 (共同議題框架比對)** to identify topics covered by 2+ outlets
3. **Select the top 3-5 topics** by coverage breadth (most outlets covering them)
4. **For each topic, pick 1 article from 2 different outlets** that represent opposite ends of the media spectrum (e.g. 自由偏綠 vs TVBS中性, or 三立偏綠 vs 風媒偏藍)
5. **Prefer outlets with full-text availability** (✅ in §1 table)

### 6.2 Article Fetching Strategy

- Use `web_extract(urls=...)` to fetch article content in parallel batches (max 5 URLs per call)
- For TVBS/中天 articles, extract the real article URLs from the RSS feed results; do not pass RSS feed URLs
- If a URL 404s or returns a paywall, substitute with the next article from the same outlet on that topic
- Fall back to `browser_navigate` if the page is SPA-rendered and `web_extract` returns insufficient content
- **Cron mode**: To extract article URLs from the cached JSON or parse data, use `terminal` with inline Python (`python3 -c "import json; ..."`) — `execute_code` is blocked for cron jobs

### 6.3 Analysis Structure Per Topic

For each topic, produce:

```
**Topic N: <topic name> (<N outlets covering>)**

#### Outlet A (<source>): <title> — <narrative frame label>

[§1 Narrative Characteristics]
[§2 Author's Viewpoint]
[§3 Author's Emotional Stance table]
[§4 Reader Emotion Targeting table]

#### Outlet B (<source>): <title> — <narrative frame label>

[Same 4 sections]

#### Cross-Media Comparison

```

When N>2 outlets cover the same topic, add one column per outlet in the comparison table.
When the topic is covered by a single aggregation platform (e.g. Yahoo) but articles come from N different original sources (信傳媒, 中天, 聯合報, etc.), treat each original source as a separate row — note explicitly that this is "single platform, multi-source" in the comparison header.

**Same-spectrum comparison**: When all outlets covering a topic are on the same editorial side (e.g. both 自由時報 and 三立 are 偏綠), still compare them — the finding is the *range of narrative tools* within one camp. One outlet may use 國安上綱 (fear), another may use 跨陣營理性包裝 (intellectual superiority). Add a note: "同光譜內部比較" in the section header, and use the comparison table with a "策略差異" dimension:

| 維度 | <outlet A> | <outlet B> |
|:----|:----------:|:----------:|
| 主框架 | ... | ... |
| 策略差異 | 嚴肅國安論述，理性包裝 | 情緒驅動 + 參與式行銷 |
| 風險等級 | 🔴高 | 🔴高（加一層操弄） |

**Single-origin supplement topic**: When analyzing a supplement topic that has only one original source (e.g. 自由時報独家 + Yahoo merely reposts 自由's RSS), there is no internal cross-source contrast. The analytical finding is the **collective silence** of all other outlets. Note this explicitly: "本議題全部報導溯源於單一來源，Yahoo 僅為聚合轉載。其餘 7 家完全沉默。"

Template for 3+ columns:

| Dimension | Outlet A | Outlet B | Outlet C |
|-----------|----------|----------|----------|
| Main frame | ... | ... | ... |
| Writing type | ... | ... | ... |
| Reader emotion | ... | ... | ... |
| Excluded voices | ... | ... | ... |
| Hidden message | ... | ... | ... |

Also flag when the only coverage of a major story comes from a single aggregation platform — this is a **單一來源盲點 (single-source blind spot)** and merits explicit analysis in the report under Key Insights (§6).

### 6.4 Updating the Automated Report's §4 Labels

After deep reading, go back and update the "🟡 待判讀" placeholders in §4 with actual labels:
- 🟢 事實/中性報導 | 🔴 批判/威脅框架 | ⚪ 沉默 | 🔵 正面框架
- Label the narrative steering direction for each outlet × topic combination

### 6.5 Narrative Stance Matrix

After all topics are analyzed, produce a summary matrix table:

| 議題/人物 | 自由時報 | 聯合報 | TVBS | ETtoday | 三立 | 中天 | 風傳媒 | Yahoo |
|:---------|:-------:|:-----:|:----:|:-------:|:----:|:----:|:------:|:-----:|
| 巴威颱風 | 🔴批判 | 🟢中性 | 🟢中性 | 🟢實用 | 🟡民生 | ⚪沉默 | ⚪沉默 | 🟡聚合 |
| 矢板明夫 | 🔴跨境鎮壓 | ⚪沉默 | ⚪沉默 | ⚪沉默 | 🔴跨境鎮壓 | ⚪沉默 | ⚪沉默 | 🔴/🟡並陳 |

Also include persona labels per person per outlet:
| 人物 | 自由時報 | 聯合報 | TVBS | 三立 | 中天 | 風傳媒 | Yahoo |
|------|:-------:|:-----:|:----:|:----:|:----:|:------:|:-----:|
| 蔣萬安 | 🗑️毀滅 | — | 😇建構 | 🗑️毀滅 | — | — | 😇建構 |
| 川普 | 🗑️毀滅 | — | — | — | — | 😇建構 | 😇建構 |

Label legend:
- 🟢 正面/中性報導 | 🟡 待判讀/民生 | 🔴 批判/威脅框架 | ⚪ 沉默
- 😇 正面建構人物 | 🗑️ 毀滅人物 | 😐 中性

## Key Insight

> **News reporting is dangerous precisely because it pretends to be neutral.**
> Commentary columns are less deceptive because they openly state their立场.
> The hardest-to-detect manipulation hides in articles that call themselves "news."

## Trigger

Use this skill whenever:
- User asks to "讀一篇報導分析", "Deep reading", "這篇報導想讓我感覺什麼", "作者的意圖是什麼"
- Cross-media comparison of article framings
- **Daily cron pipeline**: after running the automated report, use the batch workflow (§6) to deep-read the top 3-5 shared topics and produce the narrative stance matrix
- Supplementing the automated report with qualitative analysis (pick 1-2 representative articles per topic)

## Key Pitfalls

1. **URL availability**: Some article links from the scraper may 404 or return paywalls. Always verify with `web_extract` and have a fallback article ready.
2. **TVBS RSS only returns titles/URLs, not article content**: You must `web_extract` each TVBS article URL individually to get full text.
3. **中天 RSS is advertorial-only**: Deep reading of 中天 is usually uninformative for political analysis. Note this in the report.
4. **Batch scaling**: Deep-reading 10+ articles in one session can be time-consuming. Fetch articles in parallel batches (max 5 URLs per `web_extract` call). Prioritize outlets that form the clearest contrast.
5. **The stance matrix is a summary, not primary analysis**: It should be the *last* thing you produce, after all individual deep readings are done. Don't guess matrix cells without reading the articles.
6. **Label drift**: The automated keyword-based persona labels (from the scraper) may disagree with your manual deep-reading assessment. The manual assessment always wins — note discrepancies in the report.
7. **Cron mode blocks `execute_code`**: When running deep reading as part of the daily cron, `execute_code` is unavailable. Use `terminal` with inline Python (`python3 -c "..."` or `python3 << 'EOF'`) for any data extraction or JSON parsing steps. `web_extract` and `browser_navigate` remain available.
8. **Yahoo aggregation blind spot**: Yahoo 新聞 is an aggregation platform — its articles come from different original sources (鏡報, 太報, 聯合報, 信傳媒, 中天, 民報, etc.) that may have completely contradictory narrative frames on the same topic. Always note the original source outlet in parentheses after the title. When analyzing a topic only reported on Yahoo, explicitly flag the "單一來源盲點" — 7 other outlets being silent on a major story is itself an analytical finding.
9. **Yahoo 幕後/analysis articles are prone to 404**: Yahoo's original analysis pieces (e.g. 太報 【幕後】 series) often have unstable URLs. If a Yahoo article 404s, search for the title on the original source outlet's website (e.g. 太報, 鏡報) and use that URL instead.
10. **§4 vs §7 article mismatch**: The automated scraper (§4) may list one article per outlet per topic, but the deep-reading task (§7) may ask you to analyze a different article from the same outlet on the same topic. When this happens, (a) analyze the article the task specifies, (b) update §4 to list the additional article or add a footnote noting the discrepancy, and (c) in the cross-media comparison, compare frames across the actual articles read.

11. **Supplement topic deep reading (obs. 2026-07-12)**: Supplement topics (auto-detector keyword gaps or single-source blindspots) often lack the 2-outlet contrast needed for standard cross-media comparison. Two sub-cases:
    - **Multi-source aggregator** (e.g. Yahoo carries 3+ articles from different original outlets): Use internal cross-source comparison — compare frames across original sources within the aggregator, not across outlets.
    - **Single-source + aggregator repost** (e.g. only 自由時報 reports it; Yahoo just reposts 自由's RSS): There is NO internal contrast. The analytical finding is that 7 other outlets are silent. State this explicitly.
    In both cases, flag the section with ⚠️ and note the limitation in §6 Key Insights.
