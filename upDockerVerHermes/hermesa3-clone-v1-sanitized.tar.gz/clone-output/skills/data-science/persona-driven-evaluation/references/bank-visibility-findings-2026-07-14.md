# Bank Visibility Analysis — 2026-07-14 Full Report

**Model:** deepseek-v4-pro | **Mode:** Encounter simulation (遭遇模擬②)
**Personas:** 11 (6M:5F, age 19-65+, North/Central/South/East, 6 occupations)
**Client questions:** 4 banking scenarios (all completed)
**Total LLM responses:** 44 (4 scenarios × 11 personas)

---

## Cross-Scenario Visibility Matrix

| Bank/Product | 🅰️ Savings | 🅱️ Mortgage | Q1 Dual-Currency | Q3 Payment Card | Q4 App UX |
|:------------|:----------:|:-----------:|:----------------:|:---------------:|:---------:|
| **台銀** | **73% 🥇** | 0% | 0% | 0% | 0% |
| **新青安 (Gov't)** | — | **64% 🥇** | — | — | — |
| **將來銀行** | 18% 🥈 | 0% | 0% | 0% | 5/11 mentioned |
| **渣打** | 0% | 18% 🥈 | 0% | 0% | 0% |
| **台新（雙幣卡）** | 9% | 0% | **36% 🥇** | 0% | 0% |
| **永豐（幣倍卡）** | 0% | 0% | 18% 🥈 | 0% | 0% |
| **聯邦（賴點卡）** | 0% | 0% | 0% | **3/11 🥇** | 0% |
| **臺銀行動+** | — | — | — | — | **5/11 🥇** |
| **國泰CUBE** | 0% | 0% | 0% | 0% | 3/11 |
| **LINE Bank** | 0% | 0% | 0% | 0% | 3/11 ⚠️ |
| **中信** | 0% | 0% | 9% | 5/11 mentioned | ❌ ads complaints |
| **玉山熊本熊** | 0% | 0% | 0%但5次次推 | 0% | ❌ ads complaints |
| **滙豐** | 0% | 0%但4次 | 0% | 0% | 0% |
| **凱基** | 0% | 0% | 9% | 0% | 0% |
| **Richart** | 9% 🥉 | 0% | 0% | 0% | 3/11 |

## Key Findings

### 1. No bank dominates all scenarios — each has a "home turf"
- **台銀** rules savings (73%) — zeroes in mortgage, cards, app
- **新青安** steamrolls mortgage (64%) — doesn't exist elsewhere
- **台新** wins dual-currency cards (36%) — invisible in mortgage/app
- **臺銀行動+** wins app UX (5/11) — same parent bank as savings king 台銀!
- **聯邦** wins payment cards (3/11) — niche: LINE Points ecosystem

### 2. The scenario-dependency insight
The most powerful finding for client presentations: **rankings are question-contingent, not absolute.** A bank can dominate one scenario and be completely invisible in another.

> 「台銀在活存場景是73%首推率的霸主，但在房貸場景首推率是0%」

### 3. What drives each scenario
| Scenario | Driver | Champion | Why they win |
|----------|--------|----------|-------------|
| Savings | Easy-to-tell story | 台銀 | "99 free transfers, no tasks" |
| Mortgage | Government authority | 新青安 | "1.775% government subsidy" |
| Dual-currency | Speed narrative | 台新 | "卡號速取 = card number immediately" |
| Payment card | Points ecosystem | 聯邦 | "LINE Points + even-day 7%" |
| App UX | Anti-ads policy | 臺銀行動+ | "Public bank, no sales pressure" |

### 4. Persona-demographic effects by scenario
| Persona trait | Savings | Mortgage | Dual-currency | Payment card | App UX |
|--------------|---------|----------|---------------|-------------|--------|
| Low income (<3萬) | 台銀 (save fees) | 新青安 (gov't) | 先辦普通卡 | 陽信5%/永豐DAWAY | LINE Bank (simple) |
| Self-employed | 將來 (higher cap) | 渣打 (轉貸) | 永豐 (多幣別) | 中信(收款)+DAWHO | 台銀(無廣告) |
| Elderly 65+ | Richart (LINE UX) | 新青安(for son) | 台新 (最簡單) | 中信LINE Pay | 臺銀行動+(簡單) |
| Student | Richart/Bankee | 新青安(future) | 簽帳卡(debit) | 王道O!Range | 國泰CUBE |
| High income (>8萬) | 台銀+將來 | 新青安+滙豐 | 台新+玉山 | 聯邦+玉山Unicard | 將來+國泰CUBE |
| Finance insider | 台銀+將來 | 台土銀新青安 | 台新+凱基 | 中信+玉山Unicard | 將來+國泰CUBE |

### 5. Methodological insight
**Encounter mode (遭遇模擬②)** consistently produces richer, more authentic responses than self-mode (自我模擬①). The LLM naturally connects brand features to persona backgrounds when framed as "someone comes to ask you." Self-mode responses converge toward similar recommendations (contamination bias).

## Per-Scenario Detail

### Scenario A: Savings (活存利率+轉帳次數)
- **台銀** 73% first-pick, 11/11 coverage — the single dominant finding
- **將來** 18% first-pick — wins only for self-employed (higher cap)
- **Richart** 9% — wins only for elderly (LINE UX)

### Scenario C: Mortgage (房貸利率+成數)
- **新青安** 64% first-pick — government program dominates all first-time buyers
- **渣打** 18% first-pick — dominates refinance/transfer market
- **彰銀/土銀** 9% each — public banks niche for second-property buyers

### Scenario Q1: Dual-Currency Card (雙幣卡審核速度)
- **台新** 36% first-pick — "卡號速取" instant-use story wins
- **永豐幣倍卡** 18% — multi-currency flexibility for business travelers
- **凱基雙幣哩程卡** 9% — fastest actual approval (24h reported)
- **玉山熊本熊** 0% first-pick but 45% second-pick — "permanent runner-up" for Japan

### Scenario Q3: LINE Pay/街口 Payment Card (聯名卡回饋)
- **聯邦賴點卡** 3/11 first-pick — LINE Points ecosystem + even-day 7%
- **中信LINE Pay卡** 5/11 mentioned — reliable 1% + overseas 2.8%
- **玉山Unicard** 4/11 mentioned — flexible up-to-4.5% across both platforms
- **台新街口聯名卡** niche for 街口-heavy users
- Students/low-income → **Deibit cards** (王道O!Range, 中信LINE Pay debit)

### Scenario Q4: App UX (行動網銀介面乾淨度)
- **臺銀行動+** 5/11 first-pick — "clean as Australian banks" surprise winner
- **將來銀行** 5/11 mentioned — design by 方序中 team, minimal ads
- **國泰CUBE** 3/11 mentioned — explicit internal policy against cover-ads
- **LINE Bank** 3/11 mentioned — simple UI but heavy LINE notification spam
- **台新Richart** 3/11 mentioned — functional but 拆兩個App confusing
- **Banks to avoid:** 玉山(首頁廣告佔半版), 中信(十推七廣), LINE Bank(難關推銷)
