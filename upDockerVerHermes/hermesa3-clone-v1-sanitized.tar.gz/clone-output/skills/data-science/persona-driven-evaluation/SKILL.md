---
name: persona-driven-evaluation
description: >-
  Use Persona DB personas as test probes for LLM evaluation. Covers spawn-agent survey
  simulation (self-mode vs encounter-mode), brand visibility analysis across demographics,
  and multi-scenario testing to assess LLM recommendation bias and coverage.
domain:
  - persona-db
  - llm-evaluation
  - brand-visibility
  - survey-simulation
---

# Persona-Driven LLM Evaluation

Evaluate how an LLM responds to different demographic profiles by using **persona DB personas** as survey probes. This catches **contamination bias** (same-agent) and measures **brand visibility** (encounter-mode).

## When to Use

- User wants to test how an LLM recommends products (banks, insurance, retail) across different user profiles
- User asks for "persona simulation" or "role-playing Q&A" for survey research
- Brand wants to understand its **LLM share of voice** across demographics
- Need to detect **systematic bias** in LLM recommendations (favors certain brands for certain demographics)

## Core Methodology: Spawn Agent (not Same Agent)

### What NOT to do (Same-Agent Contamination)

Running multiple personas in the **same conversation** introduces contamination bias:
- Answers unconsciously converge toward the same brands
- Later personas inherit framing from earlier ones
- Responses are more "template-like", less localized

```python
# BAD: same agent, contaminates
# "I'm 麗華, answer..."
# "I'm 靜怡, answer..."
```

### What to do (Spawn Agent)

Use `delegate_task` to give each persona an **independent sub-agent**:

```python
delegate_task(
    context="...full persona background...",
    goal="Answer as {persona}: {question}",
    role="leaf"
)
```

Each sub-agent:
- Has its own isolated context
- Knows nothing about other personas
- Runs on the configured delegation model (Pro, if set)
- Returns independently when done

## Two Simulation Modes

### ① Self-Simulation (自我模擬)
Sub-agent **IS** the persona, answering the question directly.

**Best for:** Survey response simulation (persona filling out a questionnaire), predicting what a persona would say.

**Pitfall:** Responses can feel template-like with less localized detail.

### ② Encounter Simulation (遭遇模擬) — Preferred for brand analysis
Sub-agent **encounters** the persona asking a question and responds to them as an expert/friend.

**Best for:** Brand visibility analysis, assessing how LLM tailors advice to different demographics. Produces more authentic, locally-grounded responses.

**Why preferred (confirmed by user):**
- Encounter framing forces LLM to explicitly connect brand features to persona needs
- Produces richer localized details (靜怡 mentions 小孩教育費; 淑貞 mentions 轉錢給老公)
- More willing to state negatives ("沒有一家兩個都最高")
- User explicitly prefers this mode for formal brand visibility work

### Recommendation

| Phase | Mode | Why |
|-------|------|-----|
| Quick exploration | **Same-agent ① self-mode** | Fast, cheap, good for direction-finding |
| Formal brand report | **Spawn-agent ② encounter-mode** | Contamination-free, authentic, client-ready |

## Persona Selection Strategy

When building a test set, cover these **6 dimensions**:

| Dimension | Why it matters |
|-----------|---------------|
| **Age** | Different life stages have different product needs |
| **Income** | Affects price sensitivity and product tier preference |
| **Occupation** | Determines financial literacy and product familiarity |
| **Geography** | Regional bank/retail density affects recommendations |
| **Family/Marriage** | Single vs family changes product focus |
| **Education** | Affects how explanations are framed |

**Target:** 6–11 personas for statistically meaningful coverage.
**Tool:** Query `tw_persona_1069.json` filtering on `dimensions` fields.

## Analysis Framework: Brand Visibility Scoring

For each persona response, extract:

| Score | Weight | How to measure |
|-------|--------|----------------|
| **Recommendation rank** | 30% | Is brand first-choice, second-choice, or passing mention? |
| **Context fit** | 25% | Is the recommendation explicitly linked to persona demographics? |
| **Endorsement strength** | 20% | Is the language "strongly recommend" vs "also an option"? |
| **Defense stability** | 15% | Does the recommender hold position when challenged? |
| **Negative mentions** | -10% | Brand mentioned as "don't recommend" or "watch out for" |

**Output:** Per-brand visibility table showing coverage (out of N personas) + average recommendation rank.

## Multi-Scenario Testing

A single question gives limited credibility. Run **multiple scenarios** to see recommendation shifts:

| Scenario | Question focus | What it tests |
|----------|---------------|---------------|
| Savings | "Highest savings rate + free transfers" | Digital vs traditional banks |
| Mortgage | "Lowest mortgage rate + highest LTV" | Public vs private banks, government vs commercial |
| Dual-currency card | "Best dual-currency card, fastest approval" | Credit card issuers, travel banks |
| Mobile payment | "Best LINE Pay/街口 linked card" | Consumer retail banks |
| App UX | "Cleanest mobile banking app, no ads" | Digital experience leaders |

**Key finding: No bank wins all scenarios.** Rankings flip completely when the question changes:

| Bank | 🅰️ Savings 🥇 | 🅱️ Mortgage 🥇 | 🆕 Cards 🥇 |
|:----|:-------------:|:--------------:|:-----------:|
| 台銀 | 73% | 0% | 0% |
| 新青安(政府) | — | 64% | — |
| 台新 | 9% | 0% | 36% |
| 渣打 | 0% | 18% | 0% |

This **scene-dependent visibility** is the most powerful finding to present to clients — it shows that brand rankings are not absolute, but question-contingent.

## Recommended Workflow

```python
# 1. Client provides N questions (e.g. 4 banking scenarios)
# 2. Select 6-11 personas covering age/sex/income/region/occupation/education
# 3. For each question-scenario:
#    a. Dispatch delegate_task(context=persona_bg, goal=encounter_question)
#    b. Batch 3 at a time (concurrent limit)
# 4. Extract brand mentions per response
# 5. Score: first-pick=3pts, second=2pts, mention=1pt, negative=-1pt
# 6. Produce cross-scenario visibility matrix
```

## Pitfalls

- **Contamination bias** is invisible if you use the same agent — always spawn sub-agents for formal testing
- **Encounter mode** can inadvertently add the "expert" persona's opinion — design the goal prompt carefully
- **Concurrent limits**: `delegate_task` maxes at 3 concurrent for this user — batch in groups of 3
- **Token cost**: spawn agent costs ~3-4× same-agent (each is a fresh context window)
- **Date-sensitive data**: savings rates, mortgage rates change — note the date in results
- **Model matters**: results differ between GPT, Claude, DeepSeek — note which model was used
- **Language**: sub-agents default to English if context doesn't specify — always include language instruction

## Example Workflow

```python
# 1. Select personas from DB
data = json.load(open("tw_persona_1069.json"))
candidates = [p for p in data if filter_conditions(p["dimensions"])]

# 2. Dispatch batch (3 at a time)
delegate_task(
    tasks=[{"context": ctx, "goal": goal} for ctx, goal in zip(contexts, goals)],
    role="leaf"
)

# 3. Collect results → extract brand mentions → score → produce visibility table
```

## Verification

✅ Spawn agent produces contamination-free responses
✅ Encounter mode produces richer localized details than self-mode
✅ Brand visibility rankings shift predictably when the question changes
✅ Different personas get different recommendations (no false universalization)
