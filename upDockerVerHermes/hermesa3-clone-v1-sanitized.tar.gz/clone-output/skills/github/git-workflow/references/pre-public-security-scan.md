# Pre-Public Security Scan

Before making a private repo public (or splitting into a public repo), scan for:

## 1. Secrets in File Contents

Use `git grep` for each pattern:

```bash
# API keys / tokens
git grep -n 'sk-[a-zA-Z0-9]\{20,\}' -- ':!*.md'
git grep -n 'ghp_[a-zA-Z0-9]\{36,\}' -- ':!*.md'
git grep -n 'xox[bap]-[a-zA-Z0-9-]\{10,\}' -- ':!*.md'

# Passwords
git grep -ni 'password["\s:=]\+[^\s"'"'"']\{4,\}' -- ':!*.md'

# Private IPs (RFC 1918)
git grep -n '192\.168\.\|10\.\([0-9]\{1,3\}\.\)\{2\}\|172\.\(1[6-9]\|2[0-9]\|3[01]\)\.'

# SSH keys
git grep -n 'BEGIN \(RSA \|EC \)\?PRIVATE KEY'

# AWS keys
git grep -n 'AKIA[0-9A-Z]\{16\}'
```

## 2. Secrets in Git History

Use `git filter-repo` to strip sensitive files from history:

```bash
# Remove a file from all history
git filter-repo --path ai-agents/hermesa3/MEMORY.md --invert-paths

# Remove passwords from all history
git filter-repo --replace-text <(echo "hermes-admin123==>PASSWORD_REMOVED")
```

## 3. Environment / Config Files

```bash
find . -name '.env*' -o -name '*.pem' -o -name 'id_*' | grep -v node_modules
```

## 4. CI/CD / Webhook Files

Check for hardcoded paths, internal URLs, or service credentials in:
- `.github/` workflows
- Webhook receiver scripts
- Deployment configs

## 5. After Cleaning

Regenerate inventory from `networkNodes.yaml` if it contains passwords:

```bash
python3 ansible/scripts/networkNodes-to-inventory.py
```

Then make a clean initial commit for the public repo (no history from private repo).
