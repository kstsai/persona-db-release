---
name: hermes-delivery
description: >-
  Package a Hermes Agent instance for client delivery — sanitize skills, clear
  memory/state, generate template configs, produce deliverable artifacts
  (tarball, VM qcow2, Docker).
version: 1.1.0
author: Hermes Agent
platforms: [linux]
tags: [hermes, delivery, clone, sanitization, packaging, client-handover]
related_skills: [hermes-agent, git-workflow, project-restructure]
---

# Hermes Instance Delivery

Package a working Hermes Agent instance into a clean, client-ready deliverable.
Use when the user needs to clone their Hermes for a client, teammate, or
separate project — without leaking personal data, conversation history, or
business-sensitive context.

## Memory Storage Format

Memory lives in two files per profile:

| File | Path | Content |
|------|------|---------|
| **MEMORY.md** | `~/.hermes/memories/MEMORY.md` (default) or `~/.hermes/profiles/<name>/memories/MEMORY.md` | Agent's notes about the environment, workflows, technical facts |
| **USER.md** | `~/.hermes/memories/USER.md` (default) or `~/.hermes/profiles/<name>/memories/USER.md` | Agent's notes about who the user is — background, preferences, relationships, personal situation |

Both are plain-text files with entries separated by `§` on its own line. The `memory` tool in Hermes reads/writes these files. You can also edit them directly with `write_file` (useful for bulk reorganization).

**⚠️ USER.md is often MORE sensitive than MEMORY.md.** It may contain:
- Employment status and financial situation
- Client relationship dynamics (ex-boss, partner negotiation)
- Personal motivations and emotional context
- Identity information and personal philosophy

Always sanitize USER.md when preparing a delivery.

## Profile-Based Client Isolation

Create a dedicated profile for each client rather than cleaning up the default profile:

```bash
# Create a client profile (clones config + skills from default)
hermes profile create client-A --clone-from default

# Each profile has its own:
#   ~/.hermes/profiles/<name>/memories/MEMORY.md
#   ~/.hermes/profiles/<name>/memories/USER.md
#   ~/.hermes/profiles/<name>/state.db  (session history)
#   ~/.hermes/profiles/<name>/skills/   (independent symlink or copy)
```

**Workflow for moving client data between profiles:**

1. Create client profile: `hermes profile create client-A --clone-from default`
2. Remove client-specific entries from default profile's MEMORY.md and USER.md
3. Add those entries to client-A's memory files
4. Clean client-A's memory of default's personal data

To write to another profile's memory files from code tools, use the `cross_profile=True` flag on `write_file` (the soft guard blocks cross-profile writes by default for safety).

```bash
# Switch profiles:
hermes --profile client-A          # CLI
# In Slack/gateway: /profile client-A  (type at beginning of a message)
```

## Skills Reuse Across Profiles

When you `hermes profile create --clone-from default`, the new profile gets a COPY of skills. If you later install/update skills in default, they do NOT sync to existing client profiles. Two strategies:

- **Symlink skills manually** after creation: `ln -sfn ~/.hermes/skills ~/.hermes/profiles/client-a/skills`
- **Re-clone** when skills change significantly: create a fresh profile and re-migrate only the memory

## Core Principle: Three Layers of Data

When packaging a Hermes instance, data separates into three layers:

| Layer | What | Action |
|-------|------|--------|
| **Skills** | `.md` files in `~/.hermes/skills/` | Audit: keep generic, sanitize borderline, remove personal |
| **Memory** | `~/.hermes/profiles/<profile>/memories/` | Always clear — contains personal notes, client relationships, pricing |
| **Session History** | `~/.hermes/state.db` | Always clear — contains full conversation transcripts |
| **Config** | `config.yaml`, `.env` | Template only — API keys are never included |
| **Credentials** | `.ssh/`, `git-credentials`, auth tokens | Always clear — client provides their own |

## Workflow

### Phase 0: Assess What Exists

```bash
# Count skills
find ~/.hermes/skills -name 'SKILL.md' | wc -l

# Scan for personal data in skills
grep -rn 'kstsai\|myusername\|192\.168\|company-internal' ~/.hermes/skills/ \
  --include='*.md' --include='*.py' --include='*.yaml' --include='*.json' \
  | grep -v '.git/' | grep -v Binary

# Check memory
ls ~/.hermes/profiles/*/memories/
```

### Phase 1: Skill Audit — Three Categories

**① REmove** — Skills that contain personal/business-sensitive data:
- Pricing models, client lists, negotiation strategies
- Internal analysis results with real data
- Personal repo URLs with credentials
- Worklogs with hours × rate

**② Sanitize** — Skills that are useful but contain personal context:
- Repo paths (`/home/ubuntu/lab-riscv` → `/home/hermes/project`)
- Usernames (`kstsai` → `hermes-user`)
- Internal IPs (`192.168.1.178` → `gitea.local`)
- Personal quotes / philosophy statements
- Cron timing details (`UTC 10:00` → `scheduled-time`)
- Remove `author:` and `user:` metadata from YAML frontmatter if they identify the source

**③ Keep** — Pure methodology/tool skills with no personal data:
- Generic workflow skills (git, github, testing, debugging)
- Creative/design skills (ascii-art, p5js, excalidraw)
- ML/inference skills (llama-cpp, vllm)
- Platform integration skills (notion, airtable, google-workspace)

Common patterns for identifying what needs sanitization:

| Pattern | In Skills | Treatment |
|---------|-----------|-----------|
| `kstsai` / real username | author field, command examples, user metadata | Replace with `hermes-user` |
| `/home/ubuntu/lab-riscv` | cd commands, file paths, cron scripts | Replace with `/home/hermes/project` |
| `192.168.x.x` (specific IP) | git remote URLs, SSH configs | Replace with `gitea.local` or `internal-host` |
| `github.com/kstsai/...` | repo references | Replace with `github.com/client-repo/...` |
| `lzcadmin` / internal usernames | git remotes, credential examples | Replace with `hermes-admin` |
| `#qualified` / `#export` tags | memory-to-skill export logic | Remove or genericize |
| pricing/billing data | business model skills | **Remove entirely** |
| business relationship strategy | client-facing skills | **Remove entirely** |
| personal quotes / philosophy | methodology preamble | Remove or genericize |

**⚠️ Pitfall: Reference files.** Skills' `references/`, `templates/`, and `scripts/`
directories (linked via `skill_view`) can contain personal data even when the
SKILL.md itself looks clean. Always scan these too.

**⚠️ Pitfall: `.usage.json`.** The file `~/.hermes/skills/.usage.json` tracks
skill metadata and may contain skill names with personal data. Either regenerate
it or exclude it from the deliverable.

**⚠️ Pitfall: Example IPs vs Real IPs.** Third-party tool references (TouchDesigner,
vLLM) contain generic example IPs like `192.168.1.50` or `192.168.1.255`.
These are NOT personal data — only replace IPs that point to the user's actual
infrastructure.

### Phase 2: Template Configuration

Generate template files — never ship real credentials:

```bash
# .env template
cat > .env.template << 'EOF'
OPENROUTER_API_KEY="sk-or-v1-xxxxxxxxxxxxxxxxxxxx"
# Fill in your own API keys above
EOF

# config.yaml template (no personal provider config)
cat > config.yaml << 'EOF'
model:
  default: "deepseek/deepseek-chat"
  provider: "openrouter"
agent:
  max_turns: 90
terminal:
  backend: local
delegation:
  max_iterations: 50
memory:
  memory_enabled: true
  user_profile_enabled: true
display:
  interface: tui
EOF
```

Remove from config.yaml:
- `delegation.provider` / `delegation.model` — these point to your custom provider
- `model.base_url` — your private endpoint
- Any `approvals.*` config specific to your workflow

### Phase 3: State Cleanup

```bash
# Clear session history
rm -f ~/.hermes/state.db

# Clear memory
rm -rf ~/.hermes/profiles/default/memories/

# Clear shell history
> ~/.bash_history && history -c

# Clear SSH keys
rm -rf ~/.ssh/
mkdir ~/.ssh && chmod 700 ~/.ssh

# Clear git credentials store
rm -f ~/.git-credentials
```

### Phase 4: Packaging

**Tarball** (skills + configs only, smallest):
```bash
tar czf hermesa3-clone-v1-sanitized.tar.gz \
  skills/ config/ env/ gitea/ README.md
```

**qcow2 VM** (full appliance, requires KVM):
```bash
# 1. Download base cloud image
wget https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img
qemu-img resize jammy-server-cloudimg-amd64.img 20G

# 2. Create cloud-init seed with provisioning
#    - Install Hermes Agent via install.sh
#    - Install Gitea via systemd
#    - Copy sanitized skills to ~/.hermes/skills/
#    - Copy config template
#    - Run cleanup commands from Phase 3

# 3. Launch VM with virt-install
virt-install --name hermes-clone --ram 4096 --vcpus 2 \
  --disk base.qcow2,device=disk,bus=virtio \
  --disk seed.img,device=cdrom \
  --os-variant ubuntu22.04 --import --wait 120

# 4. Inject skills after first boot
scp hermesa3-clone-v1-sanitized.tar.gz ubuntu@vm:~
ssh ubuntu@vm "tar xzf hermesa3-clone-v1-sanitized.tar.gz \
  && cp -a skills ~/.hermes/ && cp config.yaml ~/.hermes/"

# 5. Finalize
virsh shutdown hermes-clone
virt-sysprep -a hermes-clone.qcow2 --operations machine-id,ssh-userdir,logfiles
```

**Docker** (lightest, needs Docker on client):
```bash
FROM ubuntu:22.04
RUN curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
COPY skills/ ~/.hermes/skills/
COPY config.yaml ~/.hermes/config.yaml
COPY .env.template ~/.hermes/.env.template
CMD ["hermes"]
```

## Verification Checklist

```bash
# No personal data in skills
grep -rn 'your-username\|your-internal-domain\|your-ip-pattern' skills/ \
  | grep -v Binary || echo "✅ Clean"

# No API keys
grep -r 'sk-[a-zA-Z0-9]\{20,\}' skills/ | grep -v Binary || echo "✅ Clean"

# Skills loadable
hermes skills list | grep -c SKILL.md

# Hermes starts
hermes chat -q "你好"
```

## Client Delivery Instructions

Include a README that tells the client:

1. `cp .env.template .env` → fill in API keys
2. `hermes setup` → run the wizard
3. `hermes` → start using

Tell the client which skills are available and which data sources they need
to set up themselves (Gitea, git repos, etc.).

## Known Pitfalls

- **Config referral chains**: The original `config.yaml` may reference
  `delegation.provider: custom:deepseek-pro` which points to a custom provider
  defined in `.env` or the config itself. Templates must strip all provider
  references.
- **Linked files survive removal**: Deleting a skill's SKILL.md directory
  removes the references too — but if a reference file path is embedded in
  another skill's SKILL.md (e.g., `skill_view(name="tw-persona-db", ...)`),
  that cross-reference will dangle. Check cross-skill references before
  removing.
- **Skill metadata in frontmatter**: `author:` and `user:` fields in YAML
  frontmatter can contain real usernames. Strip or genericize these.
- **git-credentials store**: `~/.git-credentials` contains plaintext PATs,
  not just remote URLs. This must be cleaned independently of git config.
- **`.usage.json` retains old skill names**: The file `~/.hermes/skills/.usage.json`
  tracks skill metadata and contains skill names that may reference removed
  or renamed skills. Either regenerate it or exclude it from the deliverable,
  or the verify step will show false-positive name matches.
- **USER.md is the most sensitive file**: Employment status, personal
  relationships, income motivation, and negotiation strategies often live in
  `USER.md` — not in `MEMORY.md`. It is easy to overlook because the `memory`
  tool targets it separately (`target: "user"` vs `target: "memory"`). Always
  sanitize both files.
- **MEMORY.md / USER.md edit via write_file**: These are section-delimited
  plain-text files (entries separated by `§` on its own line). Use `write_file`
  to rewrite them entirely when doing bulk reorganization (moving entries
  between profiles). The `memory` tool only supports single-entry operations,
  so batch edits are faster via direct file writes.
- **cross_profile=True guard**: When writing to another profile's `memories/`
  directory from code tools, Hermes blocks the write with a cross-profile soft
  guard. After user confirmation, use `cross_profile=True` on `write_file`
  to bypass.
- **Profile skills diverge over time**: `hermes profile create --clone-from`
  copies skills at creation time but does NOT sync subsequent updates. If you
  update a skill in default, client profiles still have the old version.
  Either symlink skills or re-clone the profile.
