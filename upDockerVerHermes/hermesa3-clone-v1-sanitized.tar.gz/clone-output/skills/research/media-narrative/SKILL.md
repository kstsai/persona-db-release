---
name: media-analysis
description: "Taiwanese media narrative analysis — scrape 8+ news sites, detect silence gaps vs CNA baseline, generate comparison reports."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [media, taiwan, news, scraping, narrative, analysis, silence-matrix]
---

# Media Narrative Analysis (Taiwan)

Automated narrative-direction detection across Taiwanese media outlets.
Scrapes 8 media sources + CNA international baseline, builds a silence
matrix, and generates a Markdown comparison report.

## Trigger Conditions

Load this skill when the user asks to:
- "Run the media narrative report"
- "Produce a silence matrix / 沉默議題分析"
- "Compare coverage across Taiwanese media for date X"
- "Fix or update the eight-media scraper"

## Workflow

### 1. Run the Report

```bash
cd /home/hermes/project/hermesa3/mediawatch-reports

# Today
python3 _eight_media_report.py

# Specific date
python3 _eight_media_report.py --date 2026-07-07
```

Output:
- Terminal: color-coded summary with article counts
- Markdown report: `hermesa3/mediawatch-reports/eight-media-comparison-YYYY-MM-DD.md`

### 2. Interpreting the Report

The report has four sections:

| Section | What it shows |
|---------|--------------|
| 資料量總覽 | Article counts per outlet, ideological spectrum label |
| CNA 國際頭條 | Baseline international headlines (what "should" be covered) |
| 比對&沉默分析 | Which outlets covered each topic; which topics are silenced |
| 原始資料 | Raw article titles per outlet for manual inspection |

**Silence Matrix Logic:**
- CNA (Central News Agency) international headlines = the baseline
- Any CNA headline topic with 0 matches across all 8 domestic outlets = silence gap
- Deep silence = topic is absent across the entire ideological spectrum (both green and blue)

### 3. Known Scraper Patterns by Site

| Outlet | Type | Method | URL |
|--------|------|--------|-----|
| CNA (中央社) | Static HTML | Regex `<a>` patterns | `cna.com.tw/list/aopl.aspx` (intl), `aipl.aspx` (politics) |
| 自由時報 | Static HTML | Regex `<a>` patterns | `news.ltn.com.tw/list/breakingnews/politics` |
| 聯合報 | Static HTML | Regex `<a>` patterns | `udn.com/news/breaknews/1` |
| TVBS | **SPA (RSS)** | RSS XML parsing | `news.tvbs.com.tw/web_api/play_feed_new/politics` |
| ETtoday | Static HTML | Regex `<a>` patterns | `ettoday.net/news/politics` |
| 三立 | Static HTML | Regex `<a>` patterns | `setn.com/ViewAll.aspx?PageGroupID=6` |
| 中天 | **SPA (RSS)** | RSS XML parsing | `www.ctitv.com.tw/feed/` |
| 風傳媒 | **Nuxt SPA** | Homepage `<a><h3>` pattern | `storm.mg` (scrape homepage, not category page) |

### 4. Fixing Broken Scrapers

When a site returns 0 articles or garbage data:

**Step 1 — Check reachability with curl:**
```bash
curl -sL --max-time 10 -o /dev/null -w '%{http_code}' 'https://site.url'
```

**Step 2 — Inspect raw HTML for article link patterns:**
```bash
curl -sL 'https://site.url' | grep -oE 'href="[^"]*article[^"]*"' | head -10
```

**Step 3 — Check for RSS feed (most reliable for SPA sites):**
- Try `/feed`, `/rss`, `/feed/`, `/feed/xml/`
- For WordPress sites: `/wp-json/wp/v2/posts?categories=N&per_page=20`
- Parse with `xml.etree.ElementTree` (RSS 2.0: `channel > item > title, link`)

**Step 4 — For Nuxt/Vue SPAs (風傳媒):**
Raw HTML from curl won't have article links on category pages.
Instead scrape the homepage which has SSR-rendered `<a href="/article/N"><h3>TITLE</h3></a>`.

## Script Location

```
/home/hermes/project/hermesa3/mediawatch-reports/_eight_media_report.py
```

The script is self-contained: uses only `curl` + Python stdlib (no external
dependencies except `yaml` for the silence matrix).

## Pitfalls

- **SPA sites don't render in curl output** — catch this early by checking raw HTML size vs expected content. If a page returns <2000 bytes of real content, it's likely SPA.
- **RSS feeds change** — sites may change their RSS URL path without notice. If a feed returns 404, try the homepage or sitemap.
- **Duplicates** — some sites (ETtoday, 三立) return the same article URL under multiple CSS classes. Use a `seen` set keyed on title text (not URL, since URLs may differ) to dedup.
- **Date parameter bug** — the script's static title string says "7/6" regardless of `--date`. This is cosmetic in the terminal output; the file path and markdown heading use the correct date.
- **Run from the script's directory** — the script uses relative output paths. `cd hermesa3/mediawatch-reports/` first, or pass the full path.
