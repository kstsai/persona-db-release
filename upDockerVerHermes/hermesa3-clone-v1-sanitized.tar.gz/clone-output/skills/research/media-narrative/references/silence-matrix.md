# Silence Matrix Methodology

## Core Concept

Use **CNA (Central News Agency)** international headlines as the baseline
for what news *exists* in the world, then check which of those topics are
**silenced** (zero coverage) across domestic Taiwanese media.

CNA is Taiwan's official news agency — it reports international news
factually without the ideological framing that colors domestic outlets.

## Detection Logic

```
CNA international headlines (today)
    ↓
Extract top 10 headlines
    ↓
For each headline, search all 8 domestic outlets for keyword matches
    ↓
Matrix: outlet × topic → covered / silenced
    ↓
Identify:
  - Partial silence: topic covered by only 1-2 outlets
  - Deep silence: topic covered by 0 outlets across the spectrum
  - Spectrum gap: topic covered only by green/blue outlets
```

## What Silence Means

| Silence Type | Signal |
|-------------|--------|
| **Deep silence** (all outlets silent) | Topic is actively avoided by the entire Taiwanese media ecosystem |
| **Green-side coverage only** | Topic serves the DPP/pro-green narrative |
| **Blue-side coverage only** | Topic serves the KMT/pro-blue narrative |
| **All coverage, same frame** | Groupthink / unified narrative |

## Historical Silences Observed

| Date | Silent Topic | Notes |
|------|-------------|-------|
| 2026-07-02 | 美伊戰爭/油價影響 | Both LTN and UDN silent |
| 2026-07-02 | 資金外逃新加坡 | UDN covered, LTN silent |
| 2026-07-06 | 美軍對伊朗開火 | 0/8 domestic outlets covered |
| 2026-07-06 | 荷莫茲海峽油輪遇襲 | 0/8 (4 straight CNA stories) |
| 2026-07-06 | 哈米尼國葬反美情緒 | 0/8 |
| 2026-07-07 | 美軍對伊朗攻勢 | Only UDN (1/8) |

## Script Implementation

In `_eight_media_report.py`, the silence check works at keyword level:

```python
KEYWORDS = {
    "以哈衝突": ["以色列","哈瑪斯","加薩"],
    "中東局勢": ["伊朗","沙烏地","中東"],
    "美中關係": ["美中","中國","拜登","川普"],
    ...
}

for topic, kws in KEYWORDS.items():
    if any(kw in cna_text for kw in kws):
        # CNA covered this — now check domestic outlets
        for outlet, articles in domestic_results.items():
            outlet_text = " ".join(a["title"] for a in articles)
            if not any(kw in outlet_text for kw in kws):
                mark_silent(outlet, topic)
```
