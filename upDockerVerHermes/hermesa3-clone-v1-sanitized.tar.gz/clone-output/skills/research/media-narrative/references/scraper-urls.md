# Scraper URL Reference — Taiwanese Media

## 8 Media Sources

| # | Outlet | Ideology | URL | Scrape Method |
|---|--------|----------|-----|--------------|
| 1 | 中央社國際 CNA Intl | Baseline | `https://www.cna.com.tw/list/aopl.aspx` | Regex `<a>` |
| 2 | 中央社政治 CNA Politics | Official | `https://www.cna.com.tw/list/aipl.aspx` | Regex `<a>` |
| 3 | 自由時報 Liberty Times | Green (偏綠) | `https://news.ltn.com.tw/list/breakingnews/politics` | Regex `<a>` |
| 4 | 聯合報 UDN | Balanced | `https://udn.com/news/breaknews/1` | Regex `<a>` |
| 5 | TVBS | Leans Green | `https://news.tvbs.com.tw/web_api/play_feed_new/politics` | **RSS XML** |
| 6 | ETtoday | Neutral | `https://www.ettoday.net/news/politics` | Regex `<a>` |
| 7 | 三立 SETN | Green (偏綠) | `https://www.setn.com/ViewAll.aspx?PageGroupID=6` | Regex `<a>` |
| 8 | 中天 CTI | Blue (偏藍) | `https://www.ctitv.com.tw/feed/` | **RSS XML** |
| 9 | 風傳媒 Storm.mg | Blue/Commentary | `https://www.storm.mg` (homepage) | **Nuxt `<a><h3>` pattern** |

## RSS Feed URLs (for SPA sites)

| Site | RSS URL | Format |
|------|---------|--------|
| TVBS politics | `https://news.tvbs.com.tw/web_api/play_feed_new/politics` | RSS 2.0 XML |
| 中天 (all) | `https://www.ctitv.com.tw/feed/` | RSS 2.0 XML |

## Regex Patterns

### Pattern 1: `<a href="URL" title="TITLE">`
```
<a[^>]*href="([^"]*URL_PATTERN[^"]*)"[^>]*title="([^"]*)"
```

### Pattern 2: `<a href="URL">TEXT</a>`
```
<a[^>]*href="([^"]*URL_PATTERN[^"]*)"[^>]*>([^<]{10,})</a>
```

### Pattern 3 (風傳媒 Nuxt): `<a href="/article/N"><h3>TITLE</h3></a>`
```
<a[^>]*href="(/article/\d+)"[^>]*>.*?<h3[^>]*>(.*?)</h3>
```

## RSS XML Parsing (Python)

```python
import xml.etree.ElementTree as ET

def extract_rss_titles(xml_text):
    articles = []
    root = ET.fromstring(xml_text)
    for item in root.iter("item"):
        title_el = item.find("title")
        link_el = item.find("link")
        if title_el is not None and link_el is not None:
            t = title_el.text.strip() if title_el.text else ""
            if t and len(t) > 6:
                articles.append((t[:65], link_el.text.strip()))
    return articles
```
