---
name: cross-media-narrative
description: "Cross-media narrative comparison: scrape multiple news outlets, detect silence, label persona/narrative manipulation, produce data-driven comparison reports."
version: 1.6.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [media, narrative, silence-detection, news-analysis, taiwan, journalism]
    related_skills: [git-workflow, deep-reading-analysis]
  user:
    kstsai:
      report_format:
        sections:
          - data_volume_and_crawl_method
          - media_narrative_characteristics
          - shared_topic_framing
          - silence_matrix
          - key_insights
---

# Cross-Media Narrative Comparison

Analyze how multiple news outlets frame the same events, detect silence patterns, and identify persona/narrative manipulation — without judging truth, only mapping intended impressions.

## Core Methodology

### Philosophy
- **Media is an impression-engineering tool**, not just a public watchdog
- **AI's role**: not judging right/wrong, but truthfully listing what impression each report wants you to have
- Apply the **same label system to all outlets** — no assumed fairness ranking
- **Silence is also a stance** — what an outlet doesn't report is as informative as what it does

### Analysis Dimensions

| Dimension | Question | Output |
|-----------|----------|--------|
| **Persona engineering** | What image of each person does this outlet create/destroy? | 😇→🗑️→⚠️→😐→🔇 |
| **Narrative steering** | What does this outlet want readers to believe about each event? | 🔴→🟢→🟡→🔵→⚪ |
| **Media spectrum** | What is this outlet's stable editorial leaning? | 偏綠/偏藍/中性/聚合 |
| **Silence matrix** | What is collectively ignored vs. covered by each outlet? | Table of issues × outlets |

## Report Format (User Preferred — Final) — 十家媒體敘事比對沉默議題偵測報告

When producing a cross-media comparison report, use this exact section numbering and content:

### §1 — 資料量與爬取方式 (Data Volume & Crawl Method)

Table with columns: Media, Article Count, Spectrum Label, Crawl Method, Full-Text Retrieved.

Also include a **transparency/notes row** per outlet with ⚠️ prefix when there are limitations (e.g. "RSS 僅輸出業配稿，非全站", "聚合平台，含多家媒體來源", "當日量偏少").

End with a data-integrity paragraph explaining any caveats about RSS vs full-site, aggregator nature, etc.

### §2 — 人物提及頻率 (Person Frequency — COLLAPSED, marked 可跳過)

Wrap the entire table in `<details><summary>📊 人物提及頻率（全內文 Top 15，可跳過）</summary>`. The user considers this section skippable but wants it available collapsed, not omitted entirely.

Columns: Person (人物) | 自由 | 聯合 | TVBS | ETto | 三立 | 中天 | 風媒 | 合計

### §3 — 各媒體敘事特徵 (Media Narrative Characteristics)

For each outlet: **one concise Chinese sentence** (e.g. "大量，偏綠", "少量，平衡", "聚合平台，涵蓋最多來源") then:
- **關鍵詞**: Top 3 persons + top 2 terms from full-text analysis
- **最突出詞彙**: The single most dominant term with count (e.g. "中共（58次）")
- **⚠️ notes** for any outlet-specific limitations

### §4 — 共同議題框架比對 (Shared Topic Framing Comparison)

Auto-detect topics by matching keyword patterns across all outlet headlines. Only show topics covered by 2+ outlets. **⚠️ False positive risk**: common keywords (e.g. "中共") may match unrelated articles. See `references/keyword-false-positives.md` for patterns and mitigation.

**⚠️ Auto-detector keyword gap (obs. 2026-07-12)**: The topic_keywords dictionary in `_eight_media_report.py` is static. Topics whose keywords aren't in the dictionary (e.g. "巴丹群島" missing keyword "巴丹") get silently dropped even when 2+ outlets cover them. After §4 auto-detection, manually scan article headlines for high-signal topics that appear in 2+ outlets but have no auto-detected entry. Add these as `### 補充議題：<topic>` sections with the note "⚠️ 自動偵測漏報". Format:

```
### 補充議題：<topic>（<outlet> N 篇、<outlet> N 篇）— ⚠️ 自動偵測漏報

| 媒體 | 篇數標題 | 前期框架 |
|:----:|:---------|:--------|
| **<outlet>** | <headline>… | <label> |
| **<outlet>** | ❌ 沉默 | ⚪ 沉默 |
```

**⚠️ Single-source blindspot**: Topics covered by only 1 outlet are silently dropped by the 2-source filter. This can hide important issues that only reach the public via an aggregator (e.g., Yahoo). After auto-detection, manually scan for high-signal single-source topics (especially on Yahoo) and add a `### 補充議題：<topic>` section with a note like "⚠️ 僅 Yahoo 報導，其餘沉默" instead of the standard ❌ silence table. See `references/single-source-blindspot.md` for examples.

Table per topic: columns = Media | 篇數標題 (title snippet + …) | 前期框架 (label).

Use "🟡 待判讀" as placeholder for auto-generated reports; **after deep reading (§7-8), update these placeholders to actual frame labels** (🟢事實/中性 🔴批判/威脅 ⚪沉默 🔵正面).

### §5 — 沉默議題矩陣 (Silence Matrix)

Columns: CNA國際頭條 (headline snippet + …) | 自由 | 聯合 | TVBS | ETtoday | 三立 | 中天 | 風媒 | Yahoo

Use ✅ / ❌ based on character-overlap detection between CNA headline and each outlet's article titles.

### §6 — 關鍵洞察 (Key Insights)

Auto-generate 3-6 numbered items from the data:
- International silence count ("CNA 頭條 X 篇中 Y 篇國內未報導")
- Largest-volume outlet
- Spectrum extremes

### §7 — 深度閱讀分析 (Deep Reading Analysis — optional, from cron)

When running as a cron job with deep reading, insert this section after §6. Use the **deep-reading-analysis** skill's batch workflow (§6 of that skill). Structure:

Select top 3-5 shared topics from §4. For each topic, pick 1 article from 2 outlets at opposite ends of the spectrum. Analyze each with the 5 dimensions (narrative characteristics, author viewpoint, emotional stance, reader emotion targeting, cross-media comparison).

#### Single-Source Deep Reading (補充議題專用)

For **single-source topics** (e.g., supplement topics that only Yahoo covers), the 2-outlet comparison pattern does not apply. See `references/supplement-topic-patterns-2026-07-12.md` for concrete examples of auto-detector keyword gaps, single-source blindspots, Yahoo source labeling, same-spectrum comparison headers, and single-origin analysis.

#### Comparing Same-Spectrum Outlets

In addition to cross-spectrum comparison, also **compare outlets on the same side of the spectrum** when they cover the same topic differently. For example, two 偏綠 media may use different strategies (one 國安上綱, the other 跨陣營理性包裝) to reach the same conclusion. This reveals the range of narrative manipulation tools available within one editorial camp.

### §8 — 敘事立場矩陣總表 (Narrative Stance Matrix — optional)

After deep reading, produce a summary matrix:

| 議題/人物 | 自由 | 聯合 | TVBS | ETtoday | 三立 | 中天 | 風媒 | Yahoo |
|:---------|:----:|:----:|:----:|:-------:|:----:|:----:|:------:|:-----:|
| Topic A | 🔴 | 🟢 | 🟢 | 🟢 | 🔴 | ⚪ | ⚪ | 🟡 |
| Person X | 🗑️ | — | 😇 | — | 🗑️ | — | — | 😇 |

Label legend: 🟢正面/中性 🔴批判/威脅 🟡待判讀 ⚪沉默 😇建構 🗑️毀滅 😐中性

### §9 — 原始資料 (Raw Data)

List all article titles per outlet (first 10 per outlet).

### Do NOT include
- Prose-heavy narrative analysis without tables
- Judgments about "truth" or "fake news"
- Full un-collapsed person frequency tables (keep §2 hidden behind `<details>`)

## Scraping Architecture — 10 Sources Total

### Source Inventory

| # | Outlet | Spectrum | Type | Method | Articles/Day | Full-Text |
|---|--------|----------|------|--------|:-----------:|:---------:|
| 1 | 自由時報 | 偏綠 | News | curl + regex list page | ~10 | ✅ |
| 2 | 聯合報 | 平衡 | News | curl + regex list page | ~3 | ✅ |
| 3 | TVBS | 中性偏綠 | News | RSS feed (`web_api/play_feed_new/politics`) | ~7 | ✅ |
| 4 | ETtoday | 中性 | News | curl + regex list page | ~30 | ✅ |
| 5 | 三立 | 偏綠 | News | curl + regex list page (`PageGroupID=6`) | ~20 | ✅ |
| 6 | 中天 | 偏藍 | News | RSS feed (`ctitv.com.tw/feed/`) | ~10 | ✅ |
| 7 | 風傳媒 | 偏藍/評論 | News/Opinion | curl + `<a><h3>` homepage pattern | ~20 | ✅ |
| 8 | Yahoo新聞 | 聚合/綜合 | Aggregator | RSS feed (`tw.news.yahoo.com/rss/politics`) | ~30 | ✅ |
| 9 | LINE NEWS | 聚合/綜合 | Aggregator | curl + SSR h3 extraction | ~12 | ❌ (titles only) |
| 10 | CNA | 官方通訊社 | Wire | curl + regex list page | ~10 | baseline |

### Source Types

| Type | Approach | Python Function | Examples |
|------|----------|----------------|---------|
| RSS feed | XML parsing | `extract_rss_titles()` | TVBS, 中天, Yahoo News |
| HTML list page | regex `<a href>` patterns | `extract_titles()` | 自由時報, 聯合報, ETtoday, 三立 |
| SPA homepage | `<a><h3>` pattern extraction | custom regex | 風傳媒 |
| SSR h3 | `<h3 class="header">` extraction | custom regex | LINE NEWS |

### Full-Text Pipeline

```python
# 1. Strip nav/header/footer HTML
html = re.sub(r'<(script|style|nav|header|footer)[^>]*>.*?</\1>', '', html, flags=re.DOTALL|re.I)

# 2. Strip all tags
text = re.sub(r'<[^>]+>', '\n', html)

# 3. Filter short lines (navigation remnants)
lines = [l.strip() for l in text.split('\n') if len(l.strip()) > 15]

# 4. Remove known nav keywords
lines = [l for l in lines if not any(kw in l.lower() for kw in NAV_KEYWORDS)]
```

### Persona/Narrative Labeling (v1 — keyword-based)

```python
DESTROY_KEYWORDS = ["雙標","打臉","造假","翻車","裝瞎","護航","蓋牌","無能","甩鍋"]
BUILD_KEYWORDS = ["肯定","讚","力挺","有功","貢獻","表率","突破"]
QUESTION_KEYWORDS = ["質疑","呼籲","要求","批","轟","酸","應說明"]

def label_persona(context, person_name):
    """😇→🗑️→⚠️→😐 based on keyword scores around person mentions."""
    # destroy > build → 🗑️; build > destroy → 😇; question found → ⚠️; else → 😐
```

## Repo Structure

Two repos involved:

### 1. `lab-riscv` (private) — gitea + GitHub
Primary working repo. Contains everything (infra, RISC-V, kubeEdge, ai-agents).
- Git workflow: `pull origin → push gitea → commit → push gitea → push origin`
- Reports live in `hermesa3/mediawatch/`
- Skills/backup live in `ai-agents/hermesa3/skills/`
- Daily cron sources `_eight_media_report.py` from here

### 2. `media-narrative` (public) — GitHub + Pages
Public snapshot of `hermesa3/` content only. GitHub Pages: `https://kstsai.github.io/media-narrative/`
- Synced manually from `lab-riscv/hermesa3/` → `media-narrative/`
- Contains `mediawatch/`, `persona/`, skills/, INDEX.md
- No sensitive data (credentials, IPs, infra configs)

## Daily Cron

Scheduled at UTC 10:00 (Taiwan 18:00) via `hermes cron`. Runs `~/.hermes/scripts/daily-mediawatch.sh` which:
1. `git pull origin main` (sync from GitHub)
2. `python3 _eight_media_report.py --date $(date +%Y-%m-%d)`
3. (optional) Perform batch deep reading on top shared topics
4. `git commit` and push to gitea + GitHub

## Deep Reading Analysis (Qualitative)

Beyond the automated data report, this skill supports deep reading analysis using the **deep-reading-analysis** skill. When used as part of the daily cron, apply the **batch deep reading workflow** (see deep-reading-analysis skill §6).

> *"What does this article want me to feel and believe?"*

### When to Use

- User explicitly asks "read this article and analyze it"
- As a supplement to the daily automated report — pick 3-5 shared topics from §4, 2 outlets each
- Cron pipeline: automated report → deep reading → updated labels → narrative stance matrix

### Batch Workflow Summary (Two Modes)

#### Mode A — Self-performed (default, cron-compatible)

1. Run the automated report, identify top shared topics from §4
2. For each topic, select 2 outlets at opposite ends of the spectrum
3. Fetch articles via `web_extract` (batch 5 URLs per call). **⚠️ Verify Yahoo URLs before fetching**: Yahoo RSS produces shortened URLs that may 404 when fetched. Always use the full URL from the RSS `<link>` element (not the shortened redirect). If a TVBS/中天 article from RSS returns insufficient content, try `browser_navigate` as fallback. **Cron mode**: To extract article URLs from the cached JSON, use `terminal` with inline Python — `python3 -c "import json; data=json.load(open('...')); [print(a['url']) for a in data['自由時報']]"`. Do NOT use `execute_code` (blocked in cron mode).
4. Analyze each article across the 5 dimensions (deep-reading-analysis skill)
5. Update §4 placeholder labels with actual frame labels
6. Produce the narrative stance matrix (§8)
7. Update the report file and commit. **Cron mode**: Since `execute_code` is blocked for cron jobs, write a Python script (via `write_file`) that uses `report.replace()` to update §4 labels, insert §7 sections, and append §8 matrix. Run the script with `python3 script.py`, then remove it. Do NOT attempt to use `execute_code` for this.

#### Mode B — Subagent-delegated (recommended when user requests deep reading interactively)

Use `delegate_task` to offload the full deep-reading pipeline to a background subagent (which uses the configured delegation model, e.g. deepseek-v4-pro). This keeps the parent session responsive and lets the subagent do the file-update work directly.

**Pre-requisites:**
- Run the automated report first (has the cached JSON with article URLs)
- Pre-fetch articles via `web_extract` (pass full text in context — subagents cannot call web_extract)

**Procedure:**
1. Read the cached JSON at `/home/ubuntu/.hermes/cache/media_deep/all_media_raw_<date>.json` to find article URLs for all 🟡 待判讀 items in §4
2. **Prioritize manually-flagged supplement topics** (§4 補充議題) — these are single-source topics with high public importance that the auto-detector missed
3. Fetch each article via `web_extract` (batch up to 5 URLs per call)
4. Dispatch one `delegate_task` with `goal` + `context` containing:
   - All article titles, URLs, and fetched full text
   - The current report file path and its §4/§6/§7/§8 structure
   - The exact 5-dimension analysis format
   - The label system reference (🟢🔴🟡⚪😇🗑️😐)
   - **Single-source topics**: note that internal cross-source comparison replaces the 2-outlet pattern; include instruction to compare different original sources within the same aggregator
   - Instruction to use `patch` tool to edit the report file directly: replace 🟡 labels in §4, append new §7 sections, update §8 matrix, expand §6 insights
4. Do NOT wait or poll — the subagent returns a summary; verify file changes by reading the updated report

**⚠️ Pitfalls:**
- The subagent gets a summary of article content (from web_extract), not the raw page. Include enough text for meaningful 5-dimension analysis.
- The subagent inherits the delegation model. It cannot call `clarify` or `delegate_task` — make instructions fully self-contained.
- The subagent can call `read_file` and `patch` for file operations; use `patch` to edit specific sections, not `write_file`.
- For single-source topics (e.g. Yahoo-only stories), the 2-outlet comparison pattern does not apply. Include all articles from the single source and note the limitation.

### Genre-Awareness Rule

Different article types manipulate differently — adjust analysis accordingly:

| Genre | Manipulation Mode | Danger Level |
|-------|------------------|:------------:|
| **Hard news** (純引述) | Hides bias in **who gets to speak** | 🔴 Highest — pretends to be objective |
| **Spot news** (現場報導) | Hides bias in **photo selection + opening sentence** | 🟡 Medium |
| **Commentary** (評論專欄) | Openly declares stance | 🟢 Lowest — reader knows it's opinion |
| **Aggregator** (Yahoo/LINE) | Manipulation via **what they choose to aggregate** | 🟡 Medium |

### Key Insight for the User

The user's statement: **「我有情緒，所以無法清楚判斷作者的情緒，或是作者的操弄意圖。」**
This is the entire project's raison d'être. The AI's value is not being smarter than humans — it's having **no ego to defend, no party to support, no emotional stake in the outcome.**

## Key Pitfalls

1. **RSS vs site content mismatch**: 中天 RSS outputs mostly advertorials, not political attack content. Always note in §1. Consider using browser/web_extract for 中天 specifically if political analysis is needed.
2. **SPA sites**: Yahoo and 風傳媒 need browser or RSS workaround for headlines. LINE NEWS is SSR — use `<h3>` extraction.
3. **Full-text noise**: ~80% navigation boilerplate. Aggressive strip may lose body text near nav elements.
4. **Yahoo is an aggregator**: RSS contains articles from 民視/中天/風傳媒/etc. Value is cross-source visibility, not original reporting.
5. **LINE NEWS is titles-only**: No full-text fetch possible.
6. **Label accuracy (v1)**: Keyword-based persona labels are imprecise. "起訴" in a neutral report may trigger 🗑️ falsely. Document as known limitation.
7. **Cron timing**: UTC 10:00 (Taiwan 18:00) captures most daily content but may miss evening-breaking stories.
8. **Rebase + gitea force-push**: After `git pull --rebase origin main`, use `git push --force-with-lease gitea main`. Never force-push to GitHub.
9. **Label drift**: Automated keyword-based persona labels from §2 (人物提及頻率) may disagree with manual deep-reading labels from §7-8. Manual assessment always wins. Note discrepancies in §6 insights when they occur.

10. **Keyword-topic false positives in §4**: The `topic_keywords` dictionary matches by simple substring overlap, which creates false positives when an overlapping word (e.g. "中共") triggers a topic match on an unrelated article. Observed 2026-07-10: "巨浪三/中共飛彈" matched a 自由時報 article about 矢板明夫 ("遭中共掐脖子") and a Yahoo article about 網攻 — neither was about missiles. **Mitigation**: After auto-detection, manually verify each matched article actually belongs to the topic. When defining topics, lead with specific non-overlapping keywords (e.g. "巨浪三" alone, not "中共").

11. **Automated persona labels skew toward 😇 (all-😇 problem)**: Build keywords (肯定, 讚, 貢獻, 成功, 突破) are common in neutral reporting ("他表示肯定", "做出貢獻"), so the system produces 😇 for nearly every detected person. Observed 2026-07-10: every person across all outlets was labeled 😇 by the scraper, while manual deep reading found 🗑️ for 川普 (風傳媒) and 盧秀燕 (三立). **Mitigation**: Add a §6 insight noting "automated persona labels are all 😇 — see §7-8 for manual assessment". Consider raising the build threshold or requiring per-paragraph context isolation in v2.

12. **`execute_code` blocked in cron mode**: The `execute_code` tool is blocked for cron jobs (it runs arbitrary local Python). When you need to parse JSON, extract URLs, or do data manipulation during a cron run, use `terminal` with inline Python instead: `python3 -c "import json; ..."` or `python3 << 'EOF' ... EOF`. This applies to the whole Daily Cron pipeline — any post-processing step that would use `execute_code` must switch to `terminal`+inline-Python.

13. **§4 single-source blindspot (obs. 2026-07-11)**: The auto-detector requires 2+ outlets covering a topic before it appears in §4. Topics covered by only 1 outlet (especially an aggregator like Yahoo that carries 3+ articles on the topic) are silently invisible. Observed 2026-07-11: 毒油/致癌油 had 3 articles on Yahoo but 0 elsewhere — dropped from §4 entirely. **Mitigation**: After reviewing §4 auto-detected topics, also scan for high-volume topics on Yahoo/LINE that were dropped. Add a `### 補充議題：<topic>` section and note the single-source coverage pattern.

14. **Subagent-delegated deep reading requires article pre-fetching**: The subagent cannot use `web_extract` or `browser_navigate`. You must fetch all pending articles first, then pass the full text in the `delegate_task` context. For long articles, include the head+tail windows from web_extract. The subagent CAN use `read_file` and `patch` to update the report — instruct it to do so rather than returning plain text for the parent to apply.

15. **聚合平台（Yahoo）的內部框架分裂（obs. 2026-07-11）**：Yahoo 作為聚合平台，同一議題的 3 篇報導可能來自 3 個不同原始來源（如信傳媒、中天、聯合報），各自使用完全不同的框架——故事化/服務報導/政治衝突。讀者在 Yahoo 上看到同一個議題時，無法獲得統一的認知。**若僅針對「Yahoo」給一個框架標籤（如 🟢），會嚴重失真**。改進方式：在 §4 和 §8 的 Yahoo 欄位加上來源名稱（如「Yahoo（信傳媒）」），並在 §7 內部跨來源比較。

16. **偏綠媒體的雙重批判策略（obs. 2026-07-11）**：面對同一在野議題（如 6 大公投），偏綠媒體可能採用不同策略——自由時報直接上綱到國安層次（「配合中國亂台灣」），而三立則以「跨陣營理性批判者」（柯文哲）來包裝相同結論。兩種策略導向相同立場，但讀者感受不同：前者觸發恐懼與憤怒，後者賦予智力優越感。**深度閱讀時應比較同光譜內媒體的策略差異，而非僅跨光譜比對**。

17. **§8 人物矩陣需要有上下文的單平台條目**：當一個人物只出現在單一媒體/單一文章時，其標籤需附帶上下文說明（如「😐故事化（新型董事出事）」、「🗑️毀滅（藍營報導中）」），而非僅給一個標籤符號。這在 §8 人物矩陣的「—」（未出現）和標籤之間需要第三種狀態——「出現但僅限單一文章」。2026-07-11 新增的吳星澄、劉偉龍、石崇良、張宏林、柯文哲條目皆屬此類。

18. **跨陣營人物的反常定位**：當一篇報導選擇讓敵對陣營的人物發言（如三立偏綠媒體報導柯文哲觀點）時，該人物在該報導中可能被建構為與其日常媒體形象不同的角色（如柯文哲在三立被建構為「理性批判者」而非日常的「謊言者」）。這通常是為了增加報導的公信力外觀（「連柯文哲都這麼說，可見這是真的」）。深度閱讀時應特別注意此類反常定位。

19. **§4 keyword gap ≠ single-source blindspot (obs. 2026-07-12, confirmed 2026-07-13)**: The `topic_keywords` dictionary in `_eight_media_report.py` is static and finite. Topics whose keywords aren't in the dictionary get silently dropped even when **2+ outlets** cover them (e.g. 2026-07-12: "巴丹群島" missing keyword "巴丹"; 2026-07-13: "佀廣洋" missing keyword "佀廣洋"). This is **not** the same problem as the single-source blindspot (#13), because keyword gaps affect topics with multiple outlets. **Mitigation**: After scanning §4 auto-detected topics, also scan headlines for name entities (person names, place names, unique terms) that appear in 2+ outlets but don't match any topic_keywords entry. Add as `### 補充議題` with "⚠️ 自動偵測漏報" note. See `references/supplement-topic-patterns-2026-07-12.md` for concrete patterns.

## Quick Start

```bash
# Run for today (automated only)
cd ~/mediawatch
python3 _eight_media_report.py --date $(date +%Y-%m-%d)

# Run for a specific date
python3 _eight_media_report.py --date 2026-07-07

# Full pipeline with deep reading:
# 1. Run the scraper → read §4 for shared topics
# 2. Fetch articles for top 3-5 topics × 2 outlets each
# 3. Perform batch deep reading (see deep-reading-analysis §6)
# 4. Update §4 labels + produce narrative stance matrix
# 5. Save updated report and commit
```
