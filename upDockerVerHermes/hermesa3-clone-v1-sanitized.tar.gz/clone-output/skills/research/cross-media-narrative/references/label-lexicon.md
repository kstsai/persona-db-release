# Persona & Narrative Label Lexicon

## Build (😇) — 正面建立

肯定, 讚, 力挺, 有功, 貢獻, 表率, 突破,
成功, 佳績, 進步, 創新高, 親民, 溫暖,
團結, 捍衛, 保護, 承諾, 落實

## Destroy (🗑️) — 負面毀滅

雙標, 打臉, 造假, 翻車, 裝瞎, 裝天真,
大雷包, 何不食肉糜, 護航, 邪惡, 可恥,
騙, 謊, 黑心, 包庇, 蓋牌, 無能,
甩鍋, 卸責, 傲慢, 酬庸, 派系, 門神

## Question (⚠️) — 質疑監督

質疑, 呼籲, 要求, 批, 轟, 酸, 怒,
應說明, 待釐清, 引發討論, 爭議

## Blame (🔴) — 攻擊歸責

應負責, 咎責, 究責, 懲處, 下台,
道歉, 打臉, 說謊, 隱瞞

## Factual (🟢) — 事實報導

公布, 宣布, 指出, 說明, 表示, 確認,
報告, 數據, 統計, 調查

## Label Logic (Python)

```python
DESTROY_KEYWORDS = ["雙標","打臉","造假","翻車","裝瞎","裝天真",
    "大雷包","何不食肉糜","護航","邪惡","可恥",
    "騙","謊","黑心","包庇","蓋牌","無能",
    "甩鍋","卸責","傲慢","酬庸","派系","門神"]
BUILD_KEYWORDS = ["肯定","讚","力挺","有功","貢獻","表率","突破",
    "成功","佳績","進步","創新高","親民","溫暖",
    "團結","捍衛","保護","承諾","落實"]
QUESTION_KEYWORDS = ["質疑","呼籲","要求","批","轟","酸","怒",
    "應說明","待釐清","引發討論","爭議"]

def label_persona(text, person_name, title=""):
    context = (title + " " + text).lower()
    destroy_score = sum(1 for kw in DESTROY_KEYWORDS if kw in context)
    build_score = sum(1 for kw in BUILD_KEYWORDS if kw in context)
    question_score = sum(1 for kw in QUESTION_KEYWORDS if kw in context)
    if destroy_score > build_score and destroy_score > 0:
        return "🗑️"
    if build_score > destroy_score and build_score > 0:
        return "😇"
    if question_score > 0:
        return "⚠️"
    return "😐"
```

## Media Spectrum Mapping (10 Sources)

| # | Outlet | Spectrum | Type | Notes |
|---|--------|----------|------|-------|
| 1 | 自由時報 | 偏綠 | News | Attack KMT figures; silences KMT-harming stories |
| 2 | 三立 | 偏綠 | News | Corporate/political blame mixed; "中聯" brand attack |
| 3 | TVBS | 中性偏綠 | News | Balanced, diverse topics; avoids witch-hunt framing |
| 4 | 聯合報 | 平衡 | News | Factual, some international; lowest volume |
| 5 | ETtoday | 中性 | News | Click-driven; ~20% politics, rest is weather/entertainment |
| 6 | 中天 | 偏藍 | News | RSS shows only advertorials; on-site has attack content |
| 7 | 風傳媒 | 偏藍/評論 | Commentary | Heavy US/China focus; opinion/analysis > news |
| 8 | Yahoo新聞 | 聚合/綜合 | Aggregator | Aggregates all sources; unique multi-source view |
| 9 | LINE NEWS | 聚合/綜合 | Aggregator | Lifestyle/social mix; titles only, no original reporting |
| 10 | 中央社 | 官方通訊社 | Wire | Neutral baseline for international coverage |
