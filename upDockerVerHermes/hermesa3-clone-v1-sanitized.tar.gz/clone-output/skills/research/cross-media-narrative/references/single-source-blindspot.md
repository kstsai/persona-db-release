# §4 Single-Source Blindspot

> Topics covered by only 1 outlet are silently dropped by the 2-source filter in §4 auto-detection.
> Updated: 2026-07-11

## The Problem

The `_eight_media_report.py` script only shows topics covered by 2+ outlets (`if len(sources_covered) < 2: continue`). This means important issues that only reach the public through one channel are invisible in the report.

## Observed Case: 2026-07-11 — 毒油/致癌油

Yahoo published 3 articles on this topic (cooking oil contamination scandal):
- 「中聯癌油》福懋油吳星澄才當董事長3個月出事 劉偉龍接手泰山才3年…」
- 「拿空桶也能退！政院公布致癌油退貨2機制 全面擴大下架…」
- 「毒油再爆 藍質疑擠牙膏公布 批石崇良烏賊戰…」

No other outlet covered it substantially that day. The topic keywords matched all 3 articles, but the <2-source filter dropped the topic entirely.

## Which Outlets Produce Single-Source Topics

| Outlet | Risk | Reason |
|:-------|:----:|:-------|
| **Yahoo** | 🔴 High | Aggregator picks up stories no domestic outlet chose to cover |
| **LINE NEWS** | 🟡 Medium | Titles-only, hard to verify, but may surface unique topics |
| **風傳媒** | 🟡 Medium | Many translated/foreign-policy articles with no domestic parallel |
| **中天** | 🟢 Low | RSS is advertorial-only, not useful for political topicality |

## Mitigation Workflow

1. After reviewing §4 auto-detected topics (`sources_covered >= 2`), run a **manual scan** of Yahoo's articles for high-volume unique topics
2. Look for topics where Yahoo has 3+ articles and no other outlet covers them
3. Add a `### 補充議題：<topic>` section formatted as:

```
### 補充議題：毒油/致癌油（⚠️ 僅 Yahoo 報導）

| 媒體 | 篇數標題 | 前期框架 |
|:----:|:---------|:--------|
| **自由時報** | ❌ 沉默 | ⚪ 沉默 |
| ... | ... | ... |
| **Yahoo新聞** | 中聯癌油》福懋油吳星澄才當董事長3個月出事… | 🟡 待判讀 |
| **Yahoo新聞** | 拿空桶也能退！政院公布致癌油退貨2機制… | 🟡 待判讀 |
```

4. Add a §6 insight noting the single-source pattern, e.g. "毒油案僅 Yahoo 報導，其餘 7 家國內媒體全沉默"

## False-Negative Detection: Known Gaps in Topic Keywords

| Topic | Title Pattern | Keywords That Should Fire | Why It Might Miss |
|:------|:-------------|:-------------------------|:------------------|
| 毒油/致癌油 | 「中聯癌油」／「致癌油退貨」 | 中聯, 致癌, 毒油 | Fire correctly — issue is the <2 filter, not keywords |
| 食安風暴 | 「食安風暴擴大！南僑、泰山、福壽全遭重罰」 | — | No keywords for "food safety scandal" as a topic |
