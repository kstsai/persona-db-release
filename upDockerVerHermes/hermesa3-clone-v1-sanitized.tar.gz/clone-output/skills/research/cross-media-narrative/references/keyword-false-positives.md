# Keyword-Topic False Positives in §4 Auto-Detection

> Observed patterns of the `topic_keywords` dictionary matching unrelated articles.
> Updated: 2026-07-13

## The Problem

The `_eight_media_report.py` script auto-detects shared topics (§4) by checking whether any keyword from a predefined set appears in each article's title. This is fast but produces false positives when:

1. A keyword is common across news domains (e.g. "中共" appears in 矢板明夫 articles, 中共網攻 articles, and 巨浪三飛彈 articles)
2. A topic label includes an overlapping word from another topic
3. Negated or quoted keywords match literally

## Observed Case: 2026-07-10

```
Topic: "巨浪三/中共飛彈"
  Matched: 自由時報 "遭中共「掐脖子」"  [about 矢板明夫, not missiles]
  Matched: Yahoo "中共若犯台「第一步」非登陸"  [about 網攻, not missiles]
```

Both articles contained "中共" which triggered the topic match. Neither article mentioned missiles or 巨浪三.

## Recurrence: 2026-07-13 — Same Topic, Wider False Positive Spread

Same topic "巨浪三/中共飛彈" (keywords: 巨浪, 飛彈, 中共) produced two more false positives:

```
Matched: 自由時報 "北京重心轉向！中共黨校學者：「民族團結法」旨在對抗西方意識形態"
         [about China's ethnic unity law, not missiles — matched via "中共"]
Matched: ETtoday "美12枚飛彈轟波灣最大島　伊朗報復襲擊5國"
         [about US-Iran conflict, not China missiles — matched via "飛彈"]
```

The 自由時報 article was about China's new 民族團結進步促進法 with zero mention of missiles. The ETtoday article was about US airstrikes on Iran's Qeshm Island. Neither belonged in the 巨浪三 topic.

## Recurrence Frequency Table

| Date | Topic | False Positives | Trigger |
|:----:|:------|:---------------:|:--------|
| 2026-07-10 | 巨浪三/中共飛彈 | 2/3 matched (66%) | 中共 |
| 2026-07-13 | 巨浪三/中共飛彈 | 2/5 matched (40%) | 中共 + 飛彈 |

**Lesson**: Any topic keyword that is a common noun (中共, 飛彈, 美國, 軍方) rather than a named entity (巨浪三, 矢板明夫, 中聯油) will produce ~40-66% false positives. Mitigation #1 (unique identifiers) is critical for these topics.

## Detection Pattern

| Topic Label | Keywords | Common Overlap Words | False Positive Risk |
|:------------|:---------|:---------------------|:-------------------:|
| 巨浪三/中共飛彈 | 巨浪, 飛彈, 中共 | 中共 (shared with many topics) | 🔴 High |
| 矢板明夫/跨境鎮壓 | 矢板, 明夫, 跨境, 鎮壓 | — | 🟢 Low (names are unique) |
| 毒油/致癌油 | 毒油, 致癌, 中聯, 苯駢芘 | 中聯 (company name, usually unique) | 🟢 Low |
| 巴威颱風 | 巴威, 颱風 | 颱風 (appears in non-巴威 contexts) | 🟡 Medium |
| 美軍/伊朗 | 美軍, 伊朗, 空襲, 荷莫茲 | 美軍 (shared with US-China topics) | 🟡 Medium |
| 黃國昌/光電 | 黃國昌, 光電, 門神, 賴勁麟 | 光電 (appears in energy policy too) | 🟡 Medium |

## Mitigation

1. **Lead with unique identifiers**: For "巨浪三/中共飛彈", the primary keyword should be "巨浪三" or "巨浪" — not "中共" which is too generic.
2. **AND logic required**: Ideally require BOTH "巨浪" AND ("飛彈" OR "中共") to fire, not any single keyword.
3. **Manual verification**: After auto-detection, verify each matched article belongs to the topic before including in §4 or selecting for deep reading (§7).
4. **False positive rate**: Estimate ~20-30% of auto-detected topics may have at least one false positive match. Budget time for verification.
