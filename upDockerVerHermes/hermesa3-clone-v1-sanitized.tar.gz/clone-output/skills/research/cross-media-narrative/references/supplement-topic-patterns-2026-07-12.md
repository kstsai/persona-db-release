# Supplement Topic Patterns (obs. 2026-07-12, updated 2026-07-13)

## Pattern 6: Keyword Gap + Yahoo Internal Frame Splitting Combo

Used when a topic is covered by 2+ outlets but the keyword dictionary misses it (keyword gap), AND Yahoo carries multiple articles from different original sources with contradictory frames (frame splitting).

**2026-07-13 Example**: 佀廣洋逃兵爭議 — 三立 had 2 articles (same content), Yahoo carried 3 articles from 3 different original sources (鏡傳媒, 中時, 桃園電子報). The keyword "佀廣洋" wasn't in topic_keywords.

**Format**: Standard supplement topic table, but with Yahoo source labels per row:

```
### 補充議題：佀廣洋逃兵爭議（三立 2 篇、Yahoo 3 篇）— ⚠️ 自動偵測漏報

> 佀廣洋為桃園市議員參選人，涉及逃兵/霸凌爭議。因關鍵詞字典未收錄「佀廣洋」而被漏報。
> Yahoo 的 3 篇來自 3 個不同原始來源，各自使用不同框架。

| 媒體 | 篇數標題 | 前期框架 |
|:----:|:---------|:--------|
| **三立** | 遭傳「跟佀廣洋有關係」！王浩宇4字親曝交集… | 🟢 事實澄清 |
| **Yahoo（鏡傳媒）** | （影）疑逃兵爭議持續延燒 她秀佀廣洋玩樂影片嗆… | 🗑️ 毀滅批判 |
| **Yahoo（中時）** | 霸凌爭議持續延燒！傳藍出手勸佀廣洋退選… | 🗑️ 毀滅批判 |
| **Yahoo（桃園電子報）** | 致電勸退佀廣洋選市議員？桃園市黨部駁斥… | 🟢 事實澄清 |
| **其餘 5 家** | ❌ 沉默 | ⚪ 沉默 |
```

**§8 matrix handling**: Use "🗑️/🟢混雜（3來源）" for the Yahoo column, and note the specific original sources in a footnote.

**Deep reading note**: Unlike standard 2-outlet cross-media comparison, this pattern requires **internal cross-source comparison within Yahoo**. The analytical finding is not just the frame divergence within a single platform, but also which sources choose which frame — here, 鏡傳媒 and 中時 (traditionally anti-green) both used 🗑️ destruction framing, while 桃園電子報 (local/neutral) used 🟢 clarification framing.

Concrete patterns produced for supplement topics and same-spectrum comparisons in the 2026-07-12 report.

## Pattern 1: Auto-Detector Keyword Gap (2+ outlets, missed by dictionary)

Used when a topic is covered by 2+ outlets but the static `topic_keywords` dict in `_eight_media_report.py` doesn't contain the relevant keywords.

**Example**: 巴丹群島/資訊操弄 — both 自由時報 (2 articles) and Yahoo (2 articles, reposting 自由) covered it, but keyword "巴丹" wasn't in topic_keywords.

```
### 補充議題：巴丹群島／資訊操弄（自由時報 2 篇、Yahoo 2 篇）— ⚠️ 自動偵測漏報

> 簡短說明為何被漏報，以及涵蓋情況。

| 媒體 | 篇數標題 | 前期框架 |
|:----:|:---------|:--------|
| **自由時報** | <headline>… | 🔴批判/威脅框架 |
| **聯合報** | ❌ 沉默 | ⚪ 沉默 |
| **TVBS** | ❌ 沉默 | ⚪ 沉默 |
| ... | ... | ... |
| **Yahoo新聞** | <headline>… | 🔴批判/威脅框架（自由來源） |
```

## Pattern 2: Single-Source Blindspot (only Yahoo covers it)

Used when a major international story is only covered by Yahoo.

**Example**: 伊朗/荷姆茲海峽 — CNA had 7 headlines about US-Iran conflict; only Yahoo reported it. 風傳媒's article was a historical column (false positive).

```
### 補充議題：伊朗／荷姆茲海峽（僅 Yahoo 報導，其餘沉默）⚠️ 單一來源盲點

CNA 國際頭條有 7 篇關於此議題，僅 Yahoo 實際報導當前時事。風傳媒的相關條目為歷史專欄（⚠️ 假陽性）。

| 媒體 | 篇數標題 | 前期框架 |
|:----:|:---------|:--------|
| **自由時報** | ❌ 沉默 | ⚪ 沉默 |
| ... | ... | ... |
| **Yahoo新聞** | <headline>… | 🟢事實/中性報導 |
```

## Pattern 3: Yahoo Source Labeling in Aggregated Topics

When Yahoo carries multiple articles on the same topic from different original sources, append the source name in parentheses after the frame label.

**Example**: 巴威颱風 on Yahoo had articles from both 聯合報 (🟢) and 三立 (🔴).

| 媒體 | 篇數標題 | 前期框架 |
|:----:|:---------|:--------|
| **Yahoo新聞** | 巴威颱風遠離… | 🟢事實/中性報導（聯合報來源） |
| **Yahoo新聞** | 蔣萬安放颱風準備假… | 🔴批判/威脅框架（三立來源） |

In the §8 stance matrix, use "🟢/🔴混雜" for the Yahoo column when contradictory frames exist.

## Pattern 4: Same-Spectrum Comparison Header

Used when both outlets in a topic are on the same editorial side (e.g. both 自由時報 and 三立 are 偏綠).

**Example**: 矢板明夫/跨境鎮壓 — both 自由 and 三立 used 🔴批判 but with different strategies.

```
### 議題 N：<topic>（N 媒體報導 — 同光譜內部比較）
```

In the comparison table, add a "策略差異" dimension:

| 維度 | 自由時報（偏綠） | 三立（偏綠） |
|:----|:----------------:|:------------:|
| **主框架** | 🔴 國安層次上綱 | 🔴 國安層次 + 事件行銷 |
| **寫作類型** | 單純引述 + 臉書全文 | 引述摘要 + 直播預告 CTA |
| **策略差異** | 嚴肅國安論述，理性包裝 | 情緒驅動 + 參與式行銷 |
| **危險等級** | 🔴高 | 🔴高（加一層參與操弄） |

## Pattern 5: Single-Origin Deep Reading (no internal contrast)

When a supplement topic has only one original source (e.g. 自由時報独家 + Yahoo repost), there is no internal contrast. State the finding explicitly.

**Example**: 巴丹群島/資訊操弄 — all articles trace back to 自由時報 (記者蘇永耀 + 國安人士).

```
**⚠️ 單一來源盲點評估**：本議題全部報導溯源於單一來源（<original outlet>）。Yahoo 僅為聚合轉載。其他 7 家媒體完全沉默。這意味著此重大議題在台灣媒體中僅由偏綠/偏藍的 <outlet> 獨家報導。
```
