# Chunk 5 (179 personas, TW-P-0717–TW-P-0895) — Full Sanity Analysis

## Overview

Chunk 5 covers personas from TW-P-0717 through TW-P-0895, spanning all age groups (0-11 through 65+). Primary demographics: senior females (65+ 家管), working-age adults (19-54 in 科技/服務/製造), and minors (0-18 students).

## Methodology

10 mechanical checks executed on all 179 records, then classified via semantic judgment:

| Category | Count | Description |
|:---------|:-----:|:------------|
| **REAL** | 31 | Genuine contradictions |
| **OK** | 137 | Explainable (by design or context) |
| **MINOR** | 5 | Editorial/word-choice issues |
| **Total flagged** | **173** | (6 clean w/ no findings across all 10 checks) |

## Key Patterns

### Pattern A: fs=1 + "夫妻兩人生活" (systematic data-entry error) — 4 cases, REAL

All four involve married seniors with `family_size=1` but background_story explicitly describing cohabitation:

| ID | Name | Age | Background Story Excerpt |
|:---|:-----|:---:|:------------------------|
| TW-P-0736 | 阿鳳 | 65+ | 「孩子在外地，**夫妻兩人生活**。經濟上要很精打細算。」 |
| TW-P-0739 | 金花嬸 | 65+ | 「孩子在外地，**夫妻兩人生活**。最近物價漲得很有感，日子更緊了。」 |
| TW-P-0828 | 國華 | 55-64 | 「孩子在外地，**夫妻兩人生活**。手頭還算寬鬆，不用太省。」 |
| TW-P-0838 | 柳伯 | 65+ | 「孩子在外地，**夫妻兩人生活**。最近物價漲得很有感，日子更緊了。」 |

**Root cause**: The `family_size` dimension field says "1" (single-person household) but the background_story template pool for "married with adult children" always renders as "夫妻兩人生活". This is a **dimension vs narrative mismatch**, not a narrative-internal contradiction.

**This differs from chunk 3/4 patterns**: In chunks 3/4, the dominant issue was economic tone mismatch (bg comfortable → pf tight). Here, the dominant issue is structural (dimension field vs narrative text).

### Pattern B: Income vs economic tone BG/PF mismatch (6 cases, REAL)

| ID | Name | Income | BG says | PF says |
|:---|:-----|:------:|:--------|:--------|
| TW-P-0762 | 阿明 | <3萬 | 生活品質還不錯 | 收入不高，要省着點 |
| TW-P-0845 | 阿鳳 | <3萬 | 經濟上滿寬裕的 | 收入不高，還是要省着點 |
| TW-P-0879 | 若希 | 無收入 | 生活品質還不錯 | (same as bg) |
| TW-P-0890 | 艾倫 | <3萬 | 生活品質還不錯 | 要省着點 |
| TW-P-0892 | 艾倫 | <3萬 | 經濟上滿寬裕的 | 要省着點 |
| TW-P-0894 | 柔伊 | <3萬 | 手頭還算寬鬆，不用太省 | 要省着點 |

**Pattern**: Background_story uses an optimistic template pool, but prompt_prefix's `gen_econ_context()` appends a pessimistic sentence based on actual income. The two code paths aren't cross-validated.

### Pattern C: Cross-segment economic tone mismatch (16 cases, REAL)

Same as Pattern B but both bg AND pf contain contradictory economic language. Example: bg says "手頭還算寬鬆，不用太省", pf appends "在新竹市這個收入不太夠用，物價太高了". 

Cases: 小白(0771), 米亞(0778), 莉亞(0782), 小奈(0783), 正雄(0791), 建宏(0808), 國華(0823), 金蓮(0833), 秀美(0836), 素蘭嬸(0847), and a few overlapping with Pattern B.

### Pattern D: Married + fs=1 no spouse mention (1 case, REAL)

| ID | Name | Detail |
|:---|:-----|:-------|
| TW-P-0779 | 若希 | Married 25-34, fs=1, bg says "新婚但暫時分居" — no spouse mention in narrative |

This is borderline — bg explains the living situation (分居) but doesn't name the spouse. Unlike the 24 other married+fs=1 cases which all mention 配偶/夫妻 explicitly.

## False Positive Patterns Encountered (During Analysis Iteration)

These are patterns the mechanical checker initially flagged but were reclassified as OK after semantic review:

### FP1: "不夠用" matching "房間不夠用"

The keyword "不夠用" triggers financial-tightness detection, but "房間不夠用" means "not enough room space" (a housing constraint), not "not enough money". Example:

- **大衛(TW-P-0873)**: BG="家裡熱鬧，但**房間不夠用**。經濟上滿寬裕的。"
  - Mechanical check: "不夠用" → tight keyword match → false positive
  - Semantic: "房間不夠用" is about space, "經濟上滿寬裕的" is about money — no contradiction

**Fix**: Exclude "房間不夠用" and "空間不夠" from financial-keyword matching.

### FP2: "小孩" within "沒有生小孩的打算"

7 cases (怡君0801, 雅芳0818, 木火0822, 國華0823, 秀琴0830, 月鳳0834, 阿鳳0845) all have:
```
bg: "結婚後沒有生小孩的打算。..."
pf: "結婚後沒有生小孩的打算。..."
```

The mechanical checker matched `"沒有生小孩" in bg AND "小孩" in pf` — but the "小孩" in pf is within the identical "沒有生小孩" negation. No contradiction exists.

**Fix**: When checking for "沒有生小孩" contradictions, verify that "小孩"/"孩子" in pf appears **outside** the negation context. Simplest check: `if "沒有生小孩" in pf: skip`.

### FP3: "一個人住" ≠ "單身/未婚"

10 cases (秀姨0735, 玉嬸0740, 米亞0784, 文彬0793, 美惠0794, 靜怡0797, 建宏0804, 金水0826, 萬伯0837, 麗媽0852) all have:
```
bg: "配偶在外地工作，**自己一個人住**。..."
```

Mechanical check: regex `(單身|未婚|一個人)` matches "一個人" → declares contradiction with spouse mention.

**Semantic**: "一個人住" (living alone) is a housing arrangement, not a marital status. A married person can live alone when their spouse works elsewhere. This is a common, reasonable situation in Taiwan (跨縣市工作).

**Fix**: Separate "一個人住"(housing) from "單身"(marital status) in checks. Use `re.search(r'單身|未婚', text)` not `re.search(r'單身|未婚|一個人', text)` when checking marital-status contradictions.

## MINOR Findings (5)

| ID | Name | Issue |
|:---|:-----|:------|
| TW-P-0725 | 金花嬸 | 65+ uses「小孩」to refer to adult children (should be「子女」) |
| TW-P-0726 | 素蘭嬸 | Same —「小孩」for adult children |
| TW-P-0839 | 茂伯 | Same —「小孩」for adult children |
| TW-P-0845 | 阿鳳 | Same —「小孩」for adult children |
| TW-P-0852 | 麗媽 | Uses「小孩」but in 含飴弄孫 context (grandchildren) — borderline acceptable |

All MINOR findings share the same root cause: template pools for 65+ personas still use youth-oriented family language ("小孩" instead of "子女"/"兒女").

## Cross-Chunk Comparison

| Pattern | Chunk 3 | Chunk 4 | Chunk 5 | Chunk 6 |
|:--------|:-------:|:-------:|:-------:|:-------:|
| Economic tone mismatch (bg→pf) | 13 | ~15 | 16 | 23 |
| fs=1 + cohabitation narrative | rare | rare | 4 (systematic) | rare |
| 65+ 小孩/子女 confusion | present | present | 5 | present |
| 已婚+fs=1+no spouse | present | present | 1 | present |

**Chunk 5 is the first chunk where the structural fs=1+夫妻兩人 problem appears systematically** (4 cases, all 65+ married seniors). This may be concentrated in the generation sweep that produced these specific IDs.

## Scripts

Final analysis script: `~/persona-db/check_chunk5_final.py`

Intermediate versions:
- `check_chunk5.py` — V1: pure keyword matching (many false positives)
- `check_chunk5_v2.py` — V2: financial-keyword exclusion, semantic classification
- `check_chunk5_final.py` — V3: complete semantic judgment with all FP patterns handled
