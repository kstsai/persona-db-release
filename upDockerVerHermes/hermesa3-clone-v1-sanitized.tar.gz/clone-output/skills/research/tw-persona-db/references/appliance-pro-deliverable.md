# TW Persona DB — Standard vs Pro 交付對照（歷史文件）

> 本文件是 2026-07-13 商業模式討論過程中產出的內部比對文件。
> 最終決議已簡化為單一 Transfer 方案（NT$60K-80K，含全部 tool）。
> 保留此文件供參考 — 7 項警告及合約條款大綱仍適用。

---

## 7 項警告（仍適用於 Transfer 方案）

### ⚠️ 警告 1：重新生成 ≠ 品質保證
每一次 regenerate，品質退回 v1.5 水準。每個 bug fix 寫在 QA 規則和 iteration 經驗裡，不是 code 邏輯。

### ⚠️ 警告 2：QA 20 條只擋已知的坑
可能會踩到第 21 個。如果發現新 pattern → 回報給本尊加 R21。

### ⚠️ 警告 3：不建議修改 generate 核心邏輯
機率表、城市加成、模板池、coherence 邏輯互相關聯。動任何一個都有蝴蝶效應。

### ⚠️ 警告 4：每次 regenerate 結果不同
seed=42 固定才 reproducible。改 seed 或 TARGET → 名字和故事不同（分布一致）。

### ⚠️ 警告 5：自改版本無法 merge 官方 release
保留 `tw_persona_1069_custom.json` 為備份。官方 release 覆蓋標準檔。

### ⚠️ 警告 6：generate script 不可轉售
授權僅限內部產品開發。不可轉售、再授權、或作為獨立產品販售。

### ⚠️ 警告 7：Transfer 是買工具，不是買服務
疊新維度、新國家版本、domain 擴充 → 類心理師方案 NT$3K/hr。

---

## 建議契約條款大綱

```
1. 授權標的：1069 筆資料 + 查詢工具 + 生成引擎 + QA 工具 + 文件 + skill
2. 授權範圍：
   2.1 可用於內部產品開發及商業用途
   2.2 可自行 regenerate persona 資料
   2.3 可修改生成參數供內部使用
   2.4 可販售自行改進後的 1069.json
   2.5 不可將生成引擎及其組成部分轉售或再授權予第三方
3. 品質責任：自行 regenerated 的資料品質由客戶自行驗證
4. 後續服務：minor bug fix 含在價內；新功能/domain 疊加/major upgrade → NT$3K/hr
5. 價格：NT$60,000-80,000 一次付清
```
