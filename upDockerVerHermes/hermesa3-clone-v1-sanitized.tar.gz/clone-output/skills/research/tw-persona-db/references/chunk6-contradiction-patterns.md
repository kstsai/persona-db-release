# Chunk 6 Contradiction Patterns (174 Personas)

Analyzed 2026-07-11. 28/174 (16.1%) had at least one logical contradiction requiring repair.

## Summary

| Category | Count | Root Cause |
|----------|-------|------------|
| Background says comfortable → prefix says tight | 23 | Template pool mismatch — bg uses optimistic pool (寬裕/積蓄/品質不錯) but `gen_econ_context()` appends "收入不高，還是要省着點" |
| Background says tight → prefix says comfortable | 4 | Reverse — bg uses tight pool (手頭緊/入不敷出/存不了錢) but `gen_econ_context()` appends "收入還不錯，不用太省" |
| family_size=1 but bg says "夫妻兩人生活" | 1 | Data model inconsistency — married person with family_size=1 but bg describes cohabitation |

## Detailed Pattern Catalogue

### Pattern A: 「經濟上滿寬裕的」→「收入不高，在XX縣還是要省着點」 (17 instances)

The dominant contradiction. Background_story uses the optimistic template pool (「經濟上滿寬裕的」「手頭還算寬鬆」「有些積蓄」「生活品質還不錯，該花的會花」) while prompt_prefix's `gen_econ_context()` appends a poverty sentence based on the `income` dimension value.

Key examples:
- **TW-P-0901 明義**: inc=`<3萬` — bg: "經濟上滿寬裕的" → pre: "收入不高，在雲林縣還是要省着點"
- **TW-P-0925 雅芳**: inc=`<3萬` — bg: "經濟上滿寬裕的" → pre: "收入不高，在雲林縣還是要省着點"
- **TW-P-0934 永昌**: inc=`<3萬` — bg: "經濟上滿寬裕的" → pre: "收入不高，在南投縣還是要省着點"
- **TW-P-0946 秀美**: inc=`<3萬` + fam_inc=`<1萬` — bg: "經濟上滿寬裕的" → pre: "收入不高，在彰化縣還是要省着點"
- **TW-P-0961 月嬸**: inc=`<3萬` — bg: "經濟上滿寬裕的" → pre: "收入不高，在南投縣還是要省着點"

All 17 share the same structure: `background_story` generated from an optimistic template that ignores the `income` dimension, while `gen_econ_context()` reads `income` correctly and appends a conflicting sentence.

**Root cause confirmed**: Same as [chunk3-contradiction-patterns.md](chunk3-contradiction-patterns.md) Pattern B. The `econ_by_tier()` helper inside `infer_background()` defaults to `inc_level="3-8萬"` when the caller doesn't pass `inc` explicitly (Variable Scoping Trap documented in SKILL.md).

### Pattern B: 「月底常常手頭緊」→「收入還不錯，不用太省」 (4 instances)

Reverse of Pattern A — background_story describes financial stress but prefix says comfortable.

| ID | Name | inc | bg signal | pre signal |
|----|------|-----|-----------|------------|
| TW-P-0898 | 俊傑 | 3-8萬 | 月底常常手頭緊 | 在彰化縣這個收入還不錯，不用太省 |
| TW-P-0984 | 小胖 | 3-8萬 | 伙食費佔了開銷的大半 | 在屏東縣這個收入還不錯，不用太省 |
| TW-P-1031 | 玉嬸 | 3-8萬 | 月底常常手頭緊 | 在屏東縣這個收入還不錯，不用太省 |
| TW-P-1063 | 雅雯 | 3-8萬 | 常常入不敷出 | 在連江縣這個收入還不錯，不用太省 |

For 3-8萬 income in low-cost cities, `gen_econ_context()` generates a positive sentence ("收入還不錯"), but bg says the opposite. Either the bg should be fixed to match the comfortable reality, or the income is actually insufficient despite the city's low prices.

**Note**: The 3-8萬 income range is a wide bracket (30K-80K NTD/month). Someone earning 30K in any city will feel tight; someone earning 80K in a low-cost city will feel comfortable. The issue is that the income dimension doesn't distinguish the sub-level, so bg templates and econ context may disagree about what "3-8萬" implies.

### Pattern C: 背景說積蓄但經濟觀點矛盾 (5 instances)

Background says "有些積蓄，偶爾會出國玩" but prefix says "收入不高，還是要省着點":

| ID | Name | inc | bg | pre |
|----|------|-----|----|-----|
| TW-P-0927 | 惠如 | <3萬 | 有些積蓄，偶爾會出國玩 | 收入不高，在南投縣還是要省着點 |
| TW-P-0986 | 小奈 | <3萬 | 有些積蓄，偶爾會出國玩 | 收入不高，在嘉義縣還是要省着點 |
| TW-P-0998 | 怡君 | <3萬 | 有些積蓄，偶爾會出國玩 | 收入不高，在嘉義縣還是要省着點 |
| TW-P-1006 | 建宏 | <3萬 | 有些積蓄，偶爾會出國玩 | 收入不高，在嘉義縣還是要省着點 |

This is the same "savings + travel" template abuse documented in chunk 3 Pattern A. The phrase appears indiscriminately even when income is `<3萬`.

### Pattern D: family_size=1 but bg says couple living together (1 instance)

**TW-P-0961 月嬸**: `married=已婚` + `family_size=1` + bg="孩子在外地，**夫妻兩人生活**。經濟上滿寬裕的。"

If the couple is living together ("夫妻兩人生活"), family_size should be 2, not 1. The `family_size` generation doesn't account for married couples who cohabitate.

Other `married=已婚` + `family_size=1` cases (17 total) are all explained by separation (配偶在外地工作/分居/配偶長期在國外), so they are consistent.

## Cross-Reference with Chunk 3

| Pattern | Chunk 3 (179) | Chunk 6 (174) | Trend |
|---------|---------------|---------------|-------|
| bg comfortable → pre tight | 13 | 23 | **Worse** |
| bg tight → pre comfortable | 9 | 4 | Better |
| Income mismatch (single) | 4 | 0 | Fixed |
| Family income vs family size | ~12 | 0 | Fixed |
| Occupation template mismatch | 1 | 0 | Fixed |

The economic tone contradiction (Pattern A) has gotten WORSE in chunk 6 — likely because more personas in chunk 6 have income=`<3萬` (lower-income demographics), so `gen_econ_context()` fires the "省着點" sentence more often, while the background_story template pool hasn't been updated to match.

## Verification Script

```bash
python3 ~/persona-db/scripts/verify_economic_tone.py
```

This script accepts a chunk file path and checks all economic tone patterns. Set `CHUNK_PATH` environment variable or edit the default in the script.
