# 112-Stratified Sample Analysis — 2026-07-11

## Context

This analysis was performed as a **hybrid QA iteration**: a Python script (`sample_stratified.py`) extracted 112 stratified samples (1 per region×age×sex combo), then a sub-agent (`delegate_task`) analyzed all 112 for naturalness, coherence, and distribution anomalies.

The sub-agent ran on model `deepseek-v4-flash` (inherited from parent session). Total duration: ~2.5min for 112 entries.

## Prompt Template for Sub-Agent Review

When spawning a sub-agent for persona sample analysis, use this exact structure:

```
Goal: 分析 N 個台灣人設樣本的自然度與合理性
Context: (file path, description of 15 dimensions, dual prompt format)

Ask the sub-agent to check 3 categories:
### A. 🟡 分布異常
- occupation × age (0-11/12-18 can't work; 65+ can't be 學生)
- marriage × age (0-18 must be 未婚; 19-24 學生 can't 離婚)
- income × age/occupation (students must be 無收入)
- media_diet × age (0-11 no 社群為主)
- family_size × age (0-18 no 一人)
- education × age (0-18 should be 國中以下/高中)
- family_income × family_size (5+ can't be <1萬)

### B. 🔴 內容不合理
- political_stance mismatch with age/occupation/income
- hobby × age appropriateness (0-11 泡茶/登山/廣場舞?)
- prompt_prefix naturalness (census-form language?)
- background_story coherence across 3 sentence groups

### C. 🔴 語言自然度
- Template placeholder residuals (%s, etc.)
- "65+歲" code residue instead of "六十多歲"
- Occupation phrasing: "做退休" / "做學生" ungrammatical?
- Location redundancy between prompt_prefix and background_story
```

## Findings Summary

| Category | Count | Severity |
|----------|-------|----------|
| 「65+歲」 code residue in prompt_prefix | 14/112 | 🔴 |
| 「做退休/做學生」 ungrammatical | 7/112 | 🔴 |
| 【】 bracket template (machine-read format) | 26/112 | 🔴 |
| Location redundancy (background_story ends with "住在XX") | ~33/112 | 🟡 |
| 「獨生子」 used for female personas | 3/112 | 🔴 |
| 55+ elderly assigned 「新婚不久」 | 3/112 | 🔴 |
| 0-11 with income instead of 無收入 | 1/112 | 🟡 |
| 12-18 with 服務 occupation + 大學 education | 1/112 | 🟡 |
| 0-11/12-18 with 泡茶 hobby | 2/112 | 🟡 |

## Root Causes Traced

### Issue 1: 「65+歲」 code residue
**Root cause**: `_generate_997.py` Template B (first-person) concatenates `dimensions.age` literally. Template A correctly passes age through `age_desc()`, but Template B does not.

Generation snippet (Template B):
```python
# Template B: f"我叫{name}，{age}歲，住{region}，做{occupation}"
# Here {age} = "65+" → output: "我叫柏伯，65+歲，住北北基，做退休"
```

Template A uses `age_desc(age)` which handles 65+ → "長者" or similar. Template B needs the same treatment.

### Issue 2: 「做退休 / 做學生」
**Root cause**: The word "做" (to work as) is grammatically incompatible with non-work occupations:
- 退休 → "already retired" (已經退休/退休了)
- 學生 → "still a student" (還是學生/還在讀書)
- 家管 → "takes care of the home" (在家照顧家庭/家管)

Fix: occupation-specific verb mapping in Template B:
```python
OCC_VERB = {
    "退休": "已經退休",
    "學生": "還是學生",
    "家管": "在家當家管",
    # default: f"做{occupation}"
}
```

### Issue 3: 「獨生子」 for female personas
**Root cause**: HH_ONLY_CHILD phrase pool only has "獨生子，爸媽的寶" which assumes male sex. No female variant exists.

Fix: Add "獨生女，爸媽的寶" to the pool, or switch to gender-neutral "家裡唯一的孩子" (already exists in other pools).

### Issue 4: 55+ elderly 「新婚不久」
**Root cause**: The LIFE_STAGE phrase pool includes "新婚不久" without age gating. The pool is shared across all age groups.

Fix: Gate "新婚不久" to age ≤ 54. For 55+ recently married scenarios, use "晚年再婚" or simply skip the life-stage tag.

### Issue 5: Location redundancy
**Root cause**: Each of the 3 background story groups (household, economics, life_stage) independently appends "住在{region}地區" as a generic ending. When prompt_prefix already states the location, this is redundant.

Fix: Remove location suffix from background groups when it's already in prompt_prefix. Or only append location once (in life_stage group only).

### Issue 6: 【】Template C format
**Root cause**: Template C was designed for "concise reference" but the syntax "【名字】age/region/occ。" reads as a structured data record, not a natural language prompt prefix.

Fix: Either reduce Template C probability from 25% to ≤10%, or add conversational framing like "這是{name}，{age}歲，住{region}，職業是{occ}。"

## Verification Methodology

To reproduce this analysis:
```bash
cd ~/persona-db

# Step 1: Extract stratified sample
python3 sample_stratified.py

# Step 2: Run regression QA
python3 qa_validate.py

# Step 3: Spawn sub-agent (via delegate_task)
# Provide the full prompt template above as 'goal'
# Provide file path + dimension description as 'context'

# Step 4: Verify each sub-agent finding against raw JSON
python3 -c "
import json
with open('tw_persona_112_stratified.json') as f:
    data = json.load(f)
# Verify claim X by searching ...
"
```

## Pitfalls

- **Sub-agent false positives**: Sub-agents flag gender-ambiguous 0-11/12-18 names as "mismatch" because they lack knowledge of the name pool design (cute reduplicated names are intentionally gender-neutral). Always verify against the actual name pool definitions before acting.
- **Sub-agent misses subtle issues**: The sub-agent found surface-level pattern issues (65+歲, 做退休) but did NOT detect the root cause chain connecting them. The agent's value is pattern discovery, not root cause analysis.
- **Sampling bias**: 112 samples cover every combo only once. Issues affecting only specific occupation×age combos (e.g., 12-18+服務) may appear only once and could be dismissed as edge cases. Check the full 997 for prevalence.
