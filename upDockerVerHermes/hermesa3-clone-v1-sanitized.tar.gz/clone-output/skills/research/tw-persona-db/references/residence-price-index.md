# Residence Price Index — Taiwan Cities & Counties

Source: 行政院主計總處 113年度 (2024) 平均每人月消費支出

## Full Data (sorted descending)

| City/County | Monthly Consumption (NTD) | vs National Avg | Tier |
|:------------|-------------------------:|:---------------:|:----:|
| 台北市 | 34,952 | 131% | 🔴 高 |
| 新竹縣 | 30,014 | 113% | 🔴 高 |
| 新竹市 | 29,722 | 112% | 🟡 中高 |
| 台中市 | 28,754 | 108% | 🟡 中高 |
| 新北市 | 27,557 | 103% | 🟡 中高 |
| 嘉義市 | 27,255 | 102% | 🟡 中高 |
| 高雄市 | 26,722 | 100% | 🟢 中 |
| 桃園市 | 25,718 | 97% | 🟢 中 |
| 基隆市 | 24,022 | 90% | 🟢 中 |
| 宜蘭縣 | 23,935 | 90% | 🔵 低 |
| 台南市 | 23,036 | 86% | 🔵 低 |
| 屏東縣 | 22,241 | 83% | 🔵 低 |
| 苗栗縣 | 22,019 | 83% | 🔵 低 |
| 花蓮縣 | 21,969 | 82% | 🔵 低 |
| 嘉義縣 | 21,473 | 81% | 🔵 低 |
| 金門縣 | ~21,000 | ~79% | ⚪ 極低 |
| 雲林縣 | 20,411 | 77% | ⚪ 極低 |
| 彰化縣 | 20,323 | 76% | ⚪ 極低 |
| 澎湖縣 | 20,188 | 76% | ⚪ 極低 |
| 連江縣 | ~19,500 | ~73% | ⚪ 極低 |
| 台東縣 | 19,402 | 73% | ⚪ 極低 |
| 南投縣 | 19,180 | 72% | ⚪ 極低 |

**National average**: 26,640 NTD/month

## Tier Classification

| Tier | Threshold | Cities |
|:----|:----------|:-------|
| 🔴 高 | >112% of avg | 台北市, 新竹縣 |
| 🟡 中高 | 102-112% | 新竹市, 台中市, 新北市, 嘉義市 |
| 🟢 中 | 90-102% | 高雄市, 桃園市, 基隆市 |
| 🔵 低 | 80-90% | 宜蘭縣, 台南市, 屏東縣, 苗栗縣, 花蓮縣, 嘉義縣 |
| ⚪ 極低 | <80% | 金門縣, 雲林縣, 彰化縣, 澎湖縣, 連江縣, 台東縣, 南投縣 |

**Key insight**: 台北市(34,952) vs 南投縣(19,180) = **1.82x gap**. Same nominal income means very different real standard of living.

## Usage in Persona DB

### Current (planned v3.2):
- Each persona gets a `price_tier` metadata field based on residence
- Economic phrase pools (`ECON_TIGHT_BIGFAM`, `ECON_COMFORTABLE`, etc.) have selection weights adjusted by tier
- Example: 台北市 + 3-8萬 income → higher chance of `ECON_STRESSED` phrases
- Example: 南投縣 + 3-8萬 income → higher chance of `ECON_COMFORTABLE` phrases
