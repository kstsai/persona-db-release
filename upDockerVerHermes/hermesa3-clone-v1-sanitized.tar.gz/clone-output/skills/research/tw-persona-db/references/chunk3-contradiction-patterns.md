# Chunk 3 Contradiction Patterns (179 Personas)

Analyzed 2026-07-11. 45/179 (25.1%) had at least one logical contradiction.

## Summary

| Category | Count | Root Cause |
|----------|-------|------------|
| Background says comfortable → prefix says tight | 13 | Template pool mismatch (generator A vs B) |
| Background says tight → prefix says comfortable | 9 | Template pool mismatch |
| Personal income ≠ family income (single living alone) | 4 | Dimension-level inconsistency |
| Family income too low for family size + optimistic bg | ~12 | Cross-validation gap |
| Occupation=家管 but bg mentions job position | 1 | Wrong template applied |

## Detailed Pattern Catalogue

### Pattern A: 「有些積蓄，偶爾會出國玩」→「收入不太夠用」
The most common single contradiction. Background uses the "savings + travel" template from the optimistic pool, while prefix's `gen_econ_context()` always appends the pessimistic city formula. Affects 5+ personas in chunk 3 across 新北市, 台中市, 台北市.

### Pattern B: 「經濟上滿寬裕的」→「收入低，生活壓力很大」
Affects personas where income is genuinely low (<3萬) but background_story was generated from the wrong template pool. The income dimension is correct in dimensions but the background template didn't read it.

### Pattern C: 「經濟壓力非常大」→「收入算很高了，日子過得滿舒服的」
Reverse of Pattern B — background picks "huge pressure" template but the prefix correctly sees high income (>8萬) + low cost city (台南市) and generates a positive econ context. The background_template didn't read the income dimension either.

### Pattern D: 離婚/鰥寡 + family_size=1 + income≠family_income
- `personal_income=">8萬"` but `family_income="3-7萬"` (TW-P-0405)
- `personal_income="<3萬"` but `family_income="7萬"` (TW-P-0434)
- `personal_income=">8萬"` but `family_income="<1萬"` (TW-P-0535) → largest gap

These are dimension-generation errors, not narrative tone issues. The `_generate_997.py` script assigns personal income and family income independently for single-person households when it shouldn't.

### Pattern E: 家管 occupation + workplace background template
TW-P-0508: occupation="家管" but background_story = "職位不上不下，有點尷尬但穩定。住在都會區。"
Fix: the `GENERIC_LIFE_POOL` contains workplace phrases that should be filtered out when occupation is 家管, 退休, or 學生.

### Pattern F: batch optimistic template for tight family economics
family_income="3-7萬" + family_size="5+" → background_story says "經濟上滿寬裕的" / "生活品質還不錯，該花的會花"
This affects 10+ personas in chunk 3 alone. The background template selection doesn't cross-reference family_income ÷ family_size.

## Verification Script

```bash
python3 ~/persona-db/analyze_chunk3.py
```

This script loads tw_persona_chunk_3.json and checks all 5 patterns above. It can be adapted for other chunks by changing the input path. The detection logic covers:

1. background_story sentiment keywords vs prompt_prefix end-of-sentence sentiment
2. personal income vs family income for single-living-alone households (married=離婚/鰥寡/未婚 + family_size=1)
3. occupation vs background_story template fit (家管→no 職位 phrases)
4. family_income range vs family_size vs background_story comfort level
5. income level vs background_story comfort level

## Priority for Regeneration Fixes

1. **High**: Income mismatch for single-person households (Pattern D) — fix dimension generation first
2. **High**: Family_income vs family_size + bg template (Pattern F) — affects 50+ personas across all chunks
3. **Medium**: 家管 template filter (Pattern E) — small fix, clear rules
4. **Low**: Background vs prefix tone alignment (A, B, C) — requires cross-function validation at merge time
