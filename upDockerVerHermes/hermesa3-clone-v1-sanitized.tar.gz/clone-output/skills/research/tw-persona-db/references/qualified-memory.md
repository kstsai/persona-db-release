# TW Persona DB — Qualified Memory (v3.2)
# 產出日期: 2026-07-13
# 來源: #persona-db-dev (748 則訊息)
# 用法: merge 到 ~/.hermes/memories/MEMORY.md 中，每條以 § 分隔

§
TW Persona DB 版本 v3.1 — 1069 筆台灣人設，18 維度分層抽樣，年齡/性別/區域分布與內政部統計誤差 ≤0.4%。QA 20 條規則全 PASS。7 個官方統計源（ODRP014、DGBAS、主計總處、內政部戶政司等）。 #qualified

§
🟢 雙 Prompt 格式：每筆人設有 prompt_prefix（角色扮演）和 reference_pre_prompt（結構化摘要），兩個路徑獨立生成，須交叉驗證經濟語氣一致性。 #qualified

§
🟢 命名慣例：11 個命名池，按年齡×性別×職業自動匹配。從疊字可愛系（0-11）到嬸系（65+ 女），deque.popleft+append 確保多樣性。 #qualified

§
🟢 物價分級（DGBAS 113年度）與家戶所得分級（2024 DGBAS）：台北市物價「高」、所得「極高」；台東縣「極低」/「低」。經濟語境句依居住地自動對應。 #qualified

§
🟢 都會區職業加成（OCC_CITY_BOOST）：新竹縣/市 30%→科技、台北市 20%→金融、桃園 20%→製造、台中/台南/高雄 15%→製造。排除了學生、退休、65+。 #qualified

§
🟢 已知限制 1 — 人口加權：小縣市（新竹市 ~1.9%、離島 ~1.1%）僅分配到 17-24 人。極端組合可能回 0，放寬 region 條件或增加 sample size。 #qualified

§
🟢 已知限制 2 — background_story 與 prompt_prefix 經濟語氣不一致：不同模板池（背景偏樂觀、prefix gen_econ_context 偏悲觀），regenerate 後需執行 verify_economic_tone.py 交叉比對。 #qualified

§
🟢 已知限制 3 — 模板池汙染：三組 BG 模板獨立抽取可能矛盾（「沒有生小孩」+「小孩開銷大」），喪偶結尾無條件附加「一個人過日子」即使 family_size>1。 #qualified

§
🟢 已知限制 4 — 65+ 子女/孫輩用詞混淆：應用「子女」「兒女」「孫子/孫女」，模板池仍用「小孩」。R17（未滿55兒孫滿堂）和 R10（65+歳殘留）在擋此類問題。 #qualified

§
🟢 已知限制 5 — 中文語意矛盾比邏輯矛盾更難檢測。「含飴弄孫」帶強烈正面語感，即使與低收入在邏輯上可並存，中文讀者仍會感到矛盾。修復：替換為「簡單過日子」。 #qualified

§
🟢 已知限制 6 — 子 agent (Pro) 可能誤報：宜蘭縣誤判為花東（實為北部）、「沒有生小孩」+「小孩」substring false positive。子 agent 回報後必須用 Python script 驗證分類。 #qualified

§
🟢 迭代流程標準化：(1) 發現 bug → (2) 修根因 → (3) 加 QA rule → (4) regenerate → (5) QA 20 rules → (6) 分層抽樣 96 → (7) Pro review → (8) 確認 → (9) commit。 #qualified

§
🟢 Pro review 實務：1069 筆切 6 chunks，dispatch 3+3 平行執行。每 chunk 跑 10-check 機械檢測 + 語意判斷。常見 real bug：收入 vs 描述語氣、獨居+小孩、已婚+fs=1、未成年有收入、65+年輕子女、含飴弄孫+低收入。 #qualified

§
🟢 查詢工具 query_persona.py：支援 18 維度過濾、模糊匹配（~前綴）、--top N、--list-dimensions。人口加權限制下極端組合可能回 0，建議從寬條件開始再逐步限縮。 #qualified

§
🟢 育兒加值卡 composite persona：志豪 — 38歲/新北市/科技業/已婚2小孩/4口/3-8萬。特徵：價格敏感、比價型、太太佔 60% 決策權。檔案：persona_childcare_card.json。 #qualified

§
🟢 商業模式決議：Phase 1 Lite 固定價 NT$20,000（永久授權）。後續可選月訂閱 NT$15K-25K/月（qualified memory 持續更新）或類心理師 NT$3,000/hr（major upgrade）。分身賣斷 NT$60K-80K 供甲方自部署。 #qualified

§
🟢 本尊與分身架構：本尊持續迭代核心、修 bug、產 qualified memory。分身（甲方自部署）瘦身版：只有 data + tools + skill，不含 generate/QA/cron。每月 pull release 匯入更新。記憶隔離確保品質不稀釋。 #qualified

§
🟢 已知 bug 修復記錄（截至 v3.1）：(1) R4 舊格式 prefix (2) R10 65+歳殘留 (3) R11 「做退休」「做學生」(4) R12 【】模板 (5) R13 女 persona 用「獨生子」(6) R14 45+「新婚不久」(7) R15 地點重複 (8) R16 55+新婚 (9) R17 未滿55「兒孫滿堂」(10) R18 未成年泡茶 (11) 65+ prompt 自然化 (12) econ_by_tier variable scoping trap (13) 「一個人過日子」污染 (14) 學生收入→無收入 (15) 1人家庭+小孩 (16) 含飴弄孫+低收入。 #qualified

§
🟢 六大地域→22 縣市對照：都會區=六都、北部=基隆/新竹縣市/苗栗/宜蘭、中部=彰化/南投/雲林、南部=嘉義市縣/屏東、花東=花蓮/台東、離島=澎湖/金門/連江。 #qualified

§
🟢 QA 20 條規則 (R1-R20)：從 9 條（v1.5）成長到 20 條（v3.1），每條對應一個真實踩過的坑。R19 擋 family 矛盾、R20 擋中高齡未婚家庭描述。 #qualified

§
🟢 經濟語氣校驗：`python3 scripts/verify_economic_tone.py [chunk]`。檢查 4 模式：bg舒適→pre緊縮、bg緊縮→pre舒適、已婚fs=1但bg同居、單人戶收入不一致。跨城市對比：台北（高物價）vs 南投（極低物價）的 tight phrase 比例應明顯不同。 #qualified

§
🟢 資料統計：1069 筆中男性 49.7%、女性 50.3%。年齡層 ~8-16% 近似實際人口。22 縣市全覆蓋。全台 30-44 歲已婚有小孩科技業男性約 40-60 筆。 #qualified
