# Real MARRIAGE_PROB from MOI 2024 Data

Computed 2026-07-12 via Pro sub-agent (deleg_8a6c490d).

## Sources

1. **ODRP014 API** — Total population by single age, sex, and village (11405 data, ~7,748 records)
2. **Divorce by age ODS** (`ps01-24`) — Annual divorce count by county, age group, and sex (113年)
3. **Divorce rate CSV** (`data.gov.tw/dataset/173964`) — Divorce rate per 1000 married persons by county, age, sex

## Methodology

```
Married population = divorce_count / (divorce_rate / 1000)
Divorced population = annual divorce count (flow as stock proxy)
Unmarried + Widowed = Total − Married − Divorced
```

## Key Findings vs Old Estimates

| Age | Old 未婚 | Real 未婚 | Old 離婚 | Real 離婚 |
|:----|:--------:|:---------:|:--------:|:---------:|
| 19-24 | 88% | **97%** | 1% | **0.3%** |
| 25-34 | 40% | **75%** | 8% | **0.9%** |
| 35-44 | 15% | **42%** | 15% | **1.0%** |
| 65+ | 3% | **22%** | 7% | **0.09%** |

Sex differences (65+): Male widowed 4.9%, Female widowed 30.2% — reflects longer female lifespan.

## Caveats

- Divorced population uses annual flow as stock proxy → underestimates cumulative divorce rate
- Widowed population estimated (no direct source)
- The real cumulative divorce stock would be ~3-5x higher than annual flow
