# TW Persona DB — Lite 方案

> NT$15,000 賣斷 | 資料 + 查詢工具，不含生成引擎
> 後續升級同 Transfer 模式（NT$2,000/hr，依 session log）

## 一句話

NT$15,000，拿到 1,069 筆台灣人設資料庫 + 查詢 CLI。不能自己 regenerate，但能馬上開始 query 目標客群。

## 交付內容

```
Lite v3.2（NT$15,000 賣斷）
├── data/
│   ├── tw_persona_1069.json      ← 1,069 筆，18 維度
│   ├── tw-persona-db-rfc.md      ← 規格文件
│   └── qualified-memory.md       ← 24 條 domain knowledge
├── tools/
│   ├── query_persona.py          ← 查詢 CLI（唯讀）
│   └── sample_stratified.py      ← 分層抽樣檢視
├── README.md + FAQ.md            ← 快速入門
└── VERSION                       ← v3.2
```

**不含：** `_generate_997.py`、`qa_validate.py`、機率表、scripts、skills

## 授權

| 允許 | 不允許 |
|:----|:-------|
| 可用於商業產品內部 | 不可轉售原始資料 |
| 可自由 query 分析 | 不可自行 regenerate |
| 可販售基於資料的分析報告 | 不可轉售 JSON 本體 |

## 升級

同 Transfer 模式: NT$2,000/hr, 依 actual session log, 每次 upgrade 產出 WORKLOG.md。
