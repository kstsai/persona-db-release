# Chunk 3 Validation Report — 179 Personas

Generated 2026-07-13 by verify_chunk3_v3.py → migrated to `scripts/verify_chunk3.py`.

## Summary

| Category | Count | Details |
|----------|-------|---------|
| **REAL** | 13 (7 unique) | Income-description mismatch + 未婚+獨生女+小孩開銷 |
| **OK**   | 48 | 低收高物價(26), 分居/新婚(14), pp舒適用語(6), fs=1+已婚(2) |
| **MINOR**| 14 | bg寬裕但pp剛好夠(10), 未婚+小孩未説對象(5) |
| Unaffected checks | 4,5,6,7,9,10 | Zero findings |

## REAL Findings

### Check 1: 收入 vs 描述 (5)

| Persona | ID | Income | Root Cause |
|---------|----|--------|------------|
| 協明 | TW-P-0421 | &lt;3萬 | bg「夫妻兩人世界。**經濟上滿寬裕的**」 |
| 惠雯 | TW-P-0479 | &lt;3萬 | bg「**經濟上滿寬裕的**」but pp「還是要省着點」 |
| 靜怡 | TW-P-0482 | &lt;3萬 | bg「**手頭還算寬鬆，不用太省**」but pp「還是要省着點」 |
| 雅雯 | TW-P-0501 | &lt;3萬 | bg「**手頭還算寬鬆，不用太省**」but pp「還是要省着點」 |
| 木火 | TW-P-0537 | &lt;3萬 | bg「**經濟上滿寬裕的**」but pp「還是要省着點」 |

**Root cause**: BG template pools and prefix `gen_econ_context()` use different code paths; `econ_by_tier()` default parameter `inc_level="3-8萬"` means low-income personas never got the income bias applied to their background story.

### Check 8: BG前後句矛盾 (8 entries, 6 unique)

| Persona | ID | Root Cause |
|---------|----|------------|
| 麗美 | TW-P-0369 | **未婚+獨生女** + bg「小孩的開銷很大」 -- impossible |
| 淑娟 | TW-P-0402 | **未婚+獨生女+&gt;8萬收入** + bg「小孩的教育費是最大開銷」 -- impossible |
| 惠雯 | TW-P-0479 | bg「寬裕」-> pp「要省」 (same as Check 1) |
| 靜怡 | TW-P-0482 | bg「手頭寬鬆」-> pp「要省」 (same as Check 1) |
| 雅雯 | TW-P-0501 | bg「寬裕」-> pp「要省」 (same as Check 1) |
| 木火 | TW-P-0537 | bg「寬裕」-> pp「要省」 (same as Check 1) |

## MINOR Findings

### Pattern A: bg says 寬裕/寬鬆, pp says 剛好夠 (10 entries)

All share: income 3-8萬, bg says "經濟上滿寬裕的" or "手頭還算寬鬆，不用太省", pp ends with "在XX收入剛好夠生活". Tone inconsistency -- bg leans optimistic, pp leans neutral.

Personas: 淑貞(TW-P-0359, TW-P-0382), 淑娟(TW-P-0389), 瑞宏(TW-P-0428), 信賢(TW-P-0435), 志豪(TW-P-0443), 協明(TW-P-0447), 志強(TW-P-0448), 慧君(TW-P-0476), 美珍(TW-P-0524)

### Pattern B: 未婚+小孩開銷 unqualified (5 entries)

Personas: 雅雯(TW-P-0367), 美珍(TW-P-0388), 婉玲(TW-P-0393), 強哥(TW-P-0423), 世昌(TW-P-0425)

bg mentions "小孩的教育費是最大開銷" or "小孩的開銷很大" without specifying whether refers to siblings/nieces/nephews.

## False Positive Patterns Discovered During Validation

1. **「女」->「女性」false positive** (fixed v3): Check 2 used single-char keyword `"女"` which matched `"女性"` in prompt_prefix intro -- 3 false REALs.
2. **「沒有生小孩」substring trap**: Contains literal substring "小孩" -- check must exclude negated "沒有生小孩" contexts when looking for children expenses.
3. **"剛好夠" vs "寬裕/寬鬆" classification**: "剛好夠" is MINOR (tone) not REAL (contradiction) -- bg says comfortable, pp says just enough.

## Cross-Chunk Trend

Same economic tone pattern (bg comfortable -> pp tight) found at:
- Chunk 3: 5 REAL
- Chunk 4: similar frequency (see chunk4-contradiction-patterns.md)
- Chunk 6: 23 instances (see chunk6-contradiction-patterns.md)

The variation is sample-dependent; root cause is the same `econ_by_tier()` default param.
