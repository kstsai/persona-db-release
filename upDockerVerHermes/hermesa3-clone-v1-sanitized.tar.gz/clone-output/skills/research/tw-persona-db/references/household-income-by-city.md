# Household Disposable Income by City (2024)

Source: 行政院主計總處 113年度家庭收支調查
Reported by: 風傳媒 (2025-10-20), referencing DGBAS data

## National Average
- **1,165,000 NTD/year** per household (全國每戶可支配所得平均)

## Full Ranking

| Rank | City | Annual Income | % of National Avg | Tier |
|:----:|------|:------------:|:-----------------:|:----:|
| 1 | 新竹縣 | 1,868,845 | 160% | 極高 |
| 2 | 新竹市 | 1,858,010 | 159% | 極高 |
| 3 | 台北市 | 1,803,192 | 155% | 極高 |
| 4 | 桃園市 | ~1,520,000 | 130% | 高 |
| 5 | 新北市 | ~1,480,000 | 127% | 高 |
| 6 | 嘉義市 | 1,455,973 | 125% | 高 |
| 7 | 台中市 | ~1,380,000 | 118% | 高 |
| 8 | 高雄市 | ~1,330,000 | 114% | 中 |
| 9 | 基隆市 | ~1,250,000 | 107% | 中 |
| 10 | 台南市 | ~1,220,000 | 105% | 中 |
| 11 | 宜蘭縣 | ~1,150,000 | 99% | 中 |
| 12 | 屏東縣 | ~1,080,000 | 93% | 中低 |
| 13 | 苗栗縣 | ~1,050,000 | 90% | 中低 |
| 14 | 花蓮縣 | ~1,020,000 | 88% | 中低 |
| 15 | 嘉義縣 | 990,000 | 85% | 中低 |
| 16 | 南投縣 | ~960,000 | 82% | 中低 |
| 17 | 雲林縣 | ~950,000 | 82% | 中低 |
| 18 | 金門縣 | ~950,000 | 82% | 中低 |
| 19 | 彰化縣 | ~940,000 | 81% | 中低 |
| 20 | 台東縣 | 920,000 | 79% | 低 |
| 21 | 連江縣 | ~920,000 | 79% | 低 |
| 22 | 澎湖縣 | 900,000 | 77% | 低 |

## Notable Patterns

- **新竹縣市** beat 台北市 by ~50K — driven by 竹科 semiconductor salaries
- **嘉義市 (#6)** outperforms 台中/高雄/台南 — anomaly attributed to specific demographic composition
- **嘉義縣 vs 嘉義市**: 47萬 gap despite geographical adjacency
- Three cities below 1M: 嘉義縣(990K), 台東縣(920K), 澎湖縣(900K)

## Usage in Generation

In `_generate_997.py`, `HH_INCOME_TIER` maps each city to one of 5 tiers:
- **極高** (cities 1-3): shifts family_income toward upper brackets
- **高** (cities 4-7): slight upward shift
- **中** (cities 8-11): no adjustment
- **中低** (cities 12-19): slight downward shift
- **低** (cities 20-22): shifts family_income toward lower brackets

The function `adjust_family_income_by_tier()` applies these shifts after coherence validation.
