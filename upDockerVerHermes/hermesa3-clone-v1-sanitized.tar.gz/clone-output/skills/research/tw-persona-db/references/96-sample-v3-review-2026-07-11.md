# 96 筆 Stratified Sample 全面 Review — 2026-07-11

## Review Methodology

**Dual-pass approach**:
1. **Pass 1 — Automated** (`scripts/persona_review.py`): Script-based check of 5 categories
2. **Pass 2 — Deep semantic** (`scripts/persona_review_deep.py`): Background coherence, economic contradiction, prefix quality

**Review model**: deepseek-v4-pro (via delegation)

## Key Findings

| Category | Issues | Severity |
|----------|--------|----------|
| A. 分布異常 | 7 (prefix稱謂 vs education不一致) | 🟡 |
| B. 內容不合理 | 96 (background_story區域殘留全數) + 6 (內部矛盾) + 15 (經濟句矛盾) + 7 (低收入寬裕) | 🔴 |
| C. 語言自然度 | 7 (19-24學生缺經濟句, 可接受) | 🟢 |
| D. 物價/所得維度 | **0** — 台北/南投/台東全部正確 | ✅ |
| E. Region/Residence | **0** — 全部96筆映射正確 | ✅ |

## Detailed Findings

### A. Prefix「國中/高中」稱謂 vs education 不一致 (7筆)
- TW-P-0100/芽泉, TW-P-0704/小桃, TW-P-0810/小莓, TW-P-0965/熙熙, TW-P-0984/小莓: prefix稱「高中」但 education=國中以下
- TW-P-0905/泡泡, TW-P-0985/芯芯: prefix稱「國中」但 education=高中
- **Root cause**: `age_desc()` in generator uses age range (12-18→高中) but doesn't check actual `education` dimension

### B. Background_story 區域殘留 (96筆全部)
- Each background_story ends with "住在都會區。/住在北部。/住在中部。/住在南部。/住在東部。/住在離島。" instead of concrete city/county
- **Root cause**: Template source in generator still uses `region` (macro label) instead of `residence` (specific city) in background_story generation

### B. Background_story 內部矛盾 (6筆)
- TW-P-0645/金花嬸: 說「沒有生小孩的打算」但第二句「小孩的開銷很大」
- TW-P-0927/惠如: 說「夫妻兩人世界」但「小孩的教育費是最大開銷」
- TW-P-0975/瑞宏: 說「沒有生小孩的打算」但「小孩慢慢大了」
- Plus 3 more in 秀琴, 金蓮, 土伯 (says 沒有生小孩 but later references 小孩 generically)

### B. Background_story vs Prefix 經濟句矛盾 (15筆)
**Type 1 — background說寬裕但prefix偏緊 (11筆)**: 0181/阿杰, 0368/淑貞, 0790/阿桃, 0814/小胖, 0881/秀琴, 0886/茂伯, 0918/米亞, 0975/瑞宏, 0980/金伯, 0989/愛莎, 0997/阿桃
**Type 2 — background說手頭緊但prefix偏鬆 (4筆)**: 0580/阿緞, 0959/金花嬸, 0993/美惠, 0995/金蓮

### D. Price/Income Tier — All 22 residences correct
- 台北市 → 高/極高 (5筆) ✓
- 南投縣 → 極低/中低 (5筆) ✓  
- 台東縣 → 低 (7筆) ✓
- 新竹縣/新竹市 → 高~中高/極高 (8筆) ✓
- **Economic sentences are consistent**: 台北+>8萬→「要算著花」, 台東+>8萬→「過得滿舒服」 ✓

## New QA Rules Needed

| Rule | Check | Priority |
|:----|:------|:---------|
| R19 | background_story 區域殘留（不該有「住在都會區/北部/中部/南部/東部/離島」） | 🔴 High |
| R20 | prefix「國中/高中」稱謂 vs education 不一致 | 🟡 Medium |
| R21 | background_story「沒有生小孩」+「小孩」矛盾 | 🟡 Medium |
| R22 | background_story vs prefix 經濟句矛盾 | 🟡 Medium |
| R23 | 低收入（<3萬）+「寬裕」描述矛盾 | 🟡 Medium |
