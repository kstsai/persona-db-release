# Coherence Validation Rules — `_generate_997.py`

All rules run after dimension sampling but before background story generation.
Each fix is counted in `coherence_fixes` dict and printed in the output stats.

## Rule 1: Large-family income floor

**Trigger:** `fam == "5+"` AND `fam_inc` is `"<1萬"` or `"1-3萬"`  
**Fix:** Re-sample from `{"3-7萬": 0.45, "7萬": 0.35, "百萬": 0.20}`  
**Rationale:** A 5+ person household surviving on <1-3萬/month is improbable.  
**Counter:** `coherence_fixes["fam_inc_5plus"]`

## Rule 2: 4-person minimum income

**Trigger:** `fam == "4"` AND `fam_inc == "<1萬"`  
**Fix:** Re-sample from `{"1-3萬": 0.30, "3-7萬": 0.40, "7萬": 0.20, "百萬": 0.10}`  
**Rationale:** A 4-person family on <10K/month is below credible minimum.  
**Counter:** `coherence_fixes["fam_inc_4"]`

## Rule 3: Student in large family

**Trigger:** `occ == "學生"` AND `fam == "5+"` AND `fam_inc in ("<1萬", "1-3萬")`  
**Fix:** Re-sample from `{"3-7萬": 0.40, "7萬": 0.35, "百萬": 0.25}`  
**Rationale:** A student in a 5+ person household needs the household to be viable.  
**Counter:** `coherence_fixes["fam_inc_student_5plus"]`

## Rule 4: Minors can't be married

**Trigger:** `marriage == "已婚"` AND `age in ("0-11", "12-18")`  
**Fix:** Set `marriage = "未婚"`  
**Rationale:** Under-18 marriage is illegal in Taiwan.  
**Counter:** `coherence_fixes["marriage_minor"]`

## Rule 5: Young students can't be divorced

**Trigger:** `marriage == "離婚"` AND `occ == "學生"` AND `age in ("19-24",)`  
**Fix:** Set `marriage = "未婚"`  
**Rationale:** A 19-24 year old who is both a current student AND divorced is extremely rare in Taiwan. MARRIAGE_PROB also adjusted (離婚 0.02→0.01, 鰥寡 0.01→0 for this age).  
**Counter:** `coherence_fixes["marriage_student_divorce"]`

## Rule 6: 35+ professionals need minimum education

**Trigger:** `edu in ("國中以下","高中")` AND `occ in ("科技","金融","醫療")` AND `age in ("35-44","45-54","55-64")`  
**Fix:** Set `edu = "大學"`  
**Rationale:** A 35+ year old working in tech/finance/medical in Taiwan without at least a university degree is extremely unusual. 19-34 exemption allowed (self-taught apprentices, young founders). Updated 2026-07-10 when education split from 高中以下 into 國中以下/高中 (now catches both sub-levels).  
**Counter:** `coherence_fixes["edu_professional_bump"]`

## Rule 7: Children don't worry about household budget

**Trigger:** `age in ("0-11", "12-18")`
**Fix:** Skip the entire Economic Situation section in `infer_background()`
**Rationale:** A child saying "月底常常手頭緊" or "每一塊錢都要算清楚" is implausible — household economics are parent-domain. Life-stage and region descriptions still apply.
**Counter:** None (it's a skip, not a transformation)

## Rule 8: Minors can't live alone

**Trigger:** `age in ("0-11", "12-18")` AND `fam == "1"`
**Fix:** Preventive — removed `"1"` from FAMILY_SIZE_PROB for 0-11 and 12-18 age groups entirely. Redistributed probability to 2/3/4/5+.
**Rationale:** A child or teenager living alone ("自己一個人住。還在唸小學。") is unrealistic in Taiwan. Rather than fixing after sampling, the probability table excludes this combination entirely.
**Statistics:** Eliminated 26 cases (14 in 0-11 + 12 in 12-18).

## Known non-issues (intentionally NOT validated)

| Situation | Reason kept |
|-----------|-------------|
| 19-24 已婚 + 學生 | Possible: married while in university (e.g. pregnant during undergrad). Kept. |
| 25-34 離婚 + 任何職業 | Normal for this age bracket. ~8% divorce rate is realistic. |
| 45-54「三代同堂」from HH_FAM5_WIDOWED | Age-appropriate: middle-aged widowed/divorced with both children and elderly parents. |
