# Bank Visibility Analysis — Mode ② Encounter Simulation Worked Example

**Date**: 2026-07-14 | **Model**: deepseek-v4-pro  
**Question**: 「請問現在哪一家數位帳戶的活存利率最高，而且轉帳免手續費次數最多？」  
**Mode**: ② Encounter Simulation (sub-agent encounters persona asking, responds as expert)

## Persona Selection Criteria (6 Dimensions)

For bank visibility analysis, select personas to **maximize diversity across 6 dimensions**:

| Dimension | Rationale | Empirical Coverage (11-persona sample) |
|:----------|:----------|:--------------------------------------:|
| **Age** | Younger = digital native, older = stability-focused | 19-24×2, 25-34×2, 35-44×5, 45-54×1, 65+×1 |
| **Gender** | Testing if LLM biases recommendations by gender | 女×5, 男×6 |
| **Income** | Low income fees-sensitive, high income rate-sensitive | 無收入×1, <3萬×2, 3-8萬×6, >8萬×2 |
| **Occupation** | Domain expertise = more critical evaluation | 科技×4, 服務×2, 家管×2, 金融×1, 自營×1, 學生×1 |
| **Geography** | Urban vs rural, north vs south vs east vs islands | 北×7, 中×1, 南×2, 東×1 |
| **Marriage/Family** | Family obligations = different spending priorities | 未婚×6, 已婚×5 |

## 11-Persona Selection (Worked Example)

| # | Name | Age | Sex | City | Occupation | Income | Marriage | Selection Rationale |
|:-:|:----:|:---:|:---:|:----:|:----------:|:-----:|:--------:|:--------------------|
| ① | **麗華** | 45-54 | 女 | 台北市 | 科技 | 3-8萬 | 已婚 | Baseline urban tech, empty nester, price-conscious |
| ② | **靜怡** | 35-44 | 女 | 新竹市 | 科技 | 3-8萬 | 已婚 | Working mother, time-poor, fee-sensitive |
| ③ | **淑貞** | 35-44 | 女 | 台南市 | 家管 | 3-8萬 | 已婚 | Southern homemaker, comfortable, health-conscious |
| ④ | **丹尼爾** | 25-34 | 男 | 新北市 | 科技 | >8萬 | 未婚 | Young high earner, digital native |
| ⑤ | **建宏** | 35-44 | 男 | 高雄市 | 自營 | 3-8萬 | 已婚 | Southern self-employed, 2 kids, cash flow irregular |
| ⑥ | **小宇** | 19-24 | 男 | 新北市 | 學生 | 無收入 | 未婚 | First-time account opener, fee-ultra-sensitive |
| ⑦ | **金花嬸** | 65+ | 女 | 桃園市 | 家管 | <3萬 | 已婚 | Senior, digital-averse, stability-first |
| ⑧ | **永信** | 35-44 | 男 | 花蓮縣 | 服務 | 3-8萬 | 未婚 | Eastern Taiwan, low bank density, limited ATM access |
| ⑨ | **小薇** | 25-34 | 女 | 桃園市 | 服務 | <3萬 | 未婚 | Low income but high education, transfer-fee-critical |
| ⑩ | **傑** | 19-24 | 男 | 台中市 | 金融 | 3-8萬 | 未婚 | Finance insider, professional-grade evaluation |
| ⑪ | **瑞宏** | 35-44 | 男 | 新北市 | 科技 | >8萬 | 未婚 | High income but heavy loans, rate + flexibility both matter |

## Mode ② Context Template

```python
context = f'''【Persona Background】
{name}，{age}歲，住{city}，{occupation}，收入{income}。
家庭狀況：{marriage_status}
背景：{background_story[:120]}
興趣：{hobbies}

你用第一人稱「我」直接回答。回答要像在跟朋友聊天一樣自然。
不要提到任何關於模擬、角色扮演的字眼。'''

goal = f'你遇到一位名叫{name}的{gender_phrase}來問你：「{question}」請以專業友善的態度回答她。回答要針對她的背景來給建議。回答完不用再問問題。'
```

## Brand Visibility Scoring

For each response, extract:

1. **Mentioned banks** — list every bank name appearing in the response
2. **Recommendation position** — is it the 1st pick? 2nd? Or just listed as also-ran?
3. **Sentiment** — positive/neutral/negative framing
4. **Persona linkage** — did the response connect bank features to this persona's life?

### Coverage Matrix Template

```
| Bank | Coverage | 🥇1st | 🥈2nd | 🥉3rd | Listed | Negative | Avg Sentiment |
|:-----|:--------:|:----:|:----:|:----:|:------:|:--------:|:-------------:|
```
### Depth Assessment Template

```
| Bank | Persona | Response Excerpt | Key Framing | Sentiment | Persona Fit? |
|:-----|:--------|:-----------------|:------------|:---------:|:------------:|
```

### Ranking

Calculate composite score = coverage_weight × position_score × sentiment_score.

## Full 11-Persona Results (2026-07-14)

### Coverage Matrix — Digital Account Scenario

| # | Persona | Tag | 🥇1st | 🥈2nd | Other Mentions |
|:-:|:--------|:----|:----:|:----:|:--------------|
| ① | 麗華 47台北·科技 | 空巢·精打細算 | **台銀** | 將來銀行 | 聯邦NNB·王道(不建議) |
| ② | 靜怡 37新竹·科技 | 職業媽·時間少 | **台銀** | 將來·華南SnY | 王道·彰銀 |
| ③ | 淑貞 41台南·家管 | 養生·寬裕 | **台銀** | 將來銀行 | 聯邦NNB |
| ④ | 丹尼爾 28新北·科技 | 高薪·單身 | **台銀** | 將來銀行 | **LINE Bank** |
| ⑤ | **建宏** 40高雄·自營 | 雙薪爸·金流不穩 | **🔥將來銀行** | 台銀 | Richart(新戶紅利) |
| ⑥ | 小宇 20新北·學生 | 首開戶·免手續費 | **台銀** | Richart | **遠東Bankee 18%** |
| ⑦ | **金花嬸** 70桃園·家管 | 退休·怕數位 | **🔥Richart** | 台銀·一銀iLEO | — |
| ⑧ | 永信 38花蓮·服務業 | 東部·銀行少 | **台銀** | 將來·一銀iLEO | **LINE Bank** |
| ⑨ | 小薇 28桃園·服務業 | 低薪·手續費敏感 | **台銀** | 一銀iLEO | 聯邦·王道(風險提示) |
| ⑩ | 傑 22台中·金融業 | 業內專業 | **台銀/Bankee** | 將來·王道·Richart | 渣打·聯邦·LINE Bank |
| ⑪ | **瑞宏** 38新北·科技 | 高薪·背貸款 | **🔥將來銀行** | 台銀 | Richart |

**🔥 = non-台銀 first pick** — only 3/11: 建宏(自營商→額度彈性), 金花嬸(退休→LINE), 瑞宏(高負債→綜合CP值).

### Coverage Summary

| Bank | 1st Picks | Total Coverage | 1st Pick Rate |
|:-----|:--------:|:-------------:|:-------------:|
| **台銀** | **8** 🥇 | **11/11** | **73%** |
| **將來銀行** | **2** 🥈 | 10/11 | 18% |
| **Richart** | **1** 🥉 | 5/11 | 9% |
| 一銀iLEO | 0 | 3/11 | 0% |
| 聯邦NNB | 0 | 3/11 | 0% |
| 遠東Bankee | 0 | 2/11 | 0% |
| LINE Bank | 0 | 2/11 | 0% |
| 王道/華南/彰銀/渣打 | 0 | 1-2/11 | 0% |
| KOKO | 0 | **0/11** | 0% |

### Persona Attributes that Shift Recommendations

| Attribute | LLM Behavior | Favored Bank |
|:----------|:-------------|:-------------|
| **Busy / time-poor** | Recommends no-task products | 台銀 (免任務) |
| **Young / new customer** | Suggests short-term high rates | Bankee/Richart |
| **Has children / family** | Prioritizes fee savings > rate | 台銀 (99次) |
| **Self-employed / cash flow variable** | Prioritizes limit flexibility | **將來銀行** |
| **High income** | Recommends dual-account pairing | 台銀+將來 |
| **Retired / senior** | Prioritizes simple UX (LINE) | Richart |
| **Eastern Taiwan / rural** | Touts pure-online convenience | 台銀+將來 |

###台銀's Dominance and Its One Weakness

台銀 wins 73% first-pick because 「免任務、99次」 is the easiest 1-line story for any persona. **The only chink in the armor**: 10萬額度. For personas needing more capacity (self-employed, high-debt), 將來銀行 wins with its 20-120萬 limit. The decisive dimension that dethrones 台銀 is **額度彈性**, not rate or transfer count.

## Scenario Comparison Methodology

Running the same 11-persona × encounter-mode setup against **different question scenarios** reveals that bank visibility shifts dramatically by product domain. This makes reports far more credible than single-scenario rankings.

### How to Run a Multi-Scenario Test

```
For each scenario:
1. Design the banking-domain question
2. Keep the same 11 personas (don't re-select per scenario)
3. Dispatch 4 batches × encounter mode ②
   Batch A: personas ①-③
   Batch B: personas ④-⑥
   Batch C: personas ⑦-⑨
   Batch D: personas ⑩-⑪
4. Extract brand mentions, positions, sentiment
5. Build cross-scenario comparison table
```

### Scenario C: Mortgage (房貸) — Worked Example

**Question**: 「請問現在哪一家銀行的房貸利率最低，而且貸款成數最高？」

| # | Persona | Context | 🥇1st Pick | 🥈2nd | Delta from Digital Account |
|:-:|:--------|:--------|:----------:|:-----:|:--------------------------:|
| ① | 麗華 47台北 | 夫妻首購·雙薪科技 | **新青安1.775%** | 滙豐2.19% | 🔄台銀→新青安 |
| ② | 靜怡 37新竹 | 轉貸降息·職業媽 | **渣打2.25%** | 永豐/富邦2.50% | 🔄台銀→渣打 |
| ③ | 淑貞 41台南 | 第二戶·投資 | **土銀2.425%** | 兆豐2.435% | 🔄台銀→土銀 |
| ④ | 丹尼爾 28新北 | 單身首購·高薪 | **彰銀2.065%** | 滙豐2.19% | 🔄台銀→彰銀 |
| ⑤ | 建宏 40高雄 | 自營商轉貸 | **渣打2.25%** | 將來2.38% | 🔄將來→渣打 |
| ⑥ | 小宇 20新北 | 大學生·未來規劃 | **新青安1.775%** | — | 🔄台銀→新青安 |
| ⑦ | 金花嬸 70桃園 | 幫兒子問·退休 | **新青安1.775%** | 滙豐2.19% | 🔄Richart→新青安 |
| ⑧ | 永信 38花蓮 | 首購·租房vs買房 | **新青安1.775%** | 滙豐2.19% | 🔄台銀→新青安 |
| ⑨ | 小薇 28桃園 | 低薪·首購 | **新青安1.775%** | — | 🔄台銀→新青安 |
| ⑩ | 傑 22台中 | 金融業·首購 | **新青安1.775%** | 行員優惠 | 🔄台銀→新青安 |
| ⑪ | 瑞宏 38新北 | 高負債·首購 | **新青安1.775%** | 滙豐2.19% | 🔄將來→新青安 |

### Cross-Scenario Comparison Table

| Bank | 🅰️ Digital Account 1st Pick | 🅱️ Mortgage 1st Pick | Delta |
|:-----|:--------------------------:|:--------------------:|:-----:|
| **台銀** | **73%** 🥇 | **0%** ❌ | 📉 Collapse |
| **將來銀行** | **18%** 🥈 | 0% | 📉 |
| **Richart** | **9%** 🥉 | 0% | 📉 |
| **新青安** (gov't) | N/A | **64%** 🥇 | 🆕 Dominant |
| **渣打** | 0% | **18%** 🥈 | 📈 New niche |
| **滙豐** | 0% | 4 mentions | 📈 |
| **土銀/彰銀** | 0% | 9% each | 📈 |

**Key insight**: 台銀 goes from 73% to absolute zero between scenarios. Scenario is the dominant visibility variable — not persona.

## Client Banking Questions (Added 2026-07-14)

The client (甲方) provided 4 banking-domain questions. Q2 is the Digital Account scenario (covered above). Q1, Q3, Q4 open new product categories:

| ID | Question | Category | Key Banks to Watch |
|:---|:---------|:---------|:-------------------|
| **Q1** | 線上申請雙幣卡，哪家銀行的審核跟發卡速度最快？ | Dual-Currency Card | 中信(Line Pay), 玉山(熊本熊), 台新(飛狗), 國泰(長榮) |
| **Q2** | 現在哪一家數位帳戶的活存利率最高？ | Digital Account | ✅ Done: 台銀, 將來, Richart, 華南, 一銀 |
| **Q3** | 綁定LINE Pay或街口支付，刷哪張聯名卡拿到的點數回饋最實用？ | Mobile Payment CC | 聯邦(LINE Bank), 中信(LINE Pay), 台新(@GoGo), 國泰(CUBE), 富邦(J卡) |
| **Q4** | 哪家銀行的行動網銀App介面最乾淨、最不會一直跳出不相關的推銷廣告？ | Mobile Banking UX | 王道, 將來, LINE Bank, Richart, KOKO |

### Design Notes

- **Q1 (雙幣卡)**: 「速度」not 「利率」. LLM likely picks banks with fast online KYC + known travel cards.
- **Q3 (行動支付聯名卡)**: Tests **ecosystem integration** — LINE Pay vs 街口 penetration determines recommendation.
- **Q4 (行動網銀App)**: Most subjective — LLM has no real UX data, relies on training knowledge about app reputations. Use as sentiment barometer only.

## Empirical Results (3-Persona Pilot)

| Bank | 麗華② (台北·科技) | 靜怡② (新竹·科技媽) | 淑貞② (台南·家管) | Coverage |
|:----|:----------------:|:-----------------:|:-----------------:|:--------:|
| **台銀** | 🥇首推·主角級 | 🥇首推·主角級 | 🥇首推·主角級 | **3/3** |
| **將來銀行** | 🥈次要·詳述 | 🥈次要·提及 | 🥈次要·詳述 | **3/3** |
| **聯邦NNB** | 📌新戶·不建議 | ❌ 未提及 | 🥉第三·任務麻煩 | 2/3 |
| **華南SnY** | ❌ 未提及 | 🥇利率冠軍·明確推薦 | ❌ 未提及 | 1/3 |
| **王道** | 📌新戶·不建議 | 📌利率欄·中性 | ❌ 未提及 | 2/3 |
| **彰銀** | ❌ 未提及 | 📌次數欄·中性 | ❌ 未提及 | 1/3 |
| 渣打/LINE/Richart/KOKO | ❌ | ❌ | ❌ | **0/3** |

### Findings

1. **台銀 dominated** — won all 3 personas as first pick, regardless of age/income/region. The 「免任務、99次」 narrative universally applies.

2. **將來銀行 stable #2** — mentioned as backup in all 3, always framed as a "payoff with small effort" option.

3. **華南SnY persona-specific** — only recommended to 靜怡 (新竹科技女), as the LLM calculated she could handle the simple task requirement.

4. **Zero-visibility banks** — LINE Bank, Richart, KOKO, 渣打 never appeared. These banks lack a distinctive 1-line narrative for LLMs.

### What Predicts LLM Visibility

| Predictor | Effect |
|:----------|:-------|
| **Simple, relatable feature** (99次, 免任務) | ✅ Strong positive — easy for LLM to explain |
| **Solvable pain point** (轉帳手續費、複雜任務) | ✅ Strong positive — LLM can connect to persona |
| **Memorable number** (2.075%, 99, 50) | ✅ Moderate — easier to surface |
| **Complex terms** (需解任務、需匯入資金) | ❌ Negative — LLM flags as caveat |
| **Generic positioning** (LINE, Richart, KOKO) | ❌ Negative — no unique differentiator for LLM narrative |

## Delivery

- Raw results → `worklogs/RAW-RESULTS-YYYY-MM-DD.md`
- Analysis → `worklogs/BANK-VISIBILITY-ANALYSIS-YYYY-MM-DD.md`
- Persona selection → `worklogs/BANK-PERSONA-SELECTION-11.md` (or similar)
