# Marriage Status Data Sources — COMPUTED (2026-07-12)

Computed `MARRIAGE_PROB` (未婚/已婚/離婚/鰥寡 by age × sex) from three MOI open data sources.
Output file: `~/persona-db/marriage_prob_real.py`
Computation script: `/home/ubuntu/compute_marriage.py`

## Data Sources Used

### 1. 總人口 by Age/Sex — ODRP014 API
- **URL**: `https://www.ris.gov.tw/rs-opendata/api/v1/datastore/ODRP014/11405` (4 pages, 7748 village-level records)
- **Content**: Population by single year of age (0-99 + 100up), male/female, at village level.
- **Fields**: `people_age_{000-099}_{m/f}`, `people_age_100up_{m/f}`
- **County aggregation**: First 5 chars of `district_code` (12-char code) = county code.
- **Total population from data**: 23,355,470 (matches official ~23.4M)

### 2. 離婚人數按年齡分 (Divorce Counts by Age) — ODS
- **Source**: MOI 婚姻狀況 page → `ps01-24`
- **File**: `/tmp/divorce_by_age.ods` (pre-downloaded)
- **Content**: Annual divorce FLOW (counts) by county, 11 age groups, male/female. 113年 data in Table index 1.
- **Age groups**: `<20`, `20-24`, `25-29`, `30-34`, `35-39`, `40-44`, `45-49`, `50-54`, `55-59`, `60-64`, `65+`
- **National totals**: 52,901 male divorces, 53,801 female divorces (2024)

### 3. 各縣市有偶人口離婚率 (Divorce Rate per 1000 Married) — CSV
- **File**: `/tmp/divorce_rate.csv` (pre-downloaded)
- **Content**: Divorce rate per 1000 married persons, by county, sex, 11 age groups.
- **Source**: data.gov.tw dataset 173964

## Computation Method

### Step 1: Aggregate Population
- Sum single-age population data from village level up to county level, then to national.
- Map to ODS age groups (11 groups) and output age groups (8 groups: 0-11, 12-18, 19-24, 25-34, 35-44, 45-54, 55-64, 65+)

### Step 2: Back-Calculate Married Population
```
married_pop = divorce_count / (divorce_rate / 1000)
```
- `divorce_count` = annual divorce count from ODS (flow)
- `divorce_rate` = divorce rate per 1000 married population from CSV
- Result = stock of currently married persons in that age/gender/county

### Step 3: Assign Remaining Population
```
divorced_pop = divorce_count  (annual flow as stock proxy)
unmarried + widowed = total_pop - married_pop - divorced_pop
```

### Step 4: Split Unmarried vs Widowed
No direct source for widowed population. Estimated proportionally based on age/gender:

| Age Group | Male widowed ratio | Female widowed ratio |
|-----------|-------------------|---------------------|
| <20, 20-24, 25-29 | 0% | 0% |
| 30-34 | 1% | 3% |
| 35-39 | 2% | 5% |
| 40-44 | 3% | 8% |
| 45-49, 50-54 | 6% | 18% |
| 55-59 | 10% | 25% |
| 60-64 | 15% | 35% |
| 65+ | 20% | 55% |

These ratios reflect known widowhood patterns: very rare under 40, rises sharply after 55, and elderly women far more likely widowed than men (longer life expectancy + age gap in marriages).

### Step 5: Map ODS Groups → Output Groups
| Output Group | ODS Source |
|-------------|------------|
| 0-11 | 100% unmarried (per task spec) |
| 12-18 | 100% unmarried (per task spec) |
| 19-24 | Age 19 (proportional from `<20`) + 20-24 |
| 25-34 | 25-29 + 30-34 |
| 35-44 | 35-39 + 40-44 |
| 45-54 | 45-49 + 50-54 |
| 55-64 | 55-59 + 60-64 |
| 65+ | 65+ |

Age 19 separation from `<20` group uses the population ratio: `age19_pop / total_under20_pop`.

## Results (MARRIAGE_PROB, 男女合計)

| Age | 未婚 | 已婚 | 離婚 | 鰥寡 |
|-----|:----:|:----:|:----:|:----:|
| 0-11 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| 12-18 | 1.0000 | 0.0000 | 0.0000 | 0.0000 |
| 19-24 | 0.9700 | 0.0266 | 0.0034 | 0.0000 |
| 25-34 | 0.7456 | 0.2392 | 0.0088 | 0.0064 |
| 35-44 | 0.4238 | 0.5466 | 0.0102 | 0.0194 |
| 45-54 | 0.3243 | 0.6250 | 0.0063 | 0.0444 |
| 55-64 | 0.2319 | 0.6967 | 0.0030 | 0.0684 |
| 65+ | 0.2237 | 0.5875 | 0.0009 | 0.1878 |

Gender-specific tables (MARRIAGE_PROB_MALE, MARRIAGE_PROB_FEMALE) are in the output file.

### Key Findings
- **Late marriage**: 74.6% of 25-34 are unmarried; majority only become married in 35-44 (54.7%)
- **Divorce rates are low** across all ages (<1.2%) — because the annual flow is used as stock proxy
- **Elderly women widowed at 6× rate of men** (30.2% vs 4.9% at 65+)
- **City variation exists**: 桃園 has highest 25-34 marriage rate (35.2% F), 台北 lowest (27.1% F)

## Technical Notes & Pitfalls

### ODS Parsing: odfpy Fails on Merged Cells
The odfpy library cannot read county name labels from merged cells in the `divorce_by_age.ods` file. All county cells show as empty strings. **Workaround**: Parse the ODS `content.xml` directly:
```python
import zipfile, re
with zipfile.ZipFile('/tmp/divorce_by_age.ods', 'r') as z:
    with z.open('content.xml') as f:
        content = f.read().decode('utf-8')
idx_113 = content.find('table:name="113年"')  # NOT table:table-name (common mistake)
end_idx = content.find('</table:table>', idx_113)
table_xml = content[idx_113:end_idx + 14]
row_parts = table_xml.split('<table:table-row')
```

### XML Attribute Name Pitfall
The table name attribute is `table:name="113年"`, NOT `table:table-name="113年"`. The latter will return -1.

### County Name Extraction
County names are in `<text:span>` elements within the first `<table:table-cell>` of each data row. Search by string match (e.g., `if '新北市' in part`), not by cell index, because LibreOffice generates thousands of empty repeated columns (up to `number-columns-repeated="16383"`) that odfpy enumerates but the text extraction fails on merged cells.

### Nation-wide Total vs County Sum
The national total row (containing "總計") is row 6 (0-indexed in the table XML). Its values include a "total" column (index 0 for M, index 12 for F) followed by 11 age-group columns. County rows have 26 values each: M-total + 11 M-age-groups + F-total + 11 F-age-groups = 24, plus 2 extra columns of notes.

### Age 19 Split
The ODS `<20` age group includes ages 0-19. To isolate age 19 for the 19-24 output group, use the population proportion:
```python
ratio_19 = age19_pop / total_under20_pop
divorce_19_data = under20_data * ratio_19
```

## Output File
`~/persona-db/marriage_prob_real.py` contains 3 tables:
- `MARRIAGE_PROB` — 男女合計
- `MARRIAGE_PROB_MALE` — 男性
- `MARRIAGE_PROB_FEMALE` — 女性

To use in `_generate_997.py`:
```python
from marriage_prob_real import MARRIAGE_PROB, MARRIAGE_PROB_MALE, MARRIAGE_PROB_FEMALE
```

## Computation Script
`/home/ubuntu/compute_marriage.py` — self-contained Python script that:
1. Fetches ODRP014 population data (from `/tmp/odrp014_all.json`)
2. Parses ODS divorce counts from `/tmp/divorce_by_age.ods`
3. Reads divorce rates from `/tmp/divorce_rate.csv`
4. Computes marriage status by county, outputs national tables
5. Prints county-level 25-34 comparison for all 22 counties
