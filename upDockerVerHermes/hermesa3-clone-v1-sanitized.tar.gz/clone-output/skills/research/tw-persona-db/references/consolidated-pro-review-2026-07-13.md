# 1069 Persona 全量常理驗證 — Consolidated Pro Review (2026-07-13)

**Source**: 6× deepseek-v4-pro sub-agents + programmatic cross-validation
**Coverage**: All 1069 personas, 6 chunks (~179 each)

## 六大模式歸納

### 🔴 模式 A：BG/PP 經濟語氣不一致（佔 REAL ~65%）
- bg 說「寬裕」「不用太省」「品質不錯」
- pp(gen_econ_context) 說「收入不高→要省着點」「生活壓力很大」
- **根因**: bg 和 pp 由不同模板池生成，未做交叉一致性校驗
- **修復**: `bg_pp_econ_tone` post-hoc fix — 掃描 bg 舒適短語 + econ_ctx 拮據信號 → 覆蓋 bg 短語
- **效果**: ~100 次修正 → 0 殘留

### 🔴 模式 B：未婚 + 小孩開銷模板（~20%）
- 未婚人設 bg 殘留「小孩的開銷很大」「小孩的教育費是最大開銷」
- **根因**: 模板池未綁定 `marriage=未婚` 條件
- **嚴重分級**: REAL(獨生子女) vs MINOR(有弟妹可解釋)
- **修復**: `unmarried_child_cost` post-hoc fix — 未婚 → 所有小孩開銷模板替換為中性
- **效果**: ~33 次修正 → 0 殘留

### 🔴 模式 C：Family_size ≠ Narrative（~10%）
- fs=1 但 bg 說「夫妻兩人生活」「一家三口」
- **根因**: 模板池未與 family_size 維度同步
- **修復**: `fs1_family_narrative` post-hoc fix — fs=1 + 夫妻/一家X口(無分居說明) → 替換
- **效果**: ~0 (HH_SINGLE_MARRIED 池已正確，只防漏)

### 🟡 模式 D：已婚 + fs=1 有配偶說明（ALL OK）
- ~47 筆，全部有配偶原因說明（分居/外派/在國外）
- 不需要修正 ✅

### 🟡 模式 E：低收入 + 高物價地區（ALL OK）
- ~55 筆，低收入 <3萬 住台北/新竹，bg 說壓力大是**真實寫照**
- 不需要修正 ✅

### 🟡 模式 F：學生 + 家庭經濟描述（ALL OK）
- ~35 筆，學生無收入但 bg 說「能省則省」= 家庭整體經濟態度
- 不需要修正 ✅

## 零觸發檢查（1069 筆中無違規）
- 未成年有收入 ✅
- 未成年非學生 ✅
- 學生+已婚 ✅
- 12-18 教育=大學 ✅

## 品質指標
| 指標 | 數值 |
|:-----|:----:|
| QA 20 rules | ✅ 全數通過 |
| 人口分佈偏差 | 全部 < 0.5% |
| 真矛盾（修正後） | ~0 筆（3 項 post-hoc 修正後） |
| 零問題 | ~670+ 筆 (63%) |

## 驗證工作流 Summary
1. `_generate_997.py (seed=42)` → 1069 personas
2. `qa_validate.py` → 20 rules pass
3. `gen_verification_report.py` → distribution stats
4. Split into 6 chunks (~179 each)
5. Dispatch 6× Pro sub-agents (deepseek-v4-pro) with 10 mechanical checks + REAL/OK/MINOR classification
6. Programmatic cross-validation (Chunk 2 false-positive correction)
7. 6-pattern consolidation → 3 post-hoc fixes implemented
8. Re-verify: 0 residual contradictions

## Known False-Positive Traps (Pro sub-agents)
- **地理 claim**: 宜蘭縣被 Pro 誤判為花東（實際是北部）
- **子字串陷阱**: 「沒有生小孩」含「小孩」但為否定 — 需 `bg.replace("沒有生小孩","")` 後檢查剩餘「小孩」
- **單字元假陽性**: 「女」匹配到「女性」intro text
- **「一個人住」≠「未婚」**: 配偶在外地一個人住是 married+fs=1 的正確描述
- **剛好夠 vs 寬裕**: 「剛好夠」(just enough) 不是「要省」(must save) — 分類要分開
