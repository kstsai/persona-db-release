# Political Stance Cross-Reference — `_generate_997.py`

## Architecture

Three layers of political stance assignment, evaluated in priority order:

### Layer 1: Occupation-Group Stance (highest priority)

`POLITICAL_STANCES_CROSS` dict, keyed by `(politics, occ_group)`.

**Occupation grouping** (`OCC_GROUP_MAP`):
- `科技金融`: 科技, 金融
- `專業`: 醫療, 教育, 公務
- `服務`: 服務
- `勞動`: 製造
- `自營`: 自營
- `學生`: 學生
- `退休家管`: 退休, 家管
- `其他`: 其他 (fallback)

**Total: 24 keys** (4 politics × 6 occ_groups that have entries — 無政治傾向 and 其他 have no cross-references, fall back to generic)

### Layer 2: Income-Aware Enrichment (30% chance)

Applied AFTER occ-group stance selection. Replaces the stance with an income-specific one at 30% probability.

- `HIGH_INCOME_STANCES`: triggered when `inc == ">8萬"`
- `LOW_INCOME_STANCES`: triggered when `inc in ("<3萬", "無收入")`

Only defined for 泛綠, 泛藍, 白/第三勢力 (無政治傾向 excluded by design).

### Layer 3: Generic Fallback

`POLITICAL_STANCES[pol]["stances"]` — 5 generic stances per leaning group. Used when:
- No occ-group key matches (無政治傾向, 其他)
- Income enrichment didn't fire

## Results

- **55 unique stance sentences** (was 20 before cross-referencing)
- **~60-70%** of non-minor personas get occ-specific stances
- **~15-20%** get income-enriched stances
- **~10-15%** fall back to generic stances (mostly 無政治傾向)

## Occ-Group Stance Themes

| Politics | 科技金融 | 專業 | 服務 | 勞動 | 自營 | 學生 | 退休家管 |
|----------|---------|------|------|------|------|------|---------|
| 泛綠 | Supply chain, TSMC, tech independence | Public services, welfare | Low wages, labor rights | Industry transition, job security | SME policy, tax reform | Housing, conscription | Long-term care, pensions |
| 泛藍 | Cross-strait trade, energy policy | Pension reform, govt competence | Inflation, check-and-balance | Trade war impact, energy prices | Business environment, tourism | Peace, conscription | Pension protection, nostalgia |
| 白/第三勢力 | Judicial reform, fiscal discipline | Process justice, KO case | Anti-blue-green, third way | Economic pragmatism | Govt efficiency, transparency | Housing,打破藍綠 | KO case, judicial independence |

## Adding New Stances

Add entries to `POLITICAL_STANCES_CROSS` with key `(politics, occ_group)` and a list of 2-3 stance strings. Keep stances:
- Relevant to the occ_group's lived experience
- Consistent with the politics' core position
- Concrete and specific, not generic slogans
- Written in Traditional Chinese
