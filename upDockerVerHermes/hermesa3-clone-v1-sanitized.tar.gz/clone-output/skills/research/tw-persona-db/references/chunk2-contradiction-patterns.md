# Chunk 2 Contradiction Patterns — TW-P-0180 ~ TW-P-0358 (179筆, 19-44歲)

> Generated 2026-07-13 via validate_chunk2_v2.py + validate_chunk2_final.py
> See `report_chunk2_validation.txt` for full output.

## Summary

| Category | Count | Primary Cause |
|----------|:-----:|---------------|
| **REAL** | **40** | — |
| OK | 15 | — |
| MINOR | 0 | — |

## REAL Breakdown by Check

### 🔴 Check 8: BG前後句矛盾 — 27 REAL (most in chunk)

| Sub-pattern | Count | Explanation |
|:------------|:-----:|:------------|
| 未婚/離婚說「小孩的開銷很大」 | **12** | bg模板從有家室角色複製，未清理 |
| bg拮据但prefix說生活輕鬆 | **7** | bg/prefix來自不同模板池，語調不一致 |
| 獨居但說「上有老下有小」 | **3** | 模板拼接殘留 |
| bg有壓力但prefix說收入不錯 | **2** | 同上，prefix模板樂觀化 |
| 夫妻兩人世界但說小孩開銷 | **1** | 矛盾句共存 |
| 「一個人租套房/自己一個人住」+「上有老下有小」 | **2** | 模板殘留 |

### 🔴 Check 1: 收入 vs 描述 — 13 REAL

| Sub-pattern | Count | Example Personas |
|:------------|:-----:|:-----------------|
| 收入<3萬但bg說「有些積蓄」「不用太省」 | **11** | TW-P-0203 小傑, TW-P-0218 小胖, TW-P-0232 小林, TW-P-0256 莉亞, TW-P-0262 愛莎, TW-P-0276 柔伊, TW-P-0305 世昌, TW-P-0324 福來, TW-P-0331 俊傑, TW-P-0351 淑娟 |
| 收入>8萬但prefix說拮据/手頭緊 | **2** | TW-P-0210 阿宏, TW-P-0294 瑞宏, TW-P-0309 正雄 |

Note: TW-P-0210 阿宏 and TW-P-0309 正雄 are double-counted (both from check 1 + check 8) because their bg says comfortable but prefix says tight.

## 🟡 OK Breakdown

### Check 3: 已婚+fs=1無配偶 — 11 OK

All 11 have explicit spouse-away explanations (分居/長期在國外/暫時分居/在外地工作):

| Persona | Explanation |
|:--------|:------------|
| TW-P-0225 小安 | 夫妻分居兩地，週末才見面 |
| TW-P-0268 可恩 | 配偶在外地工作 |
| TW-P-0270 小莉 | 配偶長期在國外 |
| TW-P-0278 菲菲 | 夫妻分居兩地 |
| TW-P-0301 建宏 | 配偶長期在國外 |
| TW-P-0310 明義 | 新婚但暫時分居 |
| TW-P-0326 協明 | 配偶在外地工作 |
| TW-P-0335 建宏 | 新婚但暫時分居 |
| TW-P-0342 強哥 | 配偶在外地工作 |
| TW-P-0349 淑貞 | 配偶在外地工作 |
| TW-P-0354 麗卿 | 新婚但暫時分居 |

### Check 8: 收入<3萬但有些積蓄還出國玩 — 4 OK

These are borderline — 有些積蓄 is technically possible with <3萬 income if the person has saved for years or had past savings, but it feels inconsistent with low-income status:

- TW-P-0203 小傑, TW-P-0262 愛莎, TW-P-0324 福來, TW-P-0331 俊傑

## Checks with 0 Findings (chunk 2 specific)

| Check | Reason |
|:------|:-------|
| 4. 未成年有收入 | No minors in this age range (19-44) |
| 5. 65+年輕子女 | No 65+ personas in this chunk |
| 6. 含飴弄孫+低收入+高物價 | No "含飴弄孫" in 19-44 age range |
| 7. 未成年非學生 | No minors |
| 9. 學生+已婚 | No students with non-未婚 marriage |
| 10. 12-18教育=大學 | No 12-18 personas |

## Cross-Chunk Comparison

| Pattern | Chunk 2 (19-44) | Chunk 3 (reported) | Chunk 4 (55-64/65+) | Chunk 6 (reported) |
|:--------|:----------------:|:-------------------:|:-------------------:|:------------------:|
| 收入矛盾: bg舒適→pre拮据 | 13 | ~13 | ~20 | 14 (refined) |
| 未婚說小孩開銷 | **12** (new) | — | — | — |
| 獨居+上有老下有小 | **3** | — | — | — |
| bg拮据→pre輕鬆 | 7 | ~12 | ~8 | 23 (raw) |
| 已婚+fs=1 (all OK) | 11 | — | ~8 | — |

**Key insight for chunk 2**: The dominant contradiction is **模板複製遺留** (未婚者bg殘留小孩開銷) rather than economic tone mismatch (which was chunk 3/6's dominant pattern). This suggests different root causes dominate in different age brackets — 19-44 age range has more "模板池汙染" from copying family-oriented templates into unmarried/single personas, while 35-54+ has more economic tone mismatches.

## Root Cause Analysis

1. **未婚者bg殘留「小孩的開銷很大」(12件)**: The household-expense template pool is shared across marriage states. Unmarried personas randomly draw from pools that contain child-expense phrases. Fix needs marriage-state gating on expense templates.

2. **bg舒適→pre拮据 (13件)**: Same `econ_by_tier()` variable-scoping bug documented in the main skill — `infer_background()` defaults to `inc_level="3-8萬"` unless `inc` is explicitly passed. The chunk 2 dataset covers all income levels, so the bug affects ~7% of personas regardless of age.

3. **獨居+上有老下有小 (3件)**: Template pool mixing — single-person housing descriptions (一個人租套房) and multi-generational household descriptions (上有老下有小) are from different pools but can land in the same persona. Pool-level co-occurrence gating needed.

## Verification Methodology

Used `validate_chunk2_v2.py` (comprehensive keyword matching) + `validate_chunk2_final.py` (final report generation with dedup and semantic classification).

Key improvements over chunk 6 methodology:
- Specific check for 「未婚/離婚說小孩開銷」 (not just 「獨居+小孩」)
- Specific check for 「bg有壓力但prefix說收入不錯」
- Better comfortable/tight phrase lists (including 「還算寬鬆」「生活品質還不錯」)
- Dedup by (check, pid, description prefix) to avoid double-counting
