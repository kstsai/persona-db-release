# Sub-Agent Review Methodology

A verification workflow established 2026-07-11 and refined through v2.0→v3.0: spawn a **DeepSeek V4 Pro** sub-agent to review stratified samples, then act on confirmed findings.

## ### Step 2: Spawn DeepSeek V4 Pro Review — 4-Category Framework

For v3.0+ (6 regions + 戸籍地), include a **4th category (D)** in the goal:

```python
goal=\"\"\"Analyze 96 samples for:
A. Distribution anomalies (age/occ/marriage/income mismatches)
B. Content/semantic reasonableness (Taiwan cultural context)
C. Prompt prefix naturalness (no code residue, no census-form language)
D. New dimension consistency: region↔residence match,
   residence distribution across regions,
   naturalness of \"住在都會區\"-style region labels\"\"\"
```

### Step 3: Verify Every Finding

⚠️ **Pro is not infallible.** On 2026-07-11 v3.0 review, Pro falsely flagged 宜蘭縣 as belonging to 花東. In reality, 宜蘭 is in 北部 (Northern Taiwan, not 花東 = Hualien/Taitung). The old 7-region system grouped 宜花東 together for population sampling, but the new 6-region system correctly places 宜蘭 in 北部.

**Verification gating:**
- Machine-verifiable (codes, patterns, counts): trust after 1-line script check
- Semantic/cultural (too young for 鰥寡, too old for 新婚): trust Pro directly — it's stronger than Flash at this
- Geography/hierarchy: double-check with web_search — Pro confused 宜蘭縣归属 in v3.0 review

### Step 4: Root Cause → Fix → QA Rule

Known design issue (v3.0, not yet fixed):
- **Region labels in prompt_prefix**: "XX是阿伯，住在都會區" is unnatural. Real people say their city, not a macro-region label. Future fix: use `residence` (dim 13) instead of `region` (dim 3) in prompt_prefix templates.

When to Use

- After regenerating the persona DB, to catch new types of issues QA rules don't cover
- Before presenting a deliverable, to catch flaws the user would spot immediately
- When you need "fresh eyes" on semantic coherence beyond what regression rules can check

## Workflow

### Step 1: Stratified Sampling (96 entries)

```bash
cd ~/persona-db
python3 sample_stratified.py
# → tw_persona_96_stratified.json (96 entries, 1 per region×age×sex combo)
# seed=42, 6 regions × 8 ages × 2 sexes
```

All 96 combos are guaranteed to have ≥1 persona in the full 997 DB (minimum population combos like 離島 have exactly 1). If a combo has 0 entries, the generation script's population model is misconfigured.

### Step 2: Spawn DeepSeek V4 Pro Review

```python
delegate_task(
    context="Persona DB is 16-dimension stratified population data... "
             "File: ~/persona-db/tw_persona_96_stratified.json... "
             "Language: Traditional Chinese (Taiwan)...",
    goal="""Analyze 96 samples for:
    A. Distribution anomalies (age/occ/marriage/income mismatches)
    B. Content/semantic reasonableness (Taiwan cultural context)
    C. Prompt prefix naturalness (no code residue, no census-form language)"""
)
```

**Important context hints to include** in the delegation:
- Mention the 6-region name system (都會區六都/北部/中部/南部/花東/離島)
- Mention the 戶籍地 dimension (22 city/county values)
- Mention known fixed issues so the Pro agent doesn't waste time re-reporting them
- Tell it to output in Traditional Chinese

### Step 3: Accept Findings (Pro Trust Level)

**Versus Flash findings** from 2026-07-11 comparison:

| Dimension | Flash (v4) | Pro (v4) |
|:----|:-----|:----|
| Analysis depth | Surface pattern matching | Semantic coherence reasoning |
| Cultural knowledge | Word-level rules | Knows "25-34 鰥寡 is extremely rare in Taiwan" |
| Background coherence | Single-sentence key words | Cross-sentence logical contradictions |
| False positive rate | Higher (flagged gender-neutral names) | Lower (only clear mismatches) |
| Unique find categories | ~9 | ~14 (5 more: background contradictions, 娘家 vs male, 東部 inconsistency, etc.) |

**Pro findings can be trusted without programmatic fact-checking** for most categories. For high-impact findings, single-line verification is sufficient (e.g., `grep "65+" tw_persona_96_stratified.json`).

### Step 4: Root Cause → Fix → QA Rule

For each confirmed issue, trace to source in `_generate_997.py`:
- **Template string**: prompt_prefix template A/B/C (∼lines 662-715)
- **Phrase pool**: `infer_background()` household/economics/life-stage pools (∼lines 428-591)
- **Probability table**: REGION_POP/EDU_PROB/OCC_PROB/MARRIAGE_PROB/etc (∼lines 13-230)
- **Coherence validation**: post-generation fix rules (∼lines 643-670)

Fix pattern: fix source → add QA rule (`qa_validate.py`) → regenerate → QA → sample → Pro review → if clean, commit.

## Config: Delegation Model

Set in `~/.hermes/config.yaml`:
```yaml
delegation:
  provider: custom:deepseek-pro
  model: deepseek-v4-pro
```

⚠️ **Pitfall**: `hermes config set` corrupts `custom_providers` YAML list into a JSON string. Use Python to write the config instead:
```python
import yaml
with open('/home/ubuntu/.hermes/config.yaml') as f:
    config = yaml.safe_load(f)
config['custom_providers'] = [
    {'name': 'Api.deepseek.com', ...},
    {'name': 'deepseek-pro', 'base_url': 'https://api.deepseek.com',
     'api_key': apikey, 'model': 'deepseek-v4-pro'},
]
with open('/home/ubuntu/.hermes/config.yaml', 'w') as f:
    yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
```

To revert to parent model: delete the delegation.provider/model keys:
```bash
hermes config set delegation.provider ""
hermes config set delegation.model ""
```

## 2026-07-11 Session Results (v2.0→v3.0)

### Round 1: v2.0 (112 samples, 7 regions)

First review (Flash) found: ~17 issues. Fact-check confirmed 14 true positives + 3 false positives.
Second review (Pro) found: ~14 categories including 5 the Flash missed entirely.

The Pro findings drove the v2.0 batch fixes: 65+歳→阿伯/阿姨、做退休→已經退休了、【】→自然語言、獨生子→獨生女、45+新婚不久 gate、25-34鰥寡 fix、0-11泡茶移除、娘家→老家(gender)、地點重複移除、missing household fallback.

### Round 2: v3.0 (96 samples, 6 regions + 戶籍地)

Pro review found 3 confirmed issues (after false-positive filtering):
1. **65+「新婚但暫時分居」** — `HH_SINGLE_MARRIED` pool had no age gate. Fix: `HH_SINGLE_MARRIED_SENIOR` pool. QA: R16.
2. **35-44「兒孫滿堂」** — `HH_FAM5_WIDOWED` pool had no age gate. Fix: `HH_FAM5_WIDOWED_YOUNG` pool. QA: R17.
3. **12-18 泡茶** — Young pool still had 0.02 泡茶. Fix: removed from young pool. QA: R18.

Pro also flagged region labels in prompt_prefix as unnatural. **Fixed in same session**: all 3 templates now use `residence` (city) instead of `region` (macro-label). Before: "住在都會區". After: "住南投縣".

### Round 3: v3.2 (same session, post-fix iteration)

Added 3 more systems after bugs were fixed:
1. **Price tier → economic phrase selection**: `econ_by_tier()` shifts ECON_TIGHT_BIGFAM/ECON_STRESSED/ECON_COMFORTABLE probability by city cost of living.
2. **Household income tier → family income**: `adjust_family_income_by_tier()` shifts FAMILY_INCOME_PROB by city household income.
3. **Economic context sentence**: `gen_econ_context()` appends income-vs-物价 sentence to prompt_prefix.

**Total QA rules after v3.2**: 18 (R1-R18).
