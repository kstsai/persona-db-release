# Survey Questionnaire Templates for Persona Role-Playing

Reusable survey templates designed for simulated persona surveys. Each template targets a specific business domain and covers shopping behavior, location preferences, and brand attitudes.

## Template 1: Drugstore / Health & Beauty Store Location (康是美/屈臣氏)

**Target personas**: Women 25-54, diverse cities, varied income and life stage.

```
Q1: 你目前最常去哪一類商店購買日常藥品、保健品或美妝保養品？
    （例如：康是美、屈臣氏、寶雅、藥局、量販店、網購）為什麼選這家？

Q2: 你住所或工作地點附近有康是美嗎？步行或騎車大概多久？
    你對目前的便利性滿意嗎？

Q3: 你覺得你居住的區域，還需要再多一家康是美嗎？
    如果需要，你覺得開在哪一區或哪種地點最適合？
    （例如：捷運站旁、學區、商圈、住宅區巷口）為什麼？

Q4: 如果家附近開了一家新的康是美，什麼因素會讓你願意走進去消費？
    （可複選或排序：價格優惠、商品齊全、離家近、店員專業、會員活動、品牌信任）

Q5: 你平均一個月花多少錢在藥妝/保健品/個人清潔用品上？
    對你來說，價格和方便性哪個更重要？

Q6: 你認為康是美和屈臣氏最大的差別是什麼？
    你比較偏好哪一家？為什麼？

Q7: 你最近一年有沒有因為「附近沒有想要的店」而放棄購買或轉買其他品牌的經驗？

Q8: 自由補充 — 對於康是美未來開店或服務，你有什麼建議或期待？
```

## Template 2: 3C / Electronics Store Location

**Target personas**: Men and women 19-44, tech/manufacturing/service occupations, urban areas.

```
Q1: 你最常在哪些通路購買3C產品或配件？（實體店面/網購/品牌官網）為什麼？

Q2: 你住所或工作地點附近有大型3C賣場嗎？（如燦坤、全國電子、三創）
    步行或騎車大概多久？

Q3: 你覺得你居住的區域，還需要再多一家3C專門店嗎？
    如果需要的話，你希望開在哪裡？（捷運共構、百貨公司、社區商圈）

Q4: 什麼因素會影響你選擇去哪一家3C店消費？
    （價格競爭力、商品種類、展示體驗、維修服務、停車方便性）

Q5: 你平均多長時間購買一次3C產品？單次消費金額大概多少？

Q6: 你對線上買3C和實體店買3C的偏好？為什麼？

Q7: 最近一年有沒有因為住家附近沒有特定品牌的體驗店，而放棄購買的經驗？

Q8: 對於3C通路未來開店或服務，你有什麼建議？
```

## Template 3: Supermarket / Grocery Expansion

**Target personas**: Married 25-64, household buyers, diverse income, urban and suburban.

```
Q1: 你目前最常去哪一類商店購買生鮮食品和日常雜貨？
    （全聯、家樂福、頂好、傳統市場、網購）為什麼？

Q2: 你住所附近有超市或量販店嗎？走路或騎車大概多久？便利性如何？

Q3: 你覺得你居住的區域需要再多一家超市嗎？
    如果需要，你覺得開在哪種地點最適合？（社區巷口、捷運站旁、大馬路邊）

Q4: 什麼因素最影響你選擇去哪家超市？
    （價格、距離、生鮮品質、停車方便、營業時間、品牌信任）

Q5: 你一個家庭平均一週花多少錢在生鮮和雜貨上？

Q6: 全聯和家樂福在你心中的差別是什麼？你比較偏好哪一家？

Q7: 附近如果新開一家超市，什麼活動或服務會吸引你第一次走進去？

Q8: 對於超市未來開店或服務，你有什麼建議？
```

## Template 4: Quick-Service Restaurant / Bubble Tea Chain

**Target personas**: Age 12-34 (with guardian proxy for minors), students and young workers.

```
Q1: 你多久喝一次手搖飲或外食？平均單次花費多少？

Q2: 你住家或學校/公司附近有____嗎？走路大概多久？

Q3: 如果附近新開一家____，什麼因素會讓你願意去試？
    （新品項、優惠活動、裝潢風格、排隊人潮、朋友推薦）

Q4: 你覺得你居住的區域還需要再多一家____嗎？
    如果需要，你覺得開在哪裡最適合？（學校旁、辦公區、捷運站、夜市）

Q5: 你對品牌的忠誠度高嗎？還是哪家近就去哪家？

Q6: 你認為____和其他品牌最大的差別是什麼？

Q7: 你願意為了喝到喜歡的飲料/餐點，多走幾分鐘路嗎？最多願意多走多久？

Q8: 對於____未來開店，你有什麼建議？
```

## Template 5: Banking Product Visibility (4-Question Battery)

**Target personas**: 11-persona diversity set (see references/bank-visibility-methodology.md).
**Purpose**: Measure LLM brand visibility across different banking product categories. Run as Mode ② encounter simulation.

These 4 questions test different dimensions of banking brand visibility:

```
Q1: 線上申請雙幣卡，哪家銀行的審核跟發卡速度最快？
    → Tests: dual-currency card, speed of issuance, online KYC, travel use
    → Likely winners: 中信(LINE Pay), 玉山(熊本熊), 台新(飛狗飛航)

Q2: 現在哪一家數位帳戶的活存利率最高，而且轉帳免手續費次數最多？
    → Tests: rate + fee sensitivity, digital account features
    → Done (see bank-visibility-methodology.md)

Q3: 綁定LINE Pay或街口支付，刷哪張聯名卡拿到的點數回饋最實用？
    → Tests: ecosystem integration, mobile payment card rewards
    → Key banks: 聯邦(LINE Bank), 中信(LINE Pay), 台新(@GoGo), 國泰(CUBE)

Q4: 哪一家銀行的行動網銀App介面最乾淨、最不會一直跳出不相關的推銷廣告？
    → Tests: mobile banking UX, subjectivity, brand sentiment
    → Key banks: 王道, 將來, LINE Bank, Richart, KOKO
```

### Cross-Scenario Analysis

After running all 4 questions through 11 personas, build a scenario × bank heatmap to reveal cross-product visibility:

```
| Bank       | Q1 雙幣卡 | Q2 活存 | Q3 聯名卡 | Q4 App | Avg |
|:-----------|:---------:|:-------:|:---------:|:------:|:---:|
| 台銀       |     %     | 🥇73%   |     %     |   %    |  %  |
| 將來銀行   |     %     | 🥈18%   |     %     |   %    |  %  |
| 中信       |     ?     |   0%    |     ?     |   %    |  %  |
| 玉山       |     ?     |   0%    |     ?     |   %    |  %  |
| 聯邦/LINE  |     %     |   0%    |     ?     |   %    |  %  |
```

## Usage Notes

1. **Tailor Q3-Q4 to the business decision**: Store location surveys should always include a "where" question with concrete location types relevant to the target city.
2. **Add Q6 (brand comparison) only** when the business has a known competitor in the market.
3. **Q7 (abandonment experience)**: This reveals unmet demand and is useful for expansion justification.
4. **Q8 (open-ended)**: Always include — persona responses often reveal needs the business hasn't considered.
5. **Translate to natural spoken Chinese**: Sub-agents should hear the question in the target language. For Traditional Chinese (Taiwan), use 台灣正體中文.
6. **3 personas is the ideal sample size** for a quick survey per batch (matches parallel sub-agent limit). For more statistical significance, run multiple batches with different persona selections.
7. **Banking Template 5**: Run all 4 questions through the same 11-persona set for cross-scenario comparability. Q2 is already benchmarked; Q1, Q3, Q4 are pending.
