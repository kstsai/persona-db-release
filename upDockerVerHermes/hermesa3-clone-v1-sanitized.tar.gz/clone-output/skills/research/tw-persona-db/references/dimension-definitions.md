# 14 Dimension Definitions — TW Persona DB

## 1. 年齡 Age

| Bracket | Label | Life Stage |
|---------|-------|------------|
| 0-11 | Child | Primary school |
| 12-18 | Teen | Middle/high school |
| 19-24 | Young Adult | University / early career |
| 25-34 | Prime | Career building |
| 35-44 | Mid-career | Family + peak earning |
| 45-54 | Established | Stable career, retirement planning |
| 55-64 | Pre-retirement | Transition phase |
| 65+ | Senior | Retirement |

Population distribution (national estimate): 0-11: 11%, 12-18: 7%, 19-24: 7%, 25-34: 14%, 35-44: 16%, 45-54: 16%, 55-64: 15%, 65+: 14%

## 2. 性別 Sex

- 男 (49.5%)
- 女 (50.5%)

## 3. 區域 Region

| Region | Pop% | Major Cities |
|--------|:----:|--------------|
| 北北基 | 30% | Taipei, New Taipei, Keelung |
| 桃竹苗 | 17% | Taoyuan, Hsinchu, Miaoli |
| 中彰投 | 19% | Taichung, Changhua, Nantou |
| 雲嘉南 | 14% | Yunlin, Chiayi, Tainan |
| 高屏 | 15% | Kaohsiung, Pingtung |
| 宜花東 | 4% | Yilan, Hualien, Taitung |
| 離島 | 1% | Penghu, Kinmen, Matsu |

## 4. 教育 Education

| Level | Age-dependent probability |
|-------|--------------------------|
| 國中以下 | High in 0-11 (100%) and 65+ (30%), low in 25-34 (2%) |
| 高中 | Peak in 12-18 (45%), declines with age to 30% at 65+ |
| 大學 | Peak at 19-24 (60%), stable through 35-44 (50%) |
| 研究所以上 | Peak at 25-34 (30%), declines with age |

## 5. 職業 Occupation

| Occupation | Typical Income | Age/Sex Profile |
|------------|---------------|-----------------|
| 學生 Student | 無收入 | 0-24 |
| 科技 Tech | >8萬 (50%) | 男 dominant, 25-44 peak |
| 服務 Service | 3-8萬 (50%) | Female leaning, all ages |
| 製造 Manufacturing | 3-8萬 (60%) | Male leaning, 35-54 peak |
| 教育 Education | 3-8萬 (60%) | Female leaning |
| 醫療 Medical | 3-8萬 (50%) | Female leaning |
| 公務 Civil Service | 3-8萬 (60%) | Stable across ages |
| 自營 Self-employed | 3-8萬/~>8萬 (40/40) | 35-54 peak |
| 家管 Homemaker | <3萬 (40%) | Female only, 35-64 |
| 退休 Retired | <3萬 (50%) | 55+ |
| 其他 Other | <3萬 (40%) | Fallback |

## 6. 收入 Income (Individual)

| Level | Typical Occupations |
|-------|-------------------|
| <3萬 | Service, Manufacturing, Student, Retired |
| 3-8萬 | Education, Civil Service, Medical |
| >8萬 | Tech, Finance, Self-employed |
| 無收入 | Student, Homemaker |

## 7. 政治傾向 Politics

| Leaning | Strong Regions | Issues |
|---------|---------------|--------|
| 泛綠 | 高屏 (45%), 雲嘉南 (40%) | 大罷免, 轉型正義, 國防自主 |
| 泛藍 | 桃竹苗 (35%), 宜花東 (35%) | 藍白合作, 兩岸交流, 經濟民生 |
| 白/第三勢力 | 北北基 (15%), 桃竹苗 (15%) | 柯文哲案, 司法獨立 |
| 無政治傾向 | 宜花東 (35%), 中彰投 (25%) | 民生, 物價, 無感 |

Age-gated: 0-11 and 12-18 always "無政治傾向"

## 8. 媒體習慣 Media Diet

| Type | Description | Peak Demographics |
|------|-------------|-------------------|
| 家長主導 | Parent-directed content consumption | 0-11 (55%) — NEW 2026-07-10 |
| 兒童內容為主 | Child-focused content (YouTube Kids, educational TV) | 0-11 (30%) — NEW 2026-07-10 |
| 傳統媒體為主 | TV/news broadcast primary | 65+ (70%), 55-64 (50%) |
| 社群為主 | Social media primary | 12-18 (70%), 19-24 (60%) |
| 混合 | Both traditional + social | 35-44 (40%), 25-34 (35%) |
| 國際來源 | International news sources | 25-34 (10%) |

## 9. 家庭口數 Family Size

Real Taiwan data (ODRP025): 1人: 41.8%, 2人: 21.3%, 3人: 17.2%, 4人: 11.8%, 5+: 7.9%

Age-adjusted: Elderly skew single (45%), children/families skew 3-5+

## 10. 家庭可支配所得 Family Income

| Level | Description | Typical |
|-------|-------------|---------|
| <1萬 | Very tight | Large families with low individual income |
| 1-3萬 | Tight | Students, service workers |
| 3-7萬 | Comfortable | Most middle-class families |
| 7萬 | Well-off | Dual-income tech/finance families |
| 百萬 | High-income | Senior tech executives, successful business owners — NEW 2026-07-10 |

## 11. 興趣嗜好 Hobby

Age-group pools:
- **kid** (0-11): 打電動, 球類, 閱讀, 追劇, 繪畫
- **young** (12-34): 打電動, 追劇, 球類, 閱讀, 登山, 逛街購物, 烹飪, 游泳
- **adult** (35-54): 追劇, 登山, 閱讀, 球類, 逛街購物, 園藝, 烹飪
- **senior_m** (55+): 閱讀, 登山, 泡茶, 追劇, 園藝, 下棋
- **senior_f** (55+): 追劇, 閱讀, 園藝, 逛街購物, 登山, 泡茶, 烹飪

Per-persona: 2-3 hobbies drawn with replacement, with occupation-based bias (tech→打電動, education→閱讀)

## 12. 婚姻狀況 Marriage

| Age | Unmarried | Married | Divorced | Widowed |
|-----|:---------:|:-------:|:--------:|:-------:|
| 0-18 | 100% | — | — | — |
| 19-24 | 88% | 11% | 1% | — |
| 25-34 | 40% | 50% | 8% | 2% |
| 35-44 | 15% | 65% | 15% | 5% |
| 45-54 | 8% | 65% | 18% | 9% |
| 55-64 | 5% | 60% | 15% | 20% |
| 65+ | 3% | 45% | 7% | 45% |

## 13. 政治立場 Political Stance

Five stances per leaning group:
- **泛綠**: 支持大罷免, 認同執政黨路線, 關注社會正義, 反對藍白合作, 支持台灣主權
- **泛藍**: 反對大罷免, 支持藍白合作, 批評執政黨, 關注經濟兩岸, 支持兩岸和平交流
- **白/第三勢力**: 柯文哲案政治迫害, 司法程序應公正, 厭惡藍綠惡鬥, 關注司法獨立, 超越藍綠
- **無政治傾向**: 政治無興趣, 藍綠一樣爛, 看政績不看黨派, 在意物價, 新聞亂報

## 14. 政治議題 Political Issues

2 issues per persona, sampled from their leaning's issue pool:
- 泛綠: 大罷免, 轉型正義, 國防自主, 社會福利
- 泛藍: 藍白合作, 兩岸交流, 經濟民生, 反對大罷免
- 白/第三勢力: 柯文哲案, 司法獨立, 第三勢力, 超越藍綠
- 無政治傾向: 民生, 物價, 無感
