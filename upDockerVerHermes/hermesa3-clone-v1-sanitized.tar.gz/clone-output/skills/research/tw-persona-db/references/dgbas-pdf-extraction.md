# DGBAS PDF Extraction via Pro Sub-Agent

## Technique: Extract Government Statistics from PDF

Used to obtain real OCC_PROB data from the 2024 Manpower Survey (113年人力資源調查統計年報).

## Process

1. **Find the source URL** on the DGBAS/stat.gov.tw website (table listing page → EXCEL/ODS links or PDF download)
2. **Download via curl**:
   ```bash
   curl -sk -o /tmp/report.pdf -w "HTTP %{http_code} Size %{size_download}" --max-time 30 "URL"
   ```
   Use `-sk` (skip SSL verification) for government servers with certificate issues.
3. **Spawn a Pro sub-agent** with:
   - Context pointing to the downloaded PDF path
   - Goal: install pdfplumber, extract the specific table, map categories to persona dimensions, output a Python dict
4. The sub-agent handles: `pip install pdfplumber` → parse PDF → locate table → extract → map → write to file

## Known Government Data Sources

| Source | URL Pattern | Content |
|--------|-------------|---------|
| 人力運用調查 (Manpower Utilization) | `ws.dgbas.gov.tw/001/Upload/463/ebook/ebook_XXXXX/pdf/full.pdf` | Employment type, income, work patterns |
| 人力資源調查 (Labor Force Survey) | `ws.dgbas.gov.tw/001/Upload/463/relfile/XXXXX/XXXXX/mtableXX.xlsx` | Occupation × Age × Sex tables |
| 家庭收支調查 (Family Income/Expenditure) | `ws.dgbas.gov.tw/001/Upload/466/ebook/ebook_XXXXX/pdf/full.pdf` | Household income, consumption by city |

## Pitfalls

- **SSL certificate issues**: Many government servers have expired/invalid certs. Always use `curl -sk` not `curl -s`.
- **PDF not table-based**: Some reports embed tables as images, not extractable text. The pdfplumber approach only works for text-based PDFs.
- **OTF/ODS files**: Government provides both Excel (.xlsx) and ODF (.ods) formats. If one fails, try the other.
- **Server rate limiting**: DGBAS servers sometimes return 504 for repeated requests. Add delays between downloads.
- **Table location varies**: Tables in the full PDF report use different numbering than the individual Excel table files. Cross-reference between the two.
- **CORS blocking**: Direct browser access may redirect to a different URL than what curl receives. Check HTTP response headers.

## Cost

A full PDF extraction task (15MB PDF, ~50 pages of tables) costs approximately:
- ~50 API calls (Pro model)
- ~2-3 minutes wall-clock time
- ~$0.15-0.25 in token cost
