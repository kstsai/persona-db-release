# DGBAS 2024 Manpower Survey — Occupation by Age & Sex (Table 47)

> Created 2026-07-12. Replaces the stale listing in SKILL.md's file table (which referenced this path but never existed).

## Data Source

**113年人力資源調查統計年報** (Manpower Resource Survey Annual Report, 2024), NOT the 人力運用調查 (Manpower Utilization Survey).

- **Publication**: 行政院主計總處 DGBAS
- **Table**: 表47 就業者之教育程度與年齡—按職業分
  (TABLE 47. EMPLOYED PERSONS BY EDUCATIONAL ATTAINMENT, AGE, AND OCCUPATION)
- **Data period**: October 2024 (民國113年)
- **Unit**: Thousand Persons (千人)
- **Download**: https://ws.dgbas.gov.tw/001/Upload/463/relfile/11516/234727/table47.xlsx

### Why not the Manpower Utilization Survey PDF?

The `/tmp/manpower_full.pdf` (15MB, 人力運用調查報告) does NOT contain occupation×age×sex cross-tabulations. It is a supplementary survey focused on income, working patterns, atypical employment, etc. The basic demographic cross-tabulation (occupation × age × sex) is only available in the main 人力資源調查統計年報.

## Table Layout

The Excel file (table47.xlsx) has this column structure:

| Col | Content | Notes |
|:---:|---------|-------|
| 1 | (blank) | Row labels column |
| 2 | Item | Occupation name |
| 3 | Total employed (千人) | |
| 4-11 | Education breakdown | 國小及以下, 國中, 高中, 專科, 大學, 研究所 |
| **13** | **15-24 合計** | |
| **14** | **15-19** | |
| **15** | **20-24** | |
| **16** | **25-44 合計** | |
| **17** | **25-29** | |
| **18** | **30-34** | |
| **19** | **35-39** | |
| **20** | **40-44** | |
| **21** | **45-64 合計** | |
| **22** | **45-49** | |
| **23** | **50-54** | |
| **24** | **55-59** | |
| **25** | **60-64** | |
| **26** | **65+** | |

Row structure:
| Row | Content |
|:---:|---------|
| 13 | 總計 Total (employed, all occupations) |
| 14 | 民意代表/主管/經理人員 |
| 15 | 專業人員 |
| 16 | 技術員及助理專業人員 |
| 17 | 事務支援人員 |
| 18 | 服務及銷售工作人員 |
| 19 | 農林漁牧業生產人員 |
| 20 | 技藝/機械操作/勞力工 |
| 21 | 男 小計 (Male subtotal) |
| 22-28 | Male × occupation (same order as 14-20) |
| 29 | 女 小計 (Female subtotal) |
| 30-36 | Female × occupation (same order as 14-20) |

## Occupation Category Mapping

DGBAS has 7 standard occupation categories (大分類). Mapping to persona dimensions:

| DGBAS Category | Persona Dimensions | Split |
|----------------|-------------------|-------|
| 民意代表/主管/經理人員 | 自營, 公務 | 0.55 / 0.45 |
| 專業人員 | 科技, 醫療, 教育 | 0.35 / 0.25 / 0.40 |
| 技術員及助理專業人員 | 科技, 製造 | 0.55 / 0.45 |
| 事務支援人員 | 公務, 服務 | 0.45 / 0.55 |
| 服務及銷售工作人員 | 服務 | 1.0 |
| 農林漁牧業生產人員 | 製造 | 1.0 |
| 技藝/機械操作/勞力工 | 製造 | 1.0 |

**Note**: 金融 (Finance) does NOT exist as a separate DGBAS occupation category. It was an invented dimension in the original estimated OCC_PROB. Finance workers are a subset of 專業人員/事務支援/服務及銷售, and their proportion is small (< 3% of total employed). The OCC_CITY_BOOST for 台北市→金融 is a heuristic approximation.

## Key Findings for OCC_PROB (vs Old Estimate)

| Dimension | Old Estimate | Real Data | Direction |
|-----------|:-----------:|:---------:|:---------:|
| 製造 (overall share) | 15-25% | **35-49%** | ↑ was the single largest occupation group |
| 科技 | 25-30% (25-34M) | **16%** | ↓ Professionals+Technicians combined |
| 自營 | 10-20% | **1-3%** | ↓ Legislators/Managers are a tiny group |
| 金融 | 5-10% | **0%** | ↑ Does not exist as DGBAS category |
| 家管 55-64F | 20% | **43%** | ↑ Many middle-aged women not in labor force |
| 退休 65+F | 85% | **28%** | ↓ Most elderly women are 家管, not formally retired |

## Computed OCC_PROB

The generated probability table lives at:
`~/persona-db/occ_prob_real.py`

This file contains the full OCC_PROB dict computed from Table 47 data, with employment-to-population ratios applied to add non-employment categories (學生, 退休, 家管).

### Employment-to-Population Ratios (employed ÷ estimated total population)

These are NOT labor force participation rates (which include the unemployed). They reflect the proportion of each age/sex group that is actually employed.

| Age | Male | Female |
|:---:|:----:|:------:|
| 19-24 | 0.540 | 0.528 |
| 25-34 | 0.920 | 0.842 |
| 35-44 | 0.937 | 0.817 |
| 45-54 | 0.885 | 0.717 |
| 55-64 | 0.642 | 0.386 |
| 65+ | 0.145 | 0.062 |

### Non-Employment Assignment

| Age | Male | Female |
|:---:|:----:|:------:|
| 19-24 | 學生 (100%) | 學生 (100%) |
| 25-54 | 其他 (100%) | 家管 75%, 其他 25% |
| 55-64 | 退休 85%, 家管 15% | 家管 70%, 退休 30% |
| 65+ | 退休 85%, 家管 15% | 家管 70%, 退休 30% |

## Usage

To replace the estimated OCC_PROB in `_generate_997.py`:

```bash
cd ~/persona-db
# Option A: Copy the pre-computed table into _generate_997.py
python3 -c "
# Read occ_prob_real.py and inject into the right location in _generate_997.py
"

# Option B: Import directly (edit _generate_997.py to import from occ_prob_real)
```

See `occ_prob_real.py` for the exact dict values. Each entry sums to 1.0.

## Related Files in Project

- `~/persona-db/occ_prob_real.py` — The computed OCC_PROB table (Python dict, ready to copy/paste)
- `/tmp/gen_occ_prob_final.py` — The generation script that produced it (from Excel source)
- `/tmp/table47.xlsx` — Raw DGBAS Excel data
