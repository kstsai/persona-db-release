#!/usr/bin/env python3
"""
build_appliance.py — 打包甲方可自部署的 persona DB appliance（分身）

用法:
    python3 build_appliance.py                          # 自動版號（從 VERSION）
    python3 build_appliance.py --version v3.2            # 指定版號
    python3 build_appliance.py --with-api                # 含簡易 API server
    python3 build_appliance.py --dry-run                 # 試跑，不產檔案

輸出: persona-appliance-v3.2.zip

Core architecture:
  - Strips internal files (_generate_997.py, qa_validate.py, etc.)
  - Generates README.md + FAQ.md for client
  - Produces simplified SKILL.md (no internal iteration detail)
  - Optional Flask API wrapper for HTTP access
  
See the parent SKILL.md §"Business Operations — Client Delivery via Qualified Memory" for full workflow.
"""

import argparse
import json
import os
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

HOME = Path.home()
PERSONA_DIR = Path("~/persona-db")
SKILL_DIR = HOME / ".hermes" / "skills" / "research" / "tw-persona-db"
OUTPUT_DIR = Path("~/persona-db/releases")
VERSION_FILE = PERSONA_DIR / "VERSION"

CORE_DATA = ["tw_persona_1069.json", "population_by_region_age_sex_2025.csv",
             "tw-persona-db-rfc.md", "qualified-memory.md", "VERSION"]
TOOLS = ["query_persona.py", "sample_stratified.py"]
EXCLUDE = {"_generate_997.py", "qa_validate.py", "export_qualified_memory.py",
           "BUSINESS-MODEL.md", "MILESTONE-v3.0.md", "MILESTONE_v0.1.md",
           "analysis_report_112.md", "stats_report.py", "stats_report_20260710.md",
           "persona_childcare_card.json", "_debug_api.py", "_fetch_family_size.py",
           "_find_top10.py", "etlPopulation.py", "marriage_prob_real.py", "occ_prob_real.py",
           "ris-opendata-apidoc.json", "tw_persona_997.json", "tw_persona_112_stratified.json",
           "tw_persona_prototype_001_v3.json", "tw_persona_prototype_002_engineer.json",
           "tw_persona_top10.json", "appliance-checklist.md"}

INCLUDE_REFS = ["dimension-definitions.md", "name-pool-architecture.md",
    "economic-context-sentences.md", "city-occupation-boost.md",
    "household-income-by-city.md", "residence-price-index.md",
    "language-standards.md", "price-consumption-data.md",
    "qualified-memory-convention.md", "qualified-memory.md",
    "96-sample-v3-review-2026-07-11.md"]

INCLUDE_SCRIPTS = ["persona_review.py", "verify_economic_tone.py", "persona_contradiction_check.py"]


def read_version() -> str:
    v = VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "v3.0"
    return v.lstrip("v")


def write_readme(ver: str) -> str:
    return f"""# TW Persona DB — Appliance v{ver}

> 1069 筆台灣人設資料庫查詢工具
> 產出日期: {datetime.now().strftime('%Y-%m-%d')}

## 這是什麼

1069 筆人口加權台灣人設資料庫 + CLI 查詢工具。18 維度結構化資料。

## 快速開始

```bash
unzip persona-appliance-v{ver}.zip -d ~/persona-db/
cd ~/persona-db
python3 tools/query_persona.py --residence 台北市 --age 35-44 --occupation 科技
python3 tools/query_persona.py --list-dimensions
```

見 FAQ.md 和 qualified-memory.md 了解已知限制。
"""


def write_faq() -> str:
    return """# FAQ

## Q: 查詢回 0 筆？→ 放寬條件（人口加權限制，見 qualified-memory.md）
## Q: 台北市多、離島少？→ 真實人口比例
## Q: 資料準嗎？→ 年齡誤差 ≤0.3%、區域 ≤0.4%、QA 20/20
## Q: 可以自己加資料？→ 可，建議備份原始檔
## Q: 何時找 Kuo-Shou？→ major upgrade、新增維度、系統性錯誤
"""


def build_appliance(version: str, with_api: bool = False, dry_run: bool = False):
    if dry_run:
        print(f"[DRY RUN] persona-appliance-v{version}.zip")
        return None
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = OUTPUT_DIR / f"persona-appliance-v{version}.zip"
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        (tmp / "README.md").write_text(write_readme(version), encoding="utf-8")
        (tmp / "FAQ.md").write_text(write_faq(), encoding="utf-8")
        (tmp / "VERSION").write_text(f"v{version}\n")
        d = tmp / "data"; d.mkdir()
        for f in CORE_DATA:
            s = PERSONA_DIR / f
            if s.exists(): shutil.copy2(s, d / f)
        t = tmp / "tools"; t.mkdir()
        for f in TOOLS:
            s = PERSONA_DIR / f
            if s.exists(): shutil.copy2(s, t / f)
        isrc = PERSONA_DIR / "auto-import-qualified.sh"
        if isrc.exists(): shutil.copy2(isrc, t / "auto-import-qualified.sh")
        smp = tmp / "samples"; smp.mkdir()
        sk = tmp / "skills" / "tw-persona-db"
        sk.mkdir(parents=True)
        if SKILL_DIR.exists():
            skill_src = SKILL_DIR / "SKILL.md"
            if skill_src.exists():
                sc = skill_src.read_text()
                for skip in ["Sub-agent Finding Verification", "### Consistency Enforcement",
                             "### Variable Scoping", "### Chinese Semantic Tone",
                             "### Realism Enforcement", "## Deployed Configuration",
                             "## Privacy Model", "## User's Quality Standards", "## Quick Start"]:
                    sc = sc.split(skip)[0] + ("<!-- stripped -->" if skip in sc else "")
                (sk / "SKILL.md").write_text(sc)
            refs = sk / "references"; refs.mkdir()
            for r in INCLUDE_REFS:
                p = SKILL_DIR / "references" / r
                if p.exists(): shutil.copy2(p, refs / r)
            scrs = sk / "scripts"; scrs.mkdir()
            for s in INCLUDE_SCRIPTS:
                p = SKILL_DIR / "scripts" / s
                if p.exists(): shutil.copy2(p, scrs / s)
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for f in tmp.rglob("*"):
                if f.is_file(): zf.write(f, f.relative_to(tmp))
    print(f"✅ persona-appliance-v{version}.zip ({zip_path.stat().st_size/1024:.0f} KB)")
    return zip_path


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--version")
    p.add_argument("--with-api", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    a = p.parse_args()
    v = a.version or read_version()
    build_appliance(v, a.with_api, a.dry_run)
