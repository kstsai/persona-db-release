#!/usr/bin/env python3
"""
TW Persona DB — Deep Semantic Review (pass 2 after automated checks)
Usage: python3 scripts/persona_review_deep.py [path/to/tw_persona_XXX.json]

Covers checks that require semantic understanding:
- background_story internal coherence (3-sentence consistency)
- background_story vs prefix economic sentence contradiction
- "寬裕" vs actual income mismatch
- Duplicate sentences in background_story
- Age-appropriate descriptions in prefix
"""
import json, sys, os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PATH = os.path.join(SCRIPT_DIR, "..", "tw_persona_112_stratified.json")
path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PATH

with open(path) as f:
    data = json.load(f)

print("=" * 60)
print("🔍 Deep Semantic Review — Pass 2")
print("=" * 60)

# --- 1. Background_story internal contradictions ---
print("\n\n### 1. Background_story 內部矛盾")
for item in data:
    d = item["dimensions"]
    pid = item["id"]; name = item["name"]
    bg = d.get("background_story", "")
    
    if "沒有生小孩" in bg and "小孩" in bg:
        print(f"  {pid}/{name}: 說「沒有生小孩」但提到「小孩」 → {bg}")
    if "夫妻兩人世界" in bg and "小孩" in bg and "教育費" in bg:
        print(f"  {pid}/{name}: 說「夫妻兩人世界」但提「小孩教育費」 → {bg}")
    sents = [s.strip().rstrip("。") for s in bg.split("。") if s.strip()]
    for i, s in enumerate(sents):
        for j in range(i+1, len(sents)):
            if s == sents[j]:
                print(f"  {pid}/{name}: background_story 重複句子「{s}」")

# --- 2. Background vs prefix economic contradiction ---
print("\n\n### 2. Background_story vs Prefix 經濟句矛盾")
for item in data:
    d = item["dimensions"]
    pid = item["id"]; name = item["name"]
    bg = d.get("background_story", "")
    prefix = item.get("prompt_prefix", "")
    age = d["age"]
    if age in ("0-11", "12-18"):
        continue
    bg_easy = "寬裕" in bg or "手頭還算寬鬆" in bg or "生活品質還不錯" in bg
    prefix_tight = "省著點" in prefix or "生活壓力" in prefix or "不太夠用" in prefix
    bg_tight = "手頭緊" in bg or "入不敷出" in bg or "喘不過氣" in bg or "算清楚" in bg or "壓力大" in bg
    prefix_easy = "還不錯" in prefix and "不用太省" in prefix
    if bg_easy and prefix_tight:
        print(f"  {pid}/{name}: background說寬裕但prefix偏緊")
        print(f"    bg: {bg}")
    if bg_tight and prefix_easy and not prefix_tight:
        print(f"  {pid}/{name}: background說手頭緊但prefix偏鬆")
        print(f"    bg: {bg}")

# --- 3. Low income + "寬裕" mismatch ---
print("\n\n### 3. 低收入 + 「寬裕」矛盾")
for item in data:
    d = item["dimensions"]
    pid = item["id"]; name = item["name"]
    income = d["income"]
    bg = d.get("background_story", "")
    if income in ("<3萬", "<1萬") and "寬裕" in bg:
        print(f"  {pid}/{name}: 收入{income}但background說「寬裕」 → {bg}")

# --- 4. Prefix school level vs education ---
print("\n\n### 4. Prefix「國中/高中」稱謂 vs education 不一致")
for item in data:
    d = item["dimensions"]
    pid = item["id"]; name = item["name"]
    prefix = item.get("prompt_prefix", "")
    edu = d["education"]
    age = d["age"]
    if age in ("12-18", "0-11"):
        if "國中" in prefix and edu == "高中":
            print(f"  {pid}/{name}: prefix稱「國中」但education=高中")
        if "高中" in prefix and edu == "國中以下":
            print(f"  {pid}/{name}: prefix稱「高中」但education=國中以下")

# --- 5. Missing economic context for adults ---
print("\n\n### 5. Prefix缺少經濟脈絡句（成人、非學生）")
for item in data:
    d = item["dimensions"]
    pid = item["id"]; name = item["name"]
    prefix = item.get("prompt_prefix", "")
    age = d["age"]; occ = d["occupation"]
    if age not in ("0-11", "12-18") and occ != "學生":
        sentences = [s.strip() for s in prefix.split("。") if s.strip()]
        econ_kw = ["收入","算著花","省著點","不用太省","過得滿舒服","生活壓力","物價太高","不太夠用"]
        if not any(any(k in s for k in econ_kw) for s in sentences):
            print(f"  {pid}/{name}: {age}/{occ} prefix無經濟句 → {prefix[:100]}")

print("\n\n✅ Deep review complete.")
