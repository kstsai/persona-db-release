#!/usr/bin/env python3
"""
Chunk-level persona validation: 10 mechanical checks + REAL/OK/MINOR classification.

Usage:
    python3 scripts/verify_chunk3.py /path/to/chunk.json

Checks performed:
  1. 收入 vs 描述 — low-income (<3萬) with comfortable bg, or high-income (>8萬) with tight bg
  2. 獨居+小孩 — family_size=1 mentioning children without spouse context
  3. 已婚+fs=1無配偶 — married + alone + no spouse mention in narrative
  4. 未成年有收入 — age 0-18 with income > 無收入
  5. 65+年輕子女 — 65+ describing young children's expenses
  6. 含飴弄孫+低收入+高物價 — 含飴弄孫 + <3萬 + high price tier combo
  7. 未成年非學生 — age 0-18 with non-student occupation
  8. BG前後句矛盾 — internal contradictions in background_story
  9. 學生+已婚 — student with non-未婚 marriage
  10. 12-18教育=大學 — age 12-18 with university education

Output: per-check summary (REAL/OK/MINOR counts) + detailed REAL list + trend analysis.
"""
import json, sys, re

def s(d, k, default=""):
    return str(d.get(k, default))

def income_val(income_str):
    m = re.search(r'[<>]?(\d+(?:\.\d+)?)萬', income_str)
    if not m:
        return None
    v = float(m.group(1))
    if income_str.startswith('<'):
        return v * 0.5
    if income_str.startswith('>'):
        return v * 1.5
    if income_str.startswith('3-8'):
        return 5.5
    if income_str.startswith('1-3'):
        return 2.0
    if income_str.startswith('3-7'):
        return 5.0
    if income_str.startswith('7'):
        return 7.0
    return v

# ---- Check 1: 收入 vs 描述 ----
def check_1(p):
    findings = []
    dim = p.get("dimensions",{})
    inc, bg, pp = s(dim,"income"), s(dim,"background_story"), s(p,"prompt_prefix")
    inc_v, pt = income_val(inc), s(dim,"price_tier")
    low_comfort = ["寬裕", "不用太省", "手頭還算寬鬆"]
    if inc_v is not None and inc_v < 3:
        if any(kw in bg for kw in low_comfort):
            findings.append(("REAL", f"收入{inc}但背景說「寬裕/不用太省/手頭寬鬆」"))
        if not any(kw in bg for kw in low_comfort):
            if "高" in pt:
                findings.append(("OK", f"收入{inc}+物價{pt}，低收高物價地區合理"))
    if inc_v is not None and inc_v > 8:
        if any(kw in pp for kw in ["要省", "壓力很大", "不夠用"]):
            findings.append(("REAL", f"收入{inc}但pp說「要省/壓力大/不夠用」"))
    return findings

# ---- Check 2: 獨居+小孩 (uses regex to avoid "女" in "女性" false positives) ----
def check_2(p):
    findings = []
    dim = p.get("dimensions",{})
    fs, bg, pp, mar = s(dim,"family_size"), s(dim,"background_story"), s(p,"prompt_prefix"), s(dim,"marriage")
    if fs == "1":
        kid_pats = [r'小孩(?!子)', r'孩子', r'育兒', r'養小孩']
        has_kid = any(re.search(k, bg) for k in kid_pats) or any(re.search(k, pp) for k in kid_pats)
        if has_kid and "上有老下有小" not in bg:
            if mar == "未婚":
                findings.append(("REAL", "family_size=1+未婚但背景提到小孩"))
            else:
                findings.append(("OK", "family_size=1+已婚姻提到小孩，分居可解釋"))
    return findings

# ---- Check 3: 已婚+fs=1無配偶 ----
def check_3(p):
    findings = []
    dim = p.get("dimensions",{})
    fs, bg, pp, mar = s(dim,"family_size"), s(dim,"background_story"), s(p,"prompt_prefix"), s(dim,"marriage")
    if mar == "已婚" and fs == "1":
        spouse_kw = ["配偶", "另一半", "老公", "老婆", "先生", "太太", "丈夫", "妻子", "分居", "新婚"]
        if any(kw in bg or kw in pp for kw in spouse_kw):
            findings.append(("OK", "已婚+fs=1，有分居/新婚說明，可解釋"))
        else:
            findings.append(("REAL", "已婚+fs=1但背景未提及配偶"))
    return findings

# ---- Check 4: 未成年有收入 ----
def check_4(p):
    findings = []
    dim, age, inc = p.get("dimensions",{}), s(p.get("dimensions",{}),"age"), s(p.get("dimensions",{}),"income")
    m = re.match(r'(\d+)-(\d+)', age)
    if m and int(m.group(2)) < 18 and inc not in ("無收入", "0", ""):
        findings.append(("REAL", f"年齡{age}未成年但有收入「{inc}」"))
    return findings

# ---- Check 5: 65+年輕子女 ----
def check_5(p):
    findings = []
    dim, age, bg, pp = p.get("dimensions",{}), s(p.get("dimensions",{}),"age"), s(p.get("dimensions",{}),"background_story"), s(p,"prompt_prefix")
    m = re.match(r'(\d+)-(\d+)', age)
    if m and int(m.group(1)) >= 65:
        if re.search(r'小孩(?!子)', bg) or re.search(r'小孩(?!子)', pp):
            if not any(k in bg+pp for k in ["子女", "兒女"]):
                findings.append(("MINOR", "65+用「小孩」而非「子女」，文編不精準"))
    return findings

# ---- Check 6: 含飴弄孫+低收入+高物價 ----
def check_6(p):
    findings = []
    dim = p.get("dimensions",{})
    inc, bg, pt = s(dim,"income"), s(dim,"background_story"), s(dim,"price_tier")
    if "含飴弄孫" in bg and income_val(inc) is not None and income_val(inc) < 3 and "高" in pt:
        findings.append(("OK", "含飴弄孫+低收入+高物價，可為老人願望"))
    return findings

# ---- Check 7: 未成年非學生 ----
def check_7(p):
    findings = []
    dim, age, occ = p.get("dimensions",{}), s(p.get("dimensions",{}),"age"), s(p.get("dimensions",{}),"occupation")
    m = re.match(r'(\d+)-(\d+)', age)
    if m and int(m.group(2)) <= 18 and occ not in ("學生", "", "0"):
        findings.append(("REAL", f"年齡{age}未成年但職業為「{occ}」"))
    return findings

# ---- Check 8: BG前後句矛盾 ----
def check_8(p):
    findings = []
    dim = p.get("dimensions",{})
    bg, pp, mar = s(dim,"background_story"), s(p,"prompt_prefix"), s(dim,"marriage")
    # 8a: 未婚+獨生女+小孩開銷 → REAL
    if mar == "未婚" and "獨生女" in bg:
        if "小孩的開銷" in bg or "小孩的教育費" in bg:
            findings.append(("REAL", "未婚+獨生女但bg說小孩開銷"))
    # 8b: 未婚+非獨生+小孩開銷無上下文 → MINOR
    if mar == "未婚" and "獨生女" not in bg:
        if ("小孩的開銷" in bg or "小孩的教育費" in bg) and not any(k in bg for k in ["弟妹", "兄弟姐妹", "姪", "甥"]):
            findings.append(("MINOR", "未婚但bg說小孩開銷，未說明對象"))
    # 8c: bg說寬裕/不用太省但pp說要省/壓力大 → REAL
    if ("寬裕" in bg or "不用太省" in bg) and ("要省" in pp or "壓力" in pp):
        findings.append(("REAL", "bg說寬裕/不用太省但pp說要省/壓力大"))
    if "手頭還算寬鬆" in bg and ("要省" in pp or "壓力" in pp):
        findings.append(("REAL", "bg說手頭寬鬆但pp說要省/壓力大"))
    # 8d: bg說寬裕/寬鬆但pp說剛好夠 → MINOR (tone inconsistency)
    if ("寬裕" in bg or "不用太省" in bg or "手頭還算寬鬆" in bg) and "剛好夠" in pp:
        if "要省" not in pp and "壓力" not in pp:
            findings.append(("MINOR", "bg說寬裕/寬鬆但pp說「剛好夠」，用詞不一致"))
    return findings

# ---- Check 9: 學生+已婚 ----
def check_9(p):
    findings = []
    dim = p.get("dimensions",{})
    occ, mar = s(dim,"occupation"), s(dim,"marriage")
    if occ == "學生" and mar not in ("未婚", ""):
        findings.append(("REAL", f"學生+婚姻「{mar}」"))
    return findings

# ---- Check 10: 12-18教育=大學 ----
def check_10(p):
    findings = []
    dim, age, edu = p.get("dimensions",{}), s(p.get("dimensions",{}),"age"), s(p.get("dimensions",{}),"education")
    m = re.match(r'(\d+)-(\d+)', age)
    if m and int(m.group(2)) >= 12 and int(m.group(1)) <= 22 and "大學" in edu:
        if int(m.group(2)) < 18:
            findings.append(("REAL", f"年齡{age}未成年但教育大學"))
        elif int(m.group(1)) >= 18:
            findings.append(("OK", f"年齡{age}教育大學，合理"))
    return findings

# ===== Main =====
def main():
    if len(sys.argv) > 1:
        path = sys.argv[1]
    else:
        path = "~/persona-db/tw_persona_chunk_3.json"

    with open(path) as f:
        data = json.load(f)

    check_funcs = [check_1, check_2, check_3, check_4, check_5, check_6, check_7, check_8, check_9, check_10]
    check_names = [
        "1. 收入 vs 描述", "2. 獨居+小孩", "3. 已婚+fs=1無配偶",
        "4. 未成年有收入", "5. 65+年輕子女", "6. 含飴弄孫+低收入+高物價",
        "7. 未成年非學生", "8. BG前後句矛盾", "9. 學生+已婚", "10. 12-18教育=大學",
    ]
    results = {i: {"REAL":[], "OK":[], "MINOR":[]} for i in range(1, 11)}

    for p in data:
        for ci, fn in enumerate(check_funcs):
            for cat, msg in fn(p):
                results[ci+1][cat].append((p["name"], p["id"], msg))

    total_REAL = sum(len(r["REAL"]) for r in results.values())
    total_OK   = sum(len(r["OK"])   for r in results.values())
    total_MINOR= sum(len(r["MINOR"]) for r in results.values())
    print(f"總計: REAL={total_REAL}, OK={total_OK}, MINOR={total_MINOR}")

    for ci in range(1, 11):
        r = results[ci]
        t = len(r["REAL"]) + len(r["OK"]) + len(r["MINOR"])
        print(f"\n{check_names[ci-1]}: REAL={len(r['REAL'])} OK={len(r['OK'])} MINOR={len(r['MINOR'])} (total={t})")
        for cat in ["REAL", "OK", "MINOR"]:
            sym = {"REAL":"🔴","OK":"🟡","MINOR":"⚪"}
            for nm, pid, msg in r[cat]:
                print(f"  {sym[cat]} {nm}({pid}): {msg}")

if __name__ == "__main__":
    main()
