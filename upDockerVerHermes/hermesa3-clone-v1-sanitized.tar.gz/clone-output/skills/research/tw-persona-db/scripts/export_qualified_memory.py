#!/usr/bin/env python3
"""
export_qualified_memory.py — 將本尊的 qualified memory + skill + data 打包成 release artifact

用法:
    python3 export_qualified_memory.py                          # 自動版號 v3.x+1
    python3 export_qualified_memory.py --version v3.2            # 指定版號
    python3 export_qualified_memory.py --list-qualified          # 只列出 qualified entries
    python3 export_qualified_memory.py --dry-run                 # 試跑，不產檔案

輸出: release-v3.2.zip 放在 releases/ 目錄下

Tagging Convention:
    在 ~/.hermes/memories/MEMORY.md 中，條目尾端加上 #qualified 就會被掃描到。
    範例:
        🟢 最佳 query：--residence 台中市 --age 30-44 --politics 泛綠 #qualified
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

# ─── 路徑設定 ────────────────────────────────────────────────
HOME = Path.home()
MEMORY_DIR = HOME / ".hermes" / "memories"
SKILL_DIR = HOME / ".hermes" / "skills" / "research" / "tw-persona-db"
PERSONA_DIR = Path("~/persona-db")
OUTPUT_DIR = PERSONA_DIR.parent / "releases"  # lab-riscv/hermesa3/releases/

# ─── 要包進 release 的資料檔案 ──────────────────────────────
DATA_FILES = [
    "tw_persona_1069.json",
    "population_by_region_age_sex_2025.csv",
    "tw-persona-db-rfc.md",
]

# ─── 要包進 release 的工具腳本（唯讀介面） ──────────────────
TOOL_SCRIPTS = [
    "query_persona.py",
    "sample_stratified.py",
]

# ─── VERSION 檔案路徑 ────────────────────────────────────────
VERSION_FILE = PERSONA_DIR / "VERSION"


def read_current_version() -> str:
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    return "v3.0"


def bump_version(current: str) -> str:
    match = re.match(r"v(\d+)\.(\d+)", current)
    if not match:
        return "v3.1"
    major, minor = int(match.group(1)), int(match.group(2))
    return f"v{major}.{minor + 1}"


def extract_qualified_entries(text: str, source_label: str) -> list[dict]:
    """從 memory markdown 中提取 #qualified 條目"""
    entries = []
    paragraphs = re.split(r'\n§\n|\n{2,}', text)
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if '#qualified' in para or '#export' in para:
            clean = re.sub(r'\s*#(qualified|export)\s*', '', para).strip()
            if clean:
                entries.append({
                    "source": source_label,
                    "content": clean,
                    "tag": "qualified",
                })
    return entries


def scan_qualified_memory() -> list[dict]:
    all_entries = []
    for fname in ["MEMORY.md", "USER.md"]:
        fpath = MEMORY_DIR / fname
        if fpath.exists():
            text = fpath.read_text(encoding="utf-8")
            entries = extract_qualified_entries(text, fname)
            all_entries.extend(entries)
    return all_entries


def make_changelog(entries: list[dict], current_version: str, new_version: str) -> str:
    lines = [
        f"# TW Persona DB — Qualified Memory Release",
        f"",
        f"## {new_version} → {new_version}",
        f"**Release date:** {datetime.now().strftime('%Y-%m-%d')}",
        f"",
        f"### Qualified Memory ({len(entries)} entries)",
    ]
    for i, e in enumerate(entries, 1):
        first_sentence = e["content"].split("。")[0].split("\n")[0][:80]
        lines.append(f"{i}. {first_sentence}… (from {e['source']})")

    lines.extend([
        "",
        "### 更新內容",
        "- 資料：最新版 tw_persona_1069.json",
        "- Skill：tw-persona-db (含 QA rules、references)",
        "- 工具：query_persona.py、sample_stratified.py",
        "- 文件：RFC、使用說明",
        "",
        "### Import 方式",
        "```bash",
        "# 1. 解壓縮",
        f"unzip qualified-memory-{new_version}.zip -d ~/persona-db-release/",
        "",
        "# 2. 更新 skill",
        "cp -r ~/persona-db-release/skills/tw-persona-db/ ~/.hermes/skills/research/",
        "",
        "# 3. 更新資料",
        "cp ~/persona-db-release/data/tw_persona_1069.json ~/persona-db/",
        "",
        "# 4. 更新工具",
        "cp ~/persona-db-release/tools/*.py ~/persona-db/",
        "",
        "# 5. 匯入 qualified memory",
        "# 開啟 ~/.hermes/memories/MEMORY.md，在適當位置貼上 qualified-memory.md 內容",
        "```",
    ])
    return "\n".join(lines)


def build_release_manifest(
    entries: list[dict],
    version: str,
    file_hashes: dict[str, str],
) -> dict:
    return {
        "release_version": version,
        "release_date": datetime.now().isoformat(),
        "qualified_memory_count": len(entries),
        "qualified_memory": entries,
        "files": file_hashes,
        "source_repo": "github.com/kstsai/media-narrative",
        "persona_db_version": version,
        "qa_status": "20/20 pass (see skill references)",
        "install_instructions": {
            "1": "unzip → copy skill dir to ~/.hermes/skills/research/",
            "2": "copy data/tw_persona_1069.json to working dir",
            "3": "copy tools/*.py to working dir (read-only CLI)",
            "4": "merge qualified-memory.md into MEMORY.md (manual review)",
        },
    }


def hash_file(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()[:16]


def build_release(
    version: str,
    entries: list[dict],
    dry_run: bool = False,
) -> Path | None:
    if dry_run:
        print(f"🧪 [DRY RUN] 將產出 release-{version}.zip")
        print(f"    qualified entries: {len(entries)}")
        print(f"    skill dir: {SKILL_DIR}")
        print(f"    data files: {DATA_FILES}")
        print(f"    tool scripts: {TOOL_SCRIPTS}")
        return None

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = OUTPUT_DIR / f"release-{version}.zip"
    file_hashes = {}

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)

        # qualified-memory.md
        mem_lines = [
            f"# TW Persona DB — Qualified Memory ({version})",
            f"# 產出日期: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"# 用法: merge 到 ~/.hermes/memories/MEMORY.md 中",
            f"",
        ]
        for i, e in enumerate(entries, 1):
            mem_lines.append(f"§")
            mem_lines.append(f"{e['content']}  #qualified")
        (tmp / "qualified-memory.md").write_text(
            "\n".join(mem_lines), encoding="utf-8")
        file_hashes["qualified-memory.md"] = hash_file(tmp / "qualified-memory.md")

        # CHANGELOG.md
        current_ver = read_current_version()
        changelog = make_changelog(entries, current_ver, version)
        (tmp / "CHANGELOG.md").write_text(changelog, encoding="utf-8")

        # manifest.json
        manifest = build_release_manifest(entries, version, file_hashes)
        (tmp / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

        # skills/
        if SKILL_DIR.exists():
            skill_target = tmp / "skills" / "tw-persona-db"
            shutil.copytree(
                SKILL_DIR, skill_target,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            for f in skill_target.rglob("*"):
                if f.is_file():
                    rel = f.relative_to(tmp)
                    file_hashes[str(rel)] = hash_file(f)

        # data/
        data_dir = tmp / "data"
        data_dir.mkdir()
        for fname in DATA_FILES:
            fpath = PERSONA_DIR / fname
            if fpath.exists():
                shutil.copy2(fpath, data_dir / fname)
                file_hashes[f"data/{fname}"] = hash_file(data_dir / fname)

        # tools/
        tools_dir = tmp / "tools"
        tools_dir.mkdir()
        for fname in TOOL_SCRIPTS:
            fpath = PERSONA_DIR / fname
            if fpath.exists():
                shutil.copy2(fpath, tools_dir / fname)
                file_hashes[f"tools/{fname}"] = hash_file(tools_dir / fname)

        # VERSION
        (tmp / "VERSION").write_text(version + "\n")

        # ZIP
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for f in tmp.rglob("*"):
                if f.is_file():
                    zf.write(f, f.relative_to(tmp))

    print(f"✅ release-{version}.zip 已產出 ({len(entries)} qualified entries)")
    print(f"   大小: {zip_path.stat().st_size / 1024:.1f} KB")
    print(f"   路徑: {zip_path}")
    return zip_path


def list_qualified(entries: list[dict]):
    print(f"\n📋 Qualified Memory Entries ({len(entries)} 條)")
    print("=" * 60)
    for i, e in enumerate(entries, 1):
        print(f"\n--- Entry {i} (from {e['source']}) ---")
        print(e["content"][:200])
        if len(e["content"]) > 200:
            print(f"    … ({len(e['content'])} chars total)")
    print(f"\n總計 {len(entries)} 條 qualified entries")


def main():
    parser = argparse.ArgumentParser(
        description="export_qualified_memory.py — 打包 qualified memory release")
    parser.add_argument("--version", help="指定版號 (如 v3.2)，預設自動 bump")
    parser.add_argument("--list-qualified", action="store_true",
                        help="只列出 qualified entries，不產檔案")
    parser.add_argument("--dry-run", action="store_true",
                        help="試跑，不產檔案")
    parser.add_argument("--gen-import-script", action="store_true",
                        help="同時產出甲方端的 auto-import-qualified.sh")
    args = parser.parse_args()

    entries = scan_qualified_memory()
    print(f"🔍 掃描 qualified memory: {len(entries)} 條 tagged #qualified")

    if args.list_qualified:
        list_qualified(entries)
        return

    if args.version:
        version = args.version
    else:
        current = read_current_version()
        version = bump_version(current)
    print(f"📌 版號: {version}")

    zip_path = build_release(version, entries, dry_run=args.dry_run)

    if args.gen_import_script and not args.dry_run:
        from shutil import which
        script_path = PERSONA_DIR / "auto-import-qualified.sh"
        # The import script is in the skill templates/ dir; copy if needed
        tmpl = SKILL_DIR / "templates" / "auto-import-qualified.sh"
        if tmpl.exists():
            shutil.copy2(tmpl, script_path)
            os.chmod(script_path, 0o755)
            print(f"✅ auto-import-qualified.sh 已複製到 {script_path}")
        else:
            print(f"⚠️ 找不到 template: {tmpl}")

    if not args.dry_run and zip_path:
        VERSION_FILE.write_text(version + "\n")
        print(f"📝 VERSION 已更新 → {version}")
        print(f"\n🚀 要 publish 給甲方:")
        print(f"    git add releases/release-{version}.zip")
        print(f"    git commit -m \"qualified memory release {version}\"")
        print(f"    git push origin main")


if __name__ == "__main__":
    main()
