# Taiwan News Outlet Quirks & Scraping Notes

> Known issues, site-specific patterns, and reliability notes for each outlet.
> Updated: 2026-07-08

## TVBS (news.tvbs.com.tw)

- **List page is SPA** — JavaScript-rendered. Raw `curl` returns empty.
- **RSS feed works**: `https://news.tvbs.com.tw/web_api/play_feed_new/{category}`
  - Returns valid RSS 2.0 XML with `<item>` entries
  - Categories: politics, life, world, etc.
- **Article pages** are server-rendered (non-SPA) — `curl` returns full HTML.
- Bodies often have heavy ad/navigation interleaving. The `body_text_from_html` function handles this adequately.
- **Known:** Some article titles in the RSS feed have leading spaces — always `.strip()`.

## 中天 (ctitv.com.tw / gotv.ctitv.com.tw)

- **gotv.ctitv.com.tw is dead** — `ERR_CONNECTION_CLOSED`. Do not use.
- **Main site RSS**: `https://www.ctitv.com.tw/feed/` returns RSS XML with 10 items.
- **Critical issue**: RSS feed items are mostly **advertorials/PR**, not hard news:
  - Product launches ("穀萃蕎麥國寶茶全新上市")
  - Shopping mall events ("桃園首家樂高授權專賣店")
  - CSR reports ("中信慈善基金會...")
  - Internal documents ("中天倫理委員會會議記錄")
- **For real political news**: the RSS feed is unreliable. Consider browser-rendering the actual site or accepting the limitation.
- `body_text_from_html` works for individual article pages fetched by URL.

## 風傳媒 (storm.mg)

- **Nuxt.js SPA** — no server-rendered list page. Category pages (`/category/politics`) return empty shell HTML.
- **No public RSS** — tried `/feed`, `/rss`, `/rss.xml`, `/atom.xml` — all 404 or SPA shell.
- **Workaround**: scrape the **homepage** (`www.storm.mg`) for article links:
  ```python
  re.findall(r'<a[^>]*href="(/article/\d+)"[^>]*>.*?<h3[^>]*>(.*?)</h3>', html, re.DOTALL)
  ```
  - Returns ~20 articles from the homepage (not category-specific)
  - Articles have mixed categories (politics, world, sports, finance)
  - No easy way to filter by category client-side
- **Article pages** are server-rendered — `curl` returns full HTML.
- **VIP/paywalled articles**: some premium articles are behind a paywall. The `body_text_from_html` function will only get the preview, not the full text.
- **Political coverage style**: heavy on commentary/opinion, not straight news. Many articles are signed columns (江岷欽觀點, 陸文浩觀點).
- **US/China focus**: mentions of 川普, 美國, 中共 are significantly higher than other outlets (see 7/7 data: 川普×55, 美國×168, 中共×119).

## 自由時報 (ltn.com.tw)

- **List page**: `https://news.ltn.com.tw/list/breakingnews/politics`
  - Returns ~10 articles, somewhat limited
- **Article pages** have heavy interstitials (ad overlays, age verification modal for some content).
- **body_text_from_html** works but may include sidebar "related news" links in the extracted text.
- **Political stance**: consistently anti-KMT/anti-China framing. High density of 矢板明夫 coverage.

## 三立 (setn.com)

- **List page**: `https://www.setn.com/ViewAll.aspx?PageGroupID=6`
  - Returns ~20 articles, mixed categories despite "politics" parameter
  - About 40-50% actual political news, rest is entertainment/sports/life
- **Article pages** are straightforward — `body_text_from_html` works well.
- **Category filtering is loose**: the "politics" page includes many non-political articles.
- **Repetition issue**: the list page often shows the same article twice (full title and abbreviated version).

## ETtoday (ettoday.net)

- **Highest volume**: ~30 articles per day from politics category
- **Lowest political relevance**: most articles are about weather (颱風), entertainment, celebrity gossip
- **List page** `https://www.ettoday.net/news/politics` has extensive duplication
- **Dedup is critical**: always use a `seen` set to filter duplicate titles
- **Known behavior**: during typhoon events, ETtoday runs 10+ articles per day about the storm, drowning out political coverage

## 聯合報 (udn.com)

- **Low volume**: typically returns 1-3 articles from `/news/breaknews/1`
- **Quality over quantity**: often the only outlet covering US/Iran international news (see 7/7: only outlet covering 美軍空襲伊朗)
- **Consider using other category pages** if volume is too low:
  - `/news/breaknews/1` — politics
  - `/news/breaknews/2` — society
  - `/news/breaknews/3` — life
- **Article body extraction** works well — clean HTML structure.

## CNA 中央社 (cna.com.tw)

- **Two feed types**:
  - International: `https://www.cna.com.tw/list/aopl.aspx`
  - Politics: `https://www.cna.com.tw/list/aipl.aspx`
- **International feed is the silence baseline**: CNA covers topics that domestic outlets ignore. The gap between CNA international headlines and domestic coverage is the silence matrix.
- **Reliable source** — always returns articles, clean HTML.
- **URLs are relative**: prepend `https://www.cna.com.tw` before storing.
