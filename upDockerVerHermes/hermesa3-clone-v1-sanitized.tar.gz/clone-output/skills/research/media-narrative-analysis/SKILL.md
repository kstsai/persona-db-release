---
name: media-analysis-analysis
description: "Scrape, analyze, and report on Taiwanese media narrative direction — headline collection, full-text person/term counting, silence matrix, and cross-outlet framing comparison."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [media, narrative, taiwan, news, scraping, framing, silence-matrix]
  user:
    hermes-user:
      preferred_report_format: data-driven comparison tables
      outlet_count: 8
      fulltext_count_target: 15 per outlet
---

# Media Narrative Analysis (Mediawatch)

Compare how different Taiwanese news outlets frame the same events and people.
Core methodology: collect headlines → fetch full text → count person/term mentions → build silence matrix → generate data-driven comparison report.

## Report Format Requirement (CRITICAL — User Preference)

**This user explicitly rejected prose-heavy narrative analysis.** Always produce reports in **data-driven comparison table format** (modeled after `five-media-comparison-20260703.md`).

### DO
- Data source transparency table (crawl method, count, reliability notes per outlet)
- One concise label per outlet's narrative character — let the comparison speak, don't narrate paragraph-by-paragraph
- Shared topic framework comparison table (same event × each outlet's framing + tendency emoji)
- Silence matrix grid (CNA baseline topics × each outlet, ❌✅⚠️)
- 3-6 quantitative key insights at the end
- Let the numbers and table comparisons speak for themselves

### DO NOT
- Write paragraph-by-paragraph prose describing what each article says
- Write long introductions, philosophical framing, or "what this means" conclusions
- Describe what each outlet "wants readers to believe" as narrative text blocks
- Use subjective narrative descriptions outside a structured comparison table

### Exact Report Section Order (User-Specified, from 2026-07-08)

```
一、資料量與爬取方式    ← Per-outlet table: count, scrape method, reliability flag, notes
                          Source transparency — "以昭公信"
三、各媒體敘事特徵      ← One concise label per outlet + keyword list
                          "單看沒啥價值，列出來就有比較" (we watch the watchers)
四、共同議題框架比對    ← Same event × each outlet's framing
                          "代表事件風向操弄方向"
五、沉默議題矩陣        ← CNA baseline × 8 outlets: ❌=silent ⚠️=low ✅=covered
                          "忽略項目, ignore by whom"
六、關鍵洞察            ← 3-6 numbered insights from the data
```

### Emoji Scheme for Framing

```
Against people:  😇=build 🗑️=destroy ⚠️=question 😐=neutral 🔇=silence
Against events:  🔴=blame 🟢=factual 🟡=balanced 🔵=commentary ⚪=silence
```

## 8-Taiwanese Media Scraping

### Outlet Sources & Techniques

| Outlet | Source URL | Technique | Status |
|--------|-----------|-----------|--------|
| 中央社國際 | cna.com.tw/list/aopl.aspx | HTML regex (`extract_titles`) | ✅ Stable |
| 中央社政治 | cna.com.tw/list/aipl.aspx | HTML regex | ✅ Stable |
| 自由時報 | news.ltn.com.tw/list/breakingnews/politics | HTML regex | ✅ Stable |
| 聯合報 | udn.com/news/breaknews/1 | HTML regex | ✅ Stable |
| TVBS | news.tvbs.com.tw/web_api/play_feed_new/politics | RSS XML (`extract_rss_titles`) | ✅ Stable (SPA) |
| ETtoday | ettoday.net/news/politics | HTML regex | ✅ Stable |
| 三立 | setn.com/ViewAll.aspx?PageGroupID=6 | HTML regex | ✅ Stable |
| 中天 | www.ctitv.com.tw/feed/ | RSS XML (`extract_rss_titles`) | ✅ Stable (SPA) |
| 風傳媒 | storm.mg (homepage) | `<a href="/article/N"><h3>TITLE</h3></a>` pattern | ✅ Stable (Nuxt SPA) |

### Pitfalls & Fixes

- **TVBS/中天/風傳媒 are SPA sites**: raw `curl` + regex on the list page returns 0 articles or JavaScript template strings. Fix: use RSS feed (TVBS, 中天) or homepage `<h3>` scraping (風傳媒).
- **中天 RSS feed returns mostly advertorials** (業配稿) not hard news. The RSS `feed/` endpoint is different from the actual site content. For real political news, consider `web_extract` with browser rendering.
- **風傳媒 has no public RSS**: use Nuxt SPA homepage `<a><h3>` pattern. Not all categories are available — only homepage articles.
- **ETtoday returns many duplicates**: the list page has the same article in multiple sections. Always dedup by title text.
- **TVBS RSS returns RSS XML** (not JSON) from `/web_api/play_feed_new/{category}` endpoint — parse with `xml.etree.ElementTree`.
- **聯合報 often returns very few articles**: the `/news/breaknews/1` list page is limited. Consider using a different category page if 0-2 results.

## Full-Text Analysis

### Body Text Extraction

```python
def body_text_from_html(html):
    """Extract clean body text from a news article HTML page."""
    # Strip <script>, <style>, <nav>, <header>, <footer>
    html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL|re.IGNORECASE)
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL|re.IGNORECASE)
    html = re.sub(r'<nav[^>]*>.*?</nav>', '', html, flags=re.DOTALL|re.IGNORECASE)
    html = re.sub(r'<header[^>]*>.*?</header>', '', html, flags=re.DOTALL|re.IGNORECASE)
    html = re.sub(r'<footer[^>]*>.*?</footer>', '', html, flags=re.DOTALL|re.IGNORECASE)
    # Strip remaining tags
    text = re.sub(r'<[^>]+>', '\n', html)
    # Filter short/nav lines
    lines = [l.strip() for l in text.split('\n') if len(l.strip()) > 15]
    nav_keywords = ['cookie', 'close', 'menu', 'search', 'share', 'facebook',
                    'copyright', 'all rights', 'subscribe', 'newsletter']
    lines = [l for l in lines if not any(kw in l.lower() for kw in nav_keywords)]
    return '\n'.join(lines)
```

### Person & Term Tracking

Track 39 political figures and 5 political term groups. Use `Counter()` for accumulation. Keep the list comprehensive — session experience shows that underrepresented names dilute the comparison matrix.

```python
PERSON_NAMES = [
    "賴清德", "蔣萬安", "沈伯洋", "韓國瑜", "蕭美琴",
    "林沛祥", "矢板明夫", "黃國昌", "王定宇", "盧秀燕",
    "陳以信", "吳子嘉", "李洋", "侯友宜", "楊珍妮",
    "柯文哲", "鄭麗文", "吳乃仁", "連勝文", "張善政",
    "柯志恩", "翁曉玲", "蘇巧慧", "何欣純", "賴瑞隆",
    "謝龍介", "江啟臣", "林姿妙", "陳其邁", "黃偉哲",
    "鄭朝方", "吳旭智", "邱臣遠", "李四川", "谷立言",
    "川普", "拜登", "馬英九", "顧立雄",
]

PARTY_KEYWORDS = {
    "民進黨": ["民進黨", "綠營", "綠委", "賴清德"],
    "國民黨": ["國民黨", "藍營", "藍委", "蔣萬安"],
    "民眾黨": ["民眾黨", "白營", "柯文哲", "黃國昌"],
    "中共": ["中共", "中國", "北京", "解放軍", "共軍"],
    "美國": ["美國", "美軍", "白宮", "川普", "拜登"],
}
```

### Performance

- Full-text fetch for top 15 articles per outlet × 8 outlets = ~120 URLs
- Each fetch takes ~20s (curl timeout) → ~40 minutes total
- Cache results to `~/.hermes/cache/media_deep/fulltext_analysis_{DATE}.json`
- On re-run, check cache first to avoid re-fetching

## Persona Engineering Label System (v1 — Keyword-Based)

Added 2026-07-08. Computed per-person, per-outlet from full article text.

### Labels

| Label | Emoji | When Applied |
|-------|-------|-------------|
| **Build** | 😇 | `build_keywords` > `destroy_keywords`, `build_score > 0` |
| **Destroy** | 🗑️ | `destroy_keywords` > `build_keywords`, `destroy_score > 0` |
| **Question** | ⚠️ | `question_keywords > 0` (but not destroy) |
| **Neutral** | 😐 | No strong keyword signal detected |
| **Silence** | 🔇 | Person not mentioned at all in this outlet |

### Keyword Lists

```python
BUILD = ["肯定","讚","力挺","有功","貢獻","表率","突破","成功","佳績","進步",
         "創新高","親民","溫暖","團結","捍衛","保護","承諾","落實"]
DESTROY = ["雙標","打臉","造假","翻車","裝瞎","裝天真","大雷包","何不食肉糜",
           "護航","邪惡","可恥","騙","謊","黑心","包庇","蓋牌","無能",
           "甩鍋","卸責","傲慢","酬庸","派系","門神"]
QUESTION = ["質疑","呼籲","要求","批","轟","酸","怒","應說明","待釐清","引發討論","爭議"]
```

### Limitations (v1)

- Keyword matching is **context-agnostic** — a "destroy" keyword near a different person in the same article can mislabel an unrelated person
- Does not handle sarcasm, quotes, or negation (e.g. "not a scam")
- TVBS articles about legal cases (黃國昌被告) can trigger 🗑️ because of "起訴"/"誹謗" in the text even though the reporting is neutral
- Plan: v2 should use per-paragraph sentiment + entity linking, or a lightweight LLM call

### Narrative Label (v1 — Simpler)

```python
def label_narrative(text, title=""):
    blame_count = count keywords like 道歉, 打臉, 說謊, 隱瞞...
    factual_count = count keywords like 公布, 宣布, 指出, 說明...
    if blame > factual: return 🔴
    if factual > 0: return 🟢
    return 🟡
```

Currently computed but not yet output to the report — planned for next version.

## Report Structure (User-Preferred — 5 Sections)

```
一、資料量與爬取方式    ← Per-outlet table: count, crawl method, reliability, notes
三、各媒體敘事特徵      ← One concise label per outlet + keyword list
四、共同議題框架比對    ← Same event per row, each outlet's framing + tendency emoji
五、沉默議題矩陣        ← CNA baseline topics × 8 outlets: ❌✅⚠️
六、關鍵洞察            ← 3-6 numbered insights from the data
```

Section order matters — the user confirmed this exact sequence. Do not reorder or rename sections without asking.

Additional sections that the script also generates (from full-text analysis) go AFTER the five core sections, clearly labelled:

- 全文分析 — 人物提及頻率 (collapsible `<details>` table)
- 全文分析 — 政治詞彙提及 (collapsible `<details>` table)
- 人設操作標籤 (collapsible `<details>` table, persona labels)
- 原始資料 (per-outlet headline listing, always at the end)

## Silence Matrix

Use CNA international headlines as the baseline for "what news exists."
For each headline, check each outlet's article text for any mention.

### Matrix Dimensions

| Dimension | Definition |
|-----------|-----------|
| ✅ Covered | Outlet has at least 1 article mentioning the topic |
| ⚠️ Low coverage | Only 1-2 articles or tangential mention |
| ❌ Silent | No mention at all in any article |

### Known Recurring Silent Topics

Topics that CNA covers but Taiwanese domestic outlets consistently ignore:
- 美伊戰爭 / 中東局勢 (Iran/US conflicts)
- 荷莫茲海峽油輪遇襲 (Strait of Hormuz incidents)
- 美中關係 (US-China relations not directly involving Taiwan)
- 全球經濟 / 油價 (Global economics)
- 北韓 / 東北亞 (North Korea / Northeast Asia)

## Report Generation

### Report Generation

The `_eight_media_report.py` script accepts `--date YYYY-MM-DD` flag.
Report file goes to `hermesa3/mediawatch-reports/eight-media-comparison-{DATE}.md`.

### GitHub Readability (Private Repo Workaround)

Since the repo is private and GitHub Pages requires a paid plan:

1. **INDEX.md** at `hermesa3/mediawatch-reports/INDEX.md` — date/summary table linking to all reports, acts as a directory
2. **Collapsible sections** — wrap large tables in `<details><summary>📊 展開表格</summary>\n\n...table...\n\n</details>`. This prevents tables from dominating the page on GitHub's markdown renderer
3. **Short header** — keep the top of each report concise (data table and a line about full-text coverage)

### Person Ranking Note

Sort the person table by total count descending. Use abbreviated outlet column headers (first 4 chars: "自由時", "聯合報", "TVBS", "ETto", "三立", "中天", "風傳") to keep the table narrow. Center-align all columns with `:---:`.

### Security: Before Making Repo Public

If the user considers making the repo public (e.g. for GitHub Pages), run a security scan first:

1. `git grep` for: `password\s*[:=]`, `sk-[a-zA-Z0-9]`, `ghp_`, `xapp-`, `xoxb-`, `AKIA`
2. Check `ai-agents/hermesa3/MEMORY.md` for plaintext passwords
3. Check `networkNodes.yaml` for DB passwords and internal IPs
4. Check `ansible/inventory/` for internal IPs and credentials
5. Check git history for committed tokens (`git log -p -S 'ghp_'`)
6. If secrets exist in history, use `git filter-repo` or split the repo (recommended: create a new public repo for `hermesa3/` only)

## Git Workflow

After generating a report or modifying the scraper, commit to the repo:

```bash
cd /home/hermes/project
git pull origin main        # 1. Pull GitHub latest
git push gitea main         # 2. Sync gitea
git add -A && git commit    # 3. Commit changes
git push gitea main         # 4. Push gitea first
git push origin main        # 5. Push GitHub upstream
```

See the `git-workflow` skill for full multi-remote sync details.

### Public Repo Sync (media-analysis)

Since 2026-07-08, the `hermesa3/` content has been split into a public repo at `github.com/hermes-user/media-analysis` (GitHub Pages: `https://hermes-user.github.io/media-analysis/`).

To sync changes to the public repo after updating `project-repo/hermesa3/`:

```bash
cd /tmp/media-analysis-prep              # or wherever media-analysis is cloned
git pull origin main                      # Pull latest
cp <updated-files> ./                     # Copy updated files from project-repo
git add -A && git commit -m "sync: ..."
git push origin main                      # Single remote, no gitea
```

The public repo has a **single remote** (`origin = GitHub`), no gitea. It contains:
- `mediawatch-reports/` — all reports + `_eight_media_report.py`
- `persona/` — persona database
- `media-analysis-prototype.md` — theory document
- `README.md`, `INDEX.md`, `MEMORY.md`
- **No** infrastructure files (networkNodes.yaml, ansible/, libvirt/)
- **No** ai-agents/ directory
