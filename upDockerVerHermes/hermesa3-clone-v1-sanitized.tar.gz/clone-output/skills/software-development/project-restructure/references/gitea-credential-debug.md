# Gitea / Internal Git Server Credential Debugging

Use when git push to an internal HTTP(S) remote (gitea, gitlab self-hosted)
fails with `Authentication failed`.

## Quick-reference commands

```bash
# 1. Test server reachability
curl -s -o /dev/null -w "%{http_code}" http://server:port/

# 2. Test credentials (200 = OK, 401 = bad)
curl -s -u "user:pass" -o /dev/null -w "%{http_code}" http://server:port/api/v1/user

# 3. Brute-force password variants when user-specified pass fails
for pw in "givenPass123" "givenPass123!" "givenPass"; do
  code=$(curl -s -u "user:$pw" -o /dev/null -w "%{http_code}" http://server:port/api/v1/user)
  echo "pass='$pw' → $code"
done

# 4. Push with embedded credentials (then restore clean URL)
git remote set-url <name> http://user:realpassword@server:port/path.git
git push <name> <branch>
git remote set-url <name> http://server:port/path.git
```

## Common password character issues

| Character | Problem | URL-encoded |
|-----------|---------|-------------|
| `!` | Shell history expansion / truncated | `%21` |
| `@` | Confused with URL user@host separator | `%40` |
| `#` | Shell comment — truncates rest of line | `%23` |
| `$` | Shell variable expansion | `%24` |
| `&` | Shell background operator | `%26` |

## Known gitea instance

User hermes-user's internal gitea: `http://gitea.local:30080`
User: `hermes-admin`, repo: `hermes-admin/project-repo.git`
Two remotes: `gitea` (HTTP internal) + `origin` (github.com/hermes-user/project-repo)
