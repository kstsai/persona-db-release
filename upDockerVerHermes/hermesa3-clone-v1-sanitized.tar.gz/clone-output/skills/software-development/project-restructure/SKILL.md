---
name: project-restructure
description: "Reorganize project files and directories — move, rename, update internal references, clean up."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [restructure, reorganize, refactor, filesystem, cleanup]
    related_skills: [simplify-code, plan]
---

# Project Restructure — Reorganize Files & Directories

Restructure a project's file layout: move files into new directory
hierarchy, update all internal path references, and clean up the old
structure. Designed for consolidating scattered files into a logical
grouping by domain.

## When to Use

Trigger when the user says any of:

- "restructure the project" / "reorganize the files" / "clean up the directory"
- "split this into subdirectories" / "move files into categories"
- "rename/nest the project folder" or describes a new directory layout

## The Process

### Phase 1 — Understand the current layout

List all files in the directory the user wants to restructure. Group them
by what domain they belong to (e.g., data files, scripts, docs, configs,
analysis outputs). Show the user your proposed grouping before moving
anything if the user hasn't already specified the mapping.

**Naming convention:** The user prefers **simple, straightforward names**
over clever/creative compound words. Examples: `mediawatch-reports/` ✓ vs
`narrascope/` ✗; `scripts/` ✓ vs `execution-engines/` ✗. When proposing a
new directory name, offer a simple default plus one alternative — let the
user pick.

### Phase 2 — Create the new structure

```bash
mkdir -p path/to/new-root/{subdir1,subdir2}
```

Create all target directories in one `mkdir -p` call. Use brace expansion
for multiple subdirectories.

### Phase 3 — Move files by category

Move files in batches, one category at a time. Use `mv` with explicit file
names (not glob patterns when the set is small and known).

```bash
cd /old/path && mv file1 file2 file3 /target/dir/
```

### Phase 4 — Scan and patch internal path references

**Critical step.** After moving files, internal references (hardcoded paths
in code, relative paths in docs, file tables in READMEs) are broken. Fix them:

1. **Search for old path patterns** in all moved files:
   - Use `search_files` on the new directory with the old prefix as pattern
   - Check both `.md` and `.py` (and relevant file types for your project)
   - Also search the `scripts/` directory under `.hermes/` if it exists
2. **Patch each broken reference** using `patch`. Common targets:
   - Python scripts with hardcoded file output paths
   - Documentation markdown with path tables or cross-references
   - README files that reference files now in different directories
3. **Verify all patches were applied** by re-running the search

### Phase 5 — Clean up old directories

After all files are moved, verify the old parent directory is empty, then
remove it:

```bash
rmdir /old/path
```

Note: rmdir will fail if the directory is not empty — this is a safety
feature. If it fails, check for leftover files you missed.

### Phase 6 — Add root README (optional)

If the new root directory lacks a README, consider adding one that explains
the directory layout so future contributors know where things live.

### Phase 7 — Git commit & push to all remotes

After restructuring, commit the changes and push:

```bash
# Stage everything (git detects renames automatically)
git add -A

# Commit with a clear message
git commit -m "refactor: restructure dir/ → new-root/{sub1, sub2}" \
  -m "- Split into domain subdirectories
- Update all internal path references
- Add root README overview"

# Push to all remotes
for remote in $(git remote); do
  git push "$remote" "$(git branch --show-current)"
done
```

**Authentication troubleshooting for internal remotes (gitea, gitlab):**

If a push fails with `Authentication failed`, do NOT retry blindly.
Diagnose in order:

1. **Test credentials with curl** against the git server's API:
   ```bash
   # Check server reachable first
   curl -s -o /dev/null -w "%{http_code}" http://server:port/

   # Then test credentials against the auth endpoint
   curl -s -u "username:password" -o /dev/null -w "%{http_code}" http://server:port/api/v1/user
   # 200 = credentials OK, 401 = wrong user/pass
   ```

2. **Try credential variants** if 401 — the password the user gave may
   contain a character that got dropped or mangled by shell quoting
   (e.g. trailing `!`, `$`, `&`). Loop through candidates:
   ```bash
   for pw in "givenPass123" "givenPass123!" "givenPass"; do
     code=$(curl -s -u "user:$pw" -o /dev/null -w "%{http_code}" http://server:port/api/v1/user)
     echo "password='$pw' → $code"
   done
   ```

3. **Push with embedded credentials in the remote URL** (one-time only —
   restore the clean URL afterward):
   ```bash
   git remote set-url <name> http://user:password@server:port/path/repo.git
   git push <name> <branch>
   git remote set-url <name> http://server:port/path/repo.git  # clean!
   ```

   For passwords with URL-unsafe characters, encode them:
   `!` → `%21`, `@` → `%40`, `#` → `%23`, `$` → `%24`

4. **Alternative:** use `GIT_ASKPASS` for two-step credential prompt:
   ```bash
   echo '#!/bin/bash
   echo "username"
   echo "password"' > /tmp/git_askpass.sh
   chmod +x /tmp/git_askpass.sh
   GIT_ASKPASS=/tmp/git_askpass.sh git push <remote> <branch>
   ```

## Pitfalls

- **Don't forget to search for cross-references.** The most common mistake
  is moving files but leaving broken path references in scripts, docs, and
  config files that still point to the old location.
- **Python output paths are often absolute.** Check for hardcoded
  `/home/.../old-dir/...` strings in scripts that write output files.
- **Document file-table references.** RFCs, milestone docs, and READMEs
  often list relative paths like `persona/foo.json`. These need the new
  prefix when the parent directory changes.
- **Handle the git repo.** If the old directory was tracked by git, the
  moves are tracked as renames if git detects similarity. After moving,
  run `git status` and `git add` the new structure. The old files remain
  in git history — they're just at a new path.
- **One move, not two.** Don't copy-then-delete. Use `mv` directly to move
  files; it's atomic on the same filesystem and preserves git metadata.
- **Verify with ls/find.** After all mv commands, run `find /new-root -type f`
  to confirm every file landed where expected.
